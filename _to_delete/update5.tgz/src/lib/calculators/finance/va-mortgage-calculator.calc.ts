import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct } from '../format';
import { VA_SOURCE, vaFundingFee } from '../data/us-loans';
import meta from './va-mortgage-calculator.meta';

function payment(p: number, annualPct: number, n: number): number {
	const r = annualPct / 100 / 12;
	if (r === 0) return p / n;
	const f = Math.pow(1 + r, n);
	return (p * r * f) / (f - 1);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'price', label: 'Home price', type: 'number', default: 400000, min: 1000, max: 10_000_000, prefix: '$' },
		{ id: 'down', label: 'Down payment', type: 'number', default: 0, min: 0, max: 99, step: 0.5, suffix: '%', help: 'VA loans allow 0% down' },
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 6, min: 0, max: 20, step: 0.01, suffix: '%' },
		{
			id: 'term',
			label: 'Loan term',
			type: 'select',
			display: 'segmented',
			default: '30',
			options: [
				{ label: '30 yr', value: '30' },
				{ label: '20 yr', value: '20' },
				{ label: '15 yr', value: '15' }
			]
		},
		{
			id: 'use',
			label: 'VA loan use',
			type: 'select',
			display: 'segmented',
			default: 'first',
			options: [
				{ label: 'First use', value: 'first' },
				{ label: 'Used before', value: 'subsequent' },
				{ label: 'Exempt', value: 'exempt' }
			],
			help: 'Exempt: e.g. receiving VA disability compensation, Purple Heart recipients'
		},
		{ id: 'tax', label: 'Property tax', type: 'number', default: 4800, min: 0, max: 200_000, prefix: '$', suffix: '/yr', width: 'half' },
		{ id: 'ins', label: 'Home insurance', type: 'number', default: 1500, min: 0, max: 100_000, prefix: '$', suffix: '/yr', width: 'half' }
	],
	calculate(v): CalculationResult {
		const price = Number(v.price);
		const down = Number(v.down) / 100;
		const rate = Number(v.rate);
		const years = Number(v.term);
		const tax = Number(v.tax) || 0;
		const ins = Number(v.ins) || 0;
		if (!(price > 0) || !(down >= 0 && down < 1) || !(rate >= 0 && rate <= 30) || ![15, 20, 30].includes(years)) {
			return { primaryResult: DASH, primaryLabel: 'Monthly payment', summary: 'Check the price, down payment and rate.' };
		}
		const base = price * (1 - down);
		const feeRate = v.use === 'exempt' ? 0 : vaFundingFee(down, v.use !== 'subsequent');
		const fee = base * feeRate;
		const loan = base + fee; // funding fee is usually financed
		const pi = payment(loan, rate, years * 12);
		const total = pi + tax / 12 + ins / 12;

		return {
			primaryResult: money(total),
			primaryLabel: 'Estimated monthly payment',
			summary: feeRate === 0 ? 'No funding fee: exempt borrower. VA loans have no monthly mortgage insurance.' : `Funding fee ${pct(feeRate * 100, 2)} financed into the loan. VA loans have no monthly mortgage insurance.`,
			secondaryMetrics: [
				{ label: 'Principal & interest', value: money(pi) },
				{ label: 'Property tax', value: money(tax / 12) },
				{ label: 'Home insurance', value: money(ins / 12) },
				{ label: 'Down payment', value: money(price * down, true) },
				{ label: `VA funding fee (${pct(feeRate * 100, 2)})`, value: money(fee, true) },
				{ label: 'Total loan amount', value: money(loan, true) }
			]
		};
	},
	content: {
		intro:
			'Estimate the monthly payment on a VA home loan, including the one-time VA funding fee, which depends on your down payment and whether you have used your VA loan benefit before.',
		howTo: [
			'Enter the home price and down payment (0% is allowed).',
			'Enter the rate and pick a term.',
			'Choose first use, later use, or exempt from the funding fee.',
			'Add property tax and insurance, then read your payment.'
		],
		formulas: [
			{
				title: 'VA funding fee (purchase loans)',
				expression: 'Down < 5%: 2.15% first use, 3.3% after first use\nDown 5% to < 10%: 1.5%\nDown 10% or more: 1.25%',
				variables: []
			},
			{
				title: 'Payment',
				expression: 'P&I on (price − down + funding fee) + tax ÷ 12 + insurance ÷ 12',
				variables: []
			}
		],
		example: {
			title: '$400,000 home, 0% down, first use, 6%, 30 years',
			steps: [
				'Funding fee: $400,000 × 2.15% = $8,600',
				'Loan: $400,000 + $8,600 = $408,600',
				'Principal & interest at 6% for 30 years: $2,449.76',
				'Plus $4,800 ÷ 12 tax and $1,500 ÷ 12 insurance = $525'
			],
			result: 'About $2,974.76 a month.'
		},
		faq: [
			{
				q: 'Who is exempt from the VA funding fee?',
				a: 'Veterans receiving (or eligible for) VA disability compensation, Purple Heart recipients on active duty, and eligible surviving spouses, among others. Your Certificate of Eligibility shows your status.'
			},
			{
				q: 'Do VA loans have mortgage insurance?',
				a: 'No. VA loans don’t charge monthly mortgage insurance. The one-time funding fee helps fund the program instead.'
			},
			{
				q: 'Can I pay the funding fee upfront?',
				a: 'Yes. You can pay it at closing or add it to the loan. This calculator assumes it is added to the loan.'
			}
		],
		sources: [VA_SOURCE],
		disclaimer: 'Estimates only. Your lender and the VA confirm eligibility, the funding fee and the final terms.'
	}
});
