import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, money, num, pct } from '../format';
import { CPI_ANNUAL, CPI_FIRST_YEAR, CPI_LAST_YEAR, CPI_LATEST } from '../data/cpi';
import meta from './inflation-calculator.meta';

const mode = (m: string) => (v: InputValues) => v.mode === m;
const latestLabel = new Date(`${CPI_LATEST.month}-01T00:00:00Z`).toLocaleDateString('en-US', {
	month: 'long',
	year: 'numeric',
	timeZone: 'UTC'
});

/** CPI for a year, or the latest month for 'latest'. */
export function cpiFor(key: string | number): number | undefined {
	if (key === 'latest') return CPI_LATEST.index;
	return CPI_ANNUAL[Number(key)];
}

const yearOptions = [
	{ label: `Today (${latestLabel})`, value: 'latest' },
	...Object.keys(CPI_ANNUAL)
		.map(Number)
		.sort((a, b) => b - a)
		.map((y) => ({ label: String(y), value: String(y) }))
];

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'What do you want to know?',
			type: 'select',
			display: 'segmented',
			default: 'cpi',
			options: [
				{ label: 'Past value (US CPI)', value: 'cpi' },
				{ label: 'Future cost at a rate', value: 'rate' }
			]
		},
		{ id: 'amount', label: 'Amount', type: 'number', default: 100, min: 0, max: 1e12, prefix: '$' },
		{
			id: 'from',
			label: 'In the year',
			type: 'select',
			display: 'menu',
			default: '2000',
			options: yearOptions.filter((o) => o.value !== 'latest'),
			visibleWhen: mode('cpi')
		},
		{ id: 'to', label: 'Is worth in', type: 'select', display: 'menu', default: 'latest', options: yearOptions, visibleWhen: mode('cpi') },
		{ id: 'rate', label: 'Inflation rate', type: 'number', default: 3, min: -10, max: 50, step: 0.1, suffix: '% / yr', visibleWhen: mode('rate') },
		{ id: 'years', label: 'Years from now', type: 'number', default: 10, min: 1, max: 100, decimal: false, suffix: 'years', visibleWhen: mode('rate') }
	],
	calculate(v): CalculationResult {
		const amount = Number(v.amount);
		if (!Number.isFinite(amount) || amount < 0) return { primaryResult: DASH, primaryLabel: 'Equivalent value', summary: 'Enter an amount.' };

		if (v.mode === 'rate') {
			const r = Number(v.rate) / 100;
			const n = Number(v.years);
			if (!Number.isFinite(r) || !(n >= 1 && n <= 100)) return { primaryResult: DASH, primaryLabel: 'Future cost', summary: 'Enter a rate and a number of years.' };
			const future = amount * Math.pow(1 + r, n);
			const power = amount / Math.pow(1 + r, n);
			return {
				primaryResult: money(future),
				primaryLabel: `Cost in ${num(n, 0)} years`,
				summary: `${money(amount)} × (1 + ${num(r * 100, 2)}%)^${num(n, 0)}.`,
				secondaryMetrics: [
					{ label: 'Total price increase', value: pct((future / amount - 1) * 100, 2) },
					{ label: `Buying power of ${money(amount, true)} then`, value: money(power) },
					{ label: 'Money lost to inflation', value: money(amount - power) }
				]
			};
		}

		const a = cpiFor(String(v.from));
		const b = cpiFor(String(v.to));
		if (!a || !b) return { primaryResult: DASH, primaryLabel: 'Equivalent value', summary: `Pick years from ${CPI_FIRST_YEAR} to ${CPI_LAST_YEAR}.` };
		const value = (amount * b) / a;
		const fromYear = Number(v.from);
		const toYear = v.to === 'latest' ? Number(CPI_LATEST.month.slice(0, 4)) + (Number(CPI_LATEST.month.slice(5)) - 0.5) / 12 : Number(v.to) + 0.5;
		const years = toYear - (fromYear + 0.5);
		const cagr = years > 0 ? (Math.pow(b / a, 1 / years) - 1) * 100 : NaN;
		const toLabel = v.to === 'latest' ? latestLabel : String(v.to);
		return {
			primaryResult: money(value),
			primaryLabel: `${money(amount)} in ${fromYear} is worth, in ${toLabel}`,
			summary: `${money(amount)} × CPI ${num(b, 3)} ÷ CPI ${num(a, 3)}.`,
			secondaryMetrics: [
				{ label: 'Cumulative inflation', value: pct((b / a - 1) * 100, 2) },
				{ label: 'Average yearly inflation', value: Number.isFinite(cagr) ? pct(cagr, 2) : '—' },
				{ label: `CPI ${fromYear}`, value: num(a, 3) },
				{ label: `CPI ${toLabel}`, value: num(b, 3) }
			]
		};
	},
	content: {
		intro:
			'Find out what an amount of money from any year since 1913 is worth today, using the official US Consumer Price Index, or project how prices grow at a rate you choose.',
		howTo: [
			'Choose past value (real CPI data) or future cost (your own rate).',
			'Enter the amount and pick the years.',
			'Read the equivalent value, the total inflation and the average yearly rate.'
		],
		formulas: [
			{
				title: 'Past value with CPI',
				expression: 'Value later = Amount × CPI(later) ÷ CPI(earlier)',
				variables: [{ symbol: 'CPI', meaning: 'Consumer Price Index for All Urban Consumers (CPI-U), annual average' }]
			},
			{
				title: 'Average yearly inflation',
				expression: 'rate = (CPI(later) ÷ CPI(earlier))^(1 ÷ years) − 1',
				variables: []
			},
			{ title: 'Future cost at a fixed rate', expression: 'Future cost = Amount × (1 + r)ⁿ', variables: [] }
		],
		example: {
			title: 'What $100 in 2000 is worth in 2024',
			steps: ['CPI 2000 (annual average) = 172.2', 'CPI 2024 (annual average) = 313.689', '$100 × 313.689 ÷ 172.2 = $182.17'],
			result: '$100 in 2000 had the same buying power as about $182.17 in 2024, an 82.2% rise in prices.'
		},
		faq: [
			{
				q: 'Which inflation data does this use?',
				a: 'The US Bureau of Labor Statistics CPI-U, the most widely quoted measure of US consumer inflation. Past years use annual averages; “today” uses the latest published month.'
			},
			{
				q: 'Why is 2025 marked as an 11-month average?',
				a: 'The Bureau of Labor Statistics did not publish October 2025 figures because of the federal government shutdown, so the 2025 average is based on the other 11 months.'
			},
			{
				q: 'Does this work for other countries?',
				a: 'The past-value mode uses US prices only. For other countries, use the future-cost mode with your country’s inflation rate, or your national statistics office’s calculator.'
			},
			{
				q: 'Why might my own costs have risen faster?',
				a: 'CPI tracks an average basket of goods. If you spend more on things that rose quickly, such as rent, insurance or tuition, your personal inflation rate can be higher.'
			}
		],
		sources: [{ title: 'U.S. Bureau of Labor Statistics — Consumer Price Index', url: 'https://www.bls.gov/cpi/' }],
		disclaimer: 'Estimates based on national averages. Prices for specific goods and places can differ.'
	}
});
