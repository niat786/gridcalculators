import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, pct } from '../format';
import { FHA_MIN_DOWN, FHA_MIP_THRESHOLD, FHA_SOURCE, FHA_UFMIP, fhaAnnualMip } from '../data/us-loans';
import meta from './fha-loan-calculator.meta';

function payment(p: number, annualPct: number, n: number): number {
	const r = annualPct / 100 / 12;
	if (r === 0) return p / n;
	const f = Math.pow(1 + r, n);
	return (p * r * f) / (f - 1);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'price', label: 'Home price', type: 'number', default: 350000, min: 1000, max: 5_000_000, prefix: '$' },
		{ id: 'down', label: 'Down payment', type: 'number', default: 3.5, min: 3.5, max: 99, step: 0.5, suffix: '%', help: 'FHA minimum is 3.5% (credit score 580+)' },
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 6.25, min: 0, max: 20, step: 0.01, suffix: '%' },
		{
			id: 'term',
			label: 'Loan term',
			type: 'select',
			display: 'segmented',
			default: '30',
			options: [
				{ label: '30 yr', value: '30' },
				{ label: '20 yr', value: '20' },
				{ label: '15 yr', value: '15' }
			]
		},
		{ id: 'tax', label: 'Property tax', type: 'number', default: 4200, min: 0, max: 200_000, prefix: '$', suffix: '/yr', width: 'half' },
		{ id: 'ins', label: 'Home insurance', type: 'number', default: 1500, min: 0, max: 100_000, prefix: '$', suffix: '/yr', width: 'half' }
	],
	calculate(v): CalculationResult {
		const price = Number(v.price);
		const downPct = Number(v.down) / 100;
		const rate = Number(v.rate);
		const years = Number(v.term);
		const tax = Number(v.tax) || 0;
		const ins = Number(v.ins) || 0;
		if (!(price > 0) || !(downPct >= FHA_MIN_DOWN && downPct < 1) || !(rate >= 0 && rate <= 30) || ![15, 20, 30].includes(years)) {
			return { primaryResult: DASH, primaryLabel: 'Monthly payment', summary: 'FHA loans need at least 3.5% down.' };
		}
		const base = price * (1 - downPct);
		const ltv = base / price;
		const ufmip = base * FHA_UFMIP;
		const loan = base + ufmip; // UFMIP is usually financed into the loan
		const n = years * 12;
		const pi = payment(loan, rate, n);
		const mip = fhaAnnualMip(base, ltv, years);
		// Annual MIP is charged on the average outstanding balance; the first year ≈ base loan.
		const mipMonthly = (base * mip.rate) / 12;
		const total = pi + mipMonthly + tax / 12 + ins / 12;

		return {
			primaryResult: money(total),
			primaryLabel: 'Estimated monthly payment',
			summary: `Annual MIP ${pct(mip.rate * 100, 2)} ${mip.years === 'life' ? 'for the life of the loan' : 'for 11 years'}; upfront MIP financed into the loan.`,
			secondaryMetrics: [
				{ label: 'Principal & interest', value: money(pi) },
				{ label: 'Mortgage insurance (MIP)', value: money(mipMonthly) },
				{ label: 'Property tax', value: money(tax / 12) },
				{ label: 'Home insurance', value: money(ins / 12) },
				{ label: 'Down payment', value: money(price * downPct, true) },
				{ label: 'Upfront MIP (1.75%)', value: money(ufmip, true) },
				{ label: 'Total loan amount', value: money(loan, true) }
			]
		};
	},
	content: {
		intro:
			'Estimate a monthly FHA mortgage payment, including the upfront and annual mortgage insurance premiums (MIP) that every FHA loan carries, using HUD’s current premium chart.',
		howTo: [
			'Enter the home price and your down payment (at least 3.5%).',
			'Enter the interest rate and pick a term.',
			'Add yearly property tax and home insurance.',
			'Read your total payment and how long the mortgage insurance lasts.'
		],
		formulas: [
			{
				title: 'Upfront MIP',
				expression: 'UFMIP = base loan × 1.75%   (added to the loan)',
				variables: [{ symbol: 'base loan', meaning: 'home price − down payment' }]
			},
			{
				title: 'Annual MIP (terms over 15 years)',
				expression: `Loans ≤ $${num(FHA_MIP_THRESHOLD, 0)}: 0.50% (≤ 95% LTV) or 0.55% (> 95% LTV)\nLarger loans: 0.70% or 0.75%`,
				variables: []
			},
			{
				title: 'Annual MIP (terms of 15 years or less)',
				expression: 'Loans ≤ $726,200: 0.15% (≤ 90% LTV) or 0.40% (> 90% LTV)',
				variables: []
			},
			{
				title: 'Monthly payment',
				expression: 'P&I on (base loan + UFMIP) + base loan × annual MIP ÷ 12 + tax ÷ 12 + insurance ÷ 12',
				variables: []
			}
		],
		example: {
			title: '$350,000 home, 3.5% down, 6.25%, 30 years',
			steps: [
				'Base loan: $350,000 × 96.5% = $337,750',
				'Upfront MIP: $337,750 × 1.75% = $5,910.63 → loan $343,660.63',
				'Principal & interest at 6.25%: $2,115.98',
				'LTV 96.5% > 95% → annual MIP 0.55%: $337,750 × 0.55% ÷ 12 = $154.80'
			],
			result: 'About $2,270.78 a month before tax and insurance, or $2,745.78 with $4,200 tax and $1,500 insurance.'
		},
		faq: [
			{
				q: 'How long do I pay FHA mortgage insurance?',
				a: 'With 10% or more down, annual MIP ends after 11 years. With less than 10% down, it lasts for the life of the loan unless you refinance into a loan without it.'
			},
			{
				q: 'What is the minimum down payment for an FHA loan?',
				a: '3.5% with a credit score of 580 or higher. With a score between 500 and 579, FHA requires 10% down.'
			},
			{
				q: 'Can I pay the upfront MIP in cash?',
				a: 'Yes. It can be paid at closing or added to the loan; most borrowers finance it, which is what this calculator assumes.'
			},
			{
				q: 'Are there limits on how much I can borrow?',
				a: 'Yes. FHA loan limits vary by county and are updated every year. Check HUD’s FHA mortgage limits lookup for your area.'
			}
		],
		sources: [FHA_SOURCE],
		disclaimer: 'Estimates only. Your lender confirms the final rate, premiums, loan limits and fees.'
	}
});
