import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num } from '../format';
import { growIra, rothAllowed } from '../data/ira-math';
import { IRS_LIMITS_SOURCE, limitIra, RETIREMENT_TAX_YEAR, ROTH_PHASEOUT } from '../data/us-retirement';
import meta from './roth-ira-calculator.meta';

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'status',
			label: 'Filing status',
			type: 'select',
			display: 'menu',
			default: 'single',
			options: Object.entries(ROTH_PHASEOUT).map(([value, p]) => ({ value, label: p.label }))
		},
		{ id: 'magi', label: 'Modified adjusted gross income', type: 'number', default: 90000, min: 0, max: 100_000_000, prefix: '$' },
		{ id: 'age', label: 'Current age', type: 'number', default: 30, min: 18, max: 90, decimal: false, suffix: 'years', width: 'half' },
		{ id: 'retire', label: 'Retirement age', type: 'number', default: 65, min: 19, max: 100, decimal: false, suffix: 'years', width: 'half' },
		{ id: 'balance', label: 'Current Roth balance', type: 'number', default: 5000, min: 0, max: 100_000_000, prefix: '$' },
		{ id: 'contrib', label: 'Yearly contribution you want', type: 'number', default: 7500, min: 0, max: 100_000, prefix: '$' },
		{ id: 'ret', label: 'Expected return', type: 'number', default: 7, min: -10, max: 20, step: 0.1, suffix: '% / yr' }
	],
	calculate(v): CalculationResult {
		const age = Number(v.age);
		const retire = Number(v.retire);
		const magi = Number(v.magi);
		const r = Number(v.ret) / 100;
		const start = Number(v.balance);
		const wanted = Number(v.contrib);
		const status = String(v.status);
		if ([age, retire, magi, r, start, wanted].some((x) => !Number.isFinite(x)) || retire <= age || retire - age > 82 || !ROTH_PHASEOUT[status]) {
			return { primaryResult: DASH, primaryLabel: `Your ${RETIREMENT_TAX_YEAR} Roth IRA limit`, summary: 'Check your ages and income.' };
		}
		const allowedNow = rothAllowed(status, magi, age);
		const p = ROTH_PHASEOUT[status];
		const phase = magi <= p.from ? 'full' : magi >= p.to ? 'none' : 'partial';
		// Future years: same income (in today's terms) → same eligibility; limit grows with catch-up at 50.
		const yearly = (a: number) => Math.min(wanted, rothAllowed(status, magi, a));
		const grown = growIra(start, yearly, age, retire, r);

		return {
			primaryResult: money(allowedNow, true),
			primaryLabel: `Your ${RETIREMENT_TAX_YEAR} Roth IRA limit`,
			summary:
				phase === 'full'
					? `Your income is below ${money(p.from, true)}, so you can contribute the full ${money(limitIra(age), true)}.`
					: phase === 'none'
						? `Your income is above ${money(p.to, true)}, so you can’t contribute directly to a Roth IRA this year.`
						: `Your income is in the ${money(p.from, true)}–${money(p.to, true)} phase-out range, so your limit is reduced.`,
			secondaryMetrics: [
				{ label: `Balance at age ${retire} (tax-free)`, value: money(grown.balance, true) },
				{ label: 'Total you contribute', value: money(grown.put, true) },
				{ label: 'Tax-free growth', value: money(grown.balance - grown.put - start, true) },
				{ label: 'Phase-out range for you', value: `${money(p.from, true)} – ${money(p.to, true)}` }
			]
		};
	},
	content: {
		intro: `Check how much you can put into a Roth IRA for ${RETIREMENT_TAX_YEAR} under the IRS income limits, and see what your tax-free savings could grow to by retirement.`,
		howTo: [
			'Pick your tax filing status and enter your modified adjusted gross income (MAGI).',
			'Enter your age, retirement age, current Roth balance and how much you want to add each year.',
			'Read your allowed contribution and your projected tax-free balance.'
		],
		formulas: [
			{
				title: 'Reduced limit in the phase-out range',
				expression: 'limit × (1 − (MAGI − start) ÷ (end − start)), rounded up to the next $10, minimum $200',
				variables: []
			},
			{ title: 'Growth each year', expression: 'balance = balance × (1 + r) + contribution × (1 + r ÷ 2)', variables: [] }
		],
		example: {
			title: 'Single filer, age 30, MAGI $160,500',
			steps: [
				`Phase-out range: $153,000–$168,000 (width $15,000)`,
				'Into the range: $160,500 − $153,000 = $7,500, which is 50%',
				'$7,500 × (1 − 0.5) = $3,750'
			],
			result: 'The maximum Roth IRA contribution is $3,750 for 2026.'
		},
		faq: [
			{
				q: `What are the Roth IRA income limits for ${RETIREMENT_TAX_YEAR}?`,
				a: `Single filers can contribute the full amount with MAGI below $${num(ROTH_PHASEOUT.single.from, 0)}, a reduced amount up to $${num(ROTH_PHASEOUT.single.to, 0)}, and nothing above that. For married couples filing jointly the range is $${num(ROTH_PHASEOUT.mfj.from, 0)}–$${num(ROTH_PHASEOUT.mfj.to, 0)}.`
			},
			{
				q: 'What if my income is too high?',
				a: 'You can’t contribute directly, but many people use a “backdoor” Roth: a non-deductible Traditional IRA contribution converted to a Roth. It has tax rules worth checking with a professional first.'
			},
			{
				q: 'When can I withdraw from a Roth IRA tax-free?',
				a: 'Your contributions can come out at any time. Earnings are tax- and penalty-free once you are 59½ and the account has been open at least five years, with some exceptions.'
			},
			{
				q: 'Is the limit shared with my Traditional IRA?',
				a: 'Yes. The yearly limit covers all your IRAs combined, Traditional and Roth.'
			}
		],
		sources: [IRS_LIMITS_SOURCE, { title: 'IRS Publication 590-A: Contributions to IRAs', url: 'https://www.irs.gov/publications/p590a' }],
		disclaimer: 'Estimates only, not tax advice. Income limits change each year; confirm with the IRS or a tax professional.'
	}
});
