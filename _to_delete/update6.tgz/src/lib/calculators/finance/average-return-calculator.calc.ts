import { defineCalculator, type CalculationResult, type InputValues, type RowValue } from '../types';
import { DASH, money, num, pct, plural } from '../format';
import meta from './average-return-calculator.meta';

const mode = (m: string) => (v: InputValues) => v.mode === m;

const DEFAULT_RETURNS: RowValue[] = [
	{ label: 'Year 1', ret: 25 },
	{ label: 'Year 2', ret: -10 },
	{ label: 'Year 3', ret: 15 },
	{ label: 'Year 4', ret: 8 },
	{ label: 'Year 5', ret: -5 },
	{ label: 'Year 6', ret: 20 },
	{ label: 'Year 7', ret: 12 },
	{ label: 'Year 8', ret: 6 }
];

function invalid(summary: string): CalculationResult {
	return { primaryResult: DASH, primaryLabel: 'Annualized return', summary };
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Calculate from',
			type: 'select',
			display: 'segmented',
			default: 'edges',
			options: [
				{ label: 'Start and end value', value: 'edges' },
				{ label: 'Yearly returns', value: 'yearly' }
			]
		},
		{ id: 'start', label: 'Starting amount', type: 'number', default: 10000, min: 0.01, max: 1_000_000_000, step: 100, prefix: '$' },
		{
			id: 'end',
			label: 'Ending amount',
			type: 'number',
			default: 25000,
			min: 0,
			max: 1_000_000_000,
			step: 100,
			prefix: '$',
			visibleWhen: mode('edges')
		},
		{
			id: 'years',
			label: 'Number of years',
			type: 'number',
			default: 10,
			min: 0.1,
			max: 100,
			step: 1,
			suffix: 'years',
			help: 'Decimals are fine, such as 2.5.',
			visibleWhen: mode('edges')
		},
		{
			id: 'returns',
			label: 'Yearly returns',
			type: 'rows',
			columns: [
				{ id: 'label', label: 'Year', type: 'text', default: '', placeholder: 'Label' },
				{ id: 'ret', label: 'Return', type: 'number', default: 0, min: -99.99, max: 1000, suffix: '%' }
			],
			default: DEFAULT_RETURNS,
			minRows: 1,
			maxRows: 100,
			addLabel: 'Add year',
			help: 'Enter each year as a percentage. Use a minus sign for a loss.',
			visibleWhen: mode('yearly')
		}
	],
	calculate(v): CalculationResult {
		const start = Number(v.start);
		if (!Number.isFinite(start) || !(start > 0)) return invalid('Enter a starting amount above zero.');

		if (v.mode === 'yearly') {
			const rows = (v.returns as RowValue[]) ?? [];
			if (rows.length < 1) return invalid('Enter at least one yearly return.');
			const rets: number[] = [];
			for (const row of rows) {
				const r = Number(row.ret);
				if (!Number.isFinite(r) || r <= -100) return invalid('Enter a return for every year, above −100%.');
				rets.push(r);
			}
			const n = rets.length;
			const arithmetic = rets.reduce((s, r) => s + r, 0) / n;
			const growth = rets.reduce((g, r) => g * (1 + r / 100), 1);
			const annualized = (Math.pow(growth, 1 / n) - 1) * 100;
			const endAmount = start * growth;
			const gap = Math.abs(arithmetic - annualized) < 1e-9 ? 0 : arithmetic - annualized;
			let value = start;
			const table = {
				title: 'Value at the end of each year',
				collapsed: false,
				columns: [
					{ key: 'year', label: 'Year' },
					{ key: 'ret', label: 'Return', align: 'end' as const },
					{ key: 'value', label: 'Value', align: 'end' as const }
				],
				rows: rets.map((r, i) => {
					value *= 1 + r / 100;
					return { year: String(rows[i].label || `Year ${i + 1}`), ret: pct(r, 2), value: money(value) };
				})
			};
			return {
				primaryResult: pct(annualized, 2),
				primaryLabel: 'Annualized return (geometric mean)',
				summary: `The simple average is ${pct(arithmetic, 2)}, but your money grew at ${pct(annualized, 2)} a year. Averaging overstates it.`,
				secondaryMetrics: [
					{ label: 'Arithmetic mean (simple average)', value: pct(arithmetic, 2) },
					{ label: 'Overstatement from averaging', value: `${num(gap, 2)} points` },
					{ label: 'Total return', value: pct((growth - 1) * 100, 2) },
					{ label: 'Ending amount', value: money(endAmount) },
					{ label: 'Years', value: plural(n, 'year') }
				],
				table
			};
		}

		const end = Number(v.end);
		const years = Number(v.years);
		if (!Number.isFinite(end) || end < 0) return invalid('Enter an ending amount of zero or more.');
		if (!Number.isFinite(years) || !(years > 0 && years <= 100)) return invalid('Enter a number of years above zero, up to 100.');

		const ratio = end / start;
		const cagr = (Math.pow(ratio, 1 / years) - 1) * 100;
		const total = (ratio - 1) * 100;
		const word = end >= start ? 'grew' : 'fell';
		return {
			primaryResult: pct(cagr, 2),
			primaryLabel: 'Annualized return (CAGR)',
			summary: `Your money ${word} ${pct(Math.abs(total), 2)} in total, which is ${pct(cagr, 2)} a year on average.`,
			secondaryMetrics: [
				{ label: 'Total return', value: pct(total, 2) },
				{ label: 'Total gain', value: money(end - start) },
				{ label: 'Growth multiple', value: `${num(ratio, 3)}×` },
				{ label: 'Ending amount', value: money(end) },
				{ label: 'Years', value: `${num(years, 2)} years` }
			]
		};
	},
	content: {
		intro:
			'Work out the average yearly return on an investment in two ways. Use a start and end value for the compound annual growth rate, or a list of yearly returns for the true annualized figure.',
		howTo: [
			'Choose whether you have a start and end value or a list of yearly returns.',
			'Enter your starting amount. For start and end values, add the ending amount and the number of years.',
			'For yearly returns, enter each year as a percentage. Use a minus sign for a loss.',
			'Read the annualized return and, for yearly returns, compare it with the simple average.'
		],
		formulas: [
			{
				title: 'Compound annual growth rate (CAGR)',
				expression: 'CAGR = (End ÷ Start)^(1 ÷ years) − 1',
				variables: [
					{ symbol: 'Start', meaning: 'value at the beginning' },
					{ symbol: 'End', meaning: 'value at the end' },
					{ symbol: 'years', meaning: 'length of time, in years' }
				]
			},
			{
				title: 'Yearly returns',
				expression: 'Arithmetic mean = (r₁ + r₂ + … + rₙ) ÷ n\nAnnualized = [(1 + r₁)(1 + r₂)…(1 + rₙ)]^(1 ÷ n) − 1',
				variables: [
					{ symbol: 'rₜ', meaning: 'return in year t, as a decimal' },
					{ symbol: 'n', meaning: 'number of years' }
				]
			},
			{
				title: 'Total return',
				expression: 'Total return = End ÷ Start − 1',
				variables: []
			}
		],
		example: {
			title: 'Eight years of yearly returns on 10,000',
			steps: [
				'Growth factors: 1.25 × 0.90 × 1.15 × 1.08 × 0.95 × 1.20 × 1.12 × 1.06 ≈ 1.891049',
				'Arithmetic mean: (25 − 10 + 15 + 8 − 5 + 20 + 12 + 6) ÷ 8 = 71 ÷ 8 = 8.88%',
				'Annualized return: 1.891049^(1 ÷ 8) − 1 ≈ 8.29%',
				'Ending amount: 10,000 × 1.891049 = $18,910.49'
			],
			result:
				'The arithmetic mean is 8.88%, but the annualized return is 8.29%. The 10,000 grows to $18,910.49.'
		},
		faq: [
			{
				q: 'Why is the arithmetic average higher than the real return?',
				a: 'A loss takes a bigger share of your balance than a gain of the same size gives back. A 50% fall needs a 100% gain to recover, so the simple average of swings lands above what your money actually earned.'
			},
			{
				q: 'Which figure should I use to compare investments?',
				a: 'Use the annualized return (CAGR or the geometric mean). It matches the change in your balance over time, so it is the fair figure to compare funds or savings products.'
			},
			{
				q: 'Does this include fees or taxes?',
				a: 'No. Enter returns after the costs you care about. Fees and taxes lower the real return, so subtract them first if you want the net figure.'
			},
			{
				q: 'Can I use a start and end value over a fractional number of years?',
				a: 'Yes. Enter a decimal such as 2.5 years. The calculator uses the exact exponent, so the result is the constant yearly rate that links the two values.'
			}
		],
		sources: [
			{
				title: 'U.S. Securities and Exchange Commission, Investor.gov',
				url: 'https://www.investor.gov/'
			}
		],
		disclaimer:
			'Past returns do not guarantee future results. These figures are estimates from the numbers you enter, not investment advice.'
	}
});
