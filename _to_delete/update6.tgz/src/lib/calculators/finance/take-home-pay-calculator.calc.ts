import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct } from '../format';
import {
	ADDL_MEDICARE_THRESHOLD,
	FILING_LABEL,
	FILING_OPTIONS,
	federalTax,
	fica,
	IRS_TAX_SOURCE,
	SS_WAGE_BASE,
	TAX_YEAR,
	type FilingStatus
} from '../data/us-tax-2026';
import meta from './take-home-pay-calculator.meta';

const PERIODS: Record<string, { label: string; n: number }> = {
	weekly: { label: 'Weekly', n: 52 },
	biweekly: { label: 'Every two weeks', n: 26 },
	semimonthly: { label: 'Twice a month', n: 24 },
	monthly: { label: 'Monthly', n: 12 },
	annual: { label: 'Yearly', n: 1 }
};

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'salary', label: 'Annual salary', type: 'number', default: 75000, min: 0, max: 50_000_000, prefix: '$' },
		{
			id: 'period',
			label: 'Pay frequency',
			type: 'select',
			default: 'biweekly',
			display: 'menu',
			options: Object.entries(PERIODS).map(([value, p]) => ({ label: p.label, value }))
		},
		{ id: 'status', label: 'Filing status', type: 'select', default: 'single', display: 'menu', options: FILING_OPTIONS },
		{ id: 'k401', label: 'Pre-tax 401(k)', type: 'number', default: 5, min: 0, max: 100, step: 0.5, suffix: '% of pay', width: 'half' },
		{ id: 'health', label: 'Pre-tax benefits', type: 'number', default: 0, min: 0, max: 1_000_000, prefix: '$', suffix: '/ yr', width: 'half', help: 'Health premiums, HSA, FSA (section 125)' },
		{ id: 'kids', label: 'Children under 17', type: 'number', default: 0, min: 0, max: 15, decimal: false, width: 'half' },
		{ id: 'state', label: 'State income tax', type: 'number', default: 0, min: 0, max: 15, step: 0.1, suffix: '%', width: 'half', help: 'Your state’s average rate. 0% in states with no wage tax (e.g. TX, FL)' }
	],
	calculate(v): CalculationResult {
		const salary = Number(v.salary);
		const period = PERIODS[String(v.period)];
		const status = String(v.status) as FilingStatus;
		const k401 = Number(v.k401) / 100;
		const health = Number(v.health);
		const kids = Number(v.kids);
		const stateRate = Number(v.state) / 100;
		if (!period || !(status in FILING_LABEL) || [salary, k401, health, kids, stateRate].some((x) => !Number.isFinite(x) || x < 0)) {
			return { primaryResult: DASH, primaryLabel: 'Take-home pay', summary: 'Enter your salary and pay details.' };
		}
		// 401(k) deferrals are capped by the IRS limit ($24,500 under 50 in 2026).
		const deferral = Math.min(salary * k401, 24_500);
		if (deferral + health > salary) {
			return { primaryResult: DASH, primaryLabel: 'Take-home pay', summary: 'Pre-tax deductions can’t be more than your salary.' };
		}
		// 401(k) is exempt from income tax but not FICA; section 125 benefits are exempt from both.
		const fed = federalTax({ status, income: salary, adjustments: deferral + health, itemized: 0, seniors: 0, children: kids, earned: salary - health });
		const fedTax = Math.max(0, fed.tax); // the refundable credit comes at filing, not in each paycheck
		const payroll = fica(salary - health, status);
		const stateTax = Math.max(0, salary - deferral - health) * stateRate;
		const net = salary - deferral - health - fedTax - payroll.total - stateTax;
		const per = (x: number) => money(x / period.n);
		const totalTax = fedTax + payroll.total + stateTax;
		return {
			primaryResult: per(net),
			primaryLabel: `Take-home pay (${period.label.toLowerCase()})`,
			summary: `${money(net, true)} a year after ${pct(salary > 0 ? (totalTax / salary) * 100 : 0, 1)} of your pay goes to taxes.`,
			secondaryMetrics: [
				{ label: 'Federal income tax', value: per(fedTax) },
				{ label: 'Social Security (6.2%)', value: per(payroll.ss) },
				{ label: 'Medicare (1.45%+)', value: per(payroll.medicare + payroll.addl) },
				{ label: 'State income tax', value: per(stateTax) },
				{ label: '401(k) contribution', value: per(deferral) },
				{ label: 'Pre-tax benefits', value: per(health) },
				{ label: 'Gross pay', value: per(salary) }
			],
			table: {
				title: `Your pay for ${TAX_YEAR} (${FILING_LABEL[status]})`,
				columns: [
					{ key: 'item', label: 'Item' },
					{ key: 'period', label: period.label, align: 'end' },
					{ key: 'year', label: 'Yearly', align: 'end' }
				],
				rows: [
					['Gross pay', salary],
					['401(k)', -deferral],
					['Pre-tax benefits', -health],
					['Federal income tax', -fedTax],
					['Social Security', -payroll.ss],
					['Medicare', -(payroll.medicare + payroll.addl)],
					['State income tax', -stateTax],
					['Take-home pay', net]
				].map(([item, x]) => ({ item: String(item), period: per(Number(x)), year: money(Number(x)) }))
			}
		};
	},
	content: {
		intro: `Estimate your US paycheck after ${TAX_YEAR} federal income tax, Social Security, Medicare, a state income tax rate and pre-tax deductions such as your 401(k).`,
		howTo: [
			'Enter your annual salary and how often you are paid.',
			'Choose your filing status and add children under 17 for the child tax credit.',
			'Add your 401(k) percentage and any pre-tax health or HSA deductions.',
			'Enter your state’s income tax rate (0% if your state has none).'
		],
		formulas: [
			{
				title: 'Take-home pay',
				expression: 'Net = Gross − 401(k) − Benefits − Federal tax − Social Security − Medicare − State tax',
				variables: [
					{ symbol: 'Federal tax', meaning: `${TAX_YEAR} brackets on (Gross − 401(k) − Benefits − standard deduction), minus the child tax credit` },
					{ symbol: 'Social Security', meaning: `6.2% of wages up to ${money(SS_WAGE_BASE, true)}` },
					{ symbol: 'Medicare', meaning: `1.45% of all wages, plus 0.9% above ${money(ADDL_MEDICARE_THRESHOLD.single, true)} (${money(ADDL_MEDICARE_THRESHOLD.mfj, true)} joint)` },
					{ symbol: 'State tax', meaning: 'your rate × (Gross − 401(k) − Benefits); a simple flat estimate' }
				]
			}
		],
		example: {
			title: '$75,000 salary, single, 5% to a 401(k), paid every two weeks, no state tax',
			steps: [
				'401(k): $3,750 a year. Taxable income: $75,000 − $3,750 − $16,100 = $55,150',
				'Federal tax: $1,240 + $4,560 + 22% × $4,750 = $6,845',
				'Social Security $4,650 and Medicare $1,087.50',
				'Net: $75,000 − $3,750 − $6,845 − $4,650 − $1,087.50 = $58,667.50 a year'
			],
			result: 'Take-home pay: $2,256.44 every two weeks.'
		},
		faq: [
			{
				q: 'Why is my real paycheck slightly different?',
				a: 'Employers withhold using the IRS percentage tables and your W-4, which can differ a little from your actual yearly tax. Local taxes, state disability insurance and after-tax deductions also change the number.'
			},
			{
				q: 'Which states have no income tax on wages?',
				a: 'Alaska, Florida, Nevada, New Hampshire, South Dakota, Tennessee, Texas, Washington and Wyoming. Enter 0% for these.'
			},
			{
				q: `What is the Social Security wage base for ${TAX_YEAR}?`,
				a: `${money(SS_WAGE_BASE, true)}. You pay 6.2% on wages up to that amount and nothing on wages above it. Medicare has no cap.`
			},
			{
				q: 'Does a 401(k) lower my Social Security tax?',
				a: 'No. Traditional 401(k) contributions lower federal (and most state) income tax, but Social Security and Medicare are still taxed on them. Health premiums paid through a section 125 plan lower both.'
			}
		],
		sources: [
			IRS_TAX_SOURCE,
			{ title: 'SSA — Contribution and benefit base', url: 'https://www.ssa.gov/oact/cola/cbb.html' }
		],
		disclaimer: 'An estimate for wage income using a flat state rate. Your W-4, local taxes and employer withholding tables can change your actual paycheck. Not tax advice.'
	}
});
