import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct } from '../format';
import meta from './estate-tax-calculator.meta';

/** Basic exclusion amount for deaths in 2026 (OBBBA; Rev. Proc. 2025-32). */
export const EXEMPTION_2026 = 15_000_000;
export const ANNUAL_GIFT_EXCLUSION_2026 = 19_000;

/** IRC §2001(c) rate schedule: [over, base tax, rate]. */
const SCHEDULE: [number, number, number][] = [
	[0, 0, 0.18],
	[10_000, 1_800, 0.2],
	[20_000, 3_800, 0.22],
	[40_000, 8_200, 0.24],
	[60_000, 13_000, 0.26],
	[80_000, 18_200, 0.28],
	[100_000, 23_800, 0.3],
	[150_000, 38_800, 0.32],
	[250_000, 70_800, 0.34],
	[500_000, 155_800, 0.37],
	[750_000, 248_300, 0.39],
	[1_000_000, 345_800, 0.4]
];
export function tentativeTax(amount: number): number {
	if (amount <= 0) return 0;
	let row = SCHEDULE[0];
	for (const r of SCHEDULE) if (amount > r[0]) row = r;
	return row[1] + (amount - row[0]) * row[2];
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'gross', label: 'Gross estate', type: 'number', default: 20_000_000, min: 0, max: 1e12, prefix: '$', help: 'Everything owned at death: property, investments, retirement accounts, life insurance you owned' },
		{ id: 'debts', label: 'Debts and expenses', type: 'number', default: 500_000, min: 0, max: 1e12, prefix: '$', help: 'Mortgages, loans, funeral and estate administration costs' },
		{ id: 'marital', label: 'Left to a US-citizen spouse', type: 'number', default: 0, min: 0, max: 1e12, prefix: '$' },
		{ id: 'charity', label: 'Left to charity', type: 'number', default: 0, min: 0, max: 1e12, prefix: '$' },
		{ id: 'gifts', label: 'Lifetime taxable gifts', type: 'number', default: 0, min: 0, max: 1e12, prefix: '$', help: 'Gifts above the yearly exclusion made since 1977' },
		{ id: 'dsue', label: 'Unused exemption from a late spouse', type: 'number', default: 0, min: 0, max: 15_000_000, prefix: '$', help: 'Portability (DSUE), if elected on their estate tax return' }
	],
	calculate(v): CalculationResult {
		const [gross, debts, marital, charity, gifts, dsue] = ['gross', 'debts', 'marital', 'charity', 'gifts', 'dsue'].map((k) => Number(v[k]));
		const label = 'Federal estate tax';
		if (![gross, debts, marital, charity, gifts, dsue].every((x) => Number.isFinite(x) && x >= 0)) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter the estate’s values.' };
		}
		const deductions = debts + marital + charity;
		if (deductions > gross) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Deductions can’t be more than the gross estate.' };
		}
		const taxable = gross - deductions;
		const base = taxable + gifts;
		const exemption = EXEMPTION_2026 + dsue;
		const tax = Math.max(0, tentativeTax(base) - tentativeTax(exemption));
		const left = exemption - base;
		return {
			primaryResult: money(tax, true),
			primaryLabel: label,
			summary:
				tax > 0
					? `${money(base - exemption, true)} is above the exemption and taxed at 40%.`
					: `No federal estate tax: ${money(left, true)} of exemption is left unused.`,
			secondaryMetrics: [
				{ label: 'Taxable estate', value: money(taxable, true) },
				{ label: 'Plus lifetime taxable gifts', value: money(base, true) },
				{ label: 'Exemption available', value: money(exemption, true) },
				{ label: 'Amount above exemption', value: money(Math.max(0, base - exemption), true) },
				{ label: 'Effective rate on gross estate', value: pct(gross > 0 ? (tax / gross) * 100 : 0, 2) },
				{ label: 'Left to heirs after tax', value: money(Math.max(0, gross - debts - charity - tax), true) }
			]
		};
	},
	content: {
		intro:
			'Estimate the US federal estate tax due on an estate for deaths in 2026, when the exemption is $15 million per person ($30 million for a married couple using portability). Amounts above the exemption are taxed at 40%.',
		howTo: [
			'Enter the gross estate: everything the person owned at death, at market value.',
			'Subtract debts, expenses, and anything left to a US-citizen spouse or to charity.',
			'Add lifetime taxable gifts, which use up part of the exemption.',
			'If a spouse died earlier and portability was elected, add their unused exemption.'
		],
		formulas: [
			{
				title: 'Federal estate tax',
				expression: 'Tax = Tentative tax(Taxable estate + Lifetime gifts) − Tentative tax(Exemption)',
				variables: [
					{ symbol: 'Taxable estate', meaning: 'Gross estate − Debts and expenses − Marital deduction − Charitable deduction' },
					{ symbol: 'Exemption', meaning: '$15,000,000 for 2026, plus any unused exemption from a late spouse (DSUE)' },
					{ symbol: 'Tentative tax', meaning: 'the §2001(c) rate schedule, 18% rising to 40% above $1 million' }
				]
			}
		],
		example: {
			title: 'A $20 million estate with $500,000 of debts and expenses',
			steps: ['Taxable estate: $20,000,000 − $500,000 = $19,500,000', 'Above the exemption: $19,500,000 − $15,000,000 = $4,500,000', 'Tax: $4,500,000 × 40% = $1,800,000'],
			result: 'Federal estate tax: $1,800,000.'
		},
		faq: [
			{
				q: 'What is the federal estate tax exemption for 2026?',
				a: '$15 million per person for deaths in 2026, made permanent and indexed for inflation from 2027 by the One, Big, Beautiful Bill Act. A married couple can shelter $30 million with portability.'
			},
			{
				q: 'Do heirs pay the estate tax?',
				a: 'No. The estate pays it before assets are passed on. A few states charge a separate inheritance tax that heirs pay, depending on their relationship to the person who died.'
			},
			{
				q: 'Do gifts during life reduce the exemption?',
				a: `Only gifts above the yearly exclusion (${money(ANNUAL_GIFT_EXCLUSION_2026, true)} per recipient in 2026). Gifts above it are reported on Form 709 and use up part of the lifetime exemption.`
			},
			{
				q: 'Does my state have an estate tax?',
				a: 'About a dozen states and Washington, D.C. have their own estate tax, often with much lower exemptions than the federal one. This calculator covers the federal tax only.'
			}
		],
		sources: [
			{ title: 'IRS — Estate tax', url: 'https://www.irs.gov/businesses/small-businesses-self-employed/estate-tax' },
			{ title: 'IRS — Tax inflation adjustments for tax year 2026', url: 'https://www.irs.gov/newsroom/irs-releases-tax-inflation-adjustments-for-tax-year-2026-including-amendments-from-the-one-big-beautiful-bill' }
		],
		disclaimer: 'A simplified estimate that ignores gift tax already paid, state taxes and valuation questions. Speak to an estate attorney or tax adviser before planning.'
	}
});
