import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money } from '../format';
import { federalTax, IRS_TAX_SOURCE, TAX_YEAR, type FilingStatus } from '../data/us-tax-2026';
import meta from './marriage-tax-calculator.meta';

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'a', label: 'Your income', type: 'number', default: 100000, min: 0, max: 100_000_000, prefix: '$', width: 'half' },
		{ id: 'b', label: 'Partner’s income', type: 'number', default: 20000, min: 0, max: 100_000_000, prefix: '$', width: 'half' },
		{ id: 'adjA', label: 'Your pre-tax contributions', type: 'number', default: 0, min: 0, max: 10_000_000, prefix: '$', width: 'half', help: '401(k), IRA, HSA' },
		{ id: 'adjB', label: 'Partner’s pre-tax contributions', type: 'number', default: 0, min: 0, max: 10_000_000, prefix: '$', width: 'half' },
		{ id: 'kids', label: 'Children under 17', type: 'number', default: 0, min: 0, max: 15, decimal: false },
		{
			id: 'claim',
			label: 'If unmarried, children are claimed by',
			type: 'select',
			default: 'a',
			display: 'segmented',
			options: [
				{ label: 'You', value: 'a' },
				{ label: 'Partner', value: 'b' }
			],
			visibleWhen: (v) => Number(v.kids) > 0
		}
	],
	calculate(v): CalculationResult {
		const a = Number(v.a);
		const b = Number(v.b);
		const adjA = Number(v.adjA);
		const adjB = Number(v.adjB);
		const kids = Number(v.kids);
		const label = 'Marriage penalty or bonus';
		if (![a, b, adjA, adjB, kids].every((x) => Number.isFinite(x) && x >= 0)) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter both incomes.' };
		}
		const claimA = String(v.claim) !== 'b';
		const one = (income: number, adj: number, children: number) => {
			const status: FilingStatus = children > 0 ? 'hoh' : 'single';
			return federalTax({ status, income, adjustments: Math.min(adj, income), itemized: 0, seniors: 0, children }).tax;
		};
		const taxA = one(a, adjA, claimA ? kids : 0);
		const taxB = one(b, adjB, claimA ? 0 : kids);
		const single = taxA + taxB;
		const joint = federalTax({ status: 'mfj', income: a + b, adjustments: Math.min(adjA, a) + Math.min(adjB, b), itemized: 0, seniors: 0, children: kids }).tax;
		const diff = joint - single;
		const fmt = (x: number) => (x < 0 ? `−${money(-x, true)}` : money(x, true));
		return {
			primaryResult: money(Math.abs(diff), true),
			primaryLabel: diff > 0.5 ? 'Marriage penalty' : diff < -0.5 ? 'Marriage bonus' : label,
			summary:
				diff > 0.5
					? `Filing jointly costs ${money(diff, true)} more in federal tax than filing as two unmarried people.`
					: diff < -0.5
						? `Filing jointly saves ${money(-diff, true)} in federal tax compared with filing as two unmarried people.`
						: 'Marriage makes no difference to your federal income tax.',
			secondaryMetrics: [
				{ label: 'Tax if married (jointly)', value: fmt(joint) },
				{ label: 'Tax if unmarried (total)', value: fmt(single) },
				{ label: `Your tax unmarried (${claimA && kids > 0 ? 'head of household' : 'single'})`, value: fmt(taxA) },
				{ label: `Partner’s tax unmarried (${!claimA && kids > 0 ? 'head of household' : 'single'})`, value: fmt(taxB) }
			]
		};
	},
	content: {
		intro: `Compare your ${TAX_YEAR} US federal income tax as a married couple filing jointly with what you would pay as two unmarried people, to see whether marriage creates a tax penalty or a bonus.`,
		howTo: [
			'Enter each partner’s yearly income.',
			'Add any pre-tax retirement or HSA contributions for each partner.',
			'Enter the number of children under 17 and who would claim them if you were not married.',
			'Read the penalty (you pay more married) or bonus (you pay less married).'
		],
		formulas: [
			{
				title: 'Marriage penalty or bonus',
				expression: 'Difference = Tax(joint return) − [Tax(you, unmarried) + Tax(partner, unmarried)]',
				variables: [
					{ symbol: 'Joint return', meaning: `${TAX_YEAR} married-filing-jointly brackets and $32,200 standard deduction on your combined income` },
					{ symbol: 'Unmarried', meaning: 'single brackets and $16,100 standard deduction, or head of household ($24,150) for the partner claiming the children' }
				]
			}
		],
		example: {
			title: 'One partner earns $100,000 and the other $20,000, no children',
			steps: [
				'Unmarried: $13,170 + $390 = $13,560',
				'Married: $120,000 − $32,200 = $87,800 taxable → $2,480 + $7,560 = $10,040',
				'Difference: $10,040 − $13,560 = −$3,520'
			],
			result: 'A marriage bonus of $3,520.'
		},
		faq: [
			{
				q: 'Why do some couples pay a marriage penalty?',
				a: 'Most joint brackets are exactly twice the single ones, so two similar incomes usually see no penalty. Penalties show up at the very top (the 37% joint bracket starts at $768,700, not twice $640,600), when an unmarried parent loses head-of-household status, or through credits that phase out on combined income.'
			},
			{
				q: 'Who gets a marriage bonus?',
				a: 'Couples with very different incomes. The higher earner’s income spreads across the wider joint brackets, so more of it is taxed at lower rates.'
			},
			{
				q: 'Can we file separately to avoid a penalty?',
				a: 'Married filing separately rarely helps: its brackets are half the joint ones and it blocks several credits and the senior deduction. It can make sense for income-driven student loan payments or to separate tax liability.'
			},
			{
				q: 'Does this include state tax or Social Security?',
				a: 'No. It compares federal income tax only. Payroll taxes are the same whether or not you are married.'
			}
		],
		sources: [IRS_TAX_SOURCE, { title: 'IRS — Publication 501, filing status', url: 'https://www.irs.gov/forms-pubs/about-publication-501' }],
		disclaimer: 'Uses the standard deduction and wage income only, and ignores state taxes and most credits. Not tax advice.'
	}
});
