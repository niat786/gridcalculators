import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct, plural } from '../format';
import meta from './real-estate-calculator.meta';

/** Fixed-rate monthly payment: M = P·r(1+r)^n / ((1+r)^n − 1); r = 0 → P / n; P = 0 → 0. */
function payment(principal: number, annualRatePct: number, months: number): number {
	if (principal <= 0) return 0;
	const r = annualRatePct / 1200;
	if (r === 0) return principal / months;
	const f = Math.pow(1 + r, months);
	return (principal * r * f) / (f - 1);
}

/** Net present value with the first flow at time 0 and each later flow one year further on. */
function npv(flows: number[], rate: number): number {
	let total = 0;
	for (let t = 0; t < flows.length; t++) total += flows[t] / Math.pow(1 + rate, t);
	return total;
}

/** Yearly IRR by bisection. Returns null when the flows never change sign. */
function irrOf(flows: number[]): number | null {
	let lo = -0.99;
	let hi = 10;
	let fLo = npv(flows, lo);
	const fHi = npv(flows, hi);
	if (!Number.isFinite(fLo) || !Number.isFinite(fHi) || (fLo > 0) === (fHi > 0)) return null;
	for (let i = 0; i < 300; i++) {
		const mid = (lo + hi) / 2;
		const fMid = npv(flows, mid);
		if (fMid === 0) return mid;
		if ((fMid > 0) === (fLo > 0)) {
			lo = mid;
			fLo = fMid;
		} else {
			hi = mid;
		}
	}
	return (lo + hi) / 2;
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'price', label: 'Purchase price', type: 'number', default: 300000, min: 0, max: 1_000_000_000, step: 1000, prefix: '$' },
		{ id: 'down', label: 'Down payment', type: 'number', default: 25, min: 0, max: 100, step: 0.5, suffix: '%' },
		{ id: 'rate', label: 'Mortgage interest rate', type: 'number', default: 6.5, min: 0, max: 30, step: 0.01, suffix: '%', help: 'Annual rate' },
		{ id: 'term', label: 'Loan term', type: 'number', default: 30, min: 1, max: 40, step: 1, suffix: 'years', decimal: false, width: 'half' },
		{ id: 'closing', label: 'Closing costs', type: 'number', default: 3, min: 0, max: 20, step: 0.1, suffix: '%', help: 'Share of the price, paid at purchase.', width: 'half' },
		{ id: 'rent', label: 'Monthly rent', type: 'number', default: 2800, min: 0, max: 1_000_000, step: 50, prefix: '$', suffix: '/mo' },
		{ id: 'rentGrowth', label: 'Rent increase per year', type: 'number', default: 3, min: -20, max: 30, step: 0.1, suffix: '%', width: 'half' },
		{ id: 'vacancy', label: 'Vacancy allowance', type: 'number', default: 5, min: 0, max: 100, step: 0.5, suffix: '%', help: 'Share of gross rent lost to empty months.', width: 'half' },
		{ id: 'expenses', label: 'Operating expenses', type: 'number', default: 35, min: 0, max: 100, step: 0.5, suffix: '%', help: 'Taxes, insurance, repairs and management, as a share of collected rent.' },
		{ id: 'appreciation', label: 'Property value growth per year', type: 'number', default: 3, min: -50, max: 50, step: 0.1, suffix: '%', width: 'half' },
		{ id: 'sellingCosts', label: 'Selling costs', type: 'number', default: 6, min: 0, max: 20, step: 0.1, suffix: '%', help: 'Share of the sale price.', width: 'half' },
		{ id: 'years', label: 'Years held', type: 'number', default: 10, min: 1, max: 40, step: 1, suffix: 'years', decimal: false }
	],
	calculate(v): CalculationResult {
		const price = Number(v.price);
		const downPct = Number(v.down);
		const rate = Number(v.rate);
		const term = Number(v.term);
		const closingPct = Number(v.closing);
		const rent = Number(v.rent);
		const rentGrowth = Number(v.rentGrowth);
		const vacancyPct = Number(v.vacancy);
		const expensePct = Number(v.expenses);
		const appreciation = Number(v.appreciation);
		const sellPct = Number(v.sellingCosts);
		const years = Number(v.years);
		const primaryLabel = 'Annualized return (IRR)';
		const invalid = (summary: string): CalculationResult => ({ primaryResult: DASH, primaryLabel, summary });

		if (
			!(price > 0) || !Number.isFinite(price) ||
			!(downPct >= 0 && downPct <= 100) ||
			!(rate >= 0 && rate <= 30) ||
			!Number.isInteger(term) || term < 1 || term > 40 ||
			!(closingPct >= 0 && closingPct <= 20) ||
			!(rent >= 0) ||
			!(rentGrowth > -100 && rentGrowth <= 100) ||
			!(vacancyPct >= 0 && vacancyPct <= 100) ||
			!(expensePct >= 0 && expensePct <= 100) ||
			!(appreciation > -100 && appreciation <= 100) ||
			!(sellPct >= 0 && sellPct <= 20) ||
			!Number.isInteger(years) || years < 1 || years > 40
		) {
			return invalid('Check the price, loan, rent, rates and holding period. Years held must be a whole number from 1 to 40.');
		}

		const loan = price * (1 - downPct / 100);
		const equity0 = (price * downPct) / 100 + (price * closingPct) / 100;
		if (!(equity0 > 0)) return invalid('Enter a down payment or closing costs above zero, so there is cash invested to measure a return on.');

		const monthly = payment(loan, rate, term * 12);
		const monthlyRate = rate / 1200;
		const loanMonths = term * 12;
		let balance = loan;
		const flows: number[] = [-equity0];
		const rows: Record<string, string>[] = [];
		let sumCoC = 0;

		for (let t = 1; t <= years; t++) {
			const gross = rent * 12 * Math.pow(1 + rentGrowth / 100, t - 1);
			const effective = gross * (1 - vacancyPct / 100);
			const operating = effective * (expensePct / 100);
			const noi = effective - operating;

			let debt = 0;
			for (let m = 0; m < 12; m++) {
				const month = (t - 1) * 12 + m + 1;
				if (month <= loanMonths && balance > 0) {
					const interest = balance * monthlyRate;
					const principal = Math.min(monthly - interest, balance);
					balance -= principal;
					debt += interest + principal;
				}
			}

			const cashFlow = noi - debt;
			const coc = cashFlow / equity0;
			sumCoC += coc;
			const value = price * Math.pow(1 + appreciation / 100, t);
			const equity = value * (1 - sellPct / 100) - balance;
			rows.push({
				year: String(t),
				cash: money(cashFlow),
				value: money(value),
				balance: money(Math.max(0, balance)),
				equity: money(equity),
				coc: pct(coc * 100, 2)
			});
			flows.push(cashFlow);
		}

		const finalValue = price * Math.pow(1 + appreciation / 100, years);
		const proceeds = finalValue * (1 - sellPct / 100) - balance;
		flows[years] += proceeds;

		const irr = irrOf(flows);
		if (irr === null) return invalid('The return could not be calculated from these inputs. Check the price, rent and loan.');

		const rawProfit = flows.slice(1).reduce((s, x) => s + x, 0) - equity0;
		const profit = Math.abs(rawProfit) < 0.005 ? 0 : rawProfit;
		const avgCoC = (sumCoC / years) * 100;

		// Anything smaller than the displayed precision is shown as exactly zero, never as −0%.
		const irrPct = Math.abs(irr * 100) < 0.005 ? 0 : irr * 100;

		return {
			primaryResult: pct(irrPct, 2),
			primaryLabel,
			summary: `Over ${plural(years, 'year')} the total ${profit >= 0 ? 'profit' : 'loss'} is ${money(Math.abs(profit))}, including the sale.`,
			secondaryMetrics: [
				{ label: 'Total profit', value: money(profit) },
				{ label: 'Equity at sale (after loan and selling costs)', value: money(proceeds) },
				{ label: 'Average cash-on-cash return', value: pct(avgCoC, 2) },
				{ label: 'Cash invested up front', value: money(equity0) },
				{ label: 'Monthly mortgage payment', value: money(monthly) }
			],
			table: {
				title: 'Year by year (sale proceeds are added in the last year for the IRR)',
				collapsed: false,
				columns: [
					{ key: 'year', label: 'Year' },
					{ key: 'cash', label: 'Cash flow', align: 'end' },
					{ key: 'value', label: 'Property value', align: 'end' },
					{ key: 'balance', label: 'Loan balance', align: 'end' },
					{ key: 'equity', label: 'Equity if sold', align: 'end' },
					{ key: 'coc', label: 'Cash-on-cash', align: 'end' }
				],
				rows
			}
		};
	},
	content: {
		intro:
			'Estimate the return on a rental property you buy, rent out and sell later. The calculator combines rent, vacancy, running costs, the mortgage and the sale price into one annualized return.',
		howTo: [
			'Enter the purchase price, down payment, mortgage rate, loan term and closing costs.',
			'Enter the monthly rent, how much you expect it to rise each year, and the vacancy allowance.',
			'Enter operating expenses, the yearly growth in property value, the selling costs and how many years you will hold the property.',
			'Read the annualized return (IRR), the total profit and the equity at sale, then open the year-by-year table.'
		],
		formulas: [
			{
				title: 'Cash invested and mortgage',
				expression: 'Loan = Price × (1 − Down ÷ 100)\nCash invested = Price × Down ÷ 100 + Price × Closing ÷ 100\nM = Loan × r(1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'r', meaning: 'monthly mortgage rate (annual rate ÷ 12 ÷ 100)' },
					{ symbol: 'n', meaning: 'number of monthly payments (loan term × 12)' }
				]
			},
			{
				title: 'Yearly cash flow',
				expression: 'Rent_t = Monthly rent × 12 × (1 + g)^(t − 1)\nNOI = Rent_t × (1 − Vacancy) × (1 − Expenses)\nCash flow_t = NOI − 12 × M (for years inside the loan term)',
				variables: [
					{ symbol: 'g', meaning: 'yearly rent increase, as a decimal' },
					{ symbol: 'NOI', meaning: 'net operating income, before the mortgage' }
				]
			},
			{
				title: 'Sale and annualized return',
				expression: 'Sale proceeds = Price × (1 + a)^Y × (1 − Selling costs ÷ 100) − Loan balance\nIRR: the rate r where Σ CFₜ ÷ (1 + r)ᵗ = 0',
				variables: [
					{ symbol: 'a', meaning: 'yearly property value growth, as a decimal' },
					{ symbol: 'Y', meaning: 'years held' }
				]
			},
			{
				title: 'Cash-on-cash return',
				expression: 'Cash-on-cash = Cash flow ÷ Cash invested up front',
				variables: []
			}
		],
		example: {
			title: 'A $300,000 rental with 25% down, rented at $2,800 a month and sold after 10 years',
			steps: [
				'Cash invested: 25% down ($75,000) plus 3% closing ($9,000) = $84,000. Loan: $225,000 at 6.5% over 30 years, so M ≈ $1,422.15',
				'Year 1 rent: 2,800 × 12 = $33,600, less 5% vacancy = $31,920, less 35% expenses = $20,748 of NOI',
				'Year 1 cash flow: 20,748 − 12 × 1,422.15 = 20,748 − 17,065.84 = $3,682.16',
				'Sale in year 10: value 300,000 × 1.03¹⁰ ≈ $403,174.91, less 6% selling costs = $378,984.42, less the loan balance of $190,746.28 = $188,238.13',
				'Total profit: all cash flows plus the sale, less the $84,000 invested, is $171,432.34. The IRR is 13.67%'
			],
			result:
				'Annualized return of 13.67%, a total profit of $171,432.34 and equity at sale of $188,238.13. The average cash-on-cash return is 8.00% a year.'
		},
		faq: [
			{
				q: 'What is the difference between IRR and cash-on-cash return?',
				a: 'Cash-on-cash measures one year of cash flow against the cash you put in. IRR also counts the sale and the timing of every cash flow, so it gives one annualized figure for the whole holding period.'
			},
			{
				q: 'Why is the vacancy allowance applied to rent before expenses?',
				a: 'Expenses are modelled as a share of the rent you actually collect. Vacancy reduces that collected rent first, so the expenses fall too.'
			},
			{
				q: 'Are taxes, insurance and maintenance included?',
				a: 'Only through the operating expenses percentage. Enter the total of taxes, insurance, repairs, management and similar running costs as a share of collected rent.'
			},
			{
				q: 'Does this account for income tax?',
				a: 'No. The figures are before income tax, depreciation and any tax on the sale. Those depend on where you live and your own tax position.'
			}
		],
		sources: [
			{
				title: 'Consumer Financial Protection Bureau',
				url: 'https://www.consumerfinance.gov/'
			}
		],
		disclaimer:
			'Estimates only. Rent, vacancy, costs, values and interest rates change, and this is not financial, tax or property advice.'
	}
});
