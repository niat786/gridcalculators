import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct } from '../format';
import meta from './mutual-fund-calculator.meta';

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'initial', label: 'Initial investment', type: 'number', default: 10000, min: 0, max: 100_000_000, step: 500, prefix: '$' },
		{ id: 'monthly', label: 'Monthly contribution', type: 'number', default: 300, min: 0, max: 1_000_000, step: 50, prefix: '$', suffix: '/mo' },
		{ id: 'years', label: 'Years invested', type: 'number', default: 20, min: 1, max: 60, step: 1, suffix: 'years', decimal: false },
		{ id: 'gross', label: 'Expected gross return', type: 'number', default: 7, min: -20, max: 30, step: 0.01, suffix: '%', help: 'Yearly return before fund costs.' },
		{ id: 'expense', label: 'Expense ratio', type: 'number', default: 0.75, min: 0, max: 10, step: 0.01, suffix: '%', help: 'Yearly running cost, taken from the fund’s assets.' },
		{ id: 'front', label: 'Front-end load', type: 'number', default: 5.75, min: 0, max: 10, step: 0.01, suffix: '%', help: 'Sales charge taken from each purchase.' },
		{ id: 'back', label: 'Back-end load', type: 'number', default: 0, min: 0, max: 10, step: 0.01, suffix: '%', help: 'Sales charge on the final value when you sell. Often zero.' }
	],
	calculate(v): CalculationResult {
		const initial = Number(v.initial);
		const monthly = Number(v.monthly);
		const years = Number(v.years);
		const gross = Number(v.gross);
		const expense = Number(v.expense);
		const front = Number(v.front);
		const back = Number(v.back);
		const primaryLabel = 'Final value after costs';

		if (
			!(initial >= 0) || !Number.isFinite(initial) ||
			!(monthly >= 0) || !Number.isFinite(monthly) ||
			!Number.isInteger(years) || years < 1 || years > 60 ||
			!(gross > -100 && gross <= 100) ||
			!(expense >= 0 && expense <= 10) ||
			!(front >= 0 && front <= 100) ||
			!(back >= 0 && back <= 100)
		) {
			return { primaryResult: DASH, primaryLabel, summary: 'Check each field. Years must be a whole number from 1 to 60.' };
		}

		const months = years * 12;
		const g = gross / 1200;
		const e = expense / 1200;
		const f = front / 100;

		// Costs: front-end load on every purchase, expense ratio on the balance each month.
		let balance = initial * (1 - f);
		let noFee = initial;
		let frontCharges = initial * f;
		let expenseCharges = 0;
		for (let m = 0; m < months; m++) {
			expenseCharges += balance * e;
			balance = balance * (1 + g - e) + monthly * (1 - f);
			noFee = noFee * (1 + g) + monthly;
			frontCharges += monthly * f;
		}

		const backCharge = (balance * back) / 100;
		const finalValue = balance - backCharge;
		const totalPaid = initial + monthly * months;
		const totalFees = frontCharges + expenseCharges + backCharge;
		const lost = Math.max(0, noFee - finalValue);
		const netReturn = gross - expense;

		return {
			primaryResult: money(finalValue),
			primaryLabel,
			summary: `After fees your investment is worth ${money(finalValue)}, ${money(lost)} less than a fund with no costs.`,
			secondaryMetrics: [
				{ label: 'Total you pay in', value: money(totalPaid) },
				{ label: 'Final value with no fees', value: money(noFee) },
				{ label: 'Total fees paid', value: money(totalFees) },
				{ label: 'Value lost to costs', value: money(lost) },
				{ label: 'Net return after expense ratio', value: pct(netReturn, 2) }
			]
		};
	},
	content: {
		intro:
			'See what fund costs do to your savings. Enter your contributions and the expected return, then add the expense ratio and any sales charges to see the final value and what the fees cost you.',
		howTo: [
			'Enter your initial investment and the monthly amount you add.',
			'Enter the number of years and the expected gross return before costs.',
			'Enter the expense ratio, the front-end load and any back-end load from the fund’s documents.',
			'Compare the final value after costs with the result for a fund that charges nothing.'
		],
		formulas: [
			{
				title: 'Front-end load',
				expression: 'Money invested = Payment × (1 − Front-end load ÷ 100)',
				variables: [{ symbol: 'Payment', meaning: 'the amount you pay in, including the sales charge' }]
			},
			{
				title: 'Monthly growth after the expense ratio',
				expression: 'B = B × (1 + (R − E) ÷ 1200) + C × (1 − L ÷ 100)',
				variables: [
					{ symbol: 'B', meaning: 'fund balance' },
					{ symbol: 'R', meaning: 'expected gross return, in percent a year' },
					{ symbol: 'E', meaning: 'expense ratio, in percent a year' },
					{ symbol: 'C', meaning: 'monthly contribution' },
					{ symbol: 'L', meaning: 'front-end load, in percent' }
				]
			},
			{
				title: 'Back-end load and total fees',
				expression: 'Final value = B × (1 − back-end load ÷ 100)\nTotal fees = Sales charges + Expense ratio charges + Back-end charge',
				variables: []
			}
		],
		example: {
			title: 'Starting with 10,000 and adding 300 a month for 20 years',
			steps: [
				'Gross return 7% and expense ratio 0.75%, so the net return is about 6.25% a year',
				'Front-end load 5.75%: the 10,000 start invests 9,425, and each 300 payment invests 282.75',
				'Final value after costs: $167,372.00',
				'Final value with no fees: $196,665.39, so costs take $29,293.39',
				'Total fees paid: sales charges of $4,715.00 plus expense ratio charges of $10,810.44 = $15,525.44'
			],
			result:
				'The fund ends at $167,372.00 after costs, against $196,665.39 with no fees. Fees paid directly total $15,525.44, and $29,293.39 of growth is lost.'
		},
		faq: [
			{
				q: 'Why is the value lost bigger than the fees paid?',
				a: 'The fees also reduce the money that would have grown in later years. The value lost includes that missed growth, so it is larger than the fees paid directly.'
			},
			{
				q: 'What is the difference between a front-end and a back-end load?',
				a: 'A front-end load is taken when you buy, so less of your money gets invested. A back-end load is taken when you sell, from the final value. Many funds have no back-end load.'
			},
			{
				q: 'Is the expense ratio in addition to loads?',
				a: 'Yes. The expense ratio is charged every year on the fund’s assets, and loads are charged separately on purchases or sales. A fund can have both.'
			},
			{
				q: 'Are these results guaranteed?',
				a: 'No. The return is an estimate. The calculator assumes a steady yearly return, contributions at the end of each month and monthly compounding.'
			}
		],
		sources: [
			{
				title: 'U.S. Securities and Exchange Commission, Investor.gov',
				url: 'https://www.investor.gov/'
			}
		],
		disclaimer:
			'Estimates only. Actual fund returns, fees, taxes and sales charges vary, and this is not investment advice.'
	}
});
