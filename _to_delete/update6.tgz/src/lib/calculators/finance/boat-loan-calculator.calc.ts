import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './boat-loan-calculator.meta';

/** Fixed-rate payment: M = P·r(1+r)^n / ((1+r)^n − 1); r = 0 → P / n. */
function payment(principal: number, annualRatePct: number, months: number): number {
	const r = annualRatePct / 1200;
	if (r === 0) return principal / months;
	const f = Math.pow(1 + r, months);
	return (principal * r * f) / (f - 1);
}

const TERMS = [60, 72, 84, 96, 120, 144, 180, 240];

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'price', label: 'Boat price', type: 'number', default: 45000, min: 0, max: 100_000_000, step: 500, prefix: '$' },
		{ id: 'down', label: 'Down payment', type: 'number', default: 5000, min: 0, max: 100_000_000, step: 500, prefix: '$' },
		{ id: 'trade', label: 'Trade-in value', type: 'number', default: 0, min: 0, max: 100_000_000, step: 500, prefix: '$', help: 'Value of a boat or vehicle you hand over.' },
		{ id: 'taxPct', label: 'Sales tax', type: 'number', default: 6, min: 0, max: 30, step: 0.1, suffix: '%', help: 'Your local rate on the taxable price.' },
		{
			id: 'taxAfter',
			label: 'Tax is charged after trade-in',
			type: 'toggle',
			default: true,
			help: 'Some places tax the price minus the trade-in. Others tax the full price. Check your local rule.'
		},
		{ id: 'fees', label: 'Fees added to the loan', type: 'number', default: 500, min: 0, max: 10_000_000, step: 50, prefix: '$', help: 'Registration, documentation, delivery and similar charges.' },
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 8.5, min: 0, max: 40, step: 0.01, suffix: '%', help: 'Annual rate' },
		{
			id: 'term',
			label: 'Loan term',
			type: 'select',
			display: 'menu',
			default: '60',
			options: TERMS.map((m) => ({ label: `${m} months (${m / 12} years)`, value: String(m) }))
		}
	],
	calculate(v): CalculationResult {
		const price = Number(v.price);
		const down = Number(v.down);
		const trade = Number(v.trade);
		const taxPct = Number(v.taxPct);
		const fees = Number(v.fees);
		const rate = Number(v.rate);
		const n = Number(v.term);
		const primaryLabel = 'Monthly payment';

		if (
			!Number.isFinite(price) || price < 0 ||
			!Number.isFinite(down) || down < 0 ||
			!Number.isFinite(trade) || trade < 0 ||
			!(taxPct >= 0 && taxPct <= 30) ||
			!(fees >= 0) ||
			!(rate >= 0 && rate <= 40) ||
			!Number.isInteger(n) || n < 1 || n > 600
		) {
			return { primaryResult: DASH, primaryLabel, summary: 'Check the prices, tax, rate and term. The term must be a whole number of months.' };
		}

		const taxable = v.taxAfter ? Math.max(0, price - trade) : price;
		const tax = (taxable * taxPct) / 100;
		const financed = price + tax + fees - down - trade;
		if (!(financed > 0)) {
			return { primaryResult: DASH, primaryLabel, summary: 'Your down payment and trade-in cover the whole cost, so no loan is needed.' };
		}

		const monthly = payment(financed, rate, n);
		const totalPayments = monthly * n;
		const totalInterest = Math.max(0, totalPayments - financed);
		const totalCost = down + totalPayments;

		return {
			primaryResult: money(monthly),
			primaryLabel,
			summary: `Borrowing ${money(financed, true)} at ${num(rate, 3)}% over ${plural(n, 'month')}.`,
			secondaryMetrics: [
				{ label: 'Amount financed', value: money(financed) },
				{ label: 'Sales tax', value: money(tax) },
				{ label: 'Total interest', value: money(totalInterest) },
				{ label: 'Total of loan payments', value: money(totalPayments) },
				{ label: 'Total cost, with down payment', value: money(totalCost) }
			]
		};
	},
	content: {
		intro:
			'Estimate the monthly payment on a boat loan, including sales tax and fees, and see how much interest you will pay over the full term.',
		howTo: [
			'Enter the boat price, then your down payment and any trade-in value.',
			'Enter your local sales tax rate and any fees you will finance. Choose whether tax is charged after the trade-in.',
			'Enter the annual interest rate and pick a term from 5 to 20 years.',
			'Read the monthly payment, the total interest and the total cost.'
		],
		formulas: [
			{
				title: 'Amount financed',
				expression: 'Financed = Price + Tax + Fees − Down payment − Trade-in\nTax = (Price − Trade-in) × Tax rate, or Price × Tax rate',
				variables: [
					{ symbol: 'Tax', meaning: 'sales tax, on the price after trade-in if that option is on' },
					{ symbol: 'Fees', meaning: 'charges you finance with the loan' }
				]
			},
			{
				title: 'Monthly payment',
				expression: 'M = P × r(1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'M', meaning: 'monthly payment' },
					{ symbol: 'P', meaning: 'amount financed' },
					{ symbol: 'r', meaning: 'monthly rate (annual rate ÷ 12 ÷ 100)' },
					{ symbol: 'n', meaning: 'number of monthly payments' }
				]
			},
			{
				title: 'Totals',
				expression: 'Total interest = M × n − P\nTotal cost = Down payment + M × n',
				variables: []
			}
		],
		example: {
			title: 'A $45,000 boat with $5,000 down over 5 years at 8.5%',
			steps: [
				'Tax: 6% × $45,000 = $2,700 (no trade-in)',
				'Amount financed: 45,000 + 2,700 + 500 fees − 5,000 down = $43,200',
				'Monthly rate: r = 8.5 ÷ 12 ÷ 100 = 0.0070833, and n = 60',
				'M = 43,200 × r × (1 + r)⁶⁰ ÷ ((1 + r)⁶⁰ − 1) ≈ $886.31',
				'Total payments = 886.31 × 60 = $53,178.85, so interest = 53,178.85 − 43,200 = $9,978.85'
			],
			result:
				'Monthly payment of $886.31. Total interest of $9,978.85, and a total cost of $58,178.85 with the down payment.'
		},
		faq: [
			{
				q: 'Should I finance the sales tax and fees?',
				a: 'You can often add them to the loan, but that raises the amount you borrow and the interest on it. Paying them up front costs less overall if you can afford it.'
			},
			{
				q: 'Why is a longer boat loan more expensive?',
				a: 'A longer term lowers each payment, but interest builds up over more months. The total interest rises even though the monthly payment falls.'
			},
			{
				q: 'Does the trade-in always reduce the sales tax?',
				a: 'Not everywhere. Some places tax the price after the trade-in is deducted, and others tax the full price. Use the toggle to match your local rule.'
			},
			{
				q: 'Is the total cost the same as the loan amount?',
				a: 'No. The total cost adds your down payment and every payment, so it includes all the interest. A trade-in is not counted as cash, because you handed it over rather than paying it.'
			}
		],
		sources: [
			{
				title: 'Consumer Financial Protection Bureau',
				url: 'https://www.consumerfinance.gov/'
			}
		],
		disclaimer:
			'Estimates only. Your actual rate, tax, fees and payment depend on your lender, your location and the loan agreement.'
	}
});
