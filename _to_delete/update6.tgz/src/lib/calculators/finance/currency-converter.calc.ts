import { defineCalculator } from '../types';
import meta from './currency-converter.meta';

export default defineCalculator({
	meta,
	widget: { name: 'currency' },
	inputs: [],
	calculate: () => ({ primaryResult: '', primaryLabel: '' }),
	content: {
		intro:
			'Convert money between more than 160 currencies using daily mid-market exchange rates. The date and source of the rates are shown with every result.',
		howTo: [
			'Enter the amount to convert.',
			'Choose the currency you have and the one you want. Use the swap button to reverse them.',
			'Read the converted amount, the rate in both directions and the value in other popular currencies.'
		],
		formulas: [
			{
				title: 'Conversion through a common base',
				expression: 'Amount in B = Amount in A × (rate of B ÷ rate of A)',
				variables: [{ symbol: 'rate', meaning: 'units of each currency per 1 US dollar, from the daily rate feed' }]
			}
		],
		example: {
			title: 'Converting 100 US dollars to euros at 1 USD = 0.92 EUR',
			steps: ['100 × 0.92 = 92', 'The reverse rate is 1 ÷ 0.92 = 1.0870 USD per euro'],
			result: '100 USD = 92.00 EUR at that rate.'
		},
		faq: [
			{
				q: 'Why does my bank give a different rate?',
				a: 'These are mid-market rates: halfway between the buy and sell prices on the wholesale market. Banks, card providers and exchange counters add a margin (often 1–5%) and sometimes a fee, so the rate you get is usually worse.'
			},
			{
				q: 'How often are the rates updated?',
				a: 'Once a day. The date of the rates is shown under the result. They are fine for planning and budgeting, but not for trading.'
			},
			{
				q: 'Where do the rates come from?',
				a: 'From ExchangeRate-API’s free daily feed. If that is unavailable, we use the European Central Bank’s reference rates, which cover about 30 major currencies.'
			}
		],
		sources: [
			{ title: 'European Central Bank — Euro foreign exchange reference rates', url: 'https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/index.en.html' },
			{ title: 'ExchangeRate-API', url: 'https://www.exchangerate-api.com' }
		],
		disclaimer: 'Indicative mid-market rates for information only. The rate you get from a bank or money transfer service will differ.'
	}
});
