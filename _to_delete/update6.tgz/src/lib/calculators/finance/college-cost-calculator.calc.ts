import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, pct, plural } from '../format';
import meta from './college-cost-calculator.meta';

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'cost',
			label: 'Yearly cost today',
			type: 'number',
			default: 25000,
			min: 0,
			max: 100_000_000,
			step: 500,
			prefix: '$',
			help: 'Tuition plus room and board for one year, in today’s money.'
		},
		{ id: 'years', label: 'Years until college', type: 'number', default: 10, min: 1, max: 60, step: 1, suffix: 'years', decimal: false, width: 'half' },
		{ id: 'study', label: 'Years of study', type: 'number', default: 4, min: 1, max: 10, step: 1, suffix: 'years', decimal: false, width: 'half' },
		{ id: 'inflation', label: 'Cost increase per year', type: 'number', default: 5, min: 0, max: 30, step: 0.1, suffix: '%' },
		{ id: 'savings', label: 'Current savings', type: 'number', default: 20000, min: 0, max: 100_000_000, step: 500, prefix: '$' },
		{ id: 'ret', label: 'Savings return per year', type: 'number', default: 6, min: 0, max: 30, step: 0.1, suffix: '%' },
		{ id: 'monthly', label: 'Monthly saving', type: 'number', default: 500, min: 0, max: 1_000_000, step: 50, prefix: '$', suffix: '/mo', help: 'What you already set aside each month.' }
	],
	calculate(v): CalculationResult {
		const cost = Number(v.cost);
		const years = Number(v.years);
		const study = Number(v.study);
		const inflation = Number(v.inflation) / 100;
		const savings = Number(v.savings);
		const annualRate = Number(v.ret) / 100;
		const monthly = Number(v.monthly);
		const primaryLabel = 'Total projected cost';

		if (
			!(cost >= 0) || !Number.isFinite(cost) ||
			!Number.isInteger(years) || years < 1 || years > 60 ||
			!Number.isInteger(study) || study < 1 || study > 10 ||
			!(inflation >= 0 && inflation <= 0.3) ||
			!(savings >= 0) || !Number.isFinite(savings) ||
			!(annualRate >= 0 && annualRate <= 0.3) ||
			!(monthly >= 0) || !Number.isFinite(monthly)
		) {
			return { primaryResult: DASH, primaryLabel, summary: 'Check each field. Years are whole numbers from 1 to 60, and years of study from 1 to 10.' };
		}

		// Cost in each year of study. The first year is `years` from now, then rises each year.
		const yearCosts: number[] = [];
		for (let j = 0; j < study; j++) yearCosts.push(cost * Math.pow(1 + inflation, years + j));
		const total = yearCosts.reduce((s, c) => s + c, 0);
		const costAtStart = cost * Math.pow(1 + inflation, years);

		// Savings grow monthly. Monthly saving is added at the end of each month.
		const r = annualRate / 12;
		const months = years * 12;
		const growth = Math.pow(1 + r, months);
		const savingsAtStart = savings * growth + (r === 0 ? monthly * months : (monthly * (growth - 1)) / r);
		const gap = savingsAtStart - total;

		// Monthly saving that exactly covers the total cost, given the growth on current savings.
		const requiredMonthly =
			r === 0
				? Math.max(0, (total - savings) / months)
				: Math.max(0, ((total - savings * growth) * r) / (growth - 1));
		const extra = Math.max(0, requiredMonthly - monthly);

		const summary =
			gap >= 0
				? `Your savings cover the projected cost, with ${money(gap)} to spare.`
				: `Your savings fall ${money(-gap)} short of the projected cost.`;

		return {
			primaryResult: money(total),
			primaryLabel,
			summary,
			secondaryMetrics: [
				{ label: 'Cost in the first year of study', value: money(costAtStart) },
				{ label: 'Projected savings at start', value: money(savingsAtStart) },
				{ label: gap >= 0 ? 'Surplus' : 'Shortfall', value: money(Math.abs(gap)) },
				{ label: 'Total monthly saving needed', value: money(requiredMonthly) },
				{ label: 'Extra monthly saving to close the gap', value: money(extra) }
			],
			table: {
				title: `Cost in each of the ${plural(study, 'year')} of study`,
				collapsed: true,
				columns: [
					{ key: 'year', label: 'Year of study' },
					{ key: 'cost', label: 'Cost', align: 'end' }
				],
				rows: yearCosts.map((c, j) => ({ year: `Year ${num(j + 1, 0)}`, cost: money(c) }))
			}
		};
	},
	content: {
		intro:
			'Estimate what a college education will cost when you need it, once yearly costs rise with inflation. Then see whether your current savings and monthly saving will cover it.',
		howTo: [
			'Enter today’s yearly cost of tuition plus room and board.',
			'Enter how many years until college starts and how many years of study you expect.',
			'Enter the yearly cost increase, your current savings, the return you expect and the amount you save each month.',
			'Read the total projected cost, the savings you will have, and the extra monthly saving needed to close any gap.'
		],
		formulas: [
			{
				title: 'Cost when you start',
				expression: 'Cost in year t = Today’s cost × (1 + i)^t',
				variables: [
					{ symbol: 'i', meaning: 'yearly cost increase, as a decimal' },
					{ symbol: 't', meaning: 'years from now, counting the first year of study as years until college' }
				]
			},
			{
				title: 'Total projected cost',
				expression: 'Total = Σ Cost in each year of study, for each year from start to finish',
				variables: []
			},
			{
				title: 'Savings at the start of college',
				expression: 'FV = P × (1 + r)ᴺ + M × ((1 + r)ᴺ − 1) ÷ r',
				variables: [
					{ symbol: 'P', meaning: 'current savings' },
					{ symbol: 'M', meaning: 'monthly saving' },
					{ symbol: 'r', meaning: 'monthly return (yearly return ÷ 12)' },
					{ symbol: 'N', meaning: 'number of months until college' }
				]
			},
			{
				title: 'Monthly saving needed',
				expression: 'M needed = (Total − P × (1 + r)ᴺ) × r ÷ ((1 + r)ᴺ − 1)',
				variables: []
			}
		],
		example: {
			title: 'Tuition of $25,000 a year, starting in 10 years, with 4 years of study',
			steps: [
				'Cost in the first year: 25,000 × 1.05¹⁰ ≈ $40,722.37',
				'Each later year rises 5%: 42,758.48 + 44,896.41 + 47,141.23, so the four years total $175,518.49',
				'Savings: $20,000 grows to $36,387.93, and $500 a month adds $81,939.67, so the total is $118,327.61',
				'Shortfall: 118,327.61 − 175,518.49 = −$57,190.88',
				'Monthly saving needed: about $848.98, which is $348.98 more than the $500 you save now'
			],
			result:
				'Total projected cost of $175,518.49. Savings of $118,327.61 leave a shortfall of $57,190.88, and closing it needs an extra $348.98 a month.'
		},
		faq: [
			{
				q: 'What cost increase should I use?',
				a: 'Costs differ by school and country, so the default is only a starting point. Check the published price history for the schools you are considering and enter a rate that fits them.'
			},
			{
				q: 'Does this include financial aid or scholarships?',
				a: 'No. Enter the net cost you expect to pay if you expect aid. Otherwise you may overstate the goal.'
			},
			{
				q: 'What counts as the cost?',
				a: 'Use tuition plus room and board, or any other yearly total you want to plan for. Books, travel and other costs are not included unless you add them.'
			},
			{
				q: 'Why is the monthly saving needed lower than the total I need to save?',
				a: 'Your current savings and their growth do part of the work. The figure needed each month assumes they keep growing at the return you entered.'
			}
		],
		sources: [
			{
				title: 'U.S. Department of Education, Federal Student Aid',
				url: 'https://studentaid.gov/'
			}
		],
		disclaimer:
			'Projections only. Real costs, returns and inflation change over time, and this is not financial advice.'
	}
});
