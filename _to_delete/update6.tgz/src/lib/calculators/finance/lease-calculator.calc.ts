import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, money, num, pct } from '../format';
import meta from './lease-calculator.meta';

const when = (id: string, value: string) => (v: InputValues) => v[id] === value;

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'asset', label: 'Asset value', type: 'number', default: 25000, min: 0.01, max: 100_000_000, step: 500, prefix: '$', help: 'Price or value of the item at the start of the lease.' },
		{
			id: 'resMode',
			label: 'Residual value entered as',
			type: 'select',
			display: 'segmented',
			default: 'percent',
			options: [
				{ label: 'Percent of value', value: 'percent' },
				{ label: 'Amount', value: 'amount' }
			]
		},
		{
			id: 'resPct',
			label: 'Residual value',
			type: 'number',
			default: 45,
			min: 0,
			max: 100,
			step: 1,
			suffix: '%',
			help: 'Expected value at the end, as a share of the asset value.',
			visibleWhen: when('resMode', 'percent')
		},
		{
			id: 'resAmt',
			label: 'Residual value',
			type: 'number',
			default: 11250,
			min: 0,
			max: 100_000_000,
			step: 500,
			prefix: '$',
			help: 'Expected value at the end of the lease.',
			visibleWhen: when('resMode', 'amount')
		},
		{ id: 'term', label: 'Lease term', type: 'number', default: 36, min: 1, max: 120, step: 1, suffix: 'months', decimal: false },
		{
			id: 'rateType',
			label: 'Rate entered as',
			type: 'select',
			display: 'segmented',
			default: 'rate',
			options: [
				{ label: 'Interest rate', value: 'rate' },
				{ label: 'Money factor', value: 'factor' }
			]
		},
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 6, min: 0, max: 100, step: 0.01, suffix: '%', help: 'Annual rate.', visibleWhen: when('rateType', 'rate') },
		{
			id: 'mf',
			label: 'Money factor',
			type: 'number',
			default: 0.0025,
			min: 0,
			max: 0.04,
			step: 0.0001,
			help: 'Common in vehicle leases. Annual rate = money factor × 2,400.',
			visibleWhen: when('rateType', 'factor')
		},
		{
			id: 'timing',
			label: 'Payment timing',
			type: 'select',
			display: 'segmented',
			default: 'advance',
			options: [
				{ label: 'Start (advance)', value: 'advance' },
				{ label: 'End (arrears)', value: 'arrears' }
			]
		}
	],
	calculate(v): CalculationResult {
		const asset = Number(v.asset);
		const n = Number(v.term);
		const annualPct = v.rateType === 'factor' ? Number(v.mf) * 2400 : Number(v.rate);
		const residual = v.resMode === 'amount' ? Number(v.resAmt) : (asset * Number(v.resPct)) / 100;
		const advance = v.timing === 'advance';
		const primaryLabel = 'Payment per month';

		if (
			!Number.isFinite(asset) || !(asset > 0) ||
			!Number.isFinite(residual) || residual < 0 || residual >= asset ||
			!Number.isInteger(n) || n < 1 || n > 120 ||
			!Number.isFinite(annualPct) || annualPct < 0 || annualPct > 100
		) {
			return {
				primaryResult: DASH,
				primaryLabel,
				summary: 'Enter an asset value, a residual value below the asset value, and a term of 1 to 120 months.'
			};
		}

		// Payment that repays the asset value down to the residual value.
		// Arrears: P = (A(1+r)ⁿ − R) × r ÷ ((1+r)ⁿ − 1). Advance: divide by (1 + r).
		const r = annualPct / 1200;
		let payment: number;
		if (r === 0) {
			payment = (asset - residual) / n;
		} else {
			const f = Math.pow(1 + r, n);
			payment = ((asset * f - residual) * r) / (f - 1);
			if (advance) payment /= 1 + r;
		}

		const total = payment * n;
		const depreciation = asset - residual;
		const impliedInterest = Math.max(0, total - depreciation);
		const moneyFactor = annualPct / 2400;

		return {
			primaryResult: money(payment),
			primaryLabel,
			summary: `Paid ${advance ? 'at the start' : 'at the end'} of each month. The residual value of ${money(residual, true)} is what the item is worth at the end.`,
			secondaryMetrics: [
				{ label: 'Total of payments', value: money(total) },
				{ label: 'Value used up (asset less residual)', value: money(depreciation) },
				{ label: 'Implied interest (rent charge)', value: money(impliedInterest) },
				{ label: 'Residual value at end', value: money(residual) },
				{ label: 'Annual interest rate', value: pct(annualPct, 3) },
				{ label: 'Money factor', value: num(moneyFactor, 6) }
			]
		};
	},
	content: {
		intro:
			'Estimate the monthly payment on a lease for equipment, property or a vehicle. You will also see the total you pay and the interest charge built into the lease.',
		howTo: [
			'Enter the asset value and the residual value, either as an amount or as a percentage of the asset value.',
			'Enter the lease term in months.',
			'Enter the interest rate, or the money factor if the lessor quotes that instead.',
			'Choose whether payments are made at the start or the end of each month, then read the payment and the implied interest.'
		],
		formulas: [
			{
				title: 'Monthly payment (payments in arrears)',
				expression: 'P = (A × (1 + r)ⁿ − R) × r ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'A', meaning: 'asset value at the start' },
					{ symbol: 'R', meaning: 'residual value at the end' },
					{ symbol: 'r', meaning: 'monthly rate (annual rate ÷ 12 ÷ 100)' },
					{ symbol: 'n', meaning: 'number of monthly payments' }
				]
			},
			{
				title: 'Payments in advance',
				expression: 'P (advance) = P (arrears) ÷ (1 + r)',
				variables: [{ symbol: 'r', meaning: 'monthly rate, as above' }]
			},
			{
				title: 'Money factor',
				expression: 'Annual rate (%) = money factor × 2,400\nMonthly rate = money factor × 2',
				variables: [{ symbol: 'MF', meaning: 'money factor, as used in vehicle leases' }]
			},
			{
				title: 'Totals',
				expression: 'Total of payments = P × n\nImplied interest = Total of payments − (A − R)',
				variables: []
			}
		],
		example: {
			title: 'A $20,000 asset with an $8,000 residual, 36 months at 6%',
			steps: [
				'Monthly rate: r = 6 ÷ 12 ÷ 100 = 0.005',
				'Payments in arrears: (20,000 × 1.005³⁶ − 8,000) × 0.005 ÷ (1.005³⁶ − 1) ≈ $405.0632',
				'Payments in advance: 405.0632 ÷ 1.005 ≈ $403.0480',
				'Total of payments: 403.0480 × 36 ≈ $14,509.73',
				'Implied interest: 14,509.73 − (20,000 − 8,000) = $2,509.73'
			],
			result:
				'Advance payments of $403.05 a month. Total payments of $14,509.73, which includes $2,509.73 of implied interest.'
		},
		faq: [
			{
				q: 'What is a residual value?',
				a: 'It is the value the lessor expects the item to have at the end of the lease. The lease payments cover the drop from the asset value to the residual, plus the interest charge.'
			},
			{
				q: 'How do I turn a money factor into an interest rate?',
				a: 'Multiply the money factor by 2,400 to get an annual rate in percent. For example, a money factor of 0.0025 is about 6% a year.'
			},
			{
				q: 'Why do payments in advance cost less each month?',
				a: 'You pay at the start of each month instead of the end, so each payment is discounted by one period of interest. The total paid is slightly lower as well.'
			},
			{
				q: 'Does this include taxes, fees or a deposit?',
				a: 'No. Add any upfront payments, taxes or fees separately. A deposit or down payment lowers the amount leased, so enter the reduced asset value in that case.'
			}
		],
		sources: [
			{
				title: 'Consumer Financial Protection Bureau',
				url: 'https://www.consumerfinance.gov/'
			}
		],
		disclaimer:
			'Estimates only. Lease terms, fees, taxes and end-of-lease charges depend on your contract, so read it before you sign.'
	}
});
