/**
 * The calculator contract (see .clauderules §2A).
 *
 * Each calculator is two files, named after its slug (e.g. bmi-calculator):
 *   <slug>.meta.ts — light metadata used by listings, search, sitemap and matchers (no math).
 *   <slug>.calc.ts — the full config: inputs, the pure `calculate` function and SEO content.
 * Only the calculator page loads the .calc.ts chunk, so hundreds of calculators never bloat
 * the home page or each other.
 */
import type { IconName } from '../icons';

export type CategoryId = 'finance' | 'health' | 'math' | 'everyday' | 'developer';

export type InputValue = number | string | boolean;
export type InputValues = Record<string, InputValue>;

interface InputBase {
	id: string;
	label: string;
	/** One short line under the field. */
	help?: string;
	/** Hide the field unless this returns true (e.g. metric vs imperial fields). */
	visibleWhen?: (values: InputValues) => boolean;
	/** 'half' keeps short fields side by side even on phones (e.g. feet + inches). */
	width?: 'half';
}

export interface NumberInput extends InputBase {
	type: 'number';
	default: number;
	min?: number;
	max?: number;
	step?: number;
	/** Text shown before the value inside the field, e.g. "$". */
	prefix?: string;
	/** Text shown after the value inside the field, e.g. "%" or "years". */
	suffix?: string;
	/** Allow decimals (true) or whole numbers only. Default true. */
	decimal?: boolean;
}

export interface SliderInput extends InputBase {
	type: 'slider';
	default: number;
	min: number;
	max: number;
	step: number;
	suffix?: string;
}

export interface SelectInput extends InputBase {
	type: 'select';
	default: string;
	options: { label: string; value: string }[];
	/** 'segmented' for 2–4 short options (HIG segmented control), 'menu' otherwise. */
	display?: 'segmented' | 'menu';
}

export interface ToggleInput extends InputBase {
	type: 'toggle';
	default: boolean;
}

export interface DateInput extends InputBase {
	type: 'date';
	/** ISO date (YYYY-MM-DD) or 'today'. */
	default: string;
}

export type CalculatorInput = NumberInput | SliderInput | SelectInput | ToggleInput | DateInput;

export interface Metric {
	label: string;
	value: string;
}

export interface GaugeBand {
	/** Upper bound of this band (exclusive). The last band runs to `max`. */
	to: number;
	label: string;
}

export interface Gauge {
	min: number;
	max: number;
	value: number;
	bands: GaugeBand[];
}

export interface LineChart {
	type: 'line';
	title: string;
	/** Key in each data row used for the x axis. */
	x: string;
	xLabel: string;
	/** Up to two series on one shared axis (never a dual axis). */
	series: { key: string; label: string }[];
	data: Record<string, number>[];
	valueFormat: 'currency' | 'number';
}

export interface Table {
	title: string;
	columns: { key: string; label: string; align?: 'start' | 'end' }[];
	rows: Record<string, string>[];
	/** Collapsed by default (HIG progressive disclosure). */
	collapsed?: boolean;
}

export interface CalculationResult {
	/** Already formatted, e.g. "$2,022.62". Use '—' when inputs are invalid. */
	primaryResult: string;
	primaryLabel: string;
	/** One short sentence under the result, e.g. the BMI category. */
	summary?: string;
	secondaryMetrics?: Metric[];
	gauge?: Gauge;
	chart?: LineChart;
	table?: Table;
}

export interface FormulaBlock {
	title?: string;
	/** Plain-text formula, e.g. "M = P × r(1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)". */
	expression: string;
	variables: { symbol: string; meaning: string }[];
}

export interface CalculatorContent {
	/** 1–2 sentences under the H1. */
	intro: string;
	/** Short "How to use" steps. */
	howTo: string[];
	formulas: FormulaBlock[];
	example: { title: string; steps: string[]; result: string };
	faq: { q: string; a: string }[];
	/** Authoritative references (E-E-A-T). */
	sources?: { title: string; url: string }[];
	/** Shown under the result for health or money tools. */
	disclaimer?: string;
}

export interface CalculatorMeta {
	slug: string;
	name: string;
	category: CategoryId;
	/** One line for cards and search results. */
	shortDescription: string;
	/** ≤ 60 characters. */
	metaTitle: string;
	/** 120–160 characters. */
	metaDescription: string;
	icon: IconName;
	keywords: string[];
	/** Lower = more popular; omit to keep it off the home page "Popular" grid. */
	popularRank?: number;
	/** ISO date the math and copy were last reviewed. */
	updated: string;
}

export interface CalculatorConfig {
	meta: CalculatorMeta;
	inputs: CalculatorInput[];
	calculate: (inputs: InputValues) => CalculationResult;
	content: CalculatorContent;
}

export function defineMeta(meta: CalculatorMeta): CalculatorMeta {
	return meta;
}

export function defineCalculator(config: CalculatorConfig): CalculatorConfig {
	return config;
}
