import type { CalculatorInput, InputValues } from '../../calculators/types';
import { parseNumber } from '../../calculators/format';

/** Raw form state: numbers stay as the text the person typed until they are parsed. */
export type RawValues = Record<string, string | boolean>;

export function defaultRaw(inputs: CalculatorInput[], today: string): RawValues {
	const raw: RawValues = {};
	for (const i of inputs) {
		if (i.type === 'toggle') raw[i.id] = i.default;
		else if (i.type === 'date') raw[i.id] = i.default === 'today' ? today : i.default;
		else raw[i.id] = String(i.default);
	}
	return raw;
}

export function toValues(inputs: CalculatorInput[], raw: RawValues): InputValues {
	const v: InputValues = {};
	for (const i of inputs) {
		const r = raw[i.id];
		if (i.type === 'number' || i.type === 'slider') v[i.id] = parseNumber(String(r));
		else if (i.type === 'toggle') v[i.id] = Boolean(r);
		else v[i.id] = String(r);
	}
	return v;
}

export function isVisible(input: CalculatorInput, values: InputValues): boolean {
	return input.visibleWhen ? input.visibleWhen(values) : true;
}

/** Returns an error message, or '' when the field is valid. */
export function validate(input: CalculatorInput, raw: string | boolean): string {
	if (input.type === 'number' || input.type === 'slider') {
		const n = parseNumber(String(raw));
		if (Number.isNaN(n)) return 'Enter a number.';
		if (input.type === 'number' && input.decimal === false && !Number.isInteger(n))
			return 'Enter a whole number.';
		const { min, max } = input;
		if (min !== undefined && n < min) return `Enter ${min.toLocaleString('en-US')} or more.`;
		if (max !== undefined && n > max) return `Enter ${max.toLocaleString('en-US')} or less.`;
	}
	if (input.type === 'date' && !/^\d{4}-\d{2}-\d{2}$/.test(String(raw))) return 'Enter a date.';
	if (input.type === 'select' && !input.options.some((o) => o.value === raw)) return 'Pick an option.';
	return '';
}

/** Read inputs from a query string, ignoring unknown keys and malformed values. */
export function fromQuery(inputs: CalculatorInput[], search: string, base: RawValues): RawValues {
	const params = new URLSearchParams(search);
	const next = { ...base };
	for (const i of inputs) {
		const q = params.get(i.id);
		if (q === null || q.length > 64) continue;
		if (i.type === 'toggle') next[i.id] = q === '1' || q === 'true';
		else if (validate(i, q) === '') next[i.id] = q;
	}
	return next;
}

/** Only values that differ from the defaults go in the URL, so links stay short. */
export function toQuery(inputs: CalculatorInput[], raw: RawValues, defaults: RawValues): string {
	const params = new URLSearchParams();
	for (const i of inputs) {
		const r = raw[i.id];
		const strip = (x: unknown) => String(x).replace(/,/g, '');
		if (strip(r) === strip(defaults[i.id])) continue;
		params.set(i.id, typeof r === 'boolean' ? (r ? '1' : '0') : String(r).replace(/,/g, ''));
	}
	const s = params.toString();
	return s ? `?${s}` : '';
}
