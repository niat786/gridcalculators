import { error } from '@sveltejs/kit';
import { loadCalculator } from '#lib/calculators/loaders.ts';
import type { PageLoad } from './$types';

// Universal load: the config holds functions (the math), so it can't be serialized.
// It is imported here instead, as a small per-calculator chunk.
export const load: PageLoad = async ({ params, data }) => {
	const config = await loadCalculator(params.slug);
	if (!config) error(404, 'Calculator not found');
	return { ...data, config };
};
