# Data updates: time-sensitive figures

Some calculators use official figures that change on a schedule: tax brackets, contribution limits,
Social Security amounts, inflation data and similar. This file lists every one of them: where it lives,
its current value, when it changes and where to get the new number.

**Rule:** each figure lives in **one place**, usually a file in `src/lib/calculators/data/`. Calculators import it
from there, so updating the data file updates every page and FAQ that uses it. Never type these
numbers directly into a calculator.

Last full review: **2026-10-28** (figures for tax year 2026).

---

## Yearly calendar

| When | What changes | Section |
| --- | --- | --- |
| **Every month (~10th–15th)** | US CPI (inflation calculator) | [CPI](#1-us-consumer-price-index-cpi) |
| **Mid-October** | Social Security COLA, wage base, bend points | [Social Security](#4-social-security) |
| **Late Oct – early Nov** | IRS tax brackets, standard deduction, credits, estate exemption | [Federal income tax](#2-us-federal-income-tax) and [Estate tax](#5-estate-and-gift-tax) |
| **Early November** | 401(k), IRA limits, Roth phase-outs | [Retirement limits](#3-retirement-plan-limits) |
| **Mid/late December** | IRS standard mileage rate | [Mileage](#6-irs-standard-mileage-rate) |
| **Whenever announced** | FHA mortgage insurance premium, VA funding fee, Army standard | [Loans](#7-fha-and-va-loans) and [Army](#8-army-body-composition-standard) |
| **Rarely (check yearly)** | RMD table and start ages, CKD-EPI eGFR equation, WHS golf rules | [Stable rules](#9-stable-rules-check-once-a-year) |

---

## 1. US Consumer Price Index (CPI)

- **File:** `src/lib/calculators/data/cpi.ts`
- **Used by:** inflation-calculator
- **Current:**
  - `CPI_ANNUAL`: annual averages for 1913–2025 (2025 is an 11-month average because the BLS published no October 2025 figure)
  - `CPI_LATEST = { month: '2026-08', index: 334.98 }`
  - `CPI_LAST_YEAR = 2025`
- **Changes:** each month, when the BLS releases CPI-U for the previous month (around the 10th–15th).
- **Source:** BLS CPI-U, All items, U.S. city average, not seasonally adjusted (series CUUR0000SA0).
  <https://www.bls.gov/cpi/>
- **Monthly update:** set `CPI_LATEST` to the newest month and index.
- **Each January**, after December's CPI is out:
  - add the full-year average to `CPI_ANNUAL`
  - raise `CPI_LAST_YEAR`
- **Tests:** `finance/inflation-calculator.test.ts`. The worked example ($1,000 in 2000 → today) changes with `CPI_LATEST`, so update the example text in the calculator and the test together.

## 2. US federal income tax

- **File:** `src/lib/calculators/data/us-tax-2026.ts`. When the year changes, rename it to `us-tax-2027.ts` and update the imports.
- **Used by:** income-tax-calculator, take-home-pay-calculator, marriage-tax-calculator. The Social Security calculator also uses `SS_WAGE_BASE`.
- **Changes:** the IRS publishes next year's figures in late October or early November (a Revenue Procedure plus a newsroom post titled "IRS releases tax inflation adjustments for tax year 20XX").

| Constant | 2026 value | Notes |
| --- | --- | --- |
| `TAX_YEAR` | 2026 | Shown in labels and FAQs |
| `THRESHOLDS.single` | 0 / 12,400 / 50,400 / 105,700 / 201,775 / 256,225 / 640,600 | Lower edge of 10%–37% |
| `THRESHOLDS.mfj` | 0 / 24,800 / 100,800 / 211,400 / 403,550 / 512,450 / 768,700 | |
| `THRESHOLDS.mfs` | 0 / 12,400 / 50,400 / 105,700 / 201,775 / 256,225 / 384,350 | |
| `THRESHOLDS.hoh` | 0 / 17,700 / 67,450 / 105,700 / 201,750 / 256,200 / 640,600 | |
| `STANDARD_DEDUCTION` | single 16,100 · mfj 32,200 · mfs 16,100 · hoh 24,150 | |
| `EXTRA_65` | single/hoh 2,050 · married 1,650 (per person) | Age 65+ or blind |
| `SENIOR_DEDUCTION` | 6,000 per person 65+ | OBBBA. **Ends after tax year 2028**: remove it for 2029 |
| `SENIOR_THRESHOLD` | 75,000 single/hoh · 150,000 mfj | Phases out at 6% |
| `CTC_PER_CHILD` / `CTC_REFUNDABLE` | 2,200 / 1,700 | Indexed for inflation from 2026 on, so check each year |
| `CTC_PHASEOUT` | 200,000 · 400,000 mfj | Not indexed |
| `SS_WAGE_BASE` | 184,500 | **From SSA, mid-October** (see §4) |
| `SS_RATE`, `MEDICARE_RATE`, `ADDL_MEDICARE_*` | 6.2%, 1.45%, 0.9% over 200k/250k/125k | Set by law; rarely change |

- **Sources:**
  - IRS newsroom (search "tax inflation adjustments for tax year"): <https://www.irs.gov/newsroom>
  - 2026 release: <https://www.irs.gov/newsroom/irs-releases-tax-inflation-adjustments-for-tax-year-2026-including-amendments-from-the-one-big-beautiful-bill>
  - The IRS post often lists brackets only for single and married filing jointly. Take head of household and married filing separately from the Revenue Procedure itself, or cross-check a reputable summary (e.g. NerdWallet's yearly bracket page).
- **Tests:**
  - `finance/income-tax-calculator.test.ts`: worked example $85,000 single → $9,870.00
  - `finance/take-home-pay-calculator.test.ts`: $75,000 every two weeks → $2,256.44
  - `finance/marriage-tax-calculator.test.ts`: $100k + $20k → bonus $3,520
  - Each calculator's `content.example` text must match its test, so recompute both.

## 3. Retirement plan limits

- **File:** `src/lib/calculators/data/us-retirement.ts`
- **Used by:** 401k-calculator, ira-calculator, roth-ira-calculator, take-home-pay-calculator (401(k) cap)
- **Changes:** the IRS announces next year's limits in early November (a newsroom post like "401(k) limit increases to $X for 20XX").

| Constant | 2026 value |
| --- | --- |
| `RETIREMENT_TAX_YEAR` | 2026 |
| `LIMIT_401K.elective` | 24,500 |
| `LIMIT_401K.catchUp50` | 8,000 |
| `LIMIT_401K.catchUp60to63` | 11,250 (SECURE 2.0, ages 60–63) |
| `LIMIT_IRA.base` / `catchUp50` | 7,500 / 1,100 (catch-up now indexed) |
| `ROTH_PHASEOUT.single` | 153,000 – 168,000 |
| `ROTH_PHASEOUT.mfj` | 242,000 – 252,000 |
| `ROTH_PHASEOUT.mfs` | 0 – 10,000 (not indexed) |
| `IRS_LIMITS_SOURCE` | Update the title and URL to the new IRS post |

- **Tests:**
  - `finance/401k-calculator.test.ts`: limits by age
  - `finance/ira-calculator.test.ts`
  - `finance/roth-ira-calculator.test.ts`
- **Note:** `roth-ira-calculator.calc.ts` has a worked example with the result "$3,750 for 2026". Recompute it and update its test.

## 4. Social Security

- **Files:**
  - `src/lib/calculators/finance/social-security-calculator.calc.ts`: `BEND_1`, `BEND_2`
  - `src/lib/calculators/data/us-tax-2026.ts`: `SS_WAGE_BASE`, shared with take-home pay
- **Changes:** SSA announces these with the COLA in mid-October, then publishes them in the Federal Register in early November.

| Constant | 2026 value |
| --- | --- |
| `BEND_1` | 1,286 |
| `BEND_2` | 7,749 |
| `SS_WAGE_BASE` | 184,500 |
| COLA (for reference only, not used) | 2.8% |

- **Sources:**
  - Bend points: <https://www.ssa.gov/oact/cola/bendpoints.html>
  - Wage base: <https://www.ssa.gov/oact/cola/cbb.html>
  - Fact sheet: <https://www.ssa.gov/news/press/factsheets/colafacts.pdf>
- **Tests:** `finance/social-security-calculator.test.ts`. The worked example ($60,000 for 35 years → $2,345 at 67, $1,642 at 62, $2,908 at 70) and the `pia(10000)` case both change with the bend points.
- **Stable:** the full retirement age table and the early/late claiming percentages are set by law.

## 5. Estate and gift tax

- **File:** `src/lib/calculators/finance/estate-tax-calculator.calc.ts`

| Constant | 2026 value | Notes |
| --- | --- | --- |
| `EXEMPTION_2026` | 15,000,000 | OBBBA made it permanent; **indexed from 2027**. Rename the constant per year |
| `ANNUAL_GIFT_EXCLUSION_2026` | 19,000 | Moves in $1,000 steps |
| `SCHEDULE` (§2001(c) rates, 18%–40%) | unchanged since 2013 | Changes only if the law changes |

- **Source:** the same IRS inflation-adjustments release as §2, under "Estate tax basic exclusion amount" and "annual exclusion for gifts".
- **Tests:** `finance/estate-tax-calculator.test.ts`. `tentativeTax(15_000_000)` = 5,945,800 must change to the new exemption's tentative tax; the worked example ($20M estate → $1.8M) also changes.

## 6. IRS standard mileage rate

- **File:** `src/lib/calculators/everyday/mileage-calculator.calc.ts`: the `default: 0.725` input value, plus the `help`, `howTo`, example and FAQ text that say "2026" and "72.5¢"
- **Current:** 72.5¢ per business mile (2026)
- **Changes:** the IRS announces next year's rate in mid/late December (a notice titled "IRS issues standard mileage rates for 20XX").
- **Source:** <https://www.irs.gov/tax-professionals/standard-mileage-rates>
- **Tests:** `everyday/mileage-calculator.test.ts`: 1,250 miles × rate.
- **To do:** move this rate into `data/` the next time it's touched.

## 7. FHA and VA loans

- **File:** `src/lib/calculators/data/us-loans.ts`
- **FHA:**
  - `FHA_UFMIP` 1.75%
  - annual premium rates in `fhaAnnualMip()` (HUD Mortgagee Letter 2023-05)
  - `FHA_MIP_THRESHOLD` 726,200, the loan-size break for the premium
- **VA:** `vaFundingFee()` covers purchase loans: 2.15% / 3.3% (first / subsequent use) with under 5% down, 1.5% with 5–9.99% down, 1.25% with 10%+ down. These rates have applied since April 2023.
- **Changes:** irregular, whenever HUD or VA announces a change. Check once a year in January.
- **Sources:**
  - HUD Mortgagee Letters: <https://www.hud.gov/program_offices/administration/hudclips/letters/mortgagee>
  - VA funding fee: <https://www.va.gov/housing-assistance/home-loans/funding-fee-and-closing-costs/>
- **Tests:** `finance/fha-loan-calculator.test.ts`, `finance/va-mortgage-calculator.test.ts`

## 8. Army body composition standard

- **File:** `src/lib/calculators/health/army-body-fat-calculator.calc.ts`: `WHTR_LIMIT = 0.55`
- **Current:** Army Directive 2026-13 (July 2026). The waist-to-height ratio must be **below 0.55**; it replaced the body fat tape test.
- **Changes:** irregular. The Army changed this standard in 2023, 2025 and 2026. Check every 6 months.
- **Source:** <https://www.army.mil/article/293753/army_modifies_body_composition_program_adopts_waist_to_height_ratio>
- **If it changes:** update the limit, the intro, the FAQs and the directive number in the meta `regionNote` and the disclaimer.

## 9. Stable rules (check once a year)

These rarely change, but confirm once a year (e.g. every January) that they are still current.

| Rule | File | Current basis |
| --- | --- | --- |
| RMD Uniform Lifetime Table | `finance/rmd-calculator.calc.ts` (`ULT`) | IRS Pub. 590-B Table III (in force since 2022) |
| RMD start ages | `finance/rmd-calculator.calc.ts` (`startAge`) | SECURE 2.0: 73 (born 1951–59), 75 (born 1960+) |
| eGFR equation | `health/gfr-calculator.calc.ts` | CKD-EPI 2021 race-free (NKF/ASN) |
| Golf handicap | `everyday/golf-handicap-calculator.calc.ts` | World Handicap System (USGA/R&A rules, 2024 edition) |
| Heat index, wind chill | `everyday/heat-index-calculator.calc.ts`, `everyday/wind-chill-calculator.calc.ts` | NWS formulas |
| Voltage drop resistances | `everyday/voltage-drop-calculator.calc.ts` | NEC Chapter 9, Table 8 |
| Atomic weights | `everyday/molecular-weight-calculator.calc.ts` | IUPAC CIAAW abridged table |
| BAC drink sizes and limits | `health/bac-calculator.calc.ts` | NIAAA, NHS; check country driving limits |
| Exchange rates | `components/widgets/CurrencyConverter.svelte` | Live (open.er-api.com, ECB fallback). Check that both feeds still respond |

---

## How to do an update

1. Get the new figure from the **official source** listed above, not from a blog. Keep the link.
2. Change the constant in the data file. Update the source title and URL if the source moved.
3. Recompute every worked example that uses it (run it in node) and update the example text **and** its test.
4. Search for leftover year text: `grep -rn "2026" src/lib/calculators --include=*.calc.ts`. Labels such as "2026 limit" usually come from the year constant, but FAQs and examples can hard-code it.
5. Set `updated: 'YYYY-MM-DD'` in the meta file of each calculator you touched (it feeds the page's "Updated" date and the sitemap).
6. Run the checks:
   ```sh
   npx vitest run
   npx svelte-check --tsconfig ./tsconfig.json
   npm run build
   ```
7. Add a line to the log below.

## Update log

| Date | What | By |
| --- | --- | --- |
| 2026-10-28 | Initial figures for tax year 2026: brackets, deductions, OBBBA senior deduction and CTC, 401(k)/IRA limits, SSA 2026, estate $15M, CPI to Aug 2026, Army WHtR 0.55 | Claude |
