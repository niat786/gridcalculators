<script lang="ts">
	import AdSlot from '#lib/components/AdSlot.svelte';
	import Breadcrumbs from '#lib/components/Breadcrumbs.svelte';
	import CalculatorTile from '#lib/components/CalculatorTile.svelte';
	import CalculatorView from '#lib/components/calculator/CalculatorView.svelte';
	import Icon from '#lib/components/Icon.svelte';
	import Seo from '#lib/components/Seo.svelte';
	import { breadcrumbs, faqPage, graph, ORG_ID } from '#lib/seo/jsonld.ts';
	import { absoluteUrl } from '#lib/site.ts';
	import type { PageProps } from './$types';

	let { data }: PageProps = $props();

	const meta = $derived(data.config.meta);
	const content = $derived(data.config.content);
	const path = $derived(`/${meta.slug}`);
	const crumbs = $derived([
		{ name: 'Home', path: '/' },
		{ name: data.category.name, path: `/${data.category.slug}` },
		{ name: meta.name, path }
	]);
	const updated = $derived(
		new Date(`${meta.updated}T00:00:00Z`).toLocaleDateString('en-US', {
			year: 'numeric',
			month: 'long',
			day: 'numeric',
			timeZone: 'UTC'
		})
	);

	const jsonLd = $derived(
		graph(
			{
				'@type': 'WebApplication',
				name: meta.name,
				url: absoluteUrl(path),
				description: meta.metaDescription,
				applicationCategory: data.category.schemaCategory,
				operatingSystem: 'Any',
				browserRequirements: 'Requires JavaScript',
				isAccessibleForFree: true,
				offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' },
				dateModified: meta.updated,
				publisher: { '@id': ORG_ID }
			},
			breadcrumbs(crumbs),
			faqPage(content.faq)
		)
	);
</script>

<Seo title={meta.metaTitle} description={meta.metaDescription} {path} {jsonLd} />

<div class="mx-auto max-w-6xl px-4 pt-5 pb-16 sm:px-6 sm:pt-8">
	<Breadcrumbs items={crumbs} />

	<header class="mt-4 mb-6 max-w-3xl sm:mb-8">
		<h1 class="text-large font-bold tracking-tight sm:text-[2.75rem] sm:leading-tight">{meta.name}</h1>
		<p class="mt-2 text-label-2 sm:text-[1.1875rem] sm:leading-relaxed">{content.intro}</p>
	</header>

	{#key meta.slug}
		{#if data.widget && data.config.widget}
			<div class="mx-auto max-w-3xl">
				<data.widget {...data.config.widget.props} label={meta.name} />
			</div>
		{:else}
			<CalculatorView config={data.config} buildDate={data.buildDate} />
		{/if}
	{/key}

	<AdSlot placement="top" size="banner" class="my-10" />

	<div class="mt-12 grid gap-10 lg:grid-cols-[minmax(0,1fr)_300px]">
		<article class="max-w-3xl min-w-0 space-y-12">
			<section aria-labelledby="howto-h">
				<h2 id="howto-h" class="text-title2 font-bold tracking-tight">How to use this calculator</h2>
				<ol class="mt-4 space-y-3">
					{#each content.howTo as step, i (i)}
						<li class="flex gap-3">
							<span class="tabular flex size-7 shrink-0 items-center justify-center rounded-full bg-fill text-footnote font-semibold">{i + 1}</span>
							<span class="pt-0.5">{step}</span>
						</li>
					{/each}
				</ol>
			</section>

			<section aria-labelledby="formula-h">
				<h2 id="formula-h" class="text-title2 font-bold tracking-tight">The formula</h2>
				<div class="mt-4 space-y-4">
					{#each content.formulas as f, i (i)}
						<div class="rounded-card bg-surface p-5">
							{#if f.title}<h3 class="mb-2 text-subhead font-semibold text-label-2">{f.title}</h3>{/if}
							<p class="overflow-x-auto font-mono text-callout leading-relaxed whitespace-pre-line text-label">{f.expression}</p>
							{#if f.variables.length}
								<dl class="mt-4 grid grid-cols-[auto_1fr] gap-x-4 gap-y-1.5 border-t border-separator pt-4 text-subhead">
									{#each f.variables as v (v.symbol)}
										<dt class="font-mono font-semibold">{v.symbol}</dt>
										<dd class="text-label-2">{v.meaning}</dd>
									{/each}
								</dl>
							{/if}
						</div>
					{/each}
				</div>
			</section>

			<section aria-labelledby="example-h">
				<h2 id="example-h" class="text-title2 font-bold tracking-tight">Worked example</h2>
				<p class="mt-2 text-label-2">{content.example.title}</p>
				<ol class="mt-4 space-y-2 rounded-card bg-surface p-5">
					{#each content.example.steps as s, i (i)}
						<li class="tabular flex gap-3 border-b border-separator pb-2 last:border-b-0 last:pb-0">
							<span class="text-label-2">{i + 1}.</span><span>{s}</span>
						</li>
					{/each}
				</ol>
				<p class="mt-4 flex gap-2 font-semibold">
					<Icon name="check" size={20} strokeWidth={2.2} class="mt-0.5 shrink-0 text-accent-text" />{content.example.result}
				</p>
			</section>

			<AdSlot placement="inContent" size="rectangle" class="lg:hidden" />

			<section aria-labelledby="faq-h">
				<h2 id="faq-h" class="text-title2 font-bold tracking-tight">Frequently asked questions</h2>
				<div class="mt-4 overflow-hidden rounded-card bg-surface">
					{#each content.faq as f, i (i)}
						<details class="group {i > 0 ? 'border-t border-separator' : ''}">
							<summary class="flex min-h-14 cursor-pointer list-none items-center justify-between gap-4 px-5 py-3 font-semibold [&::-webkit-details-marker]:hidden">
								<h3>{f.q}</h3>
								<span class="shrink-0 text-label-2 transition-transform group-open:rotate-180"><Icon name="chevronDown" size={20} /></span>
							</summary>
							<p class="px-5 pb-5 text-label-2">{f.a}</p>
						</details>
					{/each}
				</div>
			</section>

			{#if content.sources?.length}
				<section aria-labelledby="sources-h">
					<h2 id="sources-h" class="text-title3 font-semibold">Sources</h2>
					<ul class="mt-3 space-y-2 text-subhead">
						{#each content.sources as s (s.url)}
							<li><a href={s.url} rel="noopener noreferrer nofollow" target="_blank">{s.title}</a></li>
						{/each}
					</ul>
				</section>
			{/if}

			<p class="text-footnote text-label-2">
				Last reviewed <time datetime={meta.updated}>{updated}</time> by the GridCalculators team.
			</p>
		</article>

		<aside class="hidden lg:block" aria-label="Sidebar">
			<div class="sticky top-20">
				<AdSlot placement="sidebar" size="tower" />
			</div>
		</aside>
	</div>

	{#if data.related.length}
		<section aria-labelledby="related-h" class="mt-16">
			<h2 id="related-h" class="mb-4 text-title2 font-bold tracking-tight">Related calculators</h2>
			<ul class="grid gap-3 sm:grid-cols-2 sm:gap-4 lg:grid-cols-3">
				{#each data.related as c (c.slug)}
					<li><CalculatorTile calc={c} /></li>
				{/each}
			</ul>
		</section>
	{/if}
</div>
