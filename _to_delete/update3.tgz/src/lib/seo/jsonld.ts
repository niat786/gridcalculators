import { absoluteUrl, SITE } from '../site';

/**
 * Serialize JSON-LD for a <script type="application/ld+json"> block.
 * Escapes "<", ">" and "&" so content can never close the script tag (XSS-safe).
 */
export function serializeJsonLd(data: unknown): string {
	return JSON.stringify(data)
		.replace(/</g, '\\u003c')
		.replace(/>/g, '\\u003e')
		.replace(/&/g, '\\u0026')
		.replace(/\u2028/g, '\\u2028')
		.replace(/\u2029/g, '\\u2029');
}

export const ORG_ID = `${SITE.origin}/#organization`;
export const WEBSITE_ID = `${SITE.origin}/#website`;

export function organization() {
	return {
		'@type': 'Organization',
		'@id': ORG_ID,
		name: SITE.name,
		url: SITE.origin + '/',
		logo: absoluteUrl('/icon-512.png')
	};
}

export function website() {
	return {
		'@type': 'WebSite',
		'@id': WEBSITE_ID,
		name: SITE.name,
		url: SITE.origin + '/',
		description: SITE.description,
		publisher: { '@id': ORG_ID },
		inLanguage: 'en'
	};
}

export function breadcrumbs(items: { name: string; path: string }[]) {
	return {
		'@type': 'BreadcrumbList',
		itemListElement: items.map((it, i) => ({
			'@type': 'ListItem',
			position: i + 1,
			name: it.name,
			item: absoluteUrl(it.path)
		}))
	};
}

export function faqPage(faq: { q: string; a: string }[]) {
	return {
		'@type': 'FAQPage',
		mainEntity: faq.map((f) => ({
			'@type': 'Question',
			name: f.q,
			acceptedAnswer: { '@type': 'Answer', text: f.a }
		}))
	};
}

export function graph(...nodes: object[]) {
	return { '@context': 'https://schema.org', '@graph': nodes };
}
