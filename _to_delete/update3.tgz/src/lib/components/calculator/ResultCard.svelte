<script lang="ts">
	import type { CalculationResult } from '../../calculators/types';
	import Icon from '../Icon.svelte';
	import Gauge from './Gauge.svelte';

	interface Props {
		result: CalculationResult;
		/** Rows reserved for metrics so the card height never jumps (CLS). */
		metricRows: number;
		onshare: () => void;
		onreset: () => void;
		shared: boolean;
		disclaimer?: string;
	}
	let { result, metricRows, onshare, onreset, shared, disclaimer }: Props = $props();
</script>

<section aria-labelledby="result-label" class="rounded-card bg-surface p-5 sm:p-6">
	<div aria-live="polite" aria-atomic="true">
		<h2 id="result-label" class="text-subhead font-medium text-label-2">{result.primaryLabel}</h2>
		<p class="tabular mt-1 min-h-12 text-[2.5rem] leading-[1.15] font-bold tracking-tight break-words text-accent-text">
			{result.primaryResult}
		</p>
		<p class="mt-1 min-h-[1.375rem] text-subhead text-label-2">{result.summary ?? ''}</p>
	</div>

	{#if result.gauge}
		<div class="mt-4"><Gauge gauge={result.gauge} /></div>
	{/if}

	{#if metricRows > 0}
		<dl class="mt-4 border-t border-separator text-subhead" style="min-height:{metricRows * 2.75}rem">
			{#each result.secondaryMetrics ?? [] as m (m.label)}
				<div class="flex min-h-11 items-center justify-between gap-4 border-b border-separator py-2 last:border-b-0">
					<dt class="text-label-2">{m.label}</dt>
					<dd class="tabular text-right font-semibold text-label">{m.value}</dd>
				</div>
			{/each}
		</dl>
	{/if}

	<div class="mt-5 flex gap-2">
		<button
			type="button"
			onclick={onshare}
			class="flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full bg-accent px-4 text-subhead font-semibold text-white hover:brightness-110 active:brightness-95"
		>
			<Icon name={shared ? 'check' : 'link'} size={18} strokeWidth={2} />
			{shared ? 'Link copied' : 'Share result'}
		</button>
		<button
			type="button"
			onclick={onreset}
			class="flex min-h-11 items-center justify-center gap-2 rounded-full bg-fill px-4 text-subhead font-semibold text-label hover:bg-fill-strong"
		>
			<Icon name="reset" size={18} strokeWidth={2} />
			Reset
		</button>
	</div>

	{#if disclaimer}
		<p class="mt-4 flex gap-2 text-footnote text-label-2">
			<Icon name="info" size={16} class="mt-px shrink-0" />{disclaimer}
		</p>
	{/if}
</section>
