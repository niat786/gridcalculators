import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, pct, plural } from '../format';
import meta from './cd-calculator.meta';

/** Compounding periods per year. */
const PERIODS: Record<string, number> = { annually: 1, quarterly: 4, monthly: 12, daily: 365 };

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'deposit', label: 'Deposit', type: 'number', default: 10000, min: 0, max: 100_000_000, step: 100, prefix: '$' },
		{
			id: 'basis',
			label: 'Rate type',
			type: 'select',
			display: 'segmented',
			default: 'apy',
			options: [
				{ label: 'APY', value: 'apy' },
				{ label: 'APR', value: 'apr' }
			]
		},
		{
			id: 'rate',
			label: 'Rate',
			type: 'number',
			default: 4.5,
			min: 0,
			max: 100,
			step: 0.01,
			suffix: '%',
			help: 'The rate printed on the CD.'
		},
		{ id: 'months', label: 'Term', type: 'number', default: 12, min: 1, max: 360, step: 1, suffix: 'months', decimal: false },
		{
			id: 'compounding',
			label: 'Compounding',
			type: 'select',
			display: 'menu',
			default: 'monthly',
			options: [
				{ label: 'Annually', value: 'annually' },
				{ label: 'Quarterly', value: 'quarterly' },
				{ label: 'Monthly', value: 'monthly' },
				{ label: 'Daily', value: 'daily' }
			]
		}
	],
	calculate(v): CalculationResult {
		const deposit = Number(v.deposit);
		const rate = Number(v.rate);
		const months = Number(v.months);
		const basis = String(v.basis);
		const n = PERIODS[String(v.compounding)];
		if (
			!(deposit >= 0) ||
			!(rate >= 0 && rate <= 100) ||
			!(Number.isInteger(months) && months >= 1 && months <= 360) ||
			(basis !== 'apy' && basis !== 'apr') ||
			n === undefined
		) {
			return { primaryResult: DASH, primaryLabel: 'Value at maturity', summary: 'Check the deposit, rate and term.' };
		}

		const decimalRate = rate / 100;
		let periodRate: number;
		let apy: number;
		if (basis === 'apy') {
			// Convert APY to the rate for one compounding period: (1 + APY)^(1/n) − 1.
			apy = decimalRate;
			periodRate = Math.pow(1 + apy, 1 / n) - 1;
		} else {
			// APR is split evenly across the periods: r ÷ n. APY is what that adds up to.
			periodRate = decimalRate / n;
			apy = Math.pow(1 + periodRate, n) - 1;
		}

		const years = months / 12;
		const maturity = deposit * Math.pow(1 + periodRate, n * years);
		const interest = maturity - deposit;

		return {
			primaryResult: money(maturity),
			primaryLabel: 'Value at maturity',
			summary: `${money(deposit)} for ${plural(months, 'month')} earns ${money(interest)} in interest at ${pct(apy * 100, 3)} APY.`,
			secondaryMetrics: [
				{ label: 'Interest earned', value: money(interest) },
				{ label: 'Annual percentage yield', value: pct(apy * 100, 3) },
				{ label: 'Rate per compounding period', value: pct(periodRate * 100, 4) }
			]
		};
	},
	content: {
		intro:
			'Find out what a certificate of deposit (CD) will be worth when it matures. Enter the deposit, the rate and the term, and see the interest you will earn.',
		howTo: [
			'Enter the amount you will deposit.',
			'Choose APY or APR, depending on which rate the bank quoted, and enter the rate.',
			'Enter the term in months and choose how often interest compounds.',
			'Read the value at maturity and the interest earned.'
		],
		formulas: [
			{
				title: 'APY to a rate per period',
				expression: 'r = (1 + APY)^(1 ÷ n) − 1',
				variables: [
					{ symbol: 'APY', meaning: 'annual percentage yield as a decimal' },
					{ symbol: 'n', meaning: 'compounding periods per year' },
					{ symbol: 'r', meaning: 'rate for one compounding period' }
				]
			},
			{
				title: 'APR to a rate per period',
				expression: 'r = APR ÷ n        APY = (1 + r)ⁿ − 1',
				variables: [
					{ symbol: 'APR', meaning: 'annual percentage rate as a decimal, before compounding' }
				]
			},
			{
				title: 'Value at maturity',
				expression: 'Value = D × (1 + r)^(n × t)',
				variables: [
					{ symbol: 'D', meaning: 'deposit' },
					{ symbol: 't', meaning: 'term in years (months ÷ 12)' }
				]
			}
		],
		example: {
			title: '$10,000 at 4.5% APR for 12 months, compounded monthly',
			steps: [
				'Rate per month: 0.045 ÷ 12 = 0.00375',
				'Periods: 12 months = 12 monthly periods',
				'Value: 10,000 × 1.00375¹² ≈ $10,459.40',
				'Interest earned: $10,459.40 − $10,000 = $459.40',
				'APY: (1.00375)¹² − 1 ≈ 4.594%'
			],
			result:
				'Value at maturity ≈ $10,459.40. The 4.5% APR works out to a 4.594% APY because of monthly compounding.'
		},
		faq: [
			{
				q: 'What is the difference between APY and APR?',
				a: 'APR is the yearly rate before compounding. APY includes the effect of compounding, so it is the better measure for comparing savings products.'
			},
			{
				q: 'Does the compounding choice change an APY result?',
				a: 'No. An APY already includes compounding, so the value at maturity is the same whichever schedule you pick. The schedule only changes the rate per period shown in the results.'
			},
			{
				q: 'What happens if I withdraw early?',
				a: 'Most CDs charge an early withdrawal penalty, which can remove some or all of the interest. This calculator assumes you hold the CD to maturity.'
			},
			{
				q: 'Are CD earnings taxed?',
				a: 'Interest is usually taxable income in the year it is earned, and this calculator does not deduct taxes.'
			}
		],
		sources: [{ title: 'U.S. Securities and Exchange Commission — Investor.gov', url: 'https://www.investor.gov' }],
		disclaimer:
			'Estimates only. Your bank sets the actual rate, penalties and terms, and this tool does not include taxes.'
	}
});
