import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, plural, pct } from '../format';
import meta from './credit-card-payoff-calculator.meta';

/** Safety cap on the month-by-month loop (100 years). */
const MAX_MONTHS = 1200;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Calculate',
			type: 'select',
			display: 'segmented',
			default: 'fixed',
			options: [
				{ label: 'Fixed payment', value: 'fixed' },
				{ label: 'Pay off by date', value: 'target' }
			]
		},
		{
			id: 'balance',
			label: 'Card balance',
			type: 'number',
			default: 5000,
			min: 0,
			max: 100_000_000,
			step: 0.01,
			prefix: '$'
		},
		{
			id: 'apr',
			label: 'APR',
			type: 'number',
			default: 24,
			min: 0,
			max: 100,
			step: 0.01,
			suffix: '%',
			help: 'Annual percentage rate. Interest is charged monthly at APR ÷ 12.'
		},
		{
			id: 'payment',
			label: 'Monthly payment',
			type: 'number',
			default: 200,
			min: 0,
			max: 100_000_000,
			step: 1,
			prefix: '$',
			visibleWhen: (v) => v.mode === 'fixed'
		},
		{
			id: 'months',
			label: 'Months to pay off',
			type: 'number',
			default: 24,
			min: 1,
			max: 600,
			step: 1,
			suffix: 'months',
			decimal: false,
			visibleWhen: (v) => v.mode === 'target'
		}
	],
	calculate(v): CalculationResult {
		const balance = Number(v.balance);
		const apr = Number(v.apr);
		const r = apr / 100 / 12;

		if (!(balance > 0) || !Number.isFinite(balance) || !(apr >= 0 && apr <= 100)) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Time to pay off',
				summary: 'Enter a card balance above zero and an APR from 0% to 100%.'
			};
		}

		if (String(v.mode) === 'target') {
			const n = Number(v.months);
			if (!Number.isInteger(n) || n < 1 || n > 600) {
				return {
					primaryResult: DASH,
					primaryLabel: 'Monthly payment',
					summary: 'Enter a whole number of months from 1 to 600.'
				};
			}
			// Level payment: P = B × r ÷ (1 − (1 + r)^−n); with no interest, P = B ÷ n.
			const payment = r === 0 ? balance / n : (balance * r) / (1 - Math.pow(1 + r, -n));
			const total = payment * n;
			const firstInterest = balance * r;
			return {
				primaryResult: money(payment),
				primaryLabel: 'Monthly payment',
				summary: `Pay ${money(payment)} a month for ${plural(n, 'month')} to clear ${money(balance)}.`,
				secondaryMetrics: [
					{ label: 'Total interest', value: money(total - balance) },
					{ label: 'Total paid', value: money(total) },
					{ label: 'First month interest', value: money(firstInterest) }
				]
			};
		}

		const payment = Number(v.payment);
		if (!Number.isFinite(payment) || !(payment > 0)) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Time to pay off',
				summary: 'Enter a monthly payment above zero.'
			};
		}

		const firstInterest = balance * r;
		if (payment <= firstInterest) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Time to pay off',
				summary: `Interest alone is ${money(firstInterest)} a month, so a payment of ${money(payment)} never pays off the balance. Increase the payment.`
			};
		}

		// Step through each month: add interest, then subtract the payment (the last one may be smaller).
		let bal = balance;
		let months = 0;
		let interest = 0;
		let lastPayment = 0;
		while (bal > 0.005 && months < MAX_MONTHS) {
			const monthInterest = bal * r;
			interest += monthInterest;
			bal += monthInterest;
			const pay = Math.min(payment, bal);
			bal -= pay;
			lastPayment = pay;
			months++;
		}

		if (bal > 0.005) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Time to pay off',
				summary: 'At this payment the balance would take more than 100 years to clear. Increase the payment.'
			};
		}

		return {
			primaryResult: plural(months, 'month'),
			primaryLabel: 'Time to pay off',
			summary: `Paying ${money(payment)} a month clears ${money(balance)} in ${plural(months, 'month')}.`,
			secondaryMetrics: [
				{ label: 'Total interest', value: money(interest) },
				{ label: 'Total paid', value: money(balance + interest) },
				{ label: 'Final payment', value: money(lastPayment) }
			]
		};
	},
	content: {
		intro:
			'See how long it will take to clear a credit card at a fixed monthly payment, and how much interest that costs. Or work out the payment you need to be debt-free by a certain date.',
		howTo: [
			'Pick Fixed payment to find the payoff time for a payment you can make, or Pay off by date to find the payment for a deadline.',
			'Enter the card balance and the APR from your statement.',
			'Enter your monthly payment, or the number of months you want to take.',
			'Read the time to pay off, the total interest, and the total paid.'
		],
		formulas: [
			{
				title: 'Monthly interest',
				expression: 'Interest for the month = Balance × (APR ÷ 12 ÷ 100)',
				variables: [{ symbol: 'APR', meaning: 'annual percentage rate on the card' }]
			},
			{
				title: 'Months to pay off with a fixed payment',
				expression: 'n = −ln(1 − B × r ÷ P) ÷ ln(1 + r), rounded up',
				variables: [
					{ symbol: 'n', meaning: 'number of monthly payments' },
					{ symbol: 'B', meaning: 'card balance' },
					{ symbol: 'r', meaning: 'monthly interest rate (APR ÷ 12 ÷ 100)' },
					{ symbol: 'P', meaning: 'monthly payment' }
				]
			},
			{
				title: 'Payment for a set number of months',
				expression: 'P = B × r ÷ (1 − (1 + r)⁻ⁿ)',
				variables: [{ symbol: 'n', meaning: 'number of months to pay off' }]
			}
		],
		example: {
			title: 'A $5,000 balance at 24% APR with $200 a month',
			steps: [
				'Monthly rate: 24 ÷ 12 ÷ 100 = 0.02',
				'First month interest: $5,000 × 0.02 = $100, which is less than the $200 payment',
				'Each month, add interest to the balance, then subtract $200',
				'The card is cleared in 36 months, and the final payment is $0.56'
			],
			result: 'Paid off in 36 months. Total interest $2,000.56.'
		},
		faq: [
			{
				q: 'Why does a small payment take so long?',
				a: 'Interest is added to the balance every month. When the payment is only slightly above the monthly interest, most of it goes to interest and the balance falls slowly.'
			},
			{
				q: 'What happens if my payment is less than the monthly interest?',
				a: 'The balance grows every month, so the card is never paid off. The calculator shows a dash in that case. Increase the payment to at least the first month interest.'
			},
			{
				q: 'Does this include new purchases?',
				a: 'No. It assumes the balance is fixed, the APR does not change, and you make no new charges or fees. Adding new spending will extend the payoff time.'
			},
			{
				q: 'How is the monthly interest worked out?',
				a: 'This calculator divides the APR by 12 and applies it to the balance each month. Card issuers often use the average daily balance, so your statement can differ slightly.'
			}
		],
		sources: [{ title: 'Consumer Financial Protection Bureau', url: 'https://www.consumerfinance.gov/' }],
		disclaimer:
			'Estimates only. Assumes a fixed APR, no new charges and no fees. Your card issuer statements are the final word.'
	}
});
