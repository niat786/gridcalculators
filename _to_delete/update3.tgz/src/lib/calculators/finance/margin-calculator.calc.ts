import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct } from '../format';
import meta from './margin-calculator.meta';

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Calculate from',
			type: 'select',
			display: 'segmented',
			default: 'price',
			options: [
				{ label: 'Cost and price', value: 'price' },
				{ label: 'Cost and margin', value: 'margin' }
			]
		},
		{
			id: 'cost',
			label: 'Cost per unit',
			type: 'number',
			default: 60,
			min: 0,
			max: 100_000_000,
			step: 0.01,
			prefix: '$'
		},
		{
			id: 'price',
			label: 'Selling price',
			type: 'number',
			default: 100,
			min: 0,
			max: 100_000_000,
			step: 0.01,
			prefix: '$',
			visibleWhen: (v) => v.mode === 'price'
		},
		{
			id: 'margin',
			label: 'Target margin',
			type: 'number',
			default: 40,
			min: 0,
			max: 99.99,
			step: 0.01,
			suffix: '%',
			help: 'Must be below 100%.',
			visibleWhen: (v) => v.mode === 'margin'
		}
	],
	calculate(v): CalculationResult {
		const cost = Number(v.cost);
		const validCost = Number.isFinite(cost) && cost > 0;

		if (String(v.mode) === 'margin') {
			const m = Number(v.margin);
			if (!validCost || !(m >= 0 && m < 100)) {
				return {
					primaryResult: DASH,
					primaryLabel: 'Selling price',
					summary: 'Enter a cost above zero and a margin from 0% up to, but not including, 100%.'
				};
			}
			// Margin = (price − cost) ÷ price, so price = cost ÷ (1 − margin).
			const price = cost / (1 - m / 100);
			const profit = price - cost;
			const markup = (profit / cost) * 100;
			return {
				primaryResult: money(price),
				primaryLabel: 'Selling price',
				summary: `Selling at ${money(price)} keeps ${pct(m)} of each sale as gross margin.`,
				secondaryMetrics: [
					{ label: 'Profit per unit', value: money(profit) },
					{ label: 'Gross margin', value: pct(m) },
					{ label: 'Markup', value: pct(markup) }
				]
			};
		}

		const price = Number(v.price);
		if (!validCost || !Number.isFinite(price) || !(price > 0)) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Profit per unit',
				summary: 'Enter a cost above zero and a selling price above zero.'
			};
		}
		const profit = price - cost;
		const margin = (profit / price) * 100;
		const markup = (profit / cost) * 100;
		return {
			primaryResult: money(profit),
			primaryLabel: 'Profit per unit',
			summary: `Each sale earns ${money(profit)}, a ${pct(margin)} margin on the selling price.`,
			secondaryMetrics: [
				{ label: 'Gross margin', value: pct(margin) },
				{ label: 'Markup', value: pct(markup) },
				{ label: 'Selling price', value: money(price) }
			]
		};
	},
	content: {
		intro:
			'Work out your profit, gross margin and markup from the cost and selling price of a product, or find the price you need to hit a target margin.',
		howTo: [
			'Pick Cost and price to check the margin on a price you already have, or Cost and margin to find the price for a target.',
			'Enter the cost per unit, then the selling price or the target margin.',
			'Read the profit, the margin and the markup. Keep the margin below 100%.'
		],
		formulas: [
			{
				title: 'Profit and margin',
				expression: 'Profit = Selling price − Cost',
				variables: [
					{ symbol: 'Profit', meaning: 'money kept on each sale before other costs' }
				]
			},
			{
				expression: 'Gross margin = Profit ÷ Selling price × 100',
				variables: [{ symbol: '%', meaning: 'share of the selling price kept as profit' }]
			},
			{
				title: 'Markup',
				expression: 'Markup = Profit ÷ Cost × 100',
				variables: [{ symbol: '%', meaning: 'profit as a share of what the item cost' }]
			},
			{
				title: 'Price from a target margin',
				expression: 'Selling price = Cost ÷ (1 − Margin ÷ 100)',
				variables: [{ symbol: 'Margin', meaning: 'target gross margin as a percentage' }]
			}
		],
		example: {
			title: 'A product costs $60 and sells for $100',
			steps: [
				'Profit: $100 − $60 = $40',
				'Gross margin: $40 ÷ $100 × 100 = 40%',
				'Markup: $40 ÷ $60 × 100 = 66.67%'
			],
			result: 'Profit $40.00 per unit, gross margin 40%, markup 66.67%.'
		},
		faq: [
			{
				q: 'What is the difference between margin and markup?',
				a: 'Margin is profit as a share of the selling price. Markup is profit as a share of the cost. The same sale can show a 40% margin and a 66.67% markup.'
			},
			{
				q: 'Why must the margin be below 100%?',
				a: 'A 100% margin would need a selling price of cost divided by zero, which has no answer. Any margin below 100% gives a finite price.'
			},
			{
				q: 'What margin should I aim for?',
				a: 'That depends on your industry, overheads and competitors. Check that your margin covers rent, staff, shipping and other running costs before you choose a price.'
			},
			{
				q: 'Does this include fees, shipping or returns?',
				a: 'No. Enter a cost that already includes those items if you want the margin after them. Otherwise the result shows only the product cost against the price.'
			}
		],
		sources: [{ title: 'U.S. Small Business Administration', url: 'https://www.sba.gov/' }],
		disclaimer:
			'Estimates only. Real margins also depend on fees, shipping, returns and taxes that this calculator does not include.'
	}
});
