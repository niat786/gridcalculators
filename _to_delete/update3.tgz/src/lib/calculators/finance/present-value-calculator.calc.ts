import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './present-value-calculator.meta';

/**
 * Inverse of the future value calculator: solve PV from FV = PV × (1 + r)ⁿ + PMT × annuity.
 * Payments you add each period reduce the lump sum needed today.
 */
export default defineCalculator({
	meta,
	inputs: [
		{ id: 'fv', label: 'Future value', type: 'number', default: 10000, min: 0, max: 1_000_000_000, step: 100, prefix: '$', help: 'The amount you want to reach.' },
		{ id: 'rate', label: 'Interest rate per period', type: 'number', default: 0.5, min: 0, max: 100, step: 0.01, suffix: '%' },
		{ id: 'periods', label: 'Number of periods', type: 'number', default: 120, min: 1, max: 10_000, step: 1, decimal: false },
		{
			id: 'pmt',
			label: 'Payment per period',
			type: 'number',
			default: 0,
			min: 0,
			max: 1_000_000_000,
			step: 10,
			prefix: '$',
			help: 'Amount you add each period. Leave at 0 for none.'
		},
		{
			id: 'timing',
			label: 'Payment timing',
			type: 'select',
			display: 'segmented',
			default: 'end',
			options: [
				{ label: 'End', value: 'end' },
				{ label: 'Beginning', value: 'beginning' }
			]
		}
	],
	calculate(v): CalculationResult {
		const fv = Number(v.fv);
		const rate = Number(v.rate);
		const n = Number(v.periods);
		const pmt = Number(v.pmt);
		const timing = String(v.timing);
		if (
			!(fv >= 0) ||
			!(pmt >= 0) ||
			!(rate >= 0 && rate <= 100) ||
			!(Number.isInteger(n) && n >= 1 && n <= 10_000) ||
			(timing !== 'end' && timing !== 'beginning')
		) {
			return { primaryResult: DASH, primaryLabel: 'Present value', summary: 'Check the amounts, rate and periods.' };
		}

		const r = rate / 100;
		const due = timing === 'beginning' ? 1 + r : 1;
		const growth = Math.pow(1 + r, n);
		const annuity = r === 0 ? n : ((growth - 1) / r) * due;
		const pv = (fv - pmt * annuity) / growth;
		const paymentsTotal = pmt * n;

		return {
			primaryResult: money(pv),
			primaryLabel: 'Present value',
			summary:
				pv >= 0
					? `You need ${money(pv)} today to reach ${money(fv)} in ${plural(n, 'period')}.`
					: `Your payments alone pass the goal, so no lump sum is needed.`,
			secondaryMetrics: [
				{ label: 'Payments you add', value: money(paymentsTotal) },
				{ label: 'Growth from interest', value: money(fv - pv - paymentsTotal) },
				{ label: 'Discount factor', value: num(1 / growth, 6) }
			]
		};
	},
	content: {
		intro:
			'Find out how much you would need to invest today to reach a future amount. Add regular payments to see how they reduce the lump sum you need.',
		howTo: [
			'Enter the future amount you want to reach.',
			'Enter the interest rate for one period, such as a monthly rate.',
			'Enter the number of periods until the goal date.',
			'Add any payment you will make each period, then choose end or beginning timing.'
		],
		formulas: [
			{
				title: 'Present value with payments',
				expression: 'PV = (FV − PMT × ((1 + r)ⁿ − 1) ÷ r × (1 + r × t)) ÷ (1 + r)ⁿ',
				variables: [
					{ symbol: 'PV', meaning: 'present value, the amount needed today' },
					{ symbol: 'FV', meaning: 'future value you want to reach' },
					{ symbol: 'PMT', meaning: 'payment added each period' },
					{ symbol: 'r', meaning: 'interest rate per period as a decimal' },
					{ symbol: 'n', meaning: 'number of periods' },
					{ symbol: 't', meaning: '1 if payments are at the beginning of each period, otherwise 0' }
				]
			}
		],
		example: {
			title: 'A $10,000 goal in 120 months at 0.5% per month, with no payments',
			steps: [
				'Growth factor: 1.005¹²⁰ ≈ 1.819397',
				'Discount factor: 1 ÷ 1.819397 ≈ 0.549633',
				'Present value: $10,000 × 0.549633 ≈ $5,496.33'
			],
			result: 'Present value ≈ $5,496.33. Invest that amount today and it grows to $10,000 in 120 months.'
		},
		faq: [
			{
				q: 'What is present value?',
				a: 'Present value is what a future amount is worth today. Because money can earn interest, a dollar you receive later is worth less than a dollar now.'
			},
			{
				q: 'What does a negative result mean?',
				a: 'If the payments you add already reach the future amount, the calculator returns a negative value. No lump sum is needed in that case.'
			},
			{
				q: 'Why must the rate and periods match?',
				a: 'The rate is applied once per period, so the number of periods must count the same unit. A yearly rate needs a number of years.'
			},
			{
				q: 'How is this different from the future value calculator?',
				a: 'The future value calculator grows a starting amount forward in time. This calculator works backward from a goal to the amount you need today, using the same formula.'
			}
		],
		sources: [{ title: 'U.S. Securities and Exchange Commission — Investor.gov', url: 'https://www.investor.gov' }],
		disclaimer:
			'Estimates only. The discount rate you choose drives the result, and actual returns can differ.'
	}
});
