import { defineCalculator, type CalculationResult } from '../types';
import { DASH, num, pct } from '../format';
import meta from './vat-calculator.meta';

/** Round to whole cents (or the smallest unit) so the displayed amounts always add up. */
const cents = (n: number) => Math.round(n * 100) / 100;
/** Currency-neutral amount: two decimals, no currency symbol. */
const amt = (n: number) => num(n, 2, 2);

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Calculation',
			type: 'select',
			display: 'segmented',
			default: 'add',
			options: [
				{ label: 'Add VAT', value: 'add' },
				{ label: 'Remove VAT', value: 'remove' }
			]
		},
		{
			id: 'amount',
			label: 'Amount',
			type: 'number',
			default: 250,
			min: 0,
			max: 100_000_000,
			step: 0.01,
			help: 'Net (excluding VAT) in Add VAT mode. Gross (including VAT) in Remove VAT mode.'
		},
		{ id: 'rate', label: 'VAT rate', type: 'number', default: 20, min: 0, max: 100, step: 0.01, suffix: '%' }
	],
	calculate(v): CalculationResult {
		const remove = String(v.mode) === 'remove';
		const label = remove ? 'Net amount (excl. VAT)' : 'Gross amount (incl. VAT)';
		const amount = Number(v.amount);
		const rate = Number(v.rate);

		if (!(amount >= 0) || !Number.isFinite(amount) || !(rate >= 0 && rate <= 100)) {
			return {
				primaryResult: DASH,
				primaryLabel: label,
				summary: 'Enter an amount of zero or more and a VAT rate from 0% to 100%.'
			};
		}

		if (!remove) {
			const vat = cents((amount * rate) / 100);
			const gross = cents(amount + vat);
			return {
				primaryResult: amt(gross),
				primaryLabel: label,
				summary: `VAT at ${pct(rate)} on a net amount of ${amt(amount)} is ${amt(vat)}.`,
				secondaryMetrics: [
					{ label: 'Net amount', value: amt(amount) },
					{ label: 'VAT', value: amt(vat) }
				]
			};
		}

		const net = cents(amount / (1 + rate / 100));
		const vat = cents(amount - net);
		return {
			primaryResult: amt(net),
			primaryLabel: label,
			summary: `The VAT inside a gross amount of ${amt(amount)} at ${pct(rate)} is ${amt(vat)}.`,
			secondaryMetrics: [
				{ label: 'VAT', value: amt(vat) },
				{ label: 'Gross amount', value: amt(amount) }
			]
		};
	},
	content: {
		intro:
			'Add VAT to a net price, or pull the VAT out of a gross price to see the net amount. Enter any VAT rate and the calculator works in any currency.',
		howTo: [
			'Pick Add VAT if you have a price before VAT, or Remove VAT if you have a price that already includes it.',
			'Enter the amount and the VAT rate that applies to the item.',
			'Read the VAT and the gross or net amount in the result.'
		],
		formulas: [
			{
				title: 'Adding VAT',
				expression: 'VAT = Net amount × r ÷ 100',
				variables: [
					{ symbol: 'r', meaning: 'VAT rate as a percentage' },
					{ symbol: 'Net amount', meaning: 'amount before VAT' }
				]
			},
			{
				expression: 'Gross amount = Net amount + VAT',
				variables: []
			},
			{
				title: 'Removing VAT',
				expression: 'Net amount = Gross amount ÷ (1 + r ÷ 100)',
				variables: [{ symbol: 'Gross amount', meaning: 'amount that already includes VAT' }]
			},
			{
				expression: 'VAT = Gross amount − Net amount',
				variables: []
			}
		],
		example: {
			title: 'A net amount of 250 with 20% VAT',
			steps: [
				'VAT: 250 × 20 ÷ 100 = 50.00',
				'Gross amount: 250 + 50.00 = 300.00',
				'Check by removing VAT: 300 ÷ 1.20 = 250.00',
				'VAT from the gross amount: 300.00 − 250.00 = 50.00'
			],
			result: 'Gross amount 300.00 including VAT of 50.00.'
		},
		faq: [
			{
				q: 'What is the difference between net and gross?',
				a: 'Net is the amount before VAT and gross is the amount with VAT added. Gross is what the buyer pays, and net is what the seller keeps before passing VAT on.'
			},
			{
				q: 'Do shop prices show VAT included or added?',
				a: 'It depends on the country and the type of sale. Many consumer prices include VAT, while business-to-business prices are often shown before VAT. Check the price label.'
			},
			{
				q: 'Why do VAT rates differ between countries?',
				a: 'Each government sets its own VAT rate. Many also apply lower or zero rates to some goods and services, such as food or books.'
			},
			{
				q: 'Can I use this for GST or other sales taxes?',
				a: 'Yes, enter the rate for the tax you need. GST and sales tax can have different rules, so confirm the treatment with your local tax authority.'
			}
		],
		sources: [
			{ title: 'European Commission: Taxation and customs', url: 'https://taxation-customs.ec.europa.eu/' },
			{ title: 'GOV.UK: VAT rates', url: 'https://www.gov.uk/vat-rates' }
		],
		disclaimer:
			'Estimates only. VAT rules and rates vary by country, product and business status, so check official guidance before you invoice or file.'
	}
});
