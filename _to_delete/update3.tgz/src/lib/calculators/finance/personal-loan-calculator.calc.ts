import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './personal-loan-calculator.meta';

/** Fixed-rate payment: M = P·r(1+r)^n / ((1+r)^n − 1); r = 0 → P / n. */
function payment(principal: number, annualRatePct: number, months: number): number {
	const r = annualRatePct / 1200;
	if (r === 0) return principal / months;
	const f = Math.pow(1 + r, months);
	return (principal * r * f) / (f - 1);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'amount', label: 'Loan amount', type: 'number', default: 10000, min: 1, max: 10_000_000, step: 100, prefix: '$' },
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 11.5, min: 0, max: 100, step: 0.01, suffix: '%', help: 'Annual rate' },
		{ id: 'months', label: 'Loan term', type: 'number', default: 36, min: 1, max: 360, step: 1, suffix: 'months', decimal: false },
		{ id: 'fee', label: 'Origination fee', type: 'number', default: 3, min: 0, max: 20, step: 0.1, suffix: '%', help: 'Taken out of the loan before you receive it' }
	],
	calculate(v): CalculationResult {
		const amount = Number(v.amount);
		const rate = Number(v.rate);
		const n = Number(v.months);
		const feePct = Number(v.fee) || 0;

		if (
			!(amount > 0) ||
			!Number.isFinite(amount) ||
			!(rate >= 0 && rate <= 100) ||
			!Number.isInteger(n) ||
			!(n >= 1 && n <= 360) ||
			!(feePct >= 0 && feePct <= 100)
		) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Monthly payment',
				summary: 'Enter a loan amount and a term of 1 to 360 months.'
			};
		}

		const monthly = payment(amount, rate, n);
		const fee = amount * (feePct / 100);
		const net = amount - fee;
		const totalPaid = monthly * n;
		const totalInterest = Math.max(0, totalPaid - amount);

		return {
			primaryResult: money(monthly),
			primaryLabel: 'Monthly payment',
			summary: `You repay ${money(amount, true)} plus interest over ${n} months. You receive ${money(net, true)}.`,
			secondaryMetrics: [
				{ label: 'Origination fee', value: money(fee) },
				{ label: 'Net amount received', value: money(net) },
				{ label: 'Total interest', value: money(totalInterest) },
				{ label: 'Total paid', value: money(totalPaid) }
			]
		};
	},
	content: {
		intro:
			'Estimate the monthly payment on a personal loan, and see how an origination fee lowers the cash you actually receive while your repayments stay based on the full amount.',
		howTo: [
			'Enter the amount you plan to borrow and the annual interest rate.',
			'Enter the loan term in months.',
			'Enter the origination fee percentage from your loan offer, or 0 if there is none.',
			'Compare the monthly payment with the net amount you will receive.'
		],
		formulas: [
			{
				title: 'Monthly payment',
				expression: 'M = P × r(1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'M', meaning: 'monthly payment' },
					{ symbol: 'P', meaning: 'loan amount (you repay the full amount, not the net)' },
					{ symbol: 'r', meaning: 'monthly interest rate (annual rate ÷ 12 ÷ 100)' },
					{ symbol: 'n', meaning: 'number of monthly payments (the term in months)' }
				]
			},
			{
				title: 'Fee and net amount',
				expression: 'Origination fee = P × fee% ÷ 100        Net received = P − origination fee',
				variables: []
			}
		],
		example: {
			title: 'A $10,000 loan at 11.5% for 36 months with a 3% fee',
			steps: [
				'Monthly rate: r = 11.5 ÷ 12 ÷ 100 = 0.0095833',
				'Growth factor: (1 + r)³⁶ ≈ 1.4097',
				'M = 10,000 × 0.0095833 × 1.4097 ÷ (1.4097 − 1) ≈ $329.76',
				'Origination fee = $10,000 × 3% = $300, so net received = $9,700',
				'Total interest = 329.76 × 36 − $10,000 = $1,871.36'
			],
			result: 'Monthly payment of $329.76. You receive $9,700 after the $300 fee.'
		},
		faq: [
			{
				q: 'Why do I repay more than I receive?',
				a: 'An origination fee is taken out of the loan before the money reaches you. You still repay the full loan amount plus interest, so the fee adds to your cost.'
			},
			{
				q: 'Is the fee included in the monthly payment?',
				a: 'No. The monthly payment is based on the full loan amount. The fee only reduces the cash you receive, so you can compare offers by the fee and the payment together.'
			},
			{
				q: 'How does a longer term change the cost?',
				a: 'A longer term lowers the monthly payment, but you pay interest for more months, so the total interest rises.'
			},
			{
				q: 'Can I get a personal loan with no fee?',
				a: 'Some lenders charge no origination fee. Enter 0% for those loans. Always read the full offer, because other charges can apply.'
			}
		],
		sources: [
			{
				title: 'Consumer Financial Protection Bureau',
				url: 'https://www.consumerfinance.gov/'
			}
		],
		disclaimer:
			'Estimates only. Your actual rate, fees and approval depend on your credit and the lender’s terms.'
	}
});
