import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './amortization-calculator.meta';

/** Fixed-rate payment: M = P·r(1+r)^n / ((1+r)^n − 1); r = 0 → P / n. */
function payment(principal: number, annualRatePct: number, months: number): number {
	const r = annualRatePct / 1200;
	if (r === 0) return principal / months;
	const f = Math.pow(1 + r, months);
	return (principal * r * f) / (f - 1);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'amount', label: 'Loan amount', type: 'number', default: 200000, min: 1, max: 100_000_000, step: 1000, prefix: '$' },
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 6, min: 0, max: 100, step: 0.01, suffix: '%', help: 'Annual rate' },
		{ id: 'years', label: 'Loan term', type: 'number', default: 30, min: 1, max: 50, step: 1, suffix: 'years', decimal: false }
	],
	calculate(v): CalculationResult {
		const principal = Number(v.amount);
		const rate = Number(v.rate);
		const years = Number(v.years);

		if (
			!(principal > 0) ||
			!Number.isFinite(principal) ||
			!(rate >= 0 && rate <= 100) ||
			!Number.isInteger(years) ||
			!(years >= 1 && years <= 50)
		) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Monthly payment',
				summary: 'Enter a loan amount, an interest rate from 0% to 100%, and a term from 1 to 50 years.'
			};
		}

		const n = years * 12;
		const monthly = payment(principal, rate, n);
		const totalPaid = monthly * n;
		const totalInterest = Math.max(0, totalPaid - principal);

		// Month-by-month schedule. The last payment clears whatever balance is left.
		const r = rate / 1200;
		let balance = principal;
		let cumInterest = 0;
		const rows: Record<string, string>[] = [];
		const chartData: Record<string, number>[] = [{ year: 0, balance: principal, interest: 0 }];
		for (let m = 1; m <= n; m++) {
			const interest = balance * r;
			const principalPart = m === n ? balance : Math.min(monthly - interest, balance);
			balance -= principalPart;
			cumInterest += interest;
			if (Math.abs(balance) < 0.005) balance = 0;
			rows.push({
				month: String(m),
				payment: money(interest + principalPart),
				principal: money(principalPart),
				interest: money(interest),
				balance: money(balance)
			});
			if (m % 12 === 0) chartData.push({ year: m / 12, balance, interest: cumInterest });
		}

		return {
			primaryResult: money(monthly),
			primaryLabel: 'Monthly payment',
			summary: `${money(principal, true)} at ${num(rate, 3)}% repaid over ${plural(years, 'year')}.`,
			secondaryMetrics: [
				{ label: 'Total of payments', value: money(totalPaid) },
				{ label: 'Total interest', value: money(totalInterest) },
				{ label: 'Number of payments', value: plural(n, 'payment') }
			],
			chart: {
				type: 'line',
				title: 'Loan balance and interest paid over time',
				x: 'year',
				xLabel: 'Year',
				series: [
					{ key: 'balance', label: 'Remaining balance' },
					{ key: 'interest', label: 'Total interest paid' }
				],
				data: chartData,
				valueFormat: 'currency'
			},
			table: {
				title: 'Amortization schedule (monthly)',
				collapsed: true,
				columns: [
					{ key: 'month', label: 'Month' },
					{ key: 'payment', label: 'Payment', align: 'end' },
					{ key: 'principal', label: 'Principal', align: 'end' },
					{ key: 'interest', label: 'Interest', align: 'end' },
					{ key: 'balance', label: 'Balance', align: 'end' }
				],
				rows
			}
		};
	},
	content: {
		intro:
			'Build a full amortization schedule for a fixed-rate loan. See the monthly payment, how each payment splits into interest and principal, and how the balance falls over time.',
		howTo: [
			'Enter the loan amount and the annual interest rate.',
			'Enter the loan term in years.',
			'Read the monthly payment and the totals.',
			'Open the monthly schedule to see the interest and principal in each payment, and use the chart to compare the balance with the interest paid.'
		],
		formulas: [
			{
				title: 'Monthly payment',
				expression: 'M = P × r(1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'M', meaning: 'monthly payment' },
					{ symbol: 'P', meaning: 'loan amount' },
					{ symbol: 'r', meaning: 'monthly interest rate (annual rate ÷ 12 ÷ 100)' },
					{ symbol: 'n', meaning: 'number of monthly payments (years × 12)' }
				]
			},
			{
				title: 'Each month',
				expression: 'Interest = balance × r        Principal = M − interest        New balance = balance − principal',
				variables: []
			}
		],
		example: {
			title: 'A $200,000 loan at 6% over 30 years',
			steps: [
				'Monthly rate: r = 6 ÷ 12 ÷ 100 = 0.005, n = 30 × 12 = 360',
				'M = 200,000 × 0.005 × 1.005³⁶⁰ ÷ (1.005³⁶⁰ − 1) ≈ $1,199.10',
				'Month 1 interest = 200,000 × 0.005 = $1,000.00, so principal = $1,199.10 − $1,000.00 = $199.10',
				'Total of payments = 1,199.1011 × 360 ≈ $431,676.38, so total interest = $231,676.38'
			],
			result: 'Monthly payment of $1,199.10. Total interest of $231,676.38 over 360 payments.'
		},
		faq: [
			{
				q: 'Why does most of my early payment go to interest?',
				a: 'Interest is charged on the balance you still owe. Early on the balance is high, so most of each payment covers interest. As the balance falls, more of each payment reduces principal.'
			},
			{
				q: 'What is the difference between amortization and a payoff?',
				a: 'Amortization is the schedule of regular payments that repays a loan by its end date. A payoff is paying the remaining balance early, which this calculator does not model.'
			},
			{
				q: 'Why does the last payment differ by a few cents?',
				a: 'Each payment is rounded to the cent, so the final payment absorbs the small difference to bring the balance to exactly zero.'
			},
			{
				q: 'Does this include taxes or insurance?',
				a: 'No. The schedule covers principal and interest only.'
			}
		],
		sources: [
			{
				title: 'Consumer Financial Protection Bureau',
				url: 'https://www.consumerfinance.gov/'
			}
		],
		disclaimer:
			'Estimates only. Your actual payment schedule is set by your lender and may differ slightly.'
	}
});
