import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, pct } from '../format';
import meta from './roi-calculator.meta';

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'invested',
			label: 'Amount invested',
			type: 'number',
			default: 10000,
			min: 0,
			max: 1_000_000_000_000,
			step: 100,
			prefix: '$'
		},
		{
			id: 'returned',
			label: 'Amount returned',
			type: 'number',
			default: 14000,
			min: 0,
			max: 1_000_000_000_000,
			step: 100,
			prefix: '$',
			help: 'What the investment is worth at the end, including any income you kept.'
		},
		{
			id: 'years',
			label: 'Investment length',
			type: 'number',
			default: 1,
			min: 0.01,
			max: 100,
			step: 0.5,
			suffix: 'years',
			help: 'Optional. Leave blank to treat it as 1 year.'
		}
	],
	calculate(v): CalculationResult {
		const invested = Number(v.invested);
		const returned = Number(v.returned);
		const yearsInput = Number(v.years);
		const years = Number.isNaN(yearsInput) ? 1 : yearsInput;

		if (
			!(invested > 0) ||
			!Number.isFinite(invested) ||
			!(returned >= 0) ||
			!Number.isFinite(returned) ||
			!(years > 0 && years <= 100)
		) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Return on investment',
				summary: 'Enter an amount invested above zero, an amount returned, and a length up to 100 years.'
			};
		}

		const gain = returned - invested;
		const roi = (gain / invested) * 100;
		// Annualized ROI = (returned ÷ invested)^(1 ÷ years) − 1
		const annualized = (Math.pow(returned / invested, 1 / years) - 1) * 100;
		const length = years === 1 ? '1 year' : `${num(years, 2)} years`;

		return {
			primaryResult: pct(roi),
			primaryLabel: 'Return on investment',
			summary: `You ${gain >= 0 ? 'gained' : 'lost'} ${money(Math.abs(gain))} over ${length}.`,
			secondaryMetrics: [
				{ label: 'Gain or loss', value: money(gain) },
				{ label: 'Annualized ROI', value: pct(annualized) },
				{ label: 'Investment length', value: length }
			]
		};
	},
	content: {
		intro:
			'Find out how much an investment returned compared with what you put in. See your total return as a percentage, the money you gained or lost, and the yearly rate it averaged.',
		howTo: [
			'Enter the amount you invested, including any fees you paid to buy in.',
			'Enter what the investment is worth at the end, including income you kept.',
			'Enter how many years you held it, or leave it blank for one year.',
			'Read the ROI, the gain or loss, and the annualized ROI.'
		],
		formulas: [
			{
				title: 'Return on investment',
				expression: 'ROI = (Returned − Invested) ÷ Invested × 100',
				variables: [
					{ symbol: 'Invested', meaning: 'amount you put in' },
					{ symbol: 'Returned', meaning: 'value at the end of the period' }
				]
			},
			{
				title: 'Annualized ROI',
				expression: 'Annualized ROI = (Returned ÷ Invested)^(1 ÷ years) − 1',
				variables: [{ symbol: 'years', meaning: 'length of the investment in years' }]
			}
		],
		example: {
			title: '$10,000 invested and worth $14,000 after 2 years',
			steps: [
				'ROI: ($14,000 − $10,000) ÷ $10,000 × 100 = 40%',
				'Gain: $14,000 − $10,000 = $4,000',
				'Annualized: (14,000 ÷ 10,000)^(1 ÷ 2) − 1 = √1.4 − 1 ≈ 0.1832',
				'Annualized ROI ≈ 18.32% a year'
			],
			result: 'ROI 40%, gain $4,000.00, annualized ROI 18.32%.'
		},
		faq: [
			{
				q: 'What is a good ROI?',
				a: 'It depends on the risk and the time you hold the investment. Compare the annualized ROI with what you could earn on a safer option over the same period, such as a savings account or government bond.'
			},
			{
				q: 'Why use annualized ROI?',
				a: 'Total ROI does not show how fast the money grew. A 40% return over 2 years is about 18% a year, while a 40% return over 1 year is 40% a year. Annualized ROI makes the two comparable.'
			},
			{
				q: 'Should fees and taxes be included?',
				a: 'Include any fees, commissions or taxes you paid, so the result shows what you actually kept. Leaving them out makes the return look better than it was.'
			},
			{
				q: 'What if the investment lost money?',
				a: 'A negative ROI means the amount returned was less than the amount invested. The annualized ROI is negative too, showing the average yearly loss.'
			}
		],
		sources: [{ title: 'Investor.gov, U.S. Securities and Exchange Commission', url: 'https://www.investor.gov/' }],
		disclaimer:
			'Estimates only. Past returns do not guarantee future results, and this calculator does not include taxes or inflation.'
	}
});
