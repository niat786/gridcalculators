import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct } from '../format';
import meta from './discount-calculator.meta';

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'price',
			label: 'Original price',
			type: 'number',
			default: 80,
			min: 0,
			max: 100_000_000,
			step: 0.01,
			prefix: '$'
		},
		{
			id: 'discount',
			label: 'Discount (percent off)',
			type: 'number',
			default: 25,
			min: 0,
			max: 100,
			step: 0.01,
			suffix: '%'
		},
		{
			id: 'second',
			label: 'Second discount',
			type: 'number',
			default: 0,
			min: 0,
			max: 100,
			step: 0.01,
			suffix: '%',
			help: 'Applied to the price after the first discount. Leave at 0 for none.'
		}
	],
	calculate(v): CalculationResult {
		const price = Number(v.price);
		const d1 = Number(v.discount);
		const second = Number(v.second);
		const d2 = Number.isNaN(second) ? 0 : second;

		if (!(price > 0) || !Number.isFinite(price) || !(d1 >= 0 && d1 <= 100) || !(d2 >= 0 && d2 <= 100)) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Final price',
				summary: 'Enter an original price above zero and discounts from 0% to 100%.'
			};
		}

		const afterFirst = price * (1 - d1 / 100);
		const final = afterFirst * (1 - d2 / 100);
		const saved = price - final;
		const effective = (saved / price) * 100;

		return {
			primaryResult: money(final),
			primaryLabel: 'Final price',
			summary: `You save ${money(saved)}, an effective discount of ${pct(effective)} off the original price.`,
			secondaryMetrics: [
				{ label: 'After first discount', value: money(afterFirst) },
				{ label: 'You save', value: money(saved) },
				{ label: 'Effective discount', value: pct(effective) }
			]
		};
	},
	content: {
		intro:
			'Work out the sale price from a percent off, see how much you save, and check the real total discount when two discounts are stacked one after the other.',
		howTo: [
			'Enter the original price before any discount.',
			'Enter the percent off, such as 25 for 25% off.',
			'Add a second percentage if another discount applies after the first. Leave it at 0 if not.',
			'Read the final price, the amount you save and the effective discount.'
		],
		formulas: [
			{
				title: 'Sale price from a percent off',
				expression: 'Sale price = Original price × (1 − d ÷ 100)',
				variables: [
					{ symbol: 'd', meaning: 'percent off, such as 25 for 25% off' }
				]
			},
			{
				title: 'Two discounts in a row',
				expression: 'Final price = Original price × (1 − d₁ ÷ 100) × (1 − d₂ ÷ 100)',
				variables: [
					{ symbol: 'd₁', meaning: 'first discount percentage' },
					{ symbol: 'd₂', meaning: 'second discount, applied to the reduced price' }
				]
			},
			{
				title: 'Effective discount',
				expression: 'Effective discount = You save ÷ Original price × 100',
				variables: [{ symbol: 'You save', meaning: 'Original price minus final price' }]
			}
		],
		example: {
			title: 'An $80 item with 25% off, then 10% off the reduced price',
			steps: [
				'First discount: $80 × (1 − 0.25) = $60.00',
				'Second discount: $60 × (1 − 0.10) = $54.00',
				'You save: $80 − $54 = $26.00',
				'Effective discount: $26 ÷ $80 × 100 = 32.5%'
			],
			result: 'Final price $54.00. The effective discount is 32.5%, not 35%.'
		},
		faq: [
			{
				q: 'Is 25% off plus 10% off the same as 35% off?',
				a: 'No. The second discount applies to the already reduced price, so the total discount is less than 35%. Use the effective discount in the result to see the real saving.'
			},
			{
				q: 'How do I work out a sale price from a percent off?',
				a: 'Multiply the original price by 1 minus the percentage, written as a decimal. For example, 40% off a $50 item is $50 × 0.60, which is $30.00.'
			},
			{
				q: 'How do I find the percent off from two prices?',
				a: 'Subtract the sale price from the original price, divide by the original price, then multiply by 100. A $60 sale price on an $80 item is 25% off.'
			},
			{
				q: 'Is sales tax added before or after this discount?',
				a: 'Calculate the discount first, then add any sales tax to the final price. Use the Sales Tax Calculator to add tax to the result.'
			}
		],
		sources: [{ title: 'Federal Trade Commission: Consumer Information', url: 'https://consumer.ftc.gov/' }],
		disclaimer:
			'Estimates only. Store promotions can have rules, such as limits or excluded items, that change the final price.'
	}
});
