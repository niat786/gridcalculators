import { defineMeta } from '../types';

export default defineMeta({
	slug: 'mortgage-payoff-calculator',
	name: 'Mortgage Payoff Calculator',
	category: 'finance',
	shortDescription: 'Remaining balance now, and how an extra payment shortens your loan.',
	metaTitle: 'Mortgage Payoff Calculator — Balance & Extra Payment Savings',
	metaDescription:
		'Free mortgage payoff calculator. Find your balance after the years you have paid, then see how much sooner and cheaper an extra monthly payment clears the loan.',
	icon: 'house',
	keywords: ['mortgage payoff calculator', 'extra mortgage payment', 'remaining mortgage balance', 'pay off mortgage early', 'mortgage calculator'],
	updated: '2026-10-28'
});
