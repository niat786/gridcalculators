import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './future-value-calculator.meta';

const timingOptions = [
	{ label: 'End', value: 'end' },
	{ label: 'Beginning', value: 'beginning' }
];

/**
 * Standard time-value-of-money future value. Payments are amounts added each period.
 * Timing "beginning" (annuity due) grows each payment by one extra period.
 */
export default defineCalculator({
	meta,
	inputs: [
		{ id: 'pv', label: 'Present value', type: 'number', default: 1000, min: 0, max: 1_000_000_000, step: 100, prefix: '$', help: 'The amount you start with.' },
		{ id: 'rate', label: 'Interest rate per period', type: 'number', default: 0.5, min: 0, max: 100, step: 0.01, suffix: '%' },
		{ id: 'periods', label: 'Number of periods', type: 'number', default: 120, min: 1, max: 10_000, step: 1, decimal: false },
		{
			id: 'pmt',
			label: 'Payment per period',
			type: 'number',
			default: 0,
			min: 0,
			max: 1_000_000_000,
			step: 10,
			prefix: '$',
			help: 'Amount you add each period. Leave at 0 for none.'
		},
		{ id: 'timing', label: 'Payment timing', type: 'select', display: 'segmented', default: 'end', options: timingOptions }
	],
	calculate(v): CalculationResult {
		const pv = Number(v.pv);
		const rate = Number(v.rate);
		const n = Number(v.periods);
		const pmt = Number(v.pmt);
		const timing = String(v.timing);
		if (
			!(pv >= 0) ||
			!(pmt >= 0) ||
			!(rate >= 0 && rate <= 100) ||
			!(Number.isInteger(n) && n >= 1 && n <= 10_000) ||
			(timing !== 'end' && timing !== 'beginning')
		) {
			return { primaryResult: DASH, primaryLabel: 'Future value', summary: 'Check the amounts, rate and periods.' };
		}

		const r = rate / 100;
		const due = timing === 'beginning' ? 1 + r : 1;
		const growth = Math.pow(1 + r, n);
		const annuity = r === 0 ? n : ((growth - 1) / r) * due;
		const fv = pv * growth + pmt * annuity;
		const paid = pv + pmt * n;

		return {
			primaryResult: money(fv),
			primaryLabel: 'Future value',
			summary: `Your money grows ${num(growth, 4)} times over ${plural(n, 'period')} at ${num(rate, 2)}% per period.`,
			secondaryMetrics: [
				{ label: 'Total you put in', value: money(paid) },
				{ label: 'Growth from interest', value: money(fv - paid) },
				{ label: 'Payment annuity factor', value: num(annuity, 4) }
			]
		};
	},
	content: {
		intro:
			'Calculate the future value of a lump sum and of regular payments, using the same rate for each period. See what your money grows to by a set date.',
		howTo: [
			'Enter the amount you start with as the present value.',
			'Enter the interest rate for one period, such as a monthly rate.',
			'Enter the number of periods and any payment you add each period.',
			'Choose whether payments are made at the end or the beginning of each period.'
		],
		formulas: [
			{
				title: 'Future value with payments',
				expression: 'FV = PV × (1 + r)ⁿ + PMT × ((1 + r)ⁿ − 1) ÷ r × (1 + r × t)',
				variables: [
					{ symbol: 'FV', meaning: 'future value' },
					{ symbol: 'PV', meaning: 'present value (the amount you start with)' },
					{ symbol: 'PMT', meaning: 'payment added each period' },
					{ symbol: 'r', meaning: 'interest rate per period as a decimal' },
					{ symbol: 'n', meaning: 'number of periods' },
					{ symbol: 't', meaning: '1 if payments are at the beginning of each period, otherwise 0' }
				]
			}
		],
		example: {
			title: '$1,000 today plus $100 at the end of each month, 0.5% per month for 120 months',
			steps: [
				'Growth factor: 1.005¹²⁰ ≈ 1.819397',
				'Present value part: $1,000 × 1.819397 ≈ $1,819.40',
				'Annuity factor: (1.819397 − 1) ÷ 0.005 ≈ 163.8793',
				'Payment part: $100 × 163.8793 ≈ $16,387.93',
				'Future value: $1,819.40 + $16,387.93 ≈ $18,207.33'
			],
			result: 'Future value ≈ $18,207.33.'
		},
		faq: [
			{
				q: 'Does the rate have to be monthly?',
				a: 'No. The rate and the number of periods must match. Use a monthly rate with a number of months, or a yearly rate with a number of years.'
			},
			{
				q: 'Should I enter payments as positive numbers?',
				a: 'Yes. Enter the amount you add each period as a positive number. The calculator adds it to the growing balance.'
			},
			{
				q: 'What does beginning of period mean?',
				a: 'Payments made at the beginning of each period earn interest for one more period, so the future value is a little higher than with end-of-period payments.'
			},
			{
				q: 'Why is the result larger than the total I put in?',
				a: 'The difference is the interest your money earns over time. The "growth from interest" line shows that amount.'
			}
		],
		sources: [{ title: 'U.S. Securities and Exchange Commission — Investor.gov', url: 'https://www.investor.gov' }],
		disclaimer:
			'Estimates only. Actual growth depends on the real rate of return, which can differ from the rate you enter.'
	}
});
