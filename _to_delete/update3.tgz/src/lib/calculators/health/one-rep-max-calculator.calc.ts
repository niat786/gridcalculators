import { defineCalculator, type CalculationResult } from '../types';
import { DASH, num } from '../format';
import meta from './one-rep-max-calculator.meta';

const PERCENTS = [95, 90, 85, 80, 75, 70, 65, 60, 55, 50];

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'unit',
			label: 'Unit',
			type: 'select',
			display: 'segmented',
			default: 'kg',
			options: [
				{ label: 'Kilograms (kg)', value: 'kg' },
				{ label: 'Pounds (lb)', value: 'lb' }
			]
		},
		{ id: 'weight', label: 'Weight lifted', type: 'number', default: 100, min: 1, max: 1000, step: 0.5, help: 'The load you lifted for the set' },
		{ id: 'reps', label: 'Reps completed', type: 'number', default: 5, min: 1, max: 12, step: 1, decimal: false, help: 'Between 1 and 12 reps' }
	],
	calculate(v): CalculationResult {
		const weight = Number(v.weight);
		const reps = Number(v.reps);
		const unit = v.unit === 'lb' ? 'lb' : 'kg';
		if (!Number.isFinite(weight) || !(weight > 0) || !Number.isInteger(reps) || reps < 1 || reps > 12) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Estimated one-rep max (Epley)',
				summary: 'Enter a weight above zero and 1 to 12 reps.'
			};
		}

		const epley = weight * (1 + reps / 30);
		const brzycki = (weight * 36) / (37 - reps);
		const lombardi = weight * Math.pow(reps, 0.1);
		const fmt = (x: number) => `${num(x, 1, 1)} ${unit}`;

		return {
			primaryResult: fmt(epley),
			primaryLabel: 'Estimated one-rep max (Epley)',
			summary: `${num(weight, 1)} ${unit} for ${num(reps, 0)} ${reps === 1 ? 'rep' : 'reps'}: weight × (1 + reps ÷ 30).`,
			secondaryMetrics: [
				{ label: 'Brzycki', value: fmt(brzycki) },
				{ label: 'Lombardi', value: fmt(lombardi) }
			],
			table: {
				title: 'Training loads (% of estimated 1RM)',
				columns: [
					{ key: 'percent', label: 'Percent of 1RM' },
					{ key: 'load', label: 'Load', align: 'end' }
				],
				rows: PERCENTS.map((p) => ({
					percent: `${p}%`,
					load: fmt((epley * p) / 100)
				}))
			}
		};
	},
	content: {
		intro:
			'Estimate the most you could lift for one repetition, using a weight you lifted for 1 to 12 reps. Then use the percentage chart to plan training loads.',
		howTo: [
			'Choose kilograms or pounds.',
			'Enter the weight you lifted and how many reps you completed with good form.',
			'Read the Epley estimate, compare it with Brzycki and Lombardi, and use the chart for training loads.'
		],
		formulas: [
			{
				title: 'Epley',
				expression: '1RM = weight × (1 + reps ÷ 30)',
				variables: [
					{ symbol: 'weight', meaning: 'load lifted for the set' },
					{ symbol: 'reps', meaning: 'repetitions completed' }
				]
			},
			{
				title: 'Brzycki',
				expression: '1RM = weight × 36 ÷ (37 − reps)',
				variables: []
			},
			{
				title: 'Lombardi',
				expression: '1RM = weight × reps^0.10',
				variables: []
			},
			{
				title: 'Training load',
				expression: 'Load = 1RM × percent ÷ 100',
				variables: []
			}
		],
		example: {
			title: 'A set of 5 reps at 100 kg',
			steps: [
				'Epley: 100 × (1 + 5 ÷ 30) = 100 × 1.1667 = 116.7 kg',
				'Brzycki: 100 × 36 ÷ (37 − 5) = 112.5 kg',
				'Lombardi: 100 × 5^0.10 = 117.5 kg',
				'A 75% load: 116.7 × 0.75 = 87.5 kg'
			],
			result: 'Estimated one-rep max of 116.7 kg (Epley), with the three formulas between 112.5 and 117.5 kg.'
		},
		faq: [
			{
				q: 'How accurate is a one-rep max estimate?',
				a: 'Estimates are most reliable for sets of 2 to 10 reps. Results from very high reps are less precise, and the estimate is only as good as the form and effort behind the set.'
			},
			{
				q: 'Should I test a true one-rep max?',
				a: 'Testing a true 1RM is demanding and carries injury risk. Use an estimate from a set of 3 to 5 reps and get a coach or spotter if you attempt a heavy single.'
			},
			{
				q: 'Which formula should I use?',
				a: 'Epley is shown as the main result. Brzycki and Lombardi give similar numbers for most sets, so a gap of a few kilograms between them is normal.'
			}
		],
		sources: [
			{ title: 'National Strength and Conditioning Association', url: 'https://www.nsca.com/' },
			{ title: 'CDC — Physical activity basics', url: 'https://www.cdc.gov/physical-activity-basics/index.html' }
		],
		disclaimer:
			'Estimates are for training planning only. Check with a doctor before starting heavy resistance training, and use a spotter or coach for near-maximal lifts.'
	}
});
