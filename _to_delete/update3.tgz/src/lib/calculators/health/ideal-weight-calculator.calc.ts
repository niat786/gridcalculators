import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './ideal-weight-calculator.meta';

const LB = 0.45359237;
const metric = (v: InputValues) => v.units === 'metric';
const imperial = (v: InputValues) => v.units === 'imperial';

/** Height at which the formulas below apply: 5 feet (152.4 cm). */
const MIN_INCHES = 60;

/** Formula estimates in kilograms. `over` is height in inches above 5 feet. */
export const formulas: { label: string; estimate: (male: boolean, over: number) => number }[] = [
	{ label: 'Robinson (1983)', estimate: (m, o) => (m ? 52 + 1.9 * o : 49 + 1.7 * o) },
	{ label: 'Miller (1983)', estimate: (m, o) => (m ? 56.2 + 1.41 * o : 53.1 + 1.36 * o) },
	{ label: 'Devine (1974)', estimate: (m, o) => (m ? 50 + 2.3 * o : 45.5 + 2.3 * o) },
	{ label: 'Hamwi (1964)', estimate: (m, o) => (m ? 48 + 2.7 * o : 45.5 + 2.2 * o) }
];

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'sex',
			label: 'Sex',
			type: 'select',
			display: 'segmented',
			default: 'male',
			options: [
				{ label: 'Male', value: 'male' },
				{ label: 'Female', value: 'female' }
			]
		},
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'metric',
			options: [
				{ label: 'Metric (kg, cm)', value: 'metric' },
				{ label: 'Imperial (lb, ft)', value: 'imperial' }
			]
		},
		{ id: 'cm', label: 'Height', type: 'number', default: 175, min: 120, max: 230, step: 0.1, suffix: 'cm', visibleWhen: metric },
		{ id: 'ft', label: 'Height (feet)', type: 'number', default: 5, min: 4, max: 7, step: 1, suffix: 'ft', decimal: false, width: 'half', visibleWhen: imperial },
		{ id: 'in', label: 'Height (inches)', type: 'number', default: 9, min: 0, max: 11.9, step: 0.1, suffix: 'in', width: 'half', visibleWhen: imperial }
	],
	calculate(v): CalculationResult {
		const imp = v.units === 'imperial';
		const male = v.sex !== 'female';
		const inches = imp ? Number(v.ft) * 12 + Number(v.in) : Number(v.cm) / 2.54;
		const cm = imp ? inches * 2.54 : Number(v.cm);
		const unit = imp ? 'lb' : 'kg';
		const toUnit = (kg: number) => (imp ? kg / LB : kg);

		if (!Number.isFinite(inches) || inches < MIN_INCHES) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Healthy weight range',
				summary: 'These formulas need a height of at least 5 ft (152.4 cm).'
			};
		}

		const m = cm / 100;
		const low = toUnit(18.5 * m * m);
		const high = toUnit(24.9 * m * m);
		const over = inches - MIN_INCHES;

		return {
			primaryResult: `${num(low, 1, 1)}–${num(high, 1, 1)} ${unit}`,
			primaryLabel: 'Healthy weight range (BMI 18.5 to 24.9)',
			summary: 'The weight range for a healthy body mass index at your height.',
			secondaryMetrics: formulas.map((f) => ({
				label: f.label,
				value: `${num(toUnit(f.estimate(male, over)), 1, 1)} ${unit}`
			}))
		};
	},
	content: {
		intro:
			'Find the weight range that matches a healthy body mass index (BMI) for your height. Compare it with four published formula estimates based on height.',
		howTo: [
			'Choose your sex and metric or imperial units.',
			'Enter your height. The formulas need at least 5 feet (152.4 cm).',
			'Read the healthy weight range, then compare the four formula estimates.'
		],
		formulas: [
			{
				title: 'Healthy weight range',
				expression: 'Lower = 18.5 × height (m)²\nUpper = 24.9 × height (m)²',
				variables: [{ symbol: 'height (m)', meaning: 'height in metres' }]
			},
			{
				title: 'Robinson (1983)',
				expression: 'Men: 52 + 1.9 × (inches over 5 ft)\nWomen: 49 + 1.7 × (inches over 5 ft)',
				variables: []
			},
			{
				title: 'Miller (1983)',
				expression: 'Men: 56.2 + 1.41 × (inches over 5 ft)\nWomen: 53.1 + 1.36 × (inches over 5 ft)',
				variables: []
			},
			{
				title: 'Devine (1974)',
				expression: 'Men: 50 + 2.3 × (inches over 5 ft)\nWomen: 45.5 + 2.3 × (inches over 5 ft)',
				variables: []
			},
			{
				title: 'Hamwi (1964)',
				expression: 'Men: 48 + 2.7 × (inches over 5 ft)\nWomen: 45.5 + 2.2 × (inches over 5 ft)',
				variables: []
			}
		],
		example: {
			title: 'A man who is 175 cm tall',
			steps: [
				'Height in metres: 175 ÷ 100 = 1.75 m',
				'Lower limit: 18.5 × 1.75² = 56.7 kg',
				'Upper limit: 24.9 × 1.75² = 76.3 kg',
				'Robinson: 52 + 1.9 × 8.9 inches over 5 ft = 68.9 kg'
			],
			result: 'A healthy BMI range of 56.7 to 76.3 kg. The four formulas give 68.7 to 72.0 kg for the same height.'
		},
		faq: [
			{
				q: 'Why is there a range rather than one ideal weight?',
				a: 'Healthy body weight varies from person to person, so a range is more useful than a single number. The BMI range of 18.5 to 24.9 is the adult band used by the World Health Organization.'
			},
			{
				q: 'Are these formulas accurate?',
				a: 'They were developed for other purposes, such as drug dosing and general clinical estimates. They ignore body composition, frame size and age, so treat them as rough comparisons.'
			},
			{
				q: 'Why do the formulas give different answers?',
				a: 'Each one was derived from a different group of patients and era. The differences are usually a few kilograms, which is why the BMI range is shown as the main result.'
			}
		],
		sources: [
			{ title: 'World Health Organization — Obesity and overweight', url: 'https://www.who.int/news-room/fact-sheets/detail/obesity-and-overweight' },
			{ title: 'CDC — About adult BMI', url: 'https://www.cdc.gov/bmi/adult-calculator/index.html' }
		],
		disclaimer:
			'The formulas and BMI range are general estimates and do not account for muscle, bone or body composition. Talk to a healthcare professional about your weight.'
	}
});
