import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './bmr-calculator.meta';

const metric = (v: InputValues) => v.units === 'metric';
const imperial = (v: InputValues) => v.units === 'imperial';

/** Mifflin-St Jeor resting energy expenditure (kcal/day). */
export function mifflinStJeor(kg: number, cm: number, age: number, male: boolean): number {
	return 10 * kg + 6.25 * cm - 5 * age + (male ? 5 : -161);
}

/** Harris-Benedict, revised by Roza and Shizgal (1984) (kcal/day). */
export function harrisBenedict(kg: number, cm: number, age: number, male: boolean): number {
	return male
		? 88.362 + 13.397 * kg + 4.799 * cm - 5.677 * age
		: 447.593 + 9.247 * kg + 3.098 * cm - 4.33 * age;
}

/** Katch-McArdle, from lean body mass (kcal/day). */
export function katchMcArdle(kg: number, bodyFatPct: number): number {
	return 370 + 21.6 * kg * (1 - bodyFatPct / 100);
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'metric',
			options: [
				{ label: 'Metric (kg, cm)', value: 'metric' },
				{ label: 'Imperial (lb, ft)', value: 'imperial' }
			]
		},
		{
			id: 'sex',
			label: 'Sex',
			type: 'select',
			display: 'segmented',
			default: 'female',
			options: [
				{ label: 'Female', value: 'female' },
				{ label: 'Male', value: 'male' }
			]
		},
		{ id: 'age', label: 'Age', type: 'number', default: 30, min: 15, max: 80, step: 1, suffix: 'years', decimal: false, help: 'For ages 15 to 80' },
		{ id: 'kg', label: 'Weight', type: 'number', default: 70, min: 30, max: 300, step: 0.1, suffix: 'kg', visibleWhen: metric },
		{ id: 'cm', label: 'Height', type: 'number', default: 170, min: 120, max: 230, step: 0.1, suffix: 'cm', visibleWhen: metric },
		{ id: 'lb', label: 'Weight', type: 'number', default: 154, min: 66, max: 660, step: 0.1, suffix: 'lb', visibleWhen: imperial },
		{ id: 'ft', label: 'Height (feet)', type: 'number', default: 5, min: 4, max: 7, step: 1, suffix: 'ft', decimal: false, width: 'half', visibleWhen: imperial },
		{ id: 'in', label: 'Height (inches)', type: 'number', default: 7, min: 0, max: 11.9, step: 0.1, suffix: 'in', width: 'half', visibleWhen: imperial },
		{
			id: 'bodyFat',
			label: 'Body fat (optional)',
			type: 'number',
			default: 0,
			min: 0,
			max: 75,
			step: 0.1,
			suffix: '%',
			help: 'Leave at 0 if unknown. Only used for Katch-McArdle.'
		}
	],
	calculate(v): CalculationResult {
		const isImperial = v.units === 'imperial';
		const kg = isImperial ? Number(v.lb) * 0.45359237 : Number(v.kg);
		const cm = isImperial ? (Number(v.ft) * 12 + Number(v.in)) * 2.54 : Number(v.cm);
		const age = Number(v.age);
		const bodyFat = Number(v.bodyFat);
		const male = v.sex === 'male';
		if (![kg, cm, age, bodyFat].every(Number.isFinite) || !(kg > 0) || !(cm > 0) || !(age > 0) || bodyFat < 0 || bodyFat >= 75) {
			return { primaryResult: DASH, primaryLabel: 'Resting calories (BMR)', summary: 'Fill in every field.' };
		}

		const mifflin = Math.round(mifflinStJeor(kg, cm, age, male));
		const hb = Math.round(harrisBenedict(kg, cm, age, male));
		const useKatch = bodyFat > 0;
		const km = useKatch ? Math.round(katchMcArdle(kg, bodyFat)) : 0;

		return {
			primaryResult: `${num(mifflin, 0)} kcal/day`,
			primaryLabel: 'Resting calories (Mifflin-St Jeor)',
			summary: `10 × weight + 6.25 × height − 5 × age, then +5 for men or −161 for women.`,
			secondaryMetrics: [
				{ label: 'Harris-Benedict (revised 1984)', value: `${num(hb, 0)} kcal/day` },
				{ label: 'Katch-McArdle (uses body fat)', value: useKatch ? `${num(km, 0)} kcal/day` : 'Enter body fat %' },
				{ label: 'Body fat used', value: useKatch ? `${num(bodyFat, 1)}%` : 'Not used' }
			]
		};
	},
	content: {
		intro:
			'Estimate your basal metabolic rate (BMR), the number of calories your body uses at complete rest to keep you alive. Compare three common equations side by side.',
		howTo: [
			'Choose metric or imperial units and your sex.',
			'Enter your age, weight and height.',
			'Optionally enter your body fat % to add the Katch-McArdle estimate.',
			'Read the Mifflin-St Jeor result, then compare it with the other equations.'
		],
		formulas: [
			{
				title: 'Mifflin-St Jeor (primary result)',
				expression: 'Men:   BMR = 10W + 6.25H − 5A + 5\nWomen: BMR = 10W + 6.25H − 5A − 161',
				variables: [
					{ symbol: 'W', meaning: 'weight in kilograms' },
					{ symbol: 'H', meaning: 'height in centimetres' },
					{ symbol: 'A', meaning: 'age in years' }
				]
			},
			{
				title: 'Harris-Benedict, revised 1984',
				expression: 'Men:   BMR = 88.362 + 13.397W + 4.799H − 5.677A\nWomen: BMR = 447.593 + 9.247W + 3.098H − 4.330A',
				variables: [
					{ symbol: 'W', meaning: 'weight in kilograms' },
					{ symbol: 'H', meaning: 'height in centimetres' },
					{ symbol: 'A', meaning: 'age in years' }
				]
			},
			{
				title: 'Katch-McArdle (needs body fat %)',
				expression: 'BMR = 370 + 21.6 × LBM\nLBM = W × (1 − body fat ÷ 100)',
				variables: [
					{ symbol: 'LBM', meaning: 'lean body mass in kilograms' },
					{ symbol: 'W', meaning: 'weight in kilograms' }
				]
			}
		],
		example: {
			title: 'A 30-year-old woman, 70 kg, 170 cm',
			steps: [
				'Mifflin-St Jeor: 10 × 70 + 6.25 × 170 − 5 × 30 − 161 = 1,451.5 kcal',
				'Harris-Benedict: 447.593 + 9.247 × 70 + 3.098 × 170 − 4.330 × 30 = 1,491.6 kcal',
				'Rounded to whole calories, the primary result is 1,452 kcal a day'
			],
			result: 'About 1,452 kcal a day at complete rest (Mifflin-St Jeor), with Harris-Benedict close at 1,492.'
		},
		faq: [
			{
				q: 'Which BMR equation is most accurate?',
				a: 'Mifflin-St Jeor is generally considered the most accurate of the common equations for healthy adults. Harris-Benedict is older and often runs a little higher.'
			},
			{
				q: 'Do I need to enter body fat?',
				a: 'No. Katch-McArdle is more precise when you know your body fat, because it is based on lean mass. Leave the field at 0 to skip it.'
			},
			{
				q: 'Is BMR the same as the calories I need each day?',
				a: 'No. BMR covers only resting body functions. Your daily needs add the energy used for movement and exercise. Use the TDEE calculator for that.'
			}
		],
		sources: [
			{ title: 'Mifflin MD et al. (1990), American Journal of Clinical Nutrition', url: 'https://pubmed.ncbi.nlm.nih.gov/2305711/' },
			{ title: 'NIH — Body Weight Planner', url: 'https://www.niddk.nih.gov/bwp' }
		],
		disclaimer:
			'These are estimates for healthy adults and are not suitable during pregnancy or for people with medical conditions. Ask a doctor or dietitian for personal advice.'
	}
});
