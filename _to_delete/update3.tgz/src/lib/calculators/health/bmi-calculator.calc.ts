import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './bmi-calculator.meta';

const metric = (v: InputValues) => v.units === 'metric';
const imperial = (v: InputValues) => v.units === 'imperial';

/** WHO adult BMI classification. */
export function bmiCategory(bmi: number): string {
	if (bmi < 18.5) return 'Underweight';
	if (bmi < 25) return 'Healthy weight';
	if (bmi < 30) return 'Overweight';
	return 'Obesity';
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'metric',
			options: [
				{ label: 'Metric (kg, cm)', value: 'metric' },
				{ label: 'Imperial (lb, ft)', value: 'imperial' }
			]
		},
		{ id: 'kg', label: 'Weight', type: 'number', default: 70, min: 1, max: 500, step: 0.1, suffix: 'kg', visibleWhen: metric },
		{ id: 'cm', label: 'Height', type: 'number', default: 175, min: 50, max: 272, step: 0.1, suffix: 'cm', visibleWhen: metric },
		{ id: 'lb', label: 'Weight', type: 'number', default: 154, min: 2, max: 1100, step: 0.1, suffix: 'lb', visibleWhen: imperial },
		{ id: 'ft', label: 'Height (feet)', type: 'number', default: 5, min: 1, max: 8, step: 1, suffix: 'ft', decimal: false, width: 'half', visibleWhen: imperial },
		{ id: 'in', label: 'Height (inches)', type: 'number', default: 9, min: 0, max: 11.9, step: 0.1, suffix: 'in', width: 'half', visibleWhen: imperial }
	],
	calculate(v): CalculationResult {
		let kg: number;
		let m: number;
		if (v.units === 'imperial') {
			kg = Number(v.lb) * 0.45359237;
			m = (Number(v.ft) * 12 + Number(v.in)) * 0.0254;
		} else {
			kg = Number(v.kg);
			m = Number(v.cm) / 100;
		}
		if (!(kg > 0) || !(m > 0)) {
			return { primaryResult: DASH, primaryLabel: 'Your BMI', summary: 'Enter your weight and height.' };
		}
		const bmi = kg / (m * m);
		const low = 18.5 * m * m;
		const high = 24.9 * m * m;
		const toLb = (x: number) => x / 0.45359237;
		const range =
			v.units === 'imperial'
				? `${num(toLb(low), 1)}–${num(toLb(high), 1)} lb`
				: `${num(low, 1)}–${num(high, 1)} kg`;

		return {
			primaryResult: num(bmi, 1, 1),
			primaryLabel: 'Your BMI',
			summary: `${bmiCategory(bmi)} (adult WHO classification).`,
			gauge: {
				min: 12,
				max: 42,
				value: bmi,
				bands: [
					{ to: 18.5, label: 'Underweight' },
					{ to: 25, label: 'Healthy' },
					{ to: 30, label: 'Overweight' },
					{ to: 42, label: 'Obesity' }
				]
			},
			secondaryMetrics: [
				{ label: 'Category', value: bmiCategory(bmi) },
				{ label: 'Healthy weight for your height', value: range },
				{ label: 'BMI Prime', value: num(bmi / 25, 2, 2) }
			]
		};
	},
	content: {
		intro:
			'Work out your body mass index (BMI) from your height and weight, and see where it falls on the adult scale used by the World Health Organization.',
		howTo: [
			'Choose metric or imperial units.',
			'Enter your weight and height.',
			'Read your BMI, its category and the healthy weight range for your height.'
		],
		formulas: [
			{
				title: 'Metric',
				expression: 'BMI = weight (kg) ÷ height (m)²',
				variables: []
			},
			{
				title: 'Imperial',
				expression: 'BMI = 703 × weight (lb) ÷ height (in)²',
				variables: []
			}
		],
		example: {
			title: 'An adult who weighs 70 kg and is 175 cm tall',
			steps: [
				'Convert height to metres: 175 cm ÷ 100 = 1.75 m',
				'Square the height: 1.75 × 1.75 = 3.0625',
				'Divide weight by that: 70 ÷ 3.0625 = 22.86'
			],
			result: 'BMI ≈ 22.9, which is in the healthy weight range (18.5 to 24.9).'
		},
		faq: [
			{
				q: 'What is a healthy BMI for adults?',
				a: 'For most adults, a BMI from 18.5 to 24.9 is classed as a healthy weight. Below 18.5 is underweight, 25 to 29.9 is overweight and 30 or more is obesity.'
			},
			{
				q: 'Is BMI accurate for everyone?',
				a: 'No. BMI does not measure body fat directly. It can overestimate fat in muscular people and underestimate it in older adults. Some groups, including people of Asian descent, may have health risks at lower BMIs.'
			},
			{
				q: 'Can I use this for children?',
				a: 'No. Children and teens need a BMI-for-age percentile, which compares them with others of the same age and sex. Ask a pediatrician or use a dedicated child BMI calculator.'
			},
			{
				q: 'What is BMI Prime?',
				a: 'BMI Prime is your BMI divided by 25, the upper limit of the healthy range. A value of 1.0 sits right at that limit; below 1.0 is under it.'
			}
		],
		sources: [
			{ title: 'World Health Organization — Obesity and overweight', url: 'https://www.who.int/news-room/fact-sheets/detail/obesity-and-overweight' },
			{ title: 'CDC — About adult BMI', url: 'https://www.cdc.gov/bmi/adult-calculator/index.html' }
		],
		disclaimer:
			'BMI is a screening tool, not a diagnosis. Talk to a healthcare professional about your health.'
	}
});
