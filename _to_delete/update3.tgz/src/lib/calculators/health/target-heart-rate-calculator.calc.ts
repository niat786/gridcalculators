import { defineCalculator, type CalculationResult } from '../types';
import { DASH, num } from '../format';
import meta from './target-heart-rate-calculator.meta';

const ZONES = [
	{ name: 'Very light', from: 50, to: 60 },
	{ name: 'Light', from: 60, to: 70 },
	{ name: 'Moderate', from: 70, to: 80 },
	{ name: 'Vigorous', from: 80, to: 90 },
	{ name: 'Maximum', from: 90, to: 100 }
];

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'age',
			label: 'Age',
			type: 'number',
			default: 35,
			min: 10,
			max: 100,
			step: 1,
			suffix: 'years',
			decimal: false,
			help: 'For ages 10 to 100'
		},
		{
			id: 'restingHr',
			label: 'Resting heart rate (optional)',
			type: 'number',
			default: 0,
			min: 0,
			max: 120,
			step: 1,
			suffix: 'bpm',
			decimal: false,
			help: 'Leave at 0 if unknown. Adding it switches to the Karvonen method.'
		}
	],
	calculate(v): CalculationResult {
		const age = Number(v.age);
		const rest = Number(v.restingHr);
		if (!Number.isFinite(age) || !(age > 0) || !Number.isFinite(rest) || rest < 0) {
			return { primaryResult: DASH, primaryLabel: 'Estimated maximum heart rate', summary: 'Enter your age.' };
		}

		const max = 220 - age;
		const karvonen = rest > 0;
		if (karvonen && (rest < 30 || rest >= max)) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Estimated maximum heart rate',
				summary: 'Check your resting heart rate, or leave it at 0.'
			};
		}

		const bound = (pct: number) => (karvonen ? Math.round(rest + ((max - rest) * pct) / 100) : Math.round((max * pct) / 100));

		return {
			primaryResult: `${num(max, 0)} bpm`,
			primaryLabel: 'Estimated maximum heart rate (220 − age)',
			summary: karvonen
				? 'Zones use the Karvonen method: resting rate + percentage × heart rate reserve.'
				: 'Zones are a percentage of your maximum. Add your resting rate for a more personal range.',
			secondaryMetrics: [
				{ label: 'Method', value: karvonen ? 'Karvonen' : 'Percent of maximum' },
				{ label: 'Heart rate reserve', value: karvonen ? `${num(max - rest, 0)} bpm` : '—' },
				{ label: 'Resting heart rate', value: karvonen ? `${num(rest, 0)} bpm` : 'Not entered' }
			],
			table: {
				title: 'Heart rate zones',
				columns: [
					{ key: 'zone', label: 'Zone' },
					{ key: 'intensity', label: 'Intensity' },
					{ key: 'bpm', label: 'Heart rate', align: 'end' }
				],
				rows: ZONES.map((z) => ({
					zone: z.name,
					intensity: `${z.from}–${z.to}%`,
					bpm: `${num(bound(z.from), 0)}–${num(bound(z.to), 0)} bpm`
				}))
			}
		};
	},
	content: {
		intro:
			'Work out your maximum heart rate and the five training zones built from it. Add your resting heart rate to get zones that take your fitness into account.',
		howTo: [
			'Enter your age.',
			'Optionally enter your resting heart rate, taken first thing in the morning before getting up.',
			'Read your maximum heart rate, then match your target to the zone table.'
		],
		formulas: [
			{
				title: 'Maximum heart rate',
				expression: 'Max HR = 220 − age',
				variables: []
			},
			{
				title: 'Zone from percentage of maximum',
				expression: 'Zone HR = max HR × zone %',
				variables: []
			},
			{
				title: 'Zone from Karvonen (with resting heart rate)',
				expression: 'Zone HR = resting HR + zone % × (max HR − resting HR)',
				variables: []
			}
		],
		example: {
			title: 'A 40-year-old with no resting heart rate entered',
			steps: [
				'Max HR = 220 − 40 = 180 bpm',
				'Zone 50–60%: 180 × 0.50 = 90 bpm and 180 × 0.60 = 108 bpm',
				'Zone 80–90%: 180 × 0.80 = 144 bpm and 180 × 0.90 = 162 bpm'
			],
			result: 'Max HR of 180 bpm. The 50–60% zone runs from 90 to 108 bpm.'
		},
		faq: [
			{
				q: 'Is 220 minus age accurate?',
				a: 'It is a rough population average, and individual maximums can differ by 10 to 15 beats a minute. A test with a supervised maximal exercise session gives a more accurate figure.'
			},
			{
				q: 'What is the Karvonen method?',
				a: 'It uses your heart rate reserve, the gap between your maximum and resting heart rate, so zones reflect your fitness as well as your age. It is usually more personal than a simple percentage.'
			},
			{
				q: 'Which zone should I train in?',
				a: 'Most people benefit from a mix. Moderate zones build general fitness and can be held for long sessions. Vigorous and maximum zones are short and hard, and should be used with care.'
			}
		],
		sources: [
			{ title: 'American Heart Association — Target heart rates', url: 'https://www.heart.org/en/healthy-living/fitness/fitness-basics/target-heart-rates' },
			{ title: 'CDC — Physical activity basics', url: 'https://www.cdc.gov/physical-activity-basics/index.html' }
		],
		disclaimer:
			'Heart rate zones are estimates. If you have heart or lung conditions, take heart medication or feel unwell during exercise, get medical advice before you train.'
	}
});
