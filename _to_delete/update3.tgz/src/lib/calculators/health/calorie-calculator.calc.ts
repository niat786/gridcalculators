import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './calorie-calculator.meta';

const metric = (v: InputValues) => v.units === 'metric';
const imperial = (v: InputValues) => v.units === 'imperial';

export const ACTIVITY: Record<string, { factor: number; label: string }> = {
	sedentary: { factor: 1.2, label: 'Sedentary: little or no exercise' },
	light: { factor: 1.375, label: 'Light: exercise 1–3 days a week' },
	moderate: { factor: 1.55, label: 'Moderate: exercise 3–5 days a week' },
	active: { factor: 1.725, label: 'Active: hard exercise 6–7 days a week' },
	extra: { factor: 1.9, label: 'Very active: physical job or training twice a day' }
};

/** Mifflin-St Jeor resting energy expenditure (kcal/day). */
export function mifflinStJeor(kg: number, cm: number, age: number, sex: string): number {
	return 10 * kg + 6.25 * cm - 5 * age + (sex === 'male' ? 5 : -161);
}

/** ~7,700 kcal per kg of body fat (≈3,500 per lb). */
const KCAL_PER_KG = 7700;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'metric',
			options: [
				{ label: 'Metric (kg, cm)', value: 'metric' },
				{ label: 'Imperial (lb, ft)', value: 'imperial' }
			]
		},
		{
			id: 'sex',
			label: 'Sex',
			type: 'select',
			display: 'segmented',
			default: 'female',
			options: [
				{ label: 'Female', value: 'female' },
				{ label: 'Male', value: 'male' }
			]
		},
		{ id: 'age', label: 'Age', type: 'number', default: 30, min: 15, max: 80, step: 1, suffix: 'years', decimal: false, help: 'For ages 15 to 80' },
		{ id: 'kg', label: 'Weight', type: 'number', default: 70, min: 30, max: 300, step: 0.1, suffix: 'kg', visibleWhen: metric },
		{ id: 'cm', label: 'Height', type: 'number', default: 170, min: 120, max: 230, step: 0.1, suffix: 'cm', visibleWhen: metric },
		{ id: 'lb', label: 'Weight', type: 'number', default: 154, min: 66, max: 660, step: 0.1, suffix: 'lb', visibleWhen: imperial },
		{ id: 'ft', label: 'Height (feet)', type: 'number', default: 5, min: 4, max: 7, step: 1, suffix: 'ft', decimal: false, width: 'half', visibleWhen: imperial },
		{ id: 'in', label: 'Height (inches)', type: 'number', default: 7, min: 0, max: 11.9, step: 0.1, suffix: 'in', width: 'half', visibleWhen: imperial },
		{
			id: 'activity',
			label: 'Activity level',
			type: 'select',
			display: 'menu',
			default: 'light',
			options: Object.entries(ACTIVITY).map(([value, a]) => ({ value, label: a.label }))
		}
	],
	calculate(v): CalculationResult {
		const isImperial = v.units === 'imperial';
		const kg = isImperial ? Number(v.lb) * 0.45359237 : Number(v.kg);
		const cm = isImperial ? (Number(v.ft) * 12 + Number(v.in)) * 2.54 : Number(v.cm);
		const age = Number(v.age);
		const act = ACTIVITY[String(v.activity)];
		if (!(kg > 0) || !(cm > 0) || !(age > 0) || !act) {
			return { primaryResult: DASH, primaryLabel: 'Maintenance calories', summary: 'Fill in every field.' };
		}

		const bmr = mifflinStJeor(kg, cm, age, String(v.sex));
		const tdee = bmr * act.factor;
		const floor = v.sex === 'male' ? 1500 : 1200;

		// Weekly rates in the person's own units.
		const rates = isImperial
			? [
					{ label: 'Mild weight loss (0.5 lb/week)', delta: -250 },
					{ label: 'Weight loss (1 lb/week)', delta: -500 },
					{ label: 'Fast weight loss (2 lb/week)', delta: -1000 },
					{ label: 'Mild weight gain (0.5 lb/week)', delta: 250 },
					{ label: 'Weight gain (1 lb/week)', delta: 500 }
				]
			: [
					{ label: 'Mild weight loss (0.25 kg/week)', delta: (-0.25 * KCAL_PER_KG) / 7 },
					{ label: 'Weight loss (0.5 kg/week)', delta: (-0.5 * KCAL_PER_KG) / 7 },
					{ label: 'Fast weight loss (1 kg/week)', delta: (-1 * KCAL_PER_KG) / 7 },
					{ label: 'Mild weight gain (0.25 kg/week)', delta: (0.25 * KCAL_PER_KG) / 7 },
					{ label: 'Weight gain (0.5 kg/week)', delta: (0.5 * KCAL_PER_KG) / 7 }
				];

		return {
			primaryResult: `${num(Math.round(tdee), 0)} kcal/day`,
			primaryLabel: 'Calories to maintain your weight',
			summary: `Resting rate ${num(Math.round(bmr), 0)} kcal × activity factor ${act.factor}.`,
			secondaryMetrics: [
				{ label: 'Resting metabolic rate (BMR)', value: `${num(Math.round(bmr), 0)} kcal` },
				{ label: 'Maintenance (TDEE)', value: `${num(Math.round(tdee), 0)} kcal` }
			],
			table: {
				title: 'Daily calories by goal',
				columns: [
					{ key: 'goal', label: 'Goal' },
					{ key: 'kcal', label: 'Calories / day', align: 'end' }
				],
				rows: [
					{ goal: 'Maintain weight', kcal: num(Math.round(tdee), 0) },
					...rates.map((r) => {
						const k = Math.round(tdee + r.delta);
						return {
							goal: r.label,
							kcal: k < floor ? `${num(k, 0)} (below ${num(floor, 0)}: not advised)` : num(k, 0)
						};
					})
				]
			}
		};
	},
	content: {
		intro:
			'Estimate how many calories your body uses in a day, and how many to eat to keep your weight steady, lose weight gradually, or gain weight.',
		howTo: [
			'Choose metric or imperial units and your sex.',
			'Enter your age, weight and height.',
			'Pick the activity level that best matches a typical week.',
			'Read your maintenance calories and the daily targets for each goal.'
		],
		formulas: [
			{
				title: 'Resting metabolic rate (Mifflin-St Jeor)',
				expression: 'Men:   BMR = 10W + 6.25H − 5A + 5\nWomen: BMR = 10W + 6.25H − 5A − 161',
				variables: [
					{ symbol: 'W', meaning: 'weight in kilograms' },
					{ symbol: 'H', meaning: 'height in centimetres' },
					{ symbol: 'A', meaning: 'age in years' }
				]
			},
			{
				title: 'Total daily energy expenditure',
				expression: 'TDEE = BMR × activity factor (1.2 to 1.9)',
				variables: []
			},
			{
				title: 'Goal calories',
				expression: 'Target = TDEE − (kg per week × 7,700 ÷ 7)',
				variables: []
			}
		],
		example: {
			title: 'A 30-year-old woman, 70 kg, 170 cm, exercising 1–3 days a week',
			steps: [
				'BMR = 10 × 70 + 6.25 × 170 − 5 × 30 − 161',
				'BMR = 700 + 1,062.5 − 150 − 161 = 1,451.5 kcal',
				'TDEE = 1,451.5 × 1.375 = 1,995.8 kcal',
				'To lose 0.5 kg a week: 1,996 − 550 = 1,446 kcal'
			],
			result: 'About 1,996 kcal a day to maintain weight, or about 1,446 kcal to lose 0.5 kg a week.'
		},
		faq: [
			{
				q: 'How accurate is this calorie calculator?',
				a: 'The Mifflin-St Jeor equation predicts resting metabolism within about 10% for most adults. Treat the result as a starting point, track your weight for a few weeks and adjust.'
			},
			{
				q: 'Why is there a minimum calorie level?',
				a: 'Eating fewer than about 1,200 (women) or 1,500 (men) calories a day makes it hard to get enough nutrients. Very low-calorie diets should only be followed with medical supervision.'
			},
			{
				q: 'What is the difference between BMR and TDEE?',
				a: 'BMR is the energy your body uses at complete rest. TDEE adds the energy you use moving around and exercising, so it is the number to base your daily intake on.'
			},
			{
				q: 'How fast should I lose weight?',
				a: 'Losing about 0.5 kg (1 lb) a week is a common, sustainable target. Faster loss is harder to maintain and can cost muscle as well as fat.'
			}
		],
		sources: [
			{ title: 'Mifflin MD et al. (1990), American Journal of Clinical Nutrition', url: 'https://pubmed.ncbi.nlm.nih.gov/2305711/' },
			{ title: 'NIH — Body Weight Planner', url: 'https://www.niddk.nih.gov/bwp' }
		],
		disclaimer:
			'General estimates for healthy adults. Not suitable during pregnancy or for people with medical conditions. Ask a doctor or dietitian for personal advice.'
	}
});
