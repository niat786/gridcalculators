/**
 * Formatting helpers. The locale is fixed so prerendered HTML and the browser agree
 * (no hydration flicker). Localisation can come later per market.
 */
const LOCALE = 'en-US';

const usd = new Intl.NumberFormat(LOCALE, { style: 'currency', currency: 'USD' });
const usd0 = new Intl.NumberFormat(LOCALE, {
	style: 'currency',
	currency: 'USD',
	maximumFractionDigits: 0
});
const compactUsd = new Intl.NumberFormat(LOCALE, {
	style: 'currency',
	currency: 'USD',
	notation: 'compact',
	maximumFractionDigits: 1
});

export const DASH = '—';

export function money(n: number, wholeDollars = false): string {
	if (!Number.isFinite(n)) return DASH;
	return (wholeDollars ? usd0 : usd).format(n);
}

export function moneyCompact(n: number): string {
	if (!Number.isFinite(n)) return DASH;
	return compactUsd.format(n);
}

export function num(n: number, maxDecimals = 2, minDecimals = 0): string {
	if (!Number.isFinite(n)) return DASH;
	return n.toLocaleString(LOCALE, {
		maximumFractionDigits: maxDecimals,
		minimumFractionDigits: minDecimals
	});
}

export function pct(n: number, maxDecimals = 2): string {
	if (!Number.isFinite(n)) return DASH;
	return `${num(n, maxDecimals)}%`;
}

export function plural(n: number, word: string, pluralWord = `${word}s`): string {
	return `${num(n, 0)} ${n === 1 ? word : pluralWord}`;
}

/** Parse user text like "1,250.50" to a number; NaN when empty or invalid. */
export function parseNumber(raw: string): number {
	const cleaned = raw.replace(/[,\s$%]/g, '');
	if (cleaned === '' || cleaned === '-' || cleaned === '.') return NaN;
	return Number(cleaned);
}
