import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, pct } from '../format';
import meta from './rmd-calculator.meta';

/** IRS Uniform Lifetime Table (Pub. 590-B, Appendix B, Table III), in force since 2022. Index = age − 72. */
const ULT = [
	27.4, 26.5, 25.5, 24.6, 23.7, 22.9, 22.0, 21.1, 20.2, 19.4, 18.5, 17.7, 16.8, 16.0, 15.2, 14.4, 13.7, 12.9, 12.2, 11.5, 10.8,
	10.1, 9.5, 8.9, 8.4, 7.8, 7.3, 6.8, 6.4, 6.0, 5.6, 5.2, 4.9, 4.6, 4.3, 4.1, 3.9, 3.7, 3.5, 3.4, 3.3, 3.1, 3.0, 2.9, 2.8,
	2.7, 2.5, 2.3, 2.0
];
export function distributionPeriod(age: number): number {
	if (age < 72) return NaN;
	return ULT[Math.min(age - 72, ULT.length - 1)];
}

/** SECURE 2.0: RMDs start at 73 if born 1951–1959, 75 if born 1960 or later (72 or 70½ earlier). */
export function startAge(born: number): number {
	if (born <= 1950) return 72;
	if (born <= 1959) return 73;
	return 75;
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'born', label: 'Year of birth', type: 'number', default: 1952, min: 1900, max: 2010, decimal: false, width: 'half' },
		{ id: 'year', label: 'Distribution year', type: 'number', default: 2026, min: 2022, max: 2100, decimal: false, width: 'half' },
		{ id: 'balance', label: 'Account balance on Dec 31 of the previous year', type: 'number', default: 500000, min: 0, max: 1_000_000_000, prefix: '$' },
		{ id: 'growth', label: 'Expected return', type: 'number', default: 5, min: -20, max: 20, step: 0.1, suffix: '% / yr', help: 'Only used for the future-years table' }
	],
	calculate(v): CalculationResult {
		const born = Number(v.born);
		const year = Number(v.year);
		const balance = Number(v.balance);
		const growth = Number(v.growth) / 100;
		const label = `Required minimum distribution for ${Number.isFinite(year) ? year : ''}`.trim();
		if (![born, year, balance, growth].every(Number.isFinite) || balance < 0 || year - born < 0 || year - born > 130) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Check your birth year, distribution year and balance.' };
		}
		const age = year - born;
		const start = startAge(born);
		if (age < start) {
			return {
				primaryResult: money(0, true),
				primaryLabel: label,
				summary: `No RMD yet. Your first one is for ${born + start}, the year you turn ${start} (you can delay it until April 1, ${born + start + 1}).`,
				secondaryMetrics: [
					{ label: 'Your age in this year', value: String(age) },
					{ label: 'RMD start age', value: String(start) },
					{ label: 'First RMD year', value: String(born + start) },
					{ label: 'Distribution period', value: DASH }
				]
			};
		}
		const period = distributionPeriod(age);
		const rmd = balance / period;
		const rows: Record<string, string>[] = [];
		let b = balance;
		for (let a = age, y = year; a <= Math.min(age + 24, 120) && b > 0.5; a++, y++) {
			const d = distributionPeriod(a);
			const r = b / d;
			rows.push({ year: String(y), age: String(a), period: num(d, 1), balance: money(b, true), rmd: money(r, true) });
			b = (b - r) * (1 + growth);
		}
		return {
			primaryResult: money(rmd),
			primaryLabel: label,
			summary: `${money(balance, true)} ÷ ${num(period, 1)} (IRS distribution period at age ${age}) = ${pct((1 / period) * 100, 2)} of the balance.`,
			secondaryMetrics: [
				{ label: 'Your age in this year', value: String(age) },
				{ label: 'RMD start age', value: String(start) },
				{ label: 'First RMD year', value: String(born + start) },
				{ label: 'Distribution period', value: num(period, 1) }
			],
			table: {
				title: `Future RMDs at ${pct(growth * 100, 1)} return`,
				collapsed: true,
				columns: [
					{ key: 'year', label: 'Year' },
					{ key: 'age', label: 'Age' },
					{ key: 'period', label: 'Period', align: 'end' },
					{ key: 'balance', label: 'Start balance', align: 'end' },
					{ key: 'rmd', label: 'RMD', align: 'end' }
				],
				rows
			}
		};
	},
	content: {
		intro:
			'Work out the minimum you must withdraw this year from a traditional IRA, 401(k), 403(b) or similar US retirement account, using the IRS Uniform Lifetime Table and the SECURE 2.0 start ages.',
		howTo: [
			'Enter your year of birth and the year you are taking the distribution for.',
			'Enter the account balance on December 31 of the previous year.',
			'Optionally set an expected return to see future RMDs.',
			'Repeat for each account: IRA RMDs can be combined and taken from any IRA, but 401(k) RMDs come from each plan.'
		],
		formulas: [
			{
				title: 'Required minimum distribution',
				expression: 'RMD = Balance on Dec 31 of last year ÷ Distribution period',
				variables: [
					{ symbol: 'Distribution period', meaning: 'from the IRS Uniform Lifetime Table for your age at the end of this year (26.5 at 73, 24.6 at 75, 20.2 at 80)' },
					{ symbol: 'Start age', meaning: '73 if born 1951–1959, 75 if born 1960 or later' }
				]
			}
		],
		example: {
			title: 'Born in 1952, balance of $500,000 at the end of 2025',
			steps: ['Age at the end of 2026: 74', 'IRS distribution period at 74: 25.5', 'RMD: $500,000 ÷ 25.5 = $19,607.84'],
			result: 'You must withdraw at least $19,607.84 during 2026.'
		},
		faq: [
			{
				q: 'At what age do RMDs start?',
				a: 'Under SECURE 2.0, at 73 if you were born from 1951 to 1959 and at 75 if you were born in 1960 or later. You can delay the first one until April 1 of the next year, but then you take two in that year.'
			},
			{
				q: 'Do Roth IRAs have RMDs?',
				a: 'Not while the original owner is alive. Since 2024, Roth 401(k) and other Roth workplace accounts don’t require them either.'
			},
			{
				q: 'What if my spouse is more than 10 years younger?',
				a: 'If your spouse is your sole beneficiary and more than 10 years younger, you use the IRS Joint Life and Last Survivor table instead, which gives a smaller RMD. This calculator uses the Uniform Lifetime Table only.'
			},
			{
				q: 'What happens if I miss an RMD?',
				a: 'The IRS charges an excise tax of 25% of the amount not taken, cut to 10% if you correct it promptly (generally within two years).'
			}
		],
		sources: [
			{ title: 'IRS — Required minimum distributions (RMDs)', url: 'https://www.irs.gov/retirement-plans/plan-participant-employee/retirement-topics-required-minimum-distributions-rmds' },
			{ title: 'IRS — Publication 590-B', url: 'https://www.irs.gov/forms-pubs/about-publication-590-b' }
		],
		disclaimer: 'For account owners using the Uniform Lifetime Table. Inherited accounts follow different rules. Not tax advice.'
	}
});
