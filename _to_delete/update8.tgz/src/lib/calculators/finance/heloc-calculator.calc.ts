import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct, plural } from '../format';
import meta from './heloc-calculator.meta';

const isNum = (x: number, lo: number, hi: number) => Number.isFinite(x) && x >= lo && x <= hi;

/** Amortized payment over n months: M = P × r × (1 + r)ⁿ ÷ ((1 + r)ⁿ − 1), with r = 0 → P ÷ n. */
function amortizedPayment(principal: number, annualPct: number, months: number): number {
	const r = annualPct / 1200;
	if (r === 0) return principal / months;
	const f = Math.pow(1 + r, months);
	return (principal * r * f) / (f - 1);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'drawn', label: 'Amount drawn', type: 'number', default: 50000, min: 1, max: 10_000_000, step: 1000, prefix: '$' },
		{
			id: 'rate',
			label: 'Interest rate',
			type: 'number',
			default: 8.5,
			min: 0,
			max: 30,
			step: 0.01,
			suffix: '%',
			help: 'Annual rate. Many lines are variable; this assumes it stays the same.'
		},
		{
			id: 'drawYears',
			label: 'Draw period',
			type: 'number',
			default: 10,
			min: 0,
			max: 30,
			step: 1,
			suffix: 'years',
			decimal: false,
			help: 'Years you can borrow and pay interest only'
		},
		{
			id: 'repayYears',
			label: 'Repayment period',
			type: 'number',
			default: 20,
			min: 1,
			max: 30,
			step: 1,
			suffix: 'years',
			decimal: false,
			help: 'Years to pay back the balance after the draw period'
		}
	],
	calculate(v): CalculationResult {
		const drawn = Number(v.drawn);
		const rate = Number(v.rate);
		const drawYears = Number(v.drawYears);
		const repayYears = Number(v.repayYears);

		if (
			!isNum(drawn, 1, 1e9) ||
			!isNum(rate, 0, 30) ||
			!isNum(drawYears, 0, 30) ||
			!isNum(repayYears, 1, 30) ||
			!Number.isInteger(drawYears) ||
			!Number.isInteger(repayYears)
		) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Payment during draw period',
				summary: 'Enter the amount drawn, the rate, and whole-year draw and repayment periods.'
			};
		}

		const drawMonths = drawYears * 12;
		const repayMonths = repayYears * 12;
		const interestOnly = drawn * (rate / 1200);
		const repayment = amortizedPayment(drawn, rate, repayMonths);
		const totalInterest = interestOnly * drawMonths + repayment * repayMonths - drawn;
		const totalRepaid = drawn + totalInterest;

		return {
			primaryResult: money(interestOnly),
			primaryLabel: 'Payment during draw period',
			summary: `${money(drawn)} at ${pct(rate, 2)}: interest only for ${plural(drawYears, 'year')}, then repaid over ${plural(repayYears, 'year')}.`,
			secondaryMetrics: [
				{ label: 'Repayment payment', value: money(repayment) },
				{ label: 'Payment increase at repayment', value: money(repayment - interestOnly) },
				{ label: 'Draw period', value: plural(drawYears, 'year') },
				{ label: 'Repayment period', value: plural(repayYears, 'year') },
				{ label: 'Total interest', value: money(totalInterest) },
				{ label: 'Total repaid', value: money(totalRepaid) }
			]
		};
	},
	content: {
		intro:
			'Estimate payments on a home equity line of credit, or HELOC. During the draw period you pay only interest on what you have borrowed. During the repayment period the balance is paid off over a set number of years.',
		howTo: [
			'Enter the amount you have drawn on the line so far.',
			'Enter the interest rate on the line.',
			'Enter the length of the draw period and the repayment period, in whole years.',
			'Read the draw-period payment, then compare it with the repayment payment and total interest.'
		],
		formulas: [
			{
				title: 'Draw period (interest only)',
				expression: 'M = B × r        where r = annual rate ÷ 12 ÷ 100',
				variables: [{ symbol: 'B', meaning: 'balance drawn on the line' }]
			},
			{
				title: 'Repayment period (amortized)',
				expression: 'M = B × r × (1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [{ symbol: 'n', meaning: 'number of repayment months: repayment years × 12' }]
			},
			{
				title: 'Total interest',
				expression: 'Total interest = B × r × d + M × n − B',
				variables: [
					{ symbol: 'd', meaning: 'number of draw-period months' },
					{ symbol: 'M × n', meaning: 'total of the repayment payments' }
				]
			}
		],
		example: {
			title: '$50,000 drawn at 8.5%, with a 10-year draw period and a 20-year repayment period',
			steps: [
				'Draw-period payment: $50,000 × (0.085 ÷ 12) = $354.17 a month',
				'Repayment payment over 240 months: $50,000 × 0.0070833 × (1.0070833)^240 ÷ ((1.0070833)^240 − 1) ≈ $433.91',
				'Interest during draw = $354.17 × 120 = $42,500.00',
				'Total interest = $42,500.00 + $433.91 × 240 − $50,000 ≈ $96,638.79'
			],
			result: 'A payment of $354.17 a month during the draw period, rising to $433.91 during repayment, with total interest of $96,638.79.'
		},
		faq: [
			{
				q: 'Why does my payment rise when repayment starts?',
				a: 'During the draw period you pay only interest, so the balance does not fall. Once repayment starts, each payment also pays down the balance, which raises the monthly amount.'
			},
			{
				q: 'Is a HELOC rate fixed?',
				a: 'Usually not. Most HELOCs have a variable rate tied to a benchmark, so your payments can change. This calculator assumes the rate stays the same.'
			},
			{
				q: 'Does this assume I draw more during the draw period?',
				a: 'No. It assumes the balance stays at the amount you entered and that you make no new draws or extra payments.'
			}
		],
		sources: [
			{ title: 'Consumer Financial Protection Bureau: owning a home', url: 'https://www.consumerfinance.gov/owning-a-home/' },
			{ title: 'Consumer Financial Protection Bureau', url: 'https://www.consumerfinance.gov/' }
		],
		disclaimer:
			'Estimates only. Your lender sets the rate, draw and repayment terms, and fees, and rates on variable lines can change.'
	}
});
