import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num } from '../format';
import meta from './kuwait-indemnity-calculator.meta';
import { parseISO, serviceYears, yearsLabel } from '../data/service-years';
import {
	KW_CAP_MONTHS,
	KW_DAILY_DIVISOR_CALENDAR,
	KW_DAILY_DIVISOR_WORKING,
	KW_DAYS_PER_YEAR_FIRST,
	KW_FIRST_TIER_YEARS,
	KW_MONTHS_PER_YEAR_AFTER,
	KW_RESIGN_FRACTION_HALF,
	KW_RESIGN_FRACTION_TWO_THIRDS,
	KW_RESIGN_HALF_UNTIL,
	KW_RESIGN_MIN_YEARS,
	KW_RESIGN_TWO_THIRDS_UNTIL,
	KW_SOURCES
} from '../data/kw-indemnity';

/** Article 53 fraction of the indemnity paid on resignation, by years of service. */
function resignFraction(years: number): { fraction: number; text: string } {
	if (years < KW_RESIGN_MIN_YEARS) return { fraction: 0, text: 'none (under 3 years)' };
	if (years < KW_RESIGN_HALF_UNTIL) return { fraction: KW_RESIGN_FRACTION_HALF, text: 'one half (3 to under 5 years)' };
	if (years < KW_RESIGN_TWO_THIRDS_UNTIL) return { fraction: KW_RESIGN_FRACTION_TWO_THIRDS, text: 'two thirds (5 to under 10 years)' };
	return { fraction: 1, text: 'in full (10 years or more)' };
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'wage',
			label: 'Last monthly wage',
			type: 'number',
			default: 600,
			min: 0,
			max: 10_000_000,
			prefix: '$',
			help: 'Article 55 counts basic pay plus allowances and regular cash benefits, not the social and children’s allowances.'
		},
		{ id: 'start', label: 'First day of work', type: 'date', default: '2018-01-01' },
		{ id: 'end', label: 'Last day of work', type: 'date', default: 'today' },
		{
			id: 'reason',
			label: 'How the job ends',
			type: 'select',
			display: 'segmented',
			default: 'employer',
			options: [
				{ label: 'Employer ends it', value: 'employer' },
				{ label: 'I resign', value: 'resign' }
			],
			help: 'Resigning from an open-ended contract reduces the indemnity under Article 53. Cases where the full amount is due anyway (Articles 48 and 52) count as “Employer ends it”.'
		},
		{
			id: 'divisor',
			label: 'Daily wage method',
			type: 'select',
			display: 'segmented',
			default: '26',
			options: [
				{ label: 'Monthly ÷ 26', value: '26' },
				{ label: 'Monthly ÷ 30', value: '30' }
			],
			help: 'Article 67 divides by actual working days (about 26). Some employers use 30, which makes 15 days exactly half a month.'
		}
	],
	calculate(v): CalculationResult {
		const label = 'End-of-service indemnity';
		const wage = Number(v.wage);
		const start = parseISO(String(v.start));
		const end = parseISO(String(v.end));
		if (!(wage > 0) || !Number.isFinite(wage) || !start || !end) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter a monthly wage above zero and two valid dates.' };
		}
		const sy = serviceYears(start, end);
		if (!sy) return { primaryResult: DASH, primaryLabel: label, summary: 'The last day of work is before the first day.' };

		const years = sy.years;
		const divisor = String(v.divisor) === '30' ? KW_DAILY_DIVISOR_CALENDAR : KW_DAILY_DIVISOR_WORKING;
		const daily = wage / divisor;
		const first = Math.min(years, KW_FIRST_TIER_YEARS);
		const extra = Math.max(years - KW_FIRST_TIER_YEARS, 0);
		const before = first * KW_DAYS_PER_YEAR_FIRST * daily + extra * KW_MONTHS_PER_YEAR_AFTER * wage;
		const cap = wage * KW_CAP_MONTHS;
		const capped = before > cap;
		const full = Math.min(before, cap);

		const resigning = String(v.reason) === 'resign';
		const rf = resigning ? resignFraction(years) : { fraction: 1, text: 'in full' };
		const total = full * rf.fraction;

		const metrics = [
			{ label: 'Service counted', value: yearsLabel(years) },
			{ label: 'Daily wage', value: money(daily) },
			{ label: 'Full indemnity', value: capped ? `${money(full)} (capped at 18 months)` : money(full) },
			{ label: 'Resignation share (Article 53)', value: resigning ? rf.text : 'not applied' },
			{ label: 'Cap (18 months of wage)', value: capped ? `${money(cap)} (applied)` : `${money(cap)} (not reached)` }
		];
		return {
			primaryResult: money(total),
			primaryLabel: label,
			summary: resigning
				? `Full indemnity ${money(full)}; resigning after ${yearsLabel(years)} pays ${rf.text}.`
				: `${num(first * KW_DAYS_PER_YEAR_FIRST, 2)} days of wage for the first ${num(first, 2)} years${extra > 0 ? ` plus ${num(extra, 2)} months for the later years` : ''}${capped ? ', limited to 18 months of wage' : ''}.`,
			secondaryMetrics: metrics
		};
	},
	content: {
		intro:
			'Work out the end-of-service indemnity for a monthly-paid private-sector worker in Kuwait under Articles 51 and 53 of Labour Law No. 6 of 2010: 15 days of wage for each of the first five years, one month for each year after, capped at one and a half years of wage, reduced if you resign.',
		howTo: [
			'Enter your last monthly wage, including allowances and regular cash benefits, and your first and last day of work.',
			'Choose whether your employer ends the job or you resign. Resignation cuts the indemnity if you served under 10 years.',
			'Pick the daily wage method, then read the indemnity and the working underneath.'
		],
		formulas: [
			{
				title: 'Indemnity under Article 51 (monthly-paid workers)',
				expression: 'Indemnity = min(Y, 5) × 15 × D + max(Y − 5, 0) × W, capped at 18 × W',
				variables: [
					{ symbol: 'Y', meaning: 'Years of service, with the part year counted pro rata.' },
					{ symbol: 'W', meaning: 'Last monthly wage.' },
					{ symbol: 'D', meaning: 'Daily wage: W ÷ 26 (or W ÷ 30).' }
				]
			},
			{
				title: 'Resignation share, Article 53 (open-ended contracts)',
				expression: 'Under 3 years: 0 · 3 to under 5: ½ · 5 to under 10: ⅔ · 10 or more: full',
				variables: [{ symbol: '½, ⅔', meaning: 'The fraction of the Article 51 indemnity that you receive.' }]
			}
		],
		example: {
			title: 'KWD 600 wage, 1 January 2018 to 31 December 2024',
			steps: [
				'Service: exactly 7 years, so 5 years at 15 days and 2 years at one month.',
				'Daily wage (÷ 26): 600 ÷ 26 = KWD 23.077.',
				'Years 1 to 5: 5 × 15 × 23.077 = KWD 1,730.769. Years 6 and 7: 2 × 600 = KWD 1,200.000.',
				'Full indemnity: KWD 2,930.769. The cap (18 × 600 = KWD 10,800) is not reached. If you resigned, two thirds applies: KWD 1,953.846.'
			],
			result: 'KWD 2,930.769'
		},
		faq: [
			{
				q: 'Does resigning reduce my indemnity?',
				a: 'Yes, if your contract is open-ended. Under Article 53 you get nothing under 3 years, half from 3 to under 5 years, two thirds from 5 to under 10 years and the full amount from 10 years. The 2017 and 2018 amendments only stopped employers deducting their social-security contributions; they did not change this.'
			},
			{
				q: 'Which wage and which daily divisor?',
				a: 'Article 55 reads “wage” as basic pay plus the allowances and regular cash benefits set by your contract, though many employers use basic pay alone. For a day’s wage, Article 67 divides by actual working days, about 26 a month. Some employers divide by 30; that makes the first five years slightly lower than dividing by 26.'
			},
			{
				q: 'Who is not covered by this calculator?',
				a: 'Workers paid by the day, week, hour or piece (10 days a year for five years, then 15, capped at one year), fixed-term contracts, government and oil-sector staff and domestic workers have different rules and are not modelled here.'
			}
		],
		sources: KW_SOURCES,
		disclaimer:
			'Estimate for monthly-paid private-sector workers under Labour Law No. 6 of 2010. Employer loans you owe can be deducted, and your contract may pay more. This is not legal advice; confirm with the Public Authority for Manpower or a Kuwaiti lawyer.'
	}
});
