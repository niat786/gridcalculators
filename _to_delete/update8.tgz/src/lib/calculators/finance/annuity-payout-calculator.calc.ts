import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, pct, plural } from '../format';
import meta from './annuity-payout-calculator.meta';

const modeOptions = [
	{ label: 'Payout amount', value: 'amount' },
	{ label: 'How long it lasts', value: 'length' }
];

/**
 * Fixed monthly payouts from a lump sum that earns interest each month.
 * "amount": the level payment that empties the sum over a set number of years.
 * "length": the number of months a known payout lasts. If the payout does not cover the
 * monthly interest, the balance never falls, so the answer is "never runs out".
 */
export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Find',
			type: 'select',
			display: 'segmented',
			default: 'amount',
			options: modeOptions
		},
		{ id: 'principal', label: 'Starting principal', type: 'number', default: 500000, min: 0, max: 1_000_000_000, step: 1000, prefix: '$', help: 'The lump sum you start paying out from.' },
		{ id: 'rate', label: 'Annual interest rate', type: 'number', default: 5, min: 0, max: 100, step: 0.1, suffix: '%', help: 'Earned on the balance, compounded monthly.' },
		{
			id: 'years',
			label: 'Payout period',
			type: 'number',
			default: 25,
			min: 1,
			max: 100,
			step: 1,
			decimal: false,
			suffix: 'years',
			visibleWhen: (v) => v.mode === 'amount'
		},
		{
			id: 'payout',
			label: 'Monthly payout',
			type: 'number',
			default: 3000,
			min: 0,
			max: 10_000_000,
			step: 100,
			prefix: '$',
			suffix: '/mo',
			visibleWhen: (v) => v.mode === 'length'
		}
	],
	calculate(v): CalculationResult {
		const principal = Number(v.principal);
		const annualRate = Number(v.rate);
		const r = annualRate / 1200;

		if (!(principal > 0) || !(annualRate >= 0 && annualRate <= 100) || (v.mode !== 'amount' && v.mode !== 'length')) {
			return { primaryResult: DASH, primaryLabel: 'Monthly payout', summary: 'Enter a starting principal above zero and a rate from 0 to 100%.' };
		}

		if (v.mode === 'amount') {
			const years = Number(v.years);
			if (!(Number.isInteger(years) && years >= 1 && years <= 100)) {
				return { primaryResult: DASH, primaryLabel: 'Monthly payout', summary: 'Enter a payout period from 1 to 100 years.' };
			}
			const n = years * 12;
			const payment = r === 0 ? principal / n : (principal * r) / (1 - Math.pow(1 + r, -n));
			const total = payment * n;
			return {
				primaryResult: money(payment),
				primaryLabel: 'Monthly payout',
				summary: `Paying ${money(payment)} a month for ${plural(years, 'year')} empties the ${money(principal, true)} starting sum.`,
				secondaryMetrics: [
					{ label: 'Number of payouts', value: num(n, 0) },
					{ label: 'Total paid out', value: money(total) },
					{ label: 'Interest in payouts', value: money(total - principal) }
				]
			};
		}

		const payout = Number(v.payout);
		if (!(payout > 0)) {
			return { primaryResult: DASH, primaryLabel: 'Time the payouts last', summary: 'Enter a monthly payout above zero.' };
		}

		const monthlyInterest = principal * r;
		if (payout <= monthlyInterest) {
			const g = Math.pow(1 + r, 120);
			const balance10 = principal * g - payout * ((g - 1) / r);
			return {
				primaryResult: 'Never runs out',
				primaryLabel: 'Time the payouts last',
				summary: `A payout of ${money(payout)} does not cover the ${money(monthlyInterest)} earned each month, so the balance never falls.`,
				secondaryMetrics: [
					{ label: 'Monthly interest earned', value: money(monthlyInterest) },
					{ label: 'Monthly payout', value: money(payout) },
					{ label: 'Balance after 10 years', value: money(balance10) }
				]
			};
		}

		const months = r === 0 ? principal / payout : -Math.log(1 - monthlyInterest / payout) / Math.log(1 + r);
		if (!Number.isFinite(months) || months < 0) {
			return { primaryResult: DASH, primaryLabel: 'Time the payouts last', summary: 'Check the principal, rate and payout.' };
		}

		const full = Math.floor(months + 1e-9);
		const g = Math.pow(1 + r, full);
		const balance = r === 0 ? principal - payout * full : principal * g - payout * ((g - 1) / r);
		const partial = balance > 0.005 ? balance * (1 + r) : 0;
		const total = payout * full + partial;

		const years = Math.floor(full / 12);
		const rest = full % 12;
		const parts: string[] = [];
		if (years > 0) parts.push(plural(years, 'year'));
		if (rest > 0) parts.push(plural(rest, 'month'));
		const lasts = full === 0 ? 'Under 1 month' : parts.join(', ');

		return {
			primaryResult: lasts,
			primaryLabel: 'Time the payouts last',
			summary: `${plural(full, 'full payout')} of ${money(payout)}, then a final payment of ${money(partial)}.`,
			secondaryMetrics: [
				{ label: 'Total paid out', value: money(total) },
				{ label: 'Interest in payouts', value: money(total - principal) },
				{ label: 'Final partial payout', value: money(partial) }
			]
		};
	},
	content: {
		intro:
			'Work out either side of a monthly payout plan. Find the level monthly payout that uses up a lump sum over a set number of years, or find how long a fixed monthly payout lasts from the same sum.',
		howTo: [
			'Choose what you want to find: the payout amount, or how long the payouts last.',
			'Enter the starting principal and the annual interest rate the balance earns.',
			'For a payout amount, enter the number of years. For how long it lasts, enter the monthly payout.',
			'Read the result. If the payout is no more than the monthly interest, the balance never falls.'
		],
		formulas: [
			{
				title: 'Monthly payout that empties the sum',
				expression: 'PMT = P × r ÷ (1 − (1 + r)⁻ⁿ)',
				variables: [
					{ symbol: 'PMT', meaning: 'monthly payout' },
					{ symbol: 'P', meaning: 'starting principal' },
					{ symbol: 'r', meaning: 'monthly interest rate: annual rate ÷ 12 ÷ 100' },
					{ symbol: 'n', meaning: 'number of monthly payouts: years × 12' }
				]
			},
			{
				title: 'Number of months a payout lasts',
				expression: 'n = −ln(1 − P × r ÷ PMT) ÷ ln(1 + r)',
				variables: [
					{ symbol: 'n', meaning: 'number of monthly payouts' },
					{ symbol: 'ln', meaning: 'natural logarithm' }
				]
			}
		],
		example: {
			title: '$500,000 at 5% a year, paid out over 25 years',
			steps: [
				'Monthly rate: r = 5 ÷ 12 ÷ 100 ≈ 0.00416667',
				'Number of payouts: n = 25 × 12 = 300',
				'Discount factor: (1 + r)⁻³⁰⁰ ≈ 0.287250',
				'Denominator: 1 − 0.287250 = 0.712750',
				'Monthly payout: $500,000 × 0.00416667 ÷ 0.712750 ≈ $2,922.95'
			],
			result: 'A level payout of about $2,922.95 a month empties the sum over 25 years.'
		},
		faq: [
			{
				q: 'What does "never runs out" mean?',
				a: 'It means the monthly payout is no more than the interest the balance earns each month. The balance does not shrink, so the payouts can continue without end at this rate.'
			},
			{
				q: 'Why is the final payment smaller?',
				a: 'The time needed rarely comes out to a whole number of months. The last payment covers the remaining balance with its interest and is usually smaller than the regular payout.'
			},
			{
				q: 'Does this include taxes or fees?',
				a: 'No. The calculator assumes a fixed rate, a fixed payout and no fees. Taxes on the interest or the payouts, and any charges from a provider, are not included.'
			}
		],
		sources: [{ title: 'U.S. Securities and Exchange Commission — Investor.gov', url: 'https://www.investor.gov' }],
		disclaimer:
			'Estimates only. Real balances change with actual returns, and annuity contracts can have fees, surrender charges and taxes that this calculator does not include.'
	}
});
