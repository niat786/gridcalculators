import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct } from '../format';
import meta from './ir35-calculator.meta';
import {
	APPRENTICESHIP_LEVY_RATE,
	NI_EMPLOYER_RATE,
	NI_SECONDARY_THRESHOLD,
	PERSONAL_ALLOWANCE,
	UK_CORPORATION_TAX_SOURCE,
	UK_DIVIDEND_SOURCE,
	UK_INCOME_TAX_RATES_TABLE_SOURCE,
	UK_RATES_SOURCE
} from '../data/uk-tax-2026-27';
import {
	STANDARD_CODE,
	corporationTax,
	dividendTax,
	employeeNI,
	employerNI,
	incomeTax,
	taperedAllowance,
	type ParsedCode
} from '../data/uk-tax-engine';

type Costs = 'ontop' | 'ni' | 'nilevy';

/** Deemed employment payment D left after the fee-payer deducts employer costs from a gross fee G. */
export function deemedPayment(gross: number, costs: Costs): number {
	if (costs === 'ontop') return gross;
	const levy = costs === 'nilevy' ? APPRENTICESHIP_LEVY_RATE : 0;
	// G = D + 15% × (D − £5,000) + levy × D, when D is above the secondary threshold.
	const above = (gross + NI_EMPLOYER_RATE * NI_SECONDARY_THRESHOLD) / (1 + NI_EMPLOYER_RATE + levy);
	if (above > NI_SECONDARY_THRESHOLD) return above;
	return gross / (1 + levy);
}

export function insideTakeHome(gross: number, costs: Costs) {
	const d = deemedPayment(gross, costs);
	const tax = incomeTax(d, 'rest', STANDARD_CODE).tax;
	const ni = employeeNI(d).total;
	return { deemed: d, employerCosts: gross - d, tax, ni, net: d - tax - ni };
}

export function outsideTakeHome(revenue: number, running: number, salary: number) {
	const erNI = employerNI(salary);
	const profit = revenue - running - salary - erNI;
	const ct = corporationTax(profit);
	const dividends = Math.max(0, profit - ct);
	const allowance = taperedAllowance(salary + dividends);
	const salaryCode: ParsedCode = { kind: 'allowance', amount: allowance, rate: 0, taper: false };
	const salaryTax = incomeTax(salary, 'rest', salaryCode).tax;
	const ni = employeeNI(salary).total;
	const divTax = dividendTax(salary, dividends).tax;
	return { erNI, profit, ct, dividends, salaryTax, ni, divTax, net: salary - salaryTax - ni + dividends - divTax };
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'rate', label: 'Day rate', type: 'number', default: 500, min: 0, max: 10_000, step: 10, prefix: '$' },
		{ id: 'days', label: 'Days worked per year', type: 'number', default: 220, min: 1, max: 365, step: 1, decimal: false, suffix: 'days' },
		{
			id: 'costs',
			label: 'Inside IR35: employer costs',
			type: 'select',
			display: 'segmented',
			default: 'ni',
			options: [
				{ label: 'Client pays', value: 'ontop' },
				{ label: 'NI deducted', value: 'ni' },
				{ label: 'NI + levy', value: 'nilevy' }
			],
			help: 'Whether the fee-payer takes employer NI (and the 0.5% apprenticeship levy) out of your rate.'
		},
		{
			id: 'salary',
			label: 'Outside IR35: director salary',
			type: 'number',
			default: PERSONAL_ALLOWANCE,
			min: 0,
			max: 1_000_000,
			step: 100,
			prefix: '$',
			help: 'Default is the £12,570 personal allowance.'
		},
		{ id: 'running', label: 'Outside IR35: company running costs', type: 'number', default: 0, min: 0, max: 10_000_000, step: 100, prefix: '$', suffix: '/yr', help: 'Accountant, insurance and similar.' }
	],
	calculate(v): CalculationResult {
		const fail = (summary: string): CalculationResult => ({ primaryResult: DASH, primaryLabel: 'Extra take-home outside IR35', summary });
		const rate = Number(v.rate);
		const days = Number(v.days);
		const salary = Number(v.salary);
		const running = Number(v.running);
		const costs = (['ontop', 'ni', 'nilevy'].includes(String(v.costs)) ? String(v.costs) : 'ni') as Costs;
		if (!(rate > 0) || !(days >= 1) || !Number.isFinite(rate * days)) return fail('Enter a day rate and the days you work.');
		if (!(salary >= 0) || !(running >= 0) || !Number.isFinite(salary + running)) return fail('Enter your director salary and running costs.');
		const gross = rate * days;
		if (salary > gross) return fail('The director salary cannot be more than your contract income.');

		const inside = insideTakeHome(gross, costs);
		const out = outsideTakeHome(gross, running, salary);

		// Day rate inside IR35 that would give the same take-home as outside.
		let lo = 0;
		let hi = rate * 20;
		for (let i = 0; i < 80; i++) {
			const mid = (lo + hi) / 2;
			if (insideTakeHome(mid * days, costs).net < out.net) lo = mid;
			else hi = mid;
		}
		const breakEven = (lo + hi) / 2;
		const diff = out.net - inside.net;

		const rows: Record<string, string>[] = [];
		const row = (item: string, a: number | null, b: number | null) =>
			rows.push({ item, inside: a === null ? '—' : money(a), outside: b === null ? '—' : money(b) });
		row('Contract income', gross, gross);
		row('Company running costs', null, -running);
		row('Employer NI and levy', -inside.employerCosts, -out.erNI);
		row('Corporation tax', null, -out.ct);
		row('Salary / deemed payment', inside.deemed, salary);
		row('Dividends', null, out.dividends);
		row('Income tax on pay', -inside.tax, -out.salaryTax);
		row('Employee National Insurance', -inside.ni, -out.ni);
		row('Income tax on dividends', null, -out.divTax);
		row('Take-home per year', inside.net, out.net);
		row('Take-home per month', inside.net / 12, out.net / 12);

		return {
			primaryResult: money(diff),
			primaryLabel: diff >= 0 ? 'Extra take-home outside IR35 (per year)' : 'Take-home lost outside IR35 (per year)',
			summary: `Outside IR35 you keep ${money(out.net)} a year; inside IR35 you keep ${money(inside.net)}. An inside-IR35 day rate of ${money(breakEven)} would match the outside take-home.`,
			secondaryMetrics: [
				{ label: 'Inside IR35 take-home', value: money(inside.net) },
				{ label: 'Outside IR35 take-home', value: money(out.net) },
				{ label: 'Inside, share of contract income', value: pct((inside.net / gross) * 100, 1) },
				{ label: 'Outside, share of contract income', value: pct((out.net / gross) * 100, 1) },
				{ label: 'Inside day rate that matches outside', value: money(breakEven) },
				{ label: 'Corporation tax (outside)', value: money(out.ct) },
				{ label: 'Dividend tax (outside)', value: money(out.divTax) }
			],
			table: {
				title: 'Inside vs outside IR35, per year',
				columns: [
					{ key: 'item', label: 'Item' },
					{ key: 'inside', label: 'Inside IR35', align: 'end' },
					{ key: 'outside', label: 'Outside IR35', align: 'end' }
				],
				rows
			}
		};
	},
	content: {
		intro:
			'Compare a UK contractor\'s take-home pay inside IR35 (taxed as an employee) and outside IR35 (through your own limited company) for the 2026/27 tax year, using your day rate and days worked.',
		howTo: [
			'Enter your day rate and how many days you work each year.',
			'Choose whether the fee-payer takes employer NI (and the apprenticeship levy) out of your rate inside IR35.',
			'Set your director salary and company running costs for the outside IR35 case.',
			'Compare the two take-home figures and the day rate that would make them equal.'
		],
		formulas: [
			{
				title: 'Inside IR35',
				expression: 'Fee = D + 15% × (D − £5,000) [+ 0.5% × D]; take-home = D − income tax(D) − employee NI(D)',
				variables: [{ symbol: 'D', meaning: 'the deemed employment payment left after employer NI (and levy) are deducted from your fee' }]
			},
			{
				title: 'Outside IR35 (limited company)',
				expression: 'Profit = income − costs − salary − employer NI; after-tax profit = profit − corporation tax; take-home = salary − tax − NI + dividends − dividend tax',
				variables: [
					{ symbol: 'Corporation tax', meaning: '19% up to £50,000, 25% over £250,000, marginal relief between (25% less 3/200 × (£250,000 − profit))' },
					{ symbol: 'Dividends', meaning: '£500 allowance, then 10.75%, 35.75% and 39.35%' }
				]
			}
		],
		example: {
			title: '£500 a day, 220 days, default settings (employer NI deducted)',
			steps: [
				'Contract income = £500 × 220 = £110,000',
				'Inside IR35: the deemed payment is (£110,000 + £750) ÷ 1.15 = £96,304.35 after £13,695.65 of employer NI',
				'Outside IR35: salary £12,570, employer NI £1,135.50, corporation tax £21,768.04, dividends £74,526.46'
			],
			result: 'Outside IR35 you keep about £69,932 a year compared with about £66,414 inside IR35.'
		},
		faq: [
			{
				q: 'What assumptions does this make?',
				a: 'England, Wales and Northern Ireland tax rates; one director with no other income or employees; no associated companies; all profit paid out as dividends in the same year; no pension, expenses claims, student loan or VAT; the employment allowance does not apply to a sole-director company. The old 5% allowance inside IR35 no longer exists.'
			},
			{
				q: 'Why can the fee-payer deduct employer NI?',
				a: 'Under the off-payroll rules the fee-payer pays employer National Insurance on the deemed payment. Many agencies and clients build that cost into the rate they offer, which is why you can choose whether it comes off your rate.'
			},
			{
				q: 'Is this tax advice?',
				a: 'No. IR35 status depends on the facts of each engagement. Use the HMRC CEST tool or take advice, and check current rates after any Budget.'
			}
		],
		sources: [UK_RATES_SOURCE, UK_INCOME_TAX_RATES_TABLE_SOURCE, UK_DIVIDEND_SOURCE, UK_CORPORATION_TAX_SOURCE],
		disclaimer: 'Estimate for 2026/27 only. Your real position depends on your contract, expenses, other income and company circumstances. Not tax advice.'
	}
});
