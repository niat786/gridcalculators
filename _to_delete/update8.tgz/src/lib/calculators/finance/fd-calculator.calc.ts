import { defineCalculator, type InputValues } from '../types';
import { DASH, money, num, pct } from '../format';
import {
	BANK_DEPOSIT_SOURCE,
	DEPOSIT_TDS_SOURCE,
	FD_TDS_RATE_PCT,
	FD_TDS_THRESHOLD,
	FD_TDS_THRESHOLD_SENIOR,
	SENIOR_EXTRA_RATE_DEFAULT
} from '../data/in-deposits';
import meta from './fd-calculator.meta';

/** Compounding periods per year; 0 = simple interest, no compounding. */
const PERIODS: Record<string, number> = { quarterly: 4, monthly: 12, halfyearly: 2, yearly: 1, simple: 0 };

/** Maturity of a lump sum. t in years. n = 0 means simple interest. */
export function fdMaturity(principal: number, ratePct: number, n: number, t: number): number {
	const r = ratePct / 100;
	return n === 0 ? principal * (1 + r * t) : principal * Math.pow(1 + r / n, n * t);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'deposit', label: 'Deposit amount', type: 'number', default: 100000, min: 1, max: 1_000_000_000, step: 1000, prefix: '$' },
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 7, min: 0, max: 30, step: 0.05, suffix: '% a year' },
		{ id: 'years', label: 'Tenure: years', type: 'number', default: 5, min: 0, max: 30, step: 1, decimal: false, suffix: 'years', width: 'half' },
		{ id: 'months', label: 'Months', type: 'number', default: 0, min: 0, max: 360, step: 1, decimal: false, suffix: 'months', width: 'half' },
		{ id: 'days', label: 'Days', type: 'number', default: 0, min: 0, max: 3650, step: 1, decimal: false, suffix: 'days', width: 'half', help: 'Days are counted as days ÷ 365.' },
		{
			id: 'compounding',
			label: 'Interest',
			type: 'select',
			display: 'menu',
			default: 'quarterly',
			options: [
				{ label: 'Compounded quarterly (usual for Indian banks)', value: 'quarterly' },
				{ label: 'Compounded monthly', value: 'monthly' },
				{ label: 'Compounded half-yearly', value: 'halfyearly' },
				{ label: 'Compounded yearly', value: 'yearly' },
				{ label: 'Simple interest (paid out, no compounding)', value: 'simple' }
			]
		},
		{ id: 'senior', label: 'Senior citizen rate', type: 'toggle', default: false },
		{
			id: 'extra',
			label: 'Extra rate for senior citizens',
			type: 'number',
			default: SENIOR_EXTRA_RATE_DEFAULT,
			min: 0,
			max: 5,
			step: 0.05,
			suffix: '%',
			help: 'Banks usually add about 0.50%, but each bank sets its own. Edit to match yours.',
			visibleWhen: (v) => v.senior === true
		}
	],
	calculate(v: InputValues) {
		const P = Number(v.deposit);
		const rate = Number(v.rate);
		const years = Number(v.years);
		const months = Number(v.months);
		const days = Number(v.days);
		const extra = Number(v.extra);
		const n = PERIODS[String(v.compounding)];
		const senior = v.senior === true;
		const fail = (summary: string) => ({ primaryResult: DASH, primaryLabel: 'Maturity amount', summary });
		if (!(P >= 1 && P <= 1_000_000_000)) return fail('Enter the deposit amount.');
		if (!(rate >= 0 && rate <= 30)) return fail('Enter an interest rate between 0% and 30%.');
		if (![years, months, days].every((x) => Number.isInteger(x) && x >= 0)) return fail('Enter the tenure in whole years, months and days.');
		if (years > 30 || months > 360 || days > 3650) return fail('Tenure is too long.');
		if (n === undefined) return fail('Pick how interest is paid.');
		if (senior && !(extra >= 0 && extra <= 5)) return fail('Enter the extra senior citizen rate (0% to 5%).');
		const t = (years * 12 + months) / 12 + days / 365;
		if (!(t > 0 && t <= 30)) return fail('Enter a tenure above zero and up to 30 years.');

		const applied = rate + (senior ? extra : 0);
		const maturity = fdMaturity(P, applied, n, t);
		const interest = maturity - P;
		const yieldPct = n === 0 ? applied : (Math.pow(1 + applied / 100 / n, n) - 1) * 100;
		const parts = [
			years ? `${num(years, 0)} ${years === 1 ? 'year' : 'years'}` : '',
			months ? `${num(months, 0)} ${months === 1 ? 'month' : 'months'}` : '',
			days ? `${num(days, 0)} ${days === 1 ? 'day' : 'days'}` : ''
		].filter(Boolean);

		return {
			primaryResult: money(maturity),
			primaryLabel: 'Maturity amount',
			summary: `${money(P, true)} at ${pct(applied, 2)} for ${parts.join(' ')} earns ${money(interest)} in interest.`,
			secondaryMetrics: [
				{ label: 'Interest earned', value: money(interest) },
				{ label: 'Amount deposited', value: money(P) },
				{ label: 'Rate applied', value: pct(applied, 2) },
				{ label: 'Effective yearly return', value: pct(yieldPct, 3) }
			]
		};
	},
	content: {
		intro:
			'Work out what a fixed deposit (FD) will pay at maturity, using the way Indian banks quote it: interest compounded quarterly unless you choose otherwise. Enter the tenure in years, months and days.',
		howTo: [
			'Enter the deposit, the rate your bank quotes and the tenure.',
			'Pick how interest is worked out. Quarterly compounding is the usual Indian bank default; simple interest suits payout FDs.',
			'Turn on the senior citizen rate if it applies, and edit the extra rate to match your bank.'
		],
		formulas: [
			{
				title: 'Compound interest',
				expression: 'A = P × (1 + r ÷ n)^(n × t)',
				variables: [
					{ symbol: 'P', meaning: 'deposit' },
					{ symbol: 'r', meaning: 'annual rate as a decimal' },
					{ symbol: 'n', meaning: 'compounding periods a year (quarterly 4, monthly 12, half-yearly 2, yearly 1)' },
					{ symbol: 't', meaning: 'tenure in years: (years × 12 + months) ÷ 12 + days ÷ 365' }
				]
			},
			{
				title: 'Simple interest',
				expression: 'A = P × (1 + r × t)',
				variables: [{ symbol: 'A', meaning: 'principal plus interest, with no interest on interest' }]
			}
		],
		example: {
			title: '₹1,00,000 at 7% for 5 years, compounded quarterly',
			steps: [
				'Rate per quarter: 7% ÷ 4 = 1.75%',
				'Quarters: 5 × 4 = 20',
				'A = 1,00,000 × 1.0175²⁰ = ₹1,41,477.82',
				'Interest = ₹41,477.82'
			],
			result: 'Maturity amount ₹1,41,477.82, an effective yearly return of 7.186%.'
		},
		faq: [
			{
				q: 'Is tax deducted from FD interest?',
				a: `Banks in India deduct TDS at ${FD_TDS_RATE_PCT}% (with PAN) once interest at one bank passes ₹${num(FD_TDS_THRESHOLD)} in a year, or ₹${num(FD_TDS_THRESHOLD_SENIOR)} for senior citizens. This calculator shows interest before tax and does not deduct anything. Interest is taxable at your slab rate.`
			},
			{
				q: 'Why quarterly compounding?',
				a: 'Most Indian banks add interest to a cumulative FD every quarter. If your bank compounds differently, change the interest option.'
			},
			{
				q: 'Can I use this outside India?',
				a: 'Yes, the maths is general and the currency is switchable. The defaults and the tax note follow Indian bank practice. Banks may count days or round differently, so the bank’s own figure can differ slightly.'
			}
		],
		sources: [DEPOSIT_TDS_SOURCE, BANK_DEPOSIT_SOURCE],
		disclaimer:
			'Estimates only. Banks set rates, day counts, rounding and early-withdrawal penalties. Interest is shown before tax and TDS.'
	}
});
