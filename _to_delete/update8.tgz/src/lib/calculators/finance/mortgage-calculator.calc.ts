import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, moneyCompact, num, plural } from '../format';
import meta from './mortgage-calculator.meta';

/** Standard fixed-rate payment: M = P·r(1+r)^n / ((1+r)^n − 1); r = 0 → P / n. */
export function monthlyPayment(principal: number, annualRatePct: number, months: number): number {
	const r = annualRatePct / 100 / 12;
	if (r === 0) return principal / months;
	const f = Math.pow(1 + r, months);
	return (principal * r * f) / (f - 1);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'price', label: 'Home price', type: 'number', default: 400000, min: 0, max: 100_000_000, step: 1000, prefix: '$' },
		{ id: 'down', label: 'Down payment', type: 'number', default: 20, min: 0, max: 100, step: 0.5, suffix: '%' },
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 6.5, min: 0, max: 30, step: 0.01, suffix: '%', help: 'Annual rate (APR without fees)' },
		{
			id: 'term',
			label: 'Loan term',
			type: 'select',
			display: 'segmented',
			default: '30',
			options: [
				{ label: '30 yr', value: '30' },
				{ label: '20 yr', value: '20' },
				{ label: '15 yr', value: '15' },
				{ label: '10 yr', value: '10' }
			]
		},
		{ id: 'tax', label: 'Property tax', type: 'number', default: 4800, min: 0, max: 1_000_000, step: 100, prefix: '$', suffix: '/yr' },
		{ id: 'insurance', label: 'Home insurance', type: 'number', default: 1500, min: 0, max: 1_000_000, step: 100, prefix: '$', suffix: '/yr' },
		{ id: 'hoa', label: 'HOA fees', type: 'number', default: 0, min: 0, max: 100_000, step: 10, prefix: '$', suffix: '/mo' }
	],
	calculate(v): CalculationResult {
		const price = Number(v.price);
		const downPct = Number(v.down);
		const rate = Number(v.rate);
		const years = Number(v.term);
		const tax = Number(v.tax) || 0;
		const insurance = Number(v.insurance) || 0;
		const hoa = Number(v.hoa) || 0;

		const loan = price * (1 - downPct / 100);
		const n = years * 12;
		if (!(loan > 0) || !Number.isFinite(loan) || !(years >= 1 && years <= 50) || !(rate >= 0 && rate <= 100)) {
			return { primaryResult: DASH, primaryLabel: 'Monthly payment', summary: 'Enter a home price and a down payment below 100%.' };
		}

		const pi = monthlyPayment(loan, rate, n);
		const monthly = pi + tax / 12 + insurance / 12 + hoa;
		const totalPI = pi * n;
		const totalInterest = totalPI - loan;

		// Yearly amortization
		const r = rate / 100 / 12;
		let balance = loan;
		let cumInterest = 0;
		const chartData: Record<string, number>[] = [{ year: 0, balance: loan, interest: 0 }];
		const rows: Record<string, string>[] = [];
		for (let y = 1; y <= years; y++) {
			let yPrincipal = 0;
			let yInterest = 0;
			for (let m = 0; m < 12; m++) {
				const interest = balance * r;
				const principal = Math.min(pi - interest, balance);
				balance -= principal;
				yPrincipal += principal;
				yInterest += interest;
			}
			if (balance < 0.005) balance = 0;
			cumInterest += yInterest;
			chartData.push({ year: y, balance, interest: cumInterest });
			rows.push({
				year: String(y),
				principal: money(yPrincipal, true),
				interest: money(yInterest, true),
				balance: money(balance, true)
			});
		}

		return {
			primaryResult: money(monthly),
			primaryLabel: 'Estimated monthly payment',
			summary: `${money(loan, true)} loan over ${plural(years, 'year')} at ${num(rate, 3)}%.`,
			secondaryMetrics: [
				{ label: 'Principal & interest', value: money(pi) },
				{ label: 'Property tax', value: money(tax / 12) },
				{ label: 'Home insurance', value: money(insurance / 12) },
				...(hoa > 0 ? [{ label: 'HOA fees', value: money(hoa) }] : []),
				{ label: 'Loan amount', value: money(loan, true) },
				{ label: 'Total interest', value: money(totalInterest, true) },
				{ label: 'Total of payments', value: money(totalPI, true) }
			],
			chart: {
				type: 'line',
				title: 'Loan balance and interest paid over time',
				x: 'year',
				xLabel: 'Year',
				series: [
					{ key: 'balance', label: 'Remaining balance' },
					{ key: 'interest', label: 'Total interest paid' }
				],
				data: chartData,
				valueFormat: 'currency'
			},
			table: {
				title: 'Amortization schedule (yearly)',
				collapsed: true,
				columns: [
					{ key: 'year', label: 'Year' },
					{ key: 'principal', label: 'Principal', align: 'end' },
					{ key: 'interest', label: 'Interest', align: 'end' },
					{ key: 'balance', label: 'Balance', align: 'end' }
				],
				rows
			}
		};
	},
	content: {
		intro:
			'Estimate your monthly mortgage payment, including property tax, insurance and HOA fees, and see how much interest you will pay over the life of the loan.',
		howTo: [
			'Enter the home price and your down payment as a percentage.',
			'Enter the interest rate your lender quoted and pick a loan term.',
			'Add yearly property tax and insurance, and any monthly HOA fees.',
			'Read your monthly payment, then open the schedule to see each year.'
		],
		formulas: [
			{
				title: 'Monthly principal and interest',
				expression: 'M = P × r(1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'M', meaning: 'monthly principal and interest payment' },
					{ symbol: 'P', meaning: 'loan amount (home price minus down payment)' },
					{ symbol: 'r', meaning: 'monthly interest rate (annual rate ÷ 12 ÷ 100)' },
					{ symbol: 'n', meaning: 'number of monthly payments (years × 12)' }
				]
			},
			{
				expression: 'Monthly payment = M + property tax ÷ 12 + insurance ÷ 12 + HOA',
				variables: []
			}
		],
		example: {
			title: 'A $400,000 home with 20% down at 6.5% for 30 years',
			steps: [
				'Loan amount: P = $400,000 × (1 − 0.20) = $320,000',
				'Monthly rate: r = 6.5 ÷ 12 ÷ 100 = 0.00541667',
				'Number of payments: n = 30 × 12 = 360',
				'Growth factor: (1 + r)ⁿ = 1.00541667³⁶⁰ ≈ 6.991798',
				'M = 320,000 × 0.00541667 × 6.991798 ÷ (6.991798 − 1) ≈ $2,022.62',
				'Add $4,800 ÷ 12 tax ($400) and $1,500 ÷ 12 insurance ($125)'
			],
			result:
				'Monthly payment ≈ $2,547.62. Over 30 years you pay about $408,142 in interest.'
		},
		faq: [
			{
				q: 'What is included in a mortgage payment?',
				a: 'Most payments include principal and interest, plus property tax and home insurance collected by the lender into an escrow account. Some homes also have HOA fees or private mortgage insurance (PMI).'
			},
			{
				q: 'How does a bigger down payment change my payment?',
				a: 'A bigger down payment lowers the loan amount, so both the monthly payment and the total interest go down. Putting at least 20% down on a conventional loan usually also avoids PMI.'
			},
			{
				q: 'Is a 15-year or 30-year mortgage better?',
				a: 'A 15-year loan has a higher monthly payment but usually a lower rate and far less total interest. A 30-year loan keeps payments lower and more flexible. The right choice depends on your budget and goals.'
			},
			{
				q: 'Does this calculator include PMI?',
				a: 'No. If you put less than 20% down on a conventional loan, ask your lender for the PMI amount and add it to the HOA field as a monthly cost to include it.'
			}
		],
		sources: [
			{
				title: 'Consumer Financial Protection Bureau — Explore interest rates',
				url: 'https://www.consumerfinance.gov/owning-a-home/explore-rates/'
			}
		],
		disclaimer:
			'Estimates only. Your actual rate, taxes, insurance and fees depend on your lender and location.'
	}
});
