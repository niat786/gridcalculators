import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct } from '../format';
import meta from './sales-tax-calculator.meta';

/** Round to whole cents so the displayed amounts always add up. */
const cents = (n: number) => Math.round(n * 100) / 100;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Calculation',
			type: 'select',
			display: 'segmented',
			default: 'add',
			options: [
				{ label: 'Add tax', value: 'add' },
				{ label: 'Remove tax', value: 'remove' }
			]
		},
		{
			id: 'amount',
			label: 'Price',
			type: 'number',
			default: 100,
			min: 0,
			max: 100_000_000,
			step: 0.01,
			prefix: '$',
			help: 'Before tax in Add tax mode. Including tax in Remove tax mode.'
		},
		{ id: 'rate', label: 'Sales tax rate', type: 'number', default: 8, min: 0, max: 100, step: 0.01, suffix: '%' }
	],
	calculate(v): CalculationResult {
		const remove = String(v.mode) === 'remove';
		const label = remove ? 'Net price (before tax)' : 'Total with tax';
		const amount = Number(v.amount);
		const rate = Number(v.rate);

		if (!(amount >= 0) || !Number.isFinite(amount) || !(rate >= 0 && rate <= 100)) {
			return {
				primaryResult: DASH,
				primaryLabel: label,
				summary: 'Enter a price of zero or more and a tax rate from 0% to 100%.'
			};
		}

		if (!remove) {
			const tax = cents((amount * rate) / 100);
			const total = cents(amount + tax);
			return {
				primaryResult: money(total),
				primaryLabel: label,
				summary: `${money(tax)} of sales tax on ${money(amount)} at ${pct(rate)}.`,
				secondaryMetrics: [
					{ label: 'Net price', value: money(amount) },
					{ label: 'Sales tax', value: money(tax) }
				]
			};
		}

		const net = cents(amount / (1 + rate / 100));
		const tax = cents(amount - net);
		return {
			primaryResult: money(net),
			primaryLabel: label,
			summary: `${money(tax)} of sales tax is included in ${money(amount)} at ${pct(rate)}.`,
			secondaryMetrics: [
				{ label: 'Sales tax', value: money(tax) },
				{ label: 'Total with tax', value: money(amount) }
			]
		};
	},
	content: {
		intro:
			'Work out the sales tax on a price, or find the price before tax when you only know the total. Switch modes, enter a rate, and read the result.',
		howTo: [
			'Pick Add tax if you have a price before tax, or Remove tax if you have a total that already includes it.',
			'Enter the price and the sales tax rate that applies where you are buying or selling.',
			'Read the tax amount and the total or net price in the result.'
		],
		formulas: [
			{
				title: 'Adding tax',
				expression: 'Tax = Net price × r ÷ 100',
				variables: [
					{ symbol: 'r', meaning: 'sales tax rate as a percentage' },
					{ symbol: 'Net price', meaning: 'price before tax' }
				]
			},
			{
				expression: 'Total = Net price + Tax',
				variables: []
			},
			{
				title: 'Removing tax',
				expression: 'Net price = Total ÷ (1 + r ÷ 100)',
				variables: [{ symbol: 'Total', meaning: 'price that already includes tax' }]
			},
			{
				expression: 'Tax = Total − Net price',
				variables: []
			}
		],
		example: {
			title: 'A $250 purchase with 7.5% sales tax',
			steps: [
				'Tax: $250 × 7.5 ÷ 100 = $18.75',
				'Total: $250 + $18.75 = $268.75',
				'Check by removing tax: $268.75 ÷ 1.075 = $250.00',
				'Tax from the total: $268.75 − $250.00 = $18.75'
			],
			result: 'Total with tax $268.75. Sales tax $18.75.'
		},
		faq: [
			{
				q: 'Is sales tax added before or after a discount?',
				a: 'It depends on where you are. In many places sales tax applies to the price after a store discount, but manufacturer coupons can be treated differently. Check your local rules before you price goods.'
			},
			{
				q: 'Why does the net price look a cent off when I remove tax?',
				a: 'Tax is rounded to the nearest cent, and the net price is worked back from the total. A one-cent difference is normal rounding, not a mistake.'
			},
			{
				q: 'Where do I find the right sales tax rate?',
				a: 'Sales tax can be set by the state, county and city together, so the combined rate for your address is what applies. Your state revenue department publishes these rates.'
			},
			{
				q: 'Is sales tax the same as VAT?',
				a: 'No. Sales tax is charged once at the point of sale, while VAT is charged at each stage of production and sale. Use the VAT calculator for VAT-based prices.'
			}
		],
		sources: [{ title: 'Tax Foundation', url: 'https://taxfoundation.org/' }],
		disclaimer:
			'Estimates only. Sales tax rules and rates vary by location and product, so confirm the rate with your local tax authority.'
	}
});
