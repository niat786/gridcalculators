import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './loan-calculator.meta';

/** Fixed-rate payment: M = P·r(1+r)^n / ((1+r)^n − 1); r = 0 → P / n. */
function payment(principal: number, annualRatePct: number, months: number): number {
	const r = annualRatePct / 1200;
	if (r === 0) return principal / months;
	const f = Math.pow(1 + r, months);
	return (principal * r * f) / (f - 1);
}

/** "5 years 3 months", "2 years", "9 months". */
function termText(months: number): string {
	const y = Math.floor(months / 12);
	const m = months % 12;
	return [y ? plural(y, 'year') : '', m ? plural(m, 'month') : ''].filter(Boolean).join(' ');
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'amount', label: 'Loan amount', type: 'number', default: 20000, min: 1, max: 100_000_000, step: 100, prefix: '$' },
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 7, min: 0, max: 100, step: 0.01, suffix: '%', help: 'Annual rate' },
		{ id: 'years', label: 'Term (years)', type: 'number', default: 5, min: 0, max: 50, step: 1, suffix: 'years', decimal: false, width: 'half' },
		{ id: 'months', label: 'Term (months)', type: 'number', default: 0, min: 0, max: 11, step: 1, suffix: 'months', decimal: false, width: 'half' }
	],
	calculate(v): CalculationResult {
		const principal = Number(v.amount);
		const rate = Number(v.rate);
		const years = Number(v.years);
		const extraMonths = Number(v.months);
		const n = years * 12 + extraMonths;

		if (
			!(principal > 0) ||
			!Number.isFinite(principal) ||
			!(rate >= 0 && rate <= 100) ||
			!Number.isInteger(years) ||
			!Number.isInteger(extraMonths) ||
			!(n >= 1 && n <= 600)
		) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Monthly payment',
				summary: 'Enter a loan amount and a term of at least one month (up to 50 years).'
			};
		}

		const monthly = payment(principal, rate, n);
		const totalPaid = monthly * n;
		const totalInterest = Math.max(0, totalPaid - principal);

		// Yearly repayment table. Each row covers 12 payments; the last row may be shorter.
		const r = rate / 1200;
		let balance = principal;
		let yPrincipal = 0;
		let yInterest = 0;
		const rows: Record<string, string>[] = [];
		for (let m = 1; m <= n; m++) {
			const interest = balance * r;
			const part = m === n ? balance : Math.min(monthly - interest, balance);
			balance -= part;
			yPrincipal += part;
			yInterest += interest;
			if (m % 12 === 0 || m === n) {
				if (Math.abs(balance) < 0.005) balance = 0;
				rows.push({
					year: String(rows.length + 1),
					principal: money(yPrincipal, true),
					interest: money(yInterest, true),
					balance: money(balance, true)
				});
				yPrincipal = 0;
				yInterest = 0;
			}
		}

		return {
			primaryResult: money(monthly),
			primaryLabel: 'Monthly payment',
			summary: `${money(principal, true)} at ${num(rate, 3)}% over ${termText(n)}.`,
			secondaryMetrics: [
				{ label: 'Total interest', value: money(totalInterest) },
				{ label: 'Total paid', value: money(totalPaid) },
				{ label: 'Number of payments', value: plural(n, 'payment') },
				{ label: 'Loan term', value: termText(n) }
			],
			table: {
				title: 'Repayment schedule (yearly)',
				collapsed: true,
				columns: [
					{ key: 'year', label: 'Year' },
					{ key: 'principal', label: 'Principal', align: 'end' },
					{ key: 'interest', label: 'Interest', align: 'end' },
					{ key: 'balance', label: 'Balance', align: 'end' }
				],
				rows
			}
		};
	},
	content: {
		intro:
			'Work out the fixed monthly payment on any loan, plus the total interest you will pay and the full cost of borrowing over the term.',
		howTo: [
			'Enter the amount you are borrowing and the annual interest rate.',
			'Set the term in years and months. A 3-year, 6-month loan is 3 years and 6 months.',
			'Read the monthly payment and the total interest.',
			'Open the yearly schedule to see how much of each year goes to principal and interest.'
		],
		formulas: [
			{
				title: 'Monthly payment',
				expression: 'M = P × r(1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'M', meaning: 'monthly payment' },
					{ symbol: 'P', meaning: 'loan amount' },
					{ symbol: 'r', meaning: 'monthly interest rate (annual rate ÷ 12 ÷ 100)' },
					{ symbol: 'n', meaning: 'number of monthly payments (years × 12 + months)' }
				]
			},
			{
				title: 'Totals',
				expression: 'Total paid = M × n        Total interest = Total paid − P',
				variables: []
			},
			{
				title: 'Zero interest',
				expression: 'If the rate is 0%, M = P ÷ n',
				variables: []
			}
		],
		example: {
			title: 'A $20,000 loan at 7% for 5 years',
			steps: [
				'Monthly rate: r = 7 ÷ 12 ÷ 100 = 0.0058333',
				'Number of payments: n = 5 × 12 + 0 = 60',
				'Growth factor: (1 + r)ⁿ = 1.0058333⁶⁰ ≈ 1.4176',
				'M = 20,000 × 0.0058333 × 1.4176 ÷ (1.4176 − 1) ≈ $396.02',
				'Total paid = 396.024 × 60 = $23,761.44, so interest = $23,761.44 − $20,000 = $3,761.44'
			],
			result: 'Monthly payment of $396.02. Total interest of $3,761.44 over 5 years.'
		},
		faq: [
			{
				q: 'What is the difference between the interest rate and APR?',
				a: 'The interest rate is the yearly cost of borrowing the amount. APR also includes most upfront fees, so it is usually a little higher. This calculator uses the rate you enter and does not add fees.'
			},
			{
				q: 'Why does a longer term lower the payment but raise the total interest?',
				a: 'Spreading the same amount over more months lowers each payment. Interest builds up for longer, so the total you pay goes up.'
			},
			{
				q: 'Can I use months only for the term?',
				a: 'Yes. Enter 0 years and the number of months. The calculator adds years and months together to get the number of payments, up to 600 in total.'
			},
			{
				q: 'Does the yearly schedule show the exact payoff?',
				a: 'It shows each year as a total. Each payment is split into interest on the balance and principal, and the final row closes the balance at zero.'
			}
		],
		sources: [
			{
				title: 'Consumer Financial Protection Bureau',
				url: 'https://www.consumerfinance.gov/'
			}
		],
		disclaimer:
			'Estimates only. Your actual rate, fees and payment schedule depend on your lender and loan agreement.'
	}
});
