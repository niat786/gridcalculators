import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num } from '../format';
import meta from './apr-calculator.meta';

const MAX_MONTHS = 600;

/** Fixed-rate payment on the stated rate: M = P·r(1 + r)^n / ((1 + r)^n − 1); r = 0 → P / n. */
function payment(principal: number, annualPct: number, n: number): number {
	const r = annualPct / 1200;
	if (r === 0) return principal / n;
	const f = Math.pow(1 + r, n);
	return (principal * r * f) / (f - 1);
}

/** Present value of n equal payments discounted at the periodic rate j. */
function presentValue(pay: number, j: number, n: number): number {
	return j === 0 ? pay * n : (pay * (1 - Math.pow(1 + j, -n))) / j;
}

/**
 * The annual rate (as a decimal) at which the payments are worth `received` today.
 * Bisection on 0 to 1000% a year until the bracket is narrower than 1e-10.
 * Returns null when the answer would be above 1000%.
 */
function realRate(pay: number, n: number, received: number): number | null {
	const pvAt = (a: number) => presentValue(pay, a / 12, n);
	let lo = 0;
	let hi = 10;
	if (pvAt(hi) > received) return null;
	while (hi - lo > 1e-10) {
		const mid = (lo + hi) / 2;
		if (pvAt(mid) > received) lo = mid;
		else hi = mid;
	}
	return (lo + hi) / 2;
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'amount', label: 'Loan amount', type: 'number', default: 20000, min: 1, max: 100_000_000, step: 100, prefix: '$' },
		{
			id: 'rate',
			label: 'Stated interest rate',
			type: 'number',
			default: 7,
			min: 0,
			max: 100,
			step: 0.01,
			suffix: '%',
			help: 'The rate written in the loan agreement'
		},
		{ id: 'months', label: 'Term (months)', type: 'number', default: 60, min: 1, max: MAX_MONTHS, step: 1, suffix: 'months', decimal: false },
		{
			id: 'fees',
			label: 'Upfront fees',
			type: 'number',
			default: 500,
			min: 0,
			max: 100_000_000,
			step: 10,
			prefix: '$',
			help: 'Origination, processing and similar fees'
		},
		{
			id: 'feeMode',
			label: 'How fees are paid',
			type: 'select',
			display: 'segmented',
			default: 'deducted',
			options: [
				{ label: 'Deducted from loan', value: 'deducted' },
				{ label: 'Paid upfront', value: 'upfront' }
			]
		}
	],
	calculate(v): CalculationResult {
		const amount = Number(v.amount);
		const rate = Number(v.rate);
		const months = Number(v.months);
		const fees = Number(v.fees);
		const upfront = String(v.feeMode) === 'upfront';

		if (
			!(amount > 0) ||
			!Number.isFinite(amount) ||
			!(rate >= 0 && rate <= 100) ||
			!Number.isInteger(months) ||
			months < 1 ||
			months > MAX_MONTHS ||
			!(fees >= 0) ||
			fees >= amount
		) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Real APR',
				summary: 'Enter a loan amount, a rate from 0% to 100%, a term of 1 to 600 months, and fees below the loan amount.'
			};
		}

		// The payment follows the stated rate. The APR is the rate that makes the payments worth
		// what you actually keep on day one: the loan amount less the fees, in either fee mode.
		const pay = payment(amount, rate, months);
		const totalPaid = pay * months;
		const received = amount - fees;
		const annual = realRate(pay, months, received);
		if (annual === null) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Real APR',
				summary: 'The real rate would be above 1,000% a year. Check the fees and the term.'
			};
		}

		const apr = annual * 100;
		const totalCost = totalPaid - amount + fees;

		return {
			primaryResult: `${num(apr, 2, 2)}%`,
			primaryLabel: 'Real APR',
			summary:
				fees > 0
					? `A ${num(rate, 2)}% stated rate becomes ${num(apr, 2, 2)}% once ${money(fees)} in fees is counted.`
					: `With no fees, the real APR matches the ${num(rate, 2)}% stated rate.`,
			secondaryMetrics: [
				{ label: 'Monthly payment', value: money(pay) },
				{ label: 'Total fees', value: money(fees) },
				{ label: 'Cash you receive', value: money(upfront ? amount : received) },
				{ label: 'Paid at closing', value: money(upfront ? fees : 0) },
				{ label: 'Total of payments', value: money(totalPaid) },
				{ label: 'Total cost', value: money(totalCost) }
			]
		};
	},
	content: {
		intro:
			'Find the real annual percentage rate (APR) on a loan after upfront fees. Fees cut the cash you actually keep, so the APR is higher than the stated rate whenever fees apply.',
		howTo: [
			'Enter the amount you are borrowing and the stated interest rate from the loan agreement.',
			'Set the term in months and enter the total of the upfront fees.',
			'Choose whether the fees come out of the loan or are paid in cash at closing.',
			'Read the real APR, then check the monthly payment and the total cost.'
		],
		formulas: [
			{
				title: 'Monthly payment, from the stated rate',
				expression: 'M = P × r(1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'M', meaning: 'monthly payment' },
					{ symbol: 'P', meaning: 'loan amount' },
					{ symbol: 'r', meaning: 'stated annual rate ÷ 12 ÷ 100' },
					{ symbol: 'n', meaning: 'number of monthly payments' }
				]
			},
			{
				title: 'Cash you keep on day one',
				expression: 'Net = P − F',
				variables: [{ symbol: 'F', meaning: 'total upfront fees' }]
			},
			{
				title: 'Real APR',
				expression: 'Net = M × (1 − (1 + i)⁻ⁿ) ÷ i, solved for i by bisection.   APR = 12 × i × 100%',
				variables: [{ symbol: 'i', meaning: 'monthly rate that makes the payments worth the net amount' }]
			}
		],
		example: {
			title: 'A $20,000 loan at 7% for 60 months with a $500 fee',
			steps: [
				'Monthly payment on the stated rate: M = $396.02',
				'Cash you keep: 20,000 − 500 = $19,500',
				'Solve 396.024 × (1 − (1 + i)⁻⁶⁰) ÷ i = 19,500, which gives i ≈ 0.67233% a month',
				'Real APR = 12 × 0.67233% = 8.07%',
				'Total of payments: 396.024 × 60 = $23,761.44. Total cost: 23,761.44 − 20,000 + 500 = $4,261.44'
			],
			result: 'Real APR of 8.07% against a stated 7%. Total cost of $4,261.44, including the $500 fee.'
		},
		faq: [
			{
				q: 'What is the difference between APR and the interest rate?',
				a: 'The interest rate is the cost of borrowing the money. APR also includes most upfront fees, spread over the term, so it shows the full yearly cost of the loan.'
			},
			{
				q: 'Do fees change my monthly payment?',
				a: 'Not in this calculator. The payment comes from the stated rate and the loan amount. Fees lower the cash you receive, which pushes the real APR up.'
			},
			{
				q: 'What is the difference between fees deducted and fees paid upfront?',
				a: 'Deducted fees come out of the loan, so you receive less. Upfront fees are paid in cash at closing. Either way you are out the same amount on day one, so the real APR is the same.'
			},
			{
				q: 'Will this match the APR in my loan documents?',
				a: 'It should be close. Lenders follow the Truth in Lending rules, which set out exactly which fees count. Your lender’s disclosure is the official figure.'
			}
		],
		sources: [{ title: 'Consumer Financial Protection Bureau', url: 'https://www.consumerfinance.gov/' }],
		disclaimer:
			'Estimates only. Your lender’s APR disclosure, with its exact fee list and day-count rules, is the official figure.'
	}
});
