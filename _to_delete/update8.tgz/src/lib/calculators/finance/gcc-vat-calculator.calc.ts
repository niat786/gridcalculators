import { defineCalculator, type CalculationResult } from '../types';
import { DASH, moneyIn, pct } from '../format';
import meta from './gcc-vat-calculator.meta';
import { GCC_COUNTRIES, GCC_VAT_AS_OF, GCC_VAT_SOURCES } from '../data/gcc-vat';

/** Round half up to the currency's minor unit (2 or 3 decimals); the tiny epsilon beats float noise. */
const round = (n: number, d: number) => Math.round(n * 10 ** d + 1e-9) / 10 ** d;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'country',
			label: 'Country',
			type: 'select',
			display: 'menu',
			default: 'AE',
			options: GCC_COUNTRIES.map((c) => ({ value: c.value, label: `${c.label} (${c.currency})` }))
		},
		{
			id: 'mode',
			label: 'Calculation',
			type: 'select',
			display: 'segmented',
			default: 'add',
			options: [
				{ label: 'Add VAT', value: 'add' },
				{ label: 'Remove VAT', value: 'remove' }
			]
		},
		{
			id: 'amount',
			label: 'Amount',
			type: 'number',
			default: 1000,
			min: 0,
			max: 1_000_000_000,
			step: 0.001,
			help: 'In the country’s currency. Price before VAT when adding; price including VAT when removing.'
		}
	],
	calculate(v): CalculationResult {
		const remove = String(v.mode) === 'remove';
		const label = remove ? 'Price without VAT' : 'Price with VAT';
		const c = GCC_COUNTRIES.find((x) => x.value === String(v.country));
		const amount = Number(v.amount);
		if (!c || !(amount >= 0) || !Number.isFinite(amount)) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Pick a country and enter an amount of zero or more.' };
		}
		const f = (n: number) => moneyIn(c.currency, n);
		let net: number;
		let vat: number;
		let gross: number;
		if (remove) {
			gross = round(amount, c.decimals);
			net = round(gross / (1 + c.rate / 100), c.decimals);
			vat = round(gross - net, c.decimals);
		} else {
			net = round(amount, c.decimals);
			vat = round((net * c.rate) / 100, c.decimals);
			gross = round(net + vat, c.decimals);
		}
		const status = c.note;
		return {
			primaryResult: f(remove ? net : gross),
			primaryLabel: label,
			summary:
				c.rate === 0
					? `${status} No VAT is added or removed.`
					: `VAT at ${pct(c.rate)} is ${f(vat)} (${c.label}).`,
			secondaryMetrics: [
				{ label: 'VAT rate', value: pct(c.rate) },
				{ label: 'Price without VAT', value: f(net) },
				{ label: 'VAT', value: f(vat) },
				{ label: 'Price with VAT', value: f(gross) },
				{ label: 'Rate as of', value: GCC_VAT_AS_OF }
			]
		};
	},
	content: {
		intro:
			'Add VAT to a price or take it out of one for any of the six Gulf states, using each country’s current standard rate and its own currency. Qatar and Kuwait have no VAT, so they show 0%.',
		howTo: [
			'Choose the country. The rate and currency follow it.',
			'Pick Add VAT (you have the price before VAT) or Remove VAT (you have the price including VAT).',
			'Enter the amount and read the VAT and both prices.'
		],
		formulas: [
			{
				expression: 'Add: VAT = net × rate, gross = net + VAT.   Remove: net = gross ÷ (1 + rate), VAT = gross − net',
				variables: [
					{ symbol: 'rate', meaning: 'Standard rate: UAE 5%, Saudi Arabia 15%, Bahrain 10%, Oman 5%, Qatar 0%, Kuwait 0%.' },
					{ symbol: 'rounding', meaning: 'Amounts round to the currency’s smallest unit: 2 decimals for AED, SAR and QAR; 3 for BHD, OMR and KWD.' }
				]
			}
		],
		example: {
			title: 'Saudi Arabia, remove VAT from SAR 115.00',
			steps: ['The standard rate is 15%.', 'Net = 115 ÷ 1.15 = SAR 100.00.', 'VAT = 115 − 100 = SAR 15.00.'],
			result: 'SAR 100.00'
		},
		faq: [
			{
				q: 'Which VAT rates does this use?',
				a: 'The standard rates as of October 2026: UAE 5%, Saudi Arabia 15% (since July 2020), Bahrain 10% (since January 2022) and Oman 5% (since April 2021). Zero-rated and exempt supplies are not modelled.'
			},
			{
				q: 'Do Qatar and Kuwait charge VAT?',
				a: 'Not at the time of writing. Neither has enacted a domestic VAT, so this tool uses 0% for both. If that changes, the rate table will be updated.'
			},
			{
				q: 'Why does Bahrain show three decimals?',
				a: 'The Bahraini dinar, Omani rial and Kuwaiti dinar are divided into 1,000 smaller units, so amounts are shown and rounded to three decimals. The dirham and both riyals use two.'
			}
		],
		sources: GCC_VAT_SOURCES,
		disclaimer: 'Estimate for the standard rate only. Always check the invoice rules with the country’s tax authority or an adviser.'
	}
});
