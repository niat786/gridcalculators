import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './payment-calculator.meta';

/** Fixed-rate payment: M = P·r(1+r)^n / ((1+r)^n − 1); r = 0 → P / n. */
function payment(principal: number, annualRatePct: number, months: number): number {
	const r = annualRatePct / 1200;
	if (r === 0) return principal / months;
	const f = Math.pow(1 + r, months);
	return (principal * r * f) / (f - 1);
}

/** "15 years 2 months", "11 months", "3 years". */
function monthsText(months: number): string {
	const y = Math.floor(months / 12);
	const m = months % 12;
	return [y ? plural(y, 'year') : '', m ? plural(m, 'month') : ''].filter(Boolean).join(' ') || '0 months';
}

const termMode = (v: Record<string, unknown>) => v.mode === 'term';
const paymentMode = (v: Record<string, unknown>) => v.mode === 'payment';

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Find',
			type: 'select',
			display: 'segmented',
			default: 'term',
			options: [
				{ label: 'Fixed term', value: 'term' },
				{ label: 'Fixed payment', value: 'payment' }
			]
		},
		{ id: 'amount', label: 'Loan amount', type: 'number', default: 250000, min: 1, max: 100_000_000, step: 1000, prefix: '$' },
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 6.5, min: 0, max: 100, step: 0.01, suffix: '%', help: 'Annual rate' },
		{
			id: 'years',
			label: 'Loan term',
			type: 'number',
			default: 30,
			min: 1,
			max: 50,
			step: 1,
			suffix: 'years',
			decimal: false,
			help: 'Your payment is worked out from this term',
			visibleWhen: termMode
		},
		{
			id: 'payment',
			label: 'Monthly payment',
			type: 'number',
			default: 1800,
			min: 1,
			max: 10_000_000,
			step: 50,
			prefix: '$',
			help: 'Your time to repay is worked out from this payment',
			visibleWhen: paymentMode
		}
	],
	calculate(v): CalculationResult {
		const principal = Number(v.amount);
		const rate = Number(v.rate);
		const r = rate / 1200;

		if (!(principal > 0) || !Number.isFinite(principal) || !(rate >= 0 && rate <= 100)) {
			return {
				primaryResult: DASH,
				primaryLabel: v.mode === 'payment' ? 'Time to pay off' : 'Monthly payment',
				summary: 'Enter a loan amount and an interest rate from 0% to 100%.'
			};
		}

		if (v.mode === 'payment') {
			const monthly = Number(v.payment);
			const interestEachMonth = principal * r;
			if (!(monthly > 0) || !Number.isFinite(monthly)) {
				return { primaryResult: DASH, primaryLabel: 'Time to pay off', summary: 'Enter a monthly payment above zero.' };
			}
			if (monthly <= interestEachMonth) {
				return {
					primaryResult: DASH,
					primaryLabel: 'Time to pay off',
					summary: `Your payment must be more than the ${money(interestEachMonth)} of interest charged each month, or the balance never goes down.`
				};
			}

			// Solve n = −ln(1 − rP/M) ÷ ln(1 + r), then round up to whole payments.
			const exact = r === 0 ? principal / monthly : -Math.log(1 - (r * principal) / monthly) / Math.log(1 + r);
			const n = Math.ceil(exact - 1e-9);
			if (!(n >= 1 && n <= 1200)) {
				return {
					primaryResult: DASH,
					primaryLabel: 'Time to pay off',
					summary: 'That payment would take over 100 years. Try a larger monthly payment.'
				};
			}

			// The last payment is smaller: it clears what is left after n − 1 full payments.
			const growth = Math.pow(1 + r, n - 1);
			const balanceBeforeLast = r === 0 ? principal - monthly * (n - 1) : principal * growth - (monthly * (growth - 1)) / r;
			const lastPayment = Math.max(0, balanceBeforeLast * (1 + r));
			const totalPaid = monthly * (n - 1) + lastPayment;
			const totalInterest = Math.max(0, totalPaid - principal);

			return {
				primaryResult: plural(n, 'month'),
				primaryLabel: 'Time to pay off',
				summary: `Paying ${money(monthly)} a month repays ${money(principal, true)} in ${monthsText(n)}.`,
				secondaryMetrics: [
					{ label: 'Total paid', value: money(totalPaid) },
					{ label: 'Total interest', value: money(totalInterest) },
					{ label: 'Final payment', value: money(lastPayment) }
				]
			};
		}

		const years = Number(v.years);
		if (!Number.isInteger(years) || !(years >= 1 && years <= 50)) {
			return { primaryResult: DASH, primaryLabel: 'Monthly payment', summary: 'Enter a loan term from 1 to 50 years.' };
		}
		const n = years * 12;
		const monthly = payment(principal, rate, n);
		const totalPaid = monthly * n;
		const totalInterest = Math.max(0, totalPaid - principal);

		return {
			primaryResult: money(monthly),
			primaryLabel: 'Monthly payment',
			summary: `${money(principal, true)} at ${num(rate, 3)}% repaid over ${plural(years, 'year')}.`,
			secondaryMetrics: [
				{ label: 'Total paid', value: money(totalPaid) },
				{ label: 'Total interest', value: money(totalInterest) },
				{ label: 'Number of payments', value: plural(n, 'payment') }
			]
		};
	},
	content: {
		intro:
			'Work out a loan from either end. Find the monthly payment for a fixed term, or find how many months it takes to repay a loan at a fixed monthly payment.',
		howTo: [
			'Choose Fixed term to find the payment, or Fixed payment to find the payoff time.',
			'Enter the loan amount and the annual interest rate.',
			'In Fixed term, enter the number of years. In Fixed payment, enter the monthly payment you can afford.',
			'Read the result, then check the total paid and total interest below it.'
		],
		formulas: [
			{
				title: 'Fixed term: find the payment',
				expression: 'M = P × r(1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'M', meaning: 'monthly payment' },
					{ symbol: 'P', meaning: 'loan amount' },
					{ symbol: 'r', meaning: 'monthly interest rate (annual rate ÷ 12 ÷ 100)' },
					{ symbol: 'n', meaning: 'number of payments (years × 12)' }
				]
			},
			{
				title: 'Fixed payment: find the number of months',
				expression: 'n = −ln(1 − r × P ÷ M) ÷ ln(1 + r)',
				variables: [
					{ symbol: 'n', meaning: 'months to pay off, rounded up to a whole payment' },
					{ symbol: 'M', meaning: 'monthly payment you enter' },
					{ symbol: 'ln', meaning: 'natural logarithm' }
				]
			}
		],
		example: {
			title: 'A $250,000 loan at 6.5% over 30 years',
			steps: [
				'Monthly rate: r = 6.5 ÷ 12 ÷ 100 = 0.0054167',
				'Number of payments: n = 30 × 12 = 360',
				'Growth factor: (1 + r)³⁶⁰ ≈ 6.9918',
				'M = 250,000 × 0.0054167 × 6.9918 ÷ (6.9918 − 1) ≈ $1,580.17',
				'Total paid = 1,580.17 × 360 = $568,861.22, so interest = $318,861.22'
			],
			result: 'Monthly payment of $1,580.17 over 360 payments. Total interest is $318,861.22.'
		},
		faq: [
			{
				q: 'What does “fixed payment” mean here?',
				a: 'You set the monthly amount you can pay, and the calculator counts how many months it takes to clear the loan. The last payment is usually smaller than the rest.'
			},
			{
				q: 'Why does the calculator show a dash?',
				a: 'If your monthly payment is no more than the interest charged each month, the balance never goes down. Raise the payment to a figure above that interest amount.'
			},
			{
				q: 'Why is the last payment sometimes smaller?',
				a: 'The months are rounded up to a whole number. The final payment clears only what is left, so it is smaller than the regular payment.'
			},
			{
				q: 'Does this include taxes or insurance?',
				a: 'No. The results cover principal and interest only. Add any escrow or other monthly costs yourself.'
			}
		],
		sources: [
			{
				title: 'Investor.gov — SEC financial calculators',
				url: 'https://www.investor.gov/'
			}
		],
		disclaimer:
			'Estimates only. Your actual rate, fees and payment schedule depend on your lender and loan agreement.'
	}
});
