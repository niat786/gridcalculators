import { defineCalculator, type CalculationResult, type CalculatorInput, type InputValues } from '../types';
import { DASH, money, pct } from '../format';
import meta from './pakistan-property-tax-calculator.meta';
import {
	PK_CGT_AFTER_JULY_2024,
	PK_CGT_BEFORE_JULY_2024,
	PK_CGT_SOURCES,
	PK_PROPERTY_SOURCES,
	PK_RATE_236C_ATL,
	PK_RATE_236K_ATL,
	PK_TAX_YEAR_LABEL,
	PK_TAX_YEAR_PERIOD
} from '../data/pk-tax-2027';

const rs = (n: number) => money(n, true);
const MAX = 1_000_000_000_000;

/** Capital gain rate for a seller on the ATL. `years` is the holding period; (1,2] counts as "over 1 to 2 years". */
export function pkCgtRate(acquired: string, type: string, years: number): number {
	if (acquired === 'after') return PK_CGT_AFTER_JULY_2024;
	const table = PK_CGT_BEFORE_JULY_2024[type as 'plot' | 'house' | 'flat'];
	if (years > 6) return 0;
	const idx = Math.max(0, Math.ceil(years) - 1);
	return table[idx];
}

const inputs: CalculatorInput[] = [
	{
		id: 'mode',
		label: 'Transaction',
		type: 'select',
		default: 'buy',
		options: [
			{ label: 'Buying (236K)', value: 'buy' },
			{ label: 'Selling (236C)', value: 'sell' }
		],
		display: 'segmented'
	},
	{
		id: 'status',
		label: 'Your tax status',
		type: 'select',
		default: 'atl',
		options: [
			{ label: 'On the Active Taxpayers List (filer)', value: 'atl' },
			{ label: 'Late filer (on the ATL)', value: 'late' }
		],
		display: 'segmented',
		help: 'People not on the ATL (non-filers) pay higher rates that are not included here.'
	},
	{
		id: 'value',
		label: 'Property value',
		type: 'number',
		default: 20_000_000,
		min: 0,
		max: MAX,
		step: 100_000,
		prefix: '$',
		decimal: false,
		help: 'Fair market value when buying; sale consideration when selling.'
	},
	{ id: 'cgt', label: 'Also work out capital gains tax', type: 'toggle', default: false, visibleWhen: (v) => v.mode === 'sell' },
	{
		id: 'cost',
		label: 'What you paid (cost)',
		type: 'number',
		default: 15_000_000,
		min: 0,
		max: MAX,
		step: 100_000,
		prefix: '$',
		decimal: false,
		visibleWhen: (v) => v.mode === 'sell' && v.cgt === true,
		help: 'Purchase price plus costs allowed against the gain.'
	},
	{
		id: 'acquired',
		label: 'Acquired',
		type: 'select',
		default: 'after',
		options: [
			{ label: 'On or after 1 July 2024', value: 'after' },
			{ label: 'On or before 30 June 2024', value: 'before' }
		],
		display: 'segmented',
		visibleWhen: (v) => v.mode === 'sell' && v.cgt === true
	},
	{
		id: 'ptype',
		label: 'Property type',
		type: 'select',
		default: 'plot',
		options: [
			{ label: 'Open plot', value: 'plot' },
			{ label: 'Constructed property', value: 'house' },
			{ label: 'Flat', value: 'flat' }
		],
		display: 'segmented',
		visibleWhen: (v) => v.mode === 'sell' && v.cgt === true && v.acquired === 'before'
	},
	{
		id: 'years',
		label: 'Holding period',
		type: 'number',
		default: 3,
		min: 0,
		max: 100,
		step: 0.5,
		suffix: 'years',
		visibleWhen: (v) => v.mode === 'sell' && v.cgt === true && v.acquired === 'before'
	}
];

function calculate(v: InputValues): CalculationResult {
	const buy = v.mode === 'buy';
	const label = buy ? 'Advance tax on purchase (236K)' : 'Advance tax on sale (236C)';
	const value = Number(v.value);
	if (!Number.isFinite(value) || value < 0 || value > MAX) {
		return { primaryResult: DASH, primaryLabel: label, summary: 'Enter the property value as zero or more.' };
	}
	if (v.status !== 'atl' && v.status !== 'late') {
		return { primaryResult: DASH, primaryLabel: label, summary: 'Choose your tax status.' };
	}

	const rate = buy ? PK_RATE_236K_ATL : PK_RATE_236C_ATL;
	const advance = value * rate;

	let cgt = 0;
	let cgtRate = 0;
	let gain = 0;
	const withCgt = !buy && v.cgt === true;
	if (withCgt) {
		const cost = Number(v.cost);
		const years = Number(v.years);
		if (!Number.isFinite(cost) || cost < 0 || cost > MAX) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter what you paid as zero or more.' };
		}
		if (v.acquired === 'before' && (!Number.isFinite(years) || years < 0)) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter the holding period in years.' };
		}
		if (v.acquired !== 'before' && v.acquired !== 'after') {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Choose when the property was acquired.' };
		}
		gain = Math.max(0, value - cost);
		cgtRate = pkCgtRate(String(v.acquired), String(v.ptype), years);
		cgt = gain * cgtRate;
	}
	const total = advance + cgt;

	const summary = buy
		? `Buyers on the ATL pay a flat ${pct(rate * 100)} of the property value for ${PK_TAX_YEAR_LABEL}, whatever the value.`
		: withCgt
			? `Sellers on the ATL pay a flat ${pct(rate * 100)} advance tax on ${rs(value)}${gain > 0 ? `, plus ${pct(cgtRate * 100)} capital gains tax on a gain of ${rs(gain)}` : ', and there is no gain to tax'}.`
			: `Sellers on the ATL pay a flat ${pct(rate * 100)} of the sale value for ${PK_TAX_YEAR_LABEL}, whatever the value.`;

	return {
		primaryResult: rs(advance),
		primaryLabel: label,
		summary,
		secondaryMetrics: [
			{ label: 'Advance tax rate', value: pct(rate * 100) },
			{ label: 'Value taxed', value: rs(value) },
			{ label: 'Capital gain', value: withCgt ? rs(gain) : 'Not included' },
			{ label: 'Capital gains tax rate', value: withCgt ? pct(cgtRate * 100) : 'Not included' },
			{ label: 'Capital gains tax', value: withCgt ? rs(cgt) : 'Not included' },
			{ label: withCgt ? 'Advance tax + capital gains tax' : 'Total tax shown', value: rs(total) }
		]
	};
}

export default defineCalculator({
	meta,
	inputs,
	calculate,
	content: {
		intro: `Work out FBR advance tax when you buy (section 236K) or sell (section 236C) property in Pakistan for ${PK_TAX_YEAR_LABEL} (${PK_TAX_YEAR_PERIOD}), with an optional capital gains tax estimate on a sale.`,
		howTo: [
			'Choose buying or selling, and your tax status.',
			'Enter the property value. To include capital gains tax on a sale, switch it on and add your cost, when you acquired the property and, for older purchases, the type and holding period.',
			'Read the advance tax and, if selected, the capital gains tax.'
		],
		formulas: [
			{
				title: `Advance tax, ${PK_TAX_YEAR_LABEL} (Finance Act 2026), people on the ATL`,
				expression: 'Purchase (236K): 1.25% × fair market value · Sale (236C): 2.75% × consideration',
				variables: [
					{ symbol: 'Bands', meaning: 'The old value bands (up to Rs 50m, Rs 50m to 100m, above Rs 100m) were replaced by one flat rate.' },
					{ symbol: 'Late filers', meaning: 'The separate higher late-filer rates were withdrawn, so late filers on the ATL pay the same flat rates.' }
				]
			},
			{
				title: 'Capital gains tax (section 37), sellers on the ATL',
				expression: 'Gain = sale value − cost · Tax = gain × rate',
				variables: [
					{ symbol: 'Acquired on or after 1 July 2024', meaning: 'Flat 15%, whatever the holding period.' },
					{ symbol: 'Acquired on or before 30 June 2024', meaning: 'Open plot: 15, 12.5, 10, 7.5, 5, 2.5% for up to 1, 1-2, 2-3, 3-4, 4-5, 5-6 years, then 0%. Constructed property: 15, 10, 7.5, 5% for the first four years, then 0%. Flat: 15% in the first year, 7.5% in the second, then 0%.' }
				]
			}
		],
		example: {
			title: 'Buying a property worth Rs 20,000,000 as a filer',
			steps: ['Rate on purchase for people on the ATL: 1.25%.', 'Tax: 20,000,000 × 1.25% = Rs 250,000.'],
			result: 'Advance tax of Rs 250,000.'
		},
		faq: [
			{ q: 'What changed in tax year 2027?', a: 'Section 236C fell from 4.5 to 5.5% (by value band) to a flat 2.75%, and 236K fell from 1.5 to 2.5% to a flat 1.25%. Section 7E deemed income tax on property was abolished.' },
			{ q: 'Is capital gains tax the same as advance tax?', a: 'No. Advance tax is collected at registration on the whole value. Capital gains tax is charged on the profit. This tool shows both side by side and does not net one against the other, so check with a tax adviser how any credit applies.' },
			{ q: 'What is not included?', a: 'Rates for people not on the ATL, capital gains tax for sellers not on the ATL, provincial stamp duty, capital value tax, registration fees and other local charges, which vary by province.' }
		],
		sources: [...PK_PROPERTY_SOURCES, ...PK_CGT_SOURCES.slice(1)],
		disclaimer: 'Estimate only. Rates and valuations change; confirm the amount with FBR or your registrar before a transaction.'
	}
});
