import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct } from '../format';
import meta from './commission-calculator.meta';

const modeOptions = [
	{ label: 'Flat rate', value: 'flat' },
	{ label: 'Tiered', value: 'tiered' }
];

/**
 * Commission on sales. Flat: one rate on every sale. Tiered: the first rate applies up to the
 * threshold, and the second rate applies only to the sales above it.
 */
export default defineCalculator({
	meta,
	inputs: [
		{ id: 'sale', label: 'Sale amount', type: 'number', default: 25000, min: 0, max: 1_000_000_000, step: 500, prefix: '$', help: 'Total sales you are paid on.' },
		{
			id: 'rate',
			label: 'Commission rate',
			type: 'number',
			default: 5,
			min: 0,
			max: 100,
			step: 0.1,
			suffix: '%',
			help: 'Flat mode: applies to all sales. Tiered mode: applies up to the threshold.'
		},
		{ id: 'base', label: 'Base pay', type: 'number', default: 0, min: 0, max: 1_000_000_000, step: 100, prefix: '$', help: 'Fixed pay on top of commission, if any.' },
		{ id: 'mode', label: 'Commission structure', type: 'select', display: 'segmented', default: 'flat', options: modeOptions },
		{
			id: 'threshold',
			label: 'Tier threshold',
			type: 'number',
			default: 20000,
			min: 0,
			max: 1_000_000_000,
			step: 500,
			prefix: '$',
			help: 'Sales up to this amount earn the first rate.',
			visibleWhen: (v) => v.mode === 'tiered'
		},
		{
			id: 'rate2',
			label: 'Rate above threshold',
			type: 'number',
			default: 8,
			min: 0,
			max: 100,
			step: 0.1,
			suffix: '%',
			visibleWhen: (v) => v.mode === 'tiered'
		}
	],
	calculate(v): CalculationResult {
		const sale = Number(v.sale);
		const rate = Number(v.rate);
		const base = Number(v.base);
		const tiered = v.mode === 'tiered';
		const threshold = Number(v.threshold);
		const rate2 = Number(v.rate2);

		const invalid = (): CalculationResult => ({
			primaryResult: DASH,
			primaryLabel: 'Total earnings',
			summary: 'Enter a sale amount, a rate from 0 to 100%, and any base pay.'
		});

		if (
			!(sale >= 0) ||
			!(rate >= 0 && rate <= 100) ||
			!(base >= 0) ||
			(v.mode !== 'flat' && v.mode !== 'tiered') ||
			(tiered && !(threshold >= 0 && rate2 >= 0 && rate2 <= 100))
		) {
			return invalid();
		}

		const commission = tiered
			? (Math.min(sale, threshold) * rate) / 100 + (Math.max(0, sale - threshold) * rate2) / 100
			: (sale * rate) / 100;
		const total = base + commission;
		const effective = sale > 0 ? (commission / sale) * 100 : 0;

		const summary = tiered
			? `${pct(rate, 2)} on the first ${money(threshold)} of sales, then ${pct(rate2, 2)} on the rest.`
			: `${pct(rate, 2)} on ${money(sale)} of sales.`;

		return {
			primaryResult: money(total),
			primaryLabel: 'Total earnings',
			summary,
			secondaryMetrics: [
				{ label: 'Commission', value: money(commission) },
				{ label: 'Base pay', value: money(base) },
				{ label: 'Effective commission rate', value: pct(effective, 2) }
			]
		};
	},
	content: {
		intro:
			'Work out your sales commission and total earnings. Use a single flat rate, or a tiered plan where a higher rate applies only to sales above a set amount.',
		howTo: [
			'Enter the total sale amount, or the total sales for the period you are paid on.',
			'Enter the commission rate. In flat mode it applies to every sale.',
			'Add any base pay you earn on top of commission.',
			'For a tiered plan, choose Tiered, then enter the threshold and the rate for sales above it.'
		],
		formulas: [
			{
				title: 'Flat rate commission',
				expression: 'Commission = sales × rate',
				variables: [
					{ symbol: 'sales', meaning: 'total sale amount' },
					{ symbol: 'rate', meaning: 'commission rate as a decimal' }
				]
			},
			{
				title: 'Tiered commission',
				expression: 'Commission = min(sales, T) × r₁ + max(0, sales − T) × r₂',
				variables: [
					{ symbol: 'T', meaning: 'tier threshold' },
					{ symbol: 'r₁', meaning: 'rate up to the threshold' },
					{ symbol: 'r₂', meaning: 'rate on sales above the threshold' }
				]
			},
			{
				title: 'Total earnings',
				expression: 'Total = base pay + commission',
				variables: [{ symbol: 'base pay', meaning: 'fixed pay you earn regardless of sales' }]
			}
		],
		example: {
			title: '$30,000 in sales on a tiered plan, with $2,000 base pay',
			steps: [
				'First tier: $20,000 × 5% = $1,000',
				'Above the threshold: ($30,000 − $20,000) × 8% = $800',
				'Commission: $1,000 + $800 = $1,800',
				'Total earnings: $2,000 base pay + $1,800 commission = $3,800'
			],
			result: 'Your total earnings are $3,800, which is an effective commission rate of 6% on sales.'
		},
		faq: [
			{
				q: 'Is commission taxed like a salary?',
				a: 'Usually yes. Commission is treated as ordinary income, and it is often subject to the same withholding as wages. Your pay statement shows what was actually withheld.'
			},
			{
				q: 'Does a tiered rate apply to all sales once I pass the threshold?',
				a: 'Not in this calculator. The first rate applies only to sales up to the threshold, and the second rate applies to sales above it. Some plans instead switch the rate on all sales. Check your plan document.'
			},
			{
				q: 'What is effective commission rate?',
				a: 'It is the commission divided by the sales. It shows the average rate you earn, which is useful for comparing a tiered plan with a flat plan.'
			}
		],
		sources: [{ title: 'U.S. Department of Labor', url: 'https://www.dol.gov' }],
		disclaimer:
			'Estimates only. Your actual pay depends on your commission plan, returns, taxes and deductions.'
	}
});
