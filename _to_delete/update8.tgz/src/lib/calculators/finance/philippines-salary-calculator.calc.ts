import { defineCalculator, type CalculationResult, type CalculatorInput, type InputValues } from '../types';
import { DASH, money } from '../format';
import meta from './philippines-salary-calculator.meta';
import {
	PH_13TH_DIVISOR,
	PH_BONUS_EXEMPTION,
	PH_PAGIBIG_EMPLOYEE_RATE,
	PH_PAGIBIG_EMPLOYEE_RATE_LOW,
	PH_PAGIBIG_LOW_PAY_LIMIT,
	PH_PAGIBIG_MAX_FUND_SALARY,
	PH_PAGIBIG_SOURCE,
	PH_PAGIBIG_SOURCE_2,
	PH_PHILHEALTH_CEILING,
	PH_PHILHEALTH_EMPLOYEE_SHARE,
	PH_PHILHEALTH_FLOOR,
	PH_PHILHEALTH_RATE,
	PH_PHILHEALTH_SOURCE,
	PH_PHILHEALTH_SOURCE_2,
	PH_SSS_EMPLOYEE_RATE,
	PH_SSS_MSC_MAX,
	PH_SSS_MSC_MIN,
	PH_SSS_MSC_STEP,
	PH_SSS_SOURCE,
	PH_SSS_TABLE_SOURCE,
	PH_TAX_BRACKETS,
	PH_TAX_CONTRIBUTIONS_SOURCE,
	PH_TAX_SOURCE,
	PH_TAX_SOURCE_2,
	PH_YEAR_LABEL
} from '../data/ph-2026';

const cents = (n: number) => Math.round(n * 100) / 100;
const peso = (n: number) => money(n);

/** SSS monthly salary credit: 500-peso bands centred on the MSC, floor 5,000 and cap 35,000. */
export function sssMsc(pay: number): number {
	const banded = Math.floor((pay + PH_SSS_MSC_STEP / 2) / PH_SSS_MSC_STEP) * PH_SSS_MSC_STEP;
	return Math.min(PH_SSS_MSC_MAX, Math.max(PH_SSS_MSC_MIN, banded));
}

/** Annual income tax on taxable compensation (TRAIN table, 2023 onward). */
export function phAnnualTax(taxable: number): number {
	if (!(taxable > 0)) return 0;
	let b = PH_TAX_BRACKETS[0];
	for (const x of PH_TAX_BRACKETS) if (taxable > x.over) b = x;
	return b.base + (taxable - b.over) * b.rate;
}

const inputs: CalculatorInput[] = [
	{ id: 'basic', label: 'Monthly basic salary', type: 'number', default: 30_000, min: 1, max: 100_000_000, step: 500, prefix: '$', help: 'Before any deductions. SSS, PhilHealth and Pag-IBIG are all worked out on this figure.' },
	{ id: 'thirteenth', label: 'Include 13th month pay', type: 'toggle', default: true },
	{ id: 'bonus', label: 'Other bonuses and benefits per year', type: 'number', default: 0, min: 0, max: 1_000_000_000, step: 1000, prefix: '$', help: 'Christmas bonus, productivity incentives and similar. Tax-free together with the 13th month up to ₱90,000.' }
];

function calculate(v: InputValues): CalculationResult {
	const basic = Number(v.basic);
	const bonusIn = Number(v.bonus);
	if (!Number.isFinite(basic) || basic <= 0) {
		return { primaryResult: DASH, primaryLabel: 'Net monthly pay', summary: 'Enter your monthly basic salary as more than zero.' };
	}
	if (!Number.isFinite(bonusIn) || bonusIn < 0) {
		return { primaryResult: DASH, primaryLabel: 'Net monthly pay', summary: 'Enter other bonuses as zero or more.' };
	}

	// SSS: employee 5% of the monthly salary credit.
	const msc = sssMsc(basic);
	const sss = cents(msc * PH_SSS_EMPLOYEE_RATE);
	// PhilHealth: 5% of basic salary within the floor and ceiling, split equally.
	const phBase = Math.min(PH_PHILHEALTH_CEILING, Math.max(PH_PHILHEALTH_FLOOR, basic));
	const phTotal = cents(phBase * PH_PHILHEALTH_RATE);
	const philhealth = cents(phTotal * PH_PHILHEALTH_EMPLOYEE_SHARE);
	// Pag-IBIG: 1% up to 1,500 of pay, otherwise 2%, on a fund salary capped at 10,000.
	const fundSalary = Math.min(basic, PH_PAGIBIG_MAX_FUND_SALARY);
	const pagibig = cents(fundSalary * (basic <= PH_PAGIBIG_LOW_PAY_LIMIT ? PH_PAGIBIG_EMPLOYEE_RATE_LOW : PH_PAGIBIG_EMPLOYEE_RATE));
	const contributions = cents(sss + philhealth + pagibig);

	// Withholding: mandatory contributions come off first, then the annualised pay goes through the TRAIN table.
	const taxableMonthly = basic - contributions;
	const annualRegular = taxableMonthly * 12;
	const regularTax = phAnnualTax(annualRegular);
	const monthlyTax = cents(regularTax / 12);
	const net = cents(basic - contributions - monthlyTax);

	// Bonuses: 13th month (one-twelfth of a full year's basic pay) plus other benefits, tax-free up to 90,000 together.
	const thirteenth = v.thirteenth === true ? cents((basic * 12) / PH_13TH_DIVISOR) : 0;
	const bonusTotal = thirteenth + bonusIn;
	const exemptBonus = Math.min(bonusTotal, PH_BONUS_EXEMPTION);
	const taxableBonus = bonusTotal - exemptBonus;
	const annualTax = phAnnualTax(annualRegular + taxableBonus);
	const bonusTax = cents(annualTax - regularTax);
	const annualTakeHome = cents(net * 12 + bonusTotal - bonusTax);

	const deductionTotal = cents(contributions + monthlyTax);
	const summary =
		`${peso(basic)} basic less ${peso(contributions)} SSS, PhilHealth and Pag-IBIG and ${peso(monthlyTax)} withholding tax leaves ${peso(net)} a month.` +
		(bonusTax > 0 ? ` Bonuses above the ${money(PH_BONUS_EXEMPTION, true)} exemption add ${peso(bonusTax)} of tax at year end.` : '');

	return {
		primaryResult: peso(net),
		primaryLabel: 'Net monthly pay',
		summary,
		secondaryMetrics: [
			{ label: 'SSS (employee share)', value: peso(sss) },
			{ label: 'PhilHealth (employee share)', value: peso(philhealth) },
			{ label: 'Pag-IBIG (employee share)', value: peso(pagibig) },
			{ label: 'Withholding tax per month', value: peso(monthlyTax) },
			{ label: 'Total deductions per month', value: peso(deductionTotal) },
			{ label: 'Tax on bonuses above the exemption', value: peso(bonusTax) },
			{ label: 'Take-home for the year, bonuses included', value: peso(annualTakeHome) }
		],
		table: {
			title: `Monthly pay breakdown, ${PH_YEAR_LABEL}`,
			columns: [
				{ key: 'item', label: 'Item' },
				{ key: 'amount', label: 'Amount', align: 'end' }
			],
			rows: [
				{ item: 'Monthly basic salary', amount: peso(basic) },
				{ item: `SSS monthly salary credit ${money(msc, true)} × 5%`, amount: peso(sss) },
				{ item: `PhilHealth ${money(phBase, true)} × 5% ÷ 2`, amount: peso(philhealth) },
				{ item: `Pag-IBIG fund salary ${money(fundSalary, true)} × ${basic <= PH_PAGIBIG_LOW_PAY_LIMIT ? '1' : '2'}%`, amount: peso(pagibig) },
				{ item: 'Taxable pay per month', amount: peso(taxableMonthly) },
				{ item: 'Taxable pay for the year (× 12)', amount: peso(annualRegular) },
				{ item: 'Income tax for the year on regular pay', amount: peso(regularTax) },
				{ item: 'Withholding tax per month', amount: peso(monthlyTax) },
				{ item: 'Net monthly pay', amount: peso(net) },
				{ item: '13th month pay and other bonuses', amount: peso(bonusTotal) },
				{ item: 'Tax-free part (up to ₱90,000)', amount: peso(exemptBonus) },
				{ item: 'Taxable part added to income', amount: peso(taxableBonus) }
			]
		}
	};
}

export default defineCalculator({
	meta,
	inputs,
	calculate,
	content: {
		intro: `Enter your monthly basic salary to see your net pay in the Philippines for ${PH_YEAR_LABEL}. It takes out the employee shares of SSS, PhilHealth and Pag-IBIG, then BIR withholding tax under the TRAIN law table.`,
		howTo: [
			'Enter your monthly basic salary before deductions.',
			'Switch the 13th month pay on or off, and add any other yearly bonuses.',
			'Read your net monthly pay, each deduction, and the year-end tax on bonuses above ₱90,000.'
		],
		formulas: [
			{
				title: 'Contributions (employee share)',
				expression: 'SSS = 5% × MSC · PhilHealth = 2.5% × salary (₱10,000 to ₱100,000) · Pag-IBIG = 2% × salary (max ₱10,000)',
				variables: [
					{ symbol: 'MSC', meaning: 'SSS monthly salary credit: pay rounded to the nearest ₱500, minimum ₱5,000 and maximum ₱35,000' },
					{ symbol: 'PhilHealth', meaning: 'Premium is 5% of basic pay, shared equally; pay under ₱10,000 is treated as ₱10,000 and pay over ₱100,000 as ₱100,000' },
					{ symbol: 'Pag-IBIG', meaning: '1% if pay is ₱1,500 or less, otherwise 2%, on a fund salary capped at ₱10,000 (so at most ₱200)' }
				]
			},
			{
				title: 'Withholding tax (annual TRAIN table, 2023 onward)',
				expression: 'Nil to ₱250,000 · 15% to ₱400,000 · ₱22,500 + 20% to ₱800,000 · ₱102,500 + 25% to ₱2M · ₱402,500 + 30% to ₱8M · ₱2,202,500 + 35% above',
				variables: [
					{ symbol: 'Taxable pay', meaning: '(Basic salary − SSS − PhilHealth − Pag-IBIG) × 12, then tax ÷ 12 each month' },
					{ symbol: 'Bonuses', meaning: '13th month pay and other benefits up to ₱90,000 a year are tax-free; only the excess is taxed' }
				]
			}
		],
		example: {
			title: 'Basic salary of ₱30,000 a month, with 13th month pay',
			steps: [
				'SSS: salary credit ₱30,000 × 5% = ₱1,500. PhilHealth: ₱30,000 × 5% ÷ 2 = ₱750. Pag-IBIG: ₱10,000 × 2% = ₱200.',
				'Taxable pay: ₱30,000 − ₱2,450 = ₱27,550 a month, so ₱330,600 a year. Tax: (₱330,600 − ₱250,000) × 15% = ₱12,090 a year, or ₱1,007.50 a month.',
				'Net pay: ₱30,000 − ₱2,450 − ₱1,007.50 = ₱26,542.50. The 13th month pay of ₱30,000 is under ₱90,000, so it is tax-free.'
			],
			result: 'Net monthly pay ₱26,542.50'
		},
		faq: [
			{ q: 'Is the 13th month pay taxed?', a: 'Not up to ₱90,000 a year. The ₱90,000 limit covers the 13th month pay and other benefits together. Only the part above it is added to taxable income.' },
			{ q: 'Why does the employer share not show?', a: 'You do not pay it. Your employer adds its own part of SSS (10%), PhilHealth (2.5%), Pag-IBIG (2%) and the SSS EC amount on top of your pay.' },
			{ q: 'What is not included?', a: 'Minimum-wage earner exemption, taxable allowances, overtime, government employees (GSIS), self-employed rates and voluntary contributions are not modelled. SSS and PhilHealth are worked out on basic salary here; SSS actually uses total compensation.' }
		],
		sources: [PH_SSS_SOURCE, PH_SSS_TABLE_SOURCE, PH_PHILHEALTH_SOURCE, PH_PHILHEALTH_SOURCE_2, PH_PAGIBIG_SOURCE, PH_PAGIBIG_SOURCE_2, PH_TAX_SOURCE, PH_TAX_SOURCE_2, PH_TAX_CONTRIBUTIONS_SOURCE],
		disclaimer: 'Estimate for a private-sector employee on a fixed monthly salary. Check the exact figures with your employer, the SSS, PhilHealth, Pag-IBIG and the BIR.'
	}
});
