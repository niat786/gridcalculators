import { defineMeta } from '../types';

export default defineMeta({
	slug: 'investment-calculator',
	name: 'Investment Calculator',
	category: 'finance',
	shortDescription: 'Projected portfolio value with contributions that rise each year.',
	metaTitle: 'Investment Calculator — Growth and Yearly Contributions',
	metaDescription:
		'Free investment calculator. Project your ending value from a starting amount, monthly contributions and an expected return, with yearly raises and a chart.',
	icon: 'trendingUp',
	keywords: ['investment calculator', 'portfolio growth', 'investment return', 'monthly investing', 'contribution increase'],
	money: 'any',
	updated: '2026-10-28'
});
