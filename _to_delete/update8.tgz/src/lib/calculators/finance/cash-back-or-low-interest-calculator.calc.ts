import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './cash-back-or-low-interest-calculator.meta';

/** Fixed-rate payment: M = P·r(1+r)^n / ((1+r)^n − 1); r = 0 → P / n; P = 0 → 0. */
function payment(principal: number, annualRatePct: number, months: number): number {
	if (principal <= 0) return 0;
	const r = annualRatePct / 1200;
	if (r === 0) return principal / months;
	const f = Math.pow(1 + r, months);
	return (principal * r * f) / (f - 1);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'price', label: 'Purchase price', type: 'number', default: 35000, min: 0, max: 100_000_000, step: 500, prefix: '$', help: 'Price before any rebate or tax you add to the loan.' },
		{ id: 'rebate', label: 'Cash-back rebate', type: 'number', default: 2000, min: 0, max: 100_000_000, step: 100, prefix: '$', help: 'Taken off the price if you choose cash back.' },
		{ id: 'lowApr', label: 'Low dealer APR', type: 'number', default: 1.9, min: 0, max: 40, step: 0.01, suffix: '%', help: 'Offered on the full price if you skip the rebate.' },
		{ id: 'bankApr', label: 'Bank loan APR', type: 'number', default: 6.5, min: 0, max: 40, step: 0.01, suffix: '%', help: 'Your rate if you take the rebate and borrow from a bank.' },
		{ id: 'term', label: 'Loan term', type: 'number', default: 60, min: 1, max: 120, step: 1, suffix: 'months', decimal: false, width: 'half' },
		{ id: 'down', label: 'Down payment', type: 'number', default: 3000, min: 0, max: 100_000_000, step: 500, prefix: '$', width: 'half' }
	],
	calculate(v): CalculationResult {
		const price = Number(v.price);
		const rebate = Number(v.rebate);
		const lowApr = Number(v.lowApr);
		const bankApr = Number(v.bankApr);
		const n = Number(v.term);
		const down = Number(v.down);
		const primaryLabel = 'Difference in total cost';

		if (
			!Number.isFinite(price) || price <= 0 ||
			!(rebate >= 0) ||
			!(lowApr >= 0 && lowApr <= 40) ||
			!(bankApr >= 0 && bankApr <= 40) ||
			!Number.isInteger(n) || n < 1 || n > 120 ||
			!(down >= 0)
		) {
			return { primaryResult: DASH, primaryLabel, summary: 'Check the price, rates, term and down payment.' };
		}
		if (price - down < 0 || price - rebate - down < 0) {
			return { primaryResult: DASH, primaryLabel, summary: 'The down payment and rebate cannot be more than the price.' };
		}

		// Option A: rebate comes off the price, so the loan is smaller but charged at the bank rate.
		const loanA = price - rebate - down;
		// Option B: no rebate, so the loan is the full price less the down payment, at the low rate.
		const loanB = price - down;
		const monthlyA = payment(loanA, bankApr, n);
		const monthlyB = payment(loanB, lowApr, n);
		const totalA = down + monthlyA * n;
		const totalB = down + monthlyB * n;
		const diff = totalA - totalB;
		const cheaper = Math.abs(diff) < 0.005 ? 'Same cost' : diff > 0 ? 'Low APR' : 'Cash back';

		let summary: string;
		if (cheaper === 'Same cost') summary = 'Both options cost the same overall.';
		else if (cheaper === 'Low APR') summary = `The low APR is cheaper by ${money(diff)} over ${plural(n, 'month')}.`;
		else summary = `Taking the cash back is cheaper by ${money(-diff)} over ${plural(n, 'month')}.`;

		return {
			primaryResult: money(Math.abs(diff)),
			primaryLabel,
			summary,
			secondaryMetrics: [
				{ label: 'Monthly payment, cash back', value: money(monthlyA) },
				{ label: 'Monthly payment, low APR', value: money(monthlyB) },
				{ label: 'Total cost, cash back', value: money(totalA) },
				{ label: 'Total cost, low APR', value: money(totalB) },
				{ label: 'Cheaper option', value: cheaper }
			]
		};
	},
	content: {
		intro:
			'Compare two ways to buy the same item. Take a cash-back rebate and borrow less at your bank rate, or skip the rebate and take the low dealer rate on the full price. See which one costs less overall.',
		howTo: [
			'Enter the purchase price, the cash-back rebate and your down payment.',
			'Enter the low dealer APR and the bank loan APR you have been offered.',
			'Enter the loan term in months.',
			'Read which option is cheaper and by how much, then compare the monthly payments.'
		],
		formulas: [
			{
				title: 'Loan amounts',
				expression: 'Cash back loan = Price − Rebate − Down payment\nLow APR loan = Price − Down payment',
				variables: [{ symbol: 'Price', meaning: 'purchase price before the rebate' }]
			},
			{
				title: 'Monthly payment (for each option)',
				expression: 'M = P × r(1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'P', meaning: 'loan amount for that option' },
					{ symbol: 'r', meaning: 'monthly rate (that option’s APR ÷ 12 ÷ 100)' },
					{ symbol: 'n', meaning: 'number of monthly payments' }
				]
			},
			{
				title: 'Total cost and comparison',
				expression: 'Total cost = Down payment + M × n\nDifference = Total cost (cash back) − Total cost (low APR)',
				variables: []
			}
		],
		example: {
			title: 'A $35,000 car with a $2,000 rebate, a 1.9% dealer rate and a 6.5% bank rate',
			steps: [
				'Cash back: loan = 35,000 − 2,000 − 3,000 down = $30,000 at 6.5% over 60 months, so M ≈ $586.98',
				'Low APR: loan = 35,000 − 3,000 down = $32,000 at 1.9% over 60 months, so M ≈ $559.49',
				'Total cost, cash back: 3,000 + 586.98 × 60 = $38,219.07',
				'Total cost, low APR: 3,000 + 559.49 × 60 = $36,569.37, which is $1,649.70 less'
			],
			result:
				'The low APR costs $1,649.70 less overall, even though the cash-back loan is smaller. Monthly payments are $586.98 with cash back and $559.49 with the low APR.'
		},
		faq: [
			{
				q: 'Why can the smaller loan still cost more?',
				a: 'The rebate lowers the amount you borrow, but the bank rate is higher. Over the full term, the extra interest on the bank loan can outweigh the rebate.'
			},
			{
				q: 'Can I take the rebate and the low rate together?',
				a: 'Sometimes. Many offers exclude each other, so check the terms. If both are allowed, enter the rebate and the low APR, then compare again.'
			},
			{
				q: 'Should I compare total cost or the monthly payment?',
				a: 'Compare the total cost. A lower monthly payment can hide a longer or more expensive loan.'
			},
			{
				q: 'Does this include sales tax or fees?',
				a: 'Not directly. If tax and fees are added to the loan, add them to the price before you enter it, or repeat the comparison with the taxed figure.'
			}
		],
		sources: [
			{
				title: 'Consumer Financial Protection Bureau',
				url: 'https://www.consumerfinance.gov/'
			}
		],
		disclaimer:
			'Estimates only. Offers, rebates and rates vary, and your lender or dealer’s final terms decide the real cost.'
	}
});
