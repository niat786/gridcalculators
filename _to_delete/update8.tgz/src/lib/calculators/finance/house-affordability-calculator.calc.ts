import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './house-affordability-calculator.meta';

/** Monthly principal and interest per $1 borrowed: r(1+r)^n ÷ ((1+r)^n − 1); r = 0 → 1 ÷ n. */
function paymentPerDollar(annualRatePct: number, months: number): number {
	const r = annualRatePct / 1200;
	if (r === 0) return 1 / months;
	const f = Math.pow(1 + r, months);
	return (r * f) / (f - 1);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'income', label: 'Annual gross income', type: 'number', default: 90000, min: 1, max: 100_000_000, step: 1000, prefix: '$', suffix: '/yr', help: 'Before taxes, combined for everyone on the loan' },
		{ id: 'debts', label: 'Monthly debt payments', type: 'number', default: 500, min: 0, max: 1_000_000, step: 50, prefix: '$', suffix: '/mo', help: 'Car loans, student loans, cards. Not current rent.' },
		{ id: 'down', label: 'Down payment', type: 'number', default: 60000, min: 0, max: 100_000_000, step: 1000, prefix: '$' },
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 6.5, min: 0, max: 100, step: 0.01, suffix: '%', help: 'Annual rate' },
		{ id: 'term', label: 'Loan term', type: 'number', default: 30, min: 1, max: 50, step: 1, suffix: 'years', decimal: false },
		{ id: 'tax', label: 'Property tax', type: 'number', default: 1.1, min: 0, max: 20, step: 0.01, suffix: '%/yr', help: 'Percent of the home price each year' },
		{ id: 'insurance', label: 'Home insurance', type: 'number', default: 1500, min: 0, max: 1_000_000, step: 100, prefix: '$', suffix: '/yr' }
	],
	calculate(v): CalculationResult {
		const income = Number(v.income);
		const debts = Number(v.debts) || 0;
		const down = Number(v.down) || 0;
		const rate = Number(v.rate);
		const years = Number(v.term);
		const taxPct = Number(v.tax) || 0;
		const insurance = Number(v.insurance) || 0;

		if (
			!(income > 0) ||
			!Number.isFinite(income) ||
			!(debts >= 0 && down >= 0 && insurance >= 0 && taxPct >= 0) ||
			!(rate >= 0 && rate <= 100) ||
			!Number.isInteger(years) ||
			!(years >= 1 && years <= 50)
		) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Affordable home price',
				summary: 'Enter your annual income, a loan term from 1 to 50 years and valid amounts.'
			};
		}

		// Monthly housing budget: the smaller of 28% of gross income (front-end)
		// and 36% of gross income minus monthly debts (back-end).
		const monthlyIncome = income / 12;
		const frontEnd = 0.28 * monthlyIncome;
		const backEnd = 0.36 * monthlyIncome - debts;
		const housing = Math.min(frontEnd, backEnd);
		const limit = frontEnd <= backEnd ? '28% housing' : '36% total debt';

		if (!(housing > 0)) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Affordable home price',
				summary: 'Your monthly debts use up the 36% limit, so no housing budget is left.'
			};
		}

		// Housing = L·k + t·(L + D) + I, where L is the loan, D the down payment,
		// k the principal and interest per $1, t the monthly tax per $1 of price, I monthly insurance.
		const k = paymentPerDollar(rate, years * 12);
		const t = taxPct / 1200;
		const i = insurance / 12;
		const loan = (housing - t * down - i) / (k + t);

		if (!(loan > 0) || !Number.isFinite(loan)) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Affordable home price',
				summary: 'Your budget does not cover property tax and insurance with this down payment. Try a smaller down payment.'
			};
		}

		const price = loan + down;
		const principalInterest = loan * k;
		const monthlyTax = t * price;

		return {
			primaryResult: money(price, true),
			primaryLabel: 'Affordable home price',
			summary: `Limited by the ${limit} rule: up to ${money(housing)} a month for housing.`,
			secondaryMetrics: [
				{ label: 'Loan amount', value: money(loan, true) },
				{ label: 'Max monthly housing', value: money(housing) },
				{ label: 'Principal & interest', value: money(principalInterest) },
				{ label: 'Property tax (monthly)', value: money(monthlyTax) },
				{ label: 'Home insurance (monthly)', value: money(i) },
				{ label: 'Loan term', value: plural(years, 'year') }
			]
		};
	},
	content: {
		intro:
			'Estimate the most home you can afford. The calculator uses the common 28% and 36% debt-to-income guidelines, then works back from your monthly housing budget to a home price.',
		howTo: [
			'Enter your annual gross income and the monthly payments you already make on debts.',
			'Enter the down payment you plan to use, plus the interest rate and loan term.',
			'Add the yearly property tax rate and home insurance cost in your area.',
			'Read the affordable home price, then check the monthly breakdown.'
		],
		formulas: [
			{
				title: 'Monthly housing budget',
				expression: 'Housing = smaller of (28% × income ÷ 12) and (36% × income ÷ 12 − monthly debts)',
				variables: [
					{ symbol: '28%', meaning: 'front-end limit: housing costs as a share of gross income' },
					{ symbol: '36%', meaning: 'back-end limit: all debts, housing included, as a share of gross income' }
				]
			},
			{
				title: 'Affordable loan and price',
				expression: 'Loan = (Housing − t × D − I) ÷ (k + t)        Price = Loan + D',
				variables: [
					{ symbol: 'k', meaning: 'principal and interest per $1 borrowed (the payment factor for your rate and term)' },
					{ symbol: 't', meaning: 'monthly property tax per $1 of home price (tax % ÷ 12 ÷ 100)' },
					{ symbol: 'I', meaning: 'monthly home insurance (yearly cost ÷ 12)' },
					{ symbol: 'D', meaning: 'down payment' }
				]
			}
		],
		example: {
			title: 'Income of $90,000 a year, $500 of monthly debts, and $60,000 down',
			steps: [
				'Front-end: 28% × $90,000 ÷ 12 = $2,100 a month',
				'Back-end: 36% × $90,000 ÷ 12 − $500 = $2,200 a month',
				'The smaller limit is $2,100, so the front-end rule applies',
				'With 6.5% over 30 years, k ≈ 0.00632068. Tax is 1.1% a year and insurance is $1,500 a year, so t = 0.00091667 and I = $125',
				'Loan = ($2,100 − 0.00091667 × $60,000 − $125) ÷ (0.00632068 + 0.00091667) ≈ $265,291, so price ≈ $325,291'
			],
			result: 'Affordable home price of about $325,291 with a loan of about $265,291 and a monthly housing cost of $2,100.'
		},
		faq: [
			{
				q: 'What are the 28% and 36% rules?',
				a: 'Lenders often look at housing costs below 28% of gross monthly income, and total debt payments, housing included, below 36%. They are guidelines, not guarantees, so some lenders approve more or less.'
			},
			{
				q: 'Is my gross income or take-home pay used?',
				a: 'Gross income, meaning income before taxes and deductions. Lenders use gross figures when they calculate these ratios.'
			},
			{
				q: 'Why does a bigger down payment raise the price I can afford?',
				a: 'Your monthly housing budget stays the same, but more of the price is paid upfront. That means the loan is smaller for the same payment, and the total price can be higher.'
			},
			{
				q: 'What is left out of this estimate?',
				a: 'Closing costs, HOA fees, mortgage insurance (PMI) and maintenance are not included. Add them to your budget before you choose a home.'
			}
		],
		sources: [
			{
				title: 'Consumer Financial Protection Bureau — Explore interest rates',
				url: 'https://www.consumerfinance.gov/owning-a-home/explore-rates/'
			}
		],
		disclaimer:
			'Estimates only. Lenders use their own rules, and your approval, rate and taxes depend on your credit, lender and location.'
	}
});
