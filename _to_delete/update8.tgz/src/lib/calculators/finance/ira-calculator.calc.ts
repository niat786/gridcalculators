import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num } from '../format';
import { growIra } from '../data/ira-math';
import { IRS_LIMITS_SOURCE, LIMIT_IRA, limitIra, RETIREMENT_TAX_YEAR } from '../data/us-retirement';
import meta from './ira-calculator.meta';

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'age', label: 'Current age', type: 'number', default: 35, min: 18, max: 75, decimal: false, suffix: 'years', width: 'half' },
		{ id: 'retire', label: 'Retirement age', type: 'number', default: 65, min: 19, max: 90, decimal: false, suffix: 'years', width: 'half' },
		{ id: 'balance', label: 'Current balance', type: 'number', default: 10000, min: 0, max: 100_000_000, prefix: '$' },
		{ id: 'contrib', label: 'Yearly contribution', type: 'number', default: 7500, min: 0, max: 100_000, prefix: '$', help: `Capped at the ${RETIREMENT_TAX_YEAR} limit for your age` },
		{ id: 'ret', label: 'Expected return', type: 'number', default: 7, min: -10, max: 20, step: 0.1, suffix: '% / yr' },
		{ id: 'taxNow', label: 'Tax rate now', type: 'number', default: 22, min: 0, max: 60, suffix: '%', width: 'half' },
		{ id: 'taxLater', label: 'Tax rate in retirement', type: 'number', default: 15, min: 0, max: 60, suffix: '%', width: 'half' }
	],
	calculate(v): CalculationResult {
		const age = Number(v.age);
		const retire = Number(v.retire);
		const r = Number(v.ret) / 100;
		const tNow = Number(v.taxNow) / 100;
		const tLater = Number(v.taxLater) / 100;
		const start = Number(v.balance);
		const wanted = Number(v.contrib);
		if ([age, retire, r, tNow, tLater, start, wanted].some((x) => !Number.isFinite(x)) || retire <= age || retire - age > 72) {
			return { primaryResult: DASH, primaryLabel: 'IRA balance at retirement', summary: 'Retirement age must be after your current age.' };
		}
		const yearly = (a: number) => Math.min(wanted, limitIra(a));

		// Same pre-tax income for both: a Roth dollar costs 1 ÷ (1 − tax now) of pay, so a Roth
		// funded from the same pay is the Traditional amount × (1 − tax now).
		const trad = growIra(start, yearly, age, retire, r);
		const roth = growIra(start, (a) => yearly(a) * (1 - tNow), age, retire, r);
		const tradAfter = trad.balance * (1 - tLater);
		const rothAfter = roth.balance; // existing balance assumed already-taxed Roth money for comparison
		const diff = rothAfter - tradAfter;
		const winner = Math.abs(diff) < 1 ? 'Both come out the same' : diff > 0 ? 'Roth comes out ahead' : 'Traditional comes out ahead';

		return {
			primaryResult: money(trad.balance, true),
			primaryLabel: `IRA balance at age ${retire} (before tax)`,
			summary: `${winner}${Math.abs(diff) >= 1 ? ` by ${money(Math.abs(diff), true)} after tax` : ''}: you pay ${num(tNow * 100, 1)}% tax now with a Roth, ${num(tLater * 100, 1)}% later with a Traditional IRA.`,
			secondaryMetrics: [
				{ label: 'Traditional IRA, after tax', value: money(tradAfter, true) },
				{ label: 'Roth IRA, after tax (same pay)', value: money(rothAfter, true) },
				{ label: 'Total you contribute', value: money(trad.put, true) },
				{ label: `${RETIREMENT_TAX_YEAR} limit at your age`, value: money(limitIra(age), true) }
			]
		};
	},
	content: {
		intro: `Project an IRA’s growth with the ${RETIREMENT_TAX_YEAR} contribution limits, and compare how much a Traditional and a Roth IRA would leave you after tax.`,
		howTo: [
			'Enter your age, retirement age, balance and yearly contribution.',
			'Enter an expected return.',
			'Enter your tax rate now and the rate you expect in retirement.',
			'Compare the after-tax results for each type of IRA.'
		],
		formulas: [
			{
				title: 'Growth each year',
				expression: 'balance = balance × (1 + r) + contribution × (1 + r ÷ 2)',
				variables: []
			},
			{
				title: 'Fair comparison from the same pay',
				expression: 'Traditional after tax = FV(C) × (1 − tax later)\nRoth after tax = FV(C × (1 − tax now))',
				variables: [
					{ symbol: 'C', meaning: 'yearly contribution (pre-tax dollars)' },
					{ symbol: 'FV', meaning: 'value at retirement after growth' }
				]
			}
		],
		example: {
			title: '$1,000 of pay, 22% tax now, 15% in retirement, money doubles',
			steps: [
				'Traditional: invest the full $1,000 → $2,000 → pay 15% tax → $1,700',
				'Roth: pay 22% first, invest $780 → $1,560, tax-free',
				'$1,700 − $1,560 = $140'
			],
			result: 'With a lower tax rate later, the Traditional IRA leaves $140 more per $1,000 of pay.'
		},
		faq: [
			{
				q: `What is the IRA contribution limit for ${RETIREMENT_TAX_YEAR}?`,
				a: `$${num(LIMIT_IRA.base, 0)}, or $${num(LIMIT_IRA.base + LIMIT_IRA.catchUp50, 0)} from age 50. The limit is shared across all your Traditional and Roth IRAs.`
			},
			{
				q: 'Which is better, a Traditional or a Roth IRA?',
				a: 'It mostly comes down to tax rates. If you expect a higher tax rate in retirement than now, a Roth usually wins; if lower, a Traditional IRA usually wins. If they are equal, the results are the same.'
			},
			{
				q: 'Can I deduct Traditional IRA contributions?',
				a: 'It depends on your income and whether you or your spouse have a workplace retirement plan. Above certain incomes the deduction phases out. Check IRS Publication 590-A.'
			},
			{
				q: 'Are there other differences besides tax?',
				a: 'Yes. Roth IRAs have no required minimum distributions for the owner and allow withdrawals of contributions at any time; Traditional IRAs require minimum distributions later in life.'
			}
		],
		sources: [IRS_LIMITS_SOURCE, { title: 'IRS Publication 590-A: Contributions to IRAs', url: 'https://www.irs.gov/publications/p590a' }],
		disclaimer: 'Estimates only, not tax advice. Tax rules, eligibility and your future tax rate can change.'
	}
});
