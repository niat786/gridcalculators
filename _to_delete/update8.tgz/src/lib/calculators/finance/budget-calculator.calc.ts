import { defineCalculator, type CalculationResult, type RowValue } from '../types';
import { DASH, money, plural } from '../format';
import meta from './budget-calculator.meta';

const categoryOptions = [
	{ label: 'Needs', value: 'needs' },
	{ label: 'Wants', value: 'wants' },
	{ label: 'Savings', value: 'savings' }
];

/** Share of take-home pay for each category in the 50/30/20 rule. */
const SHARES = { needs: 0.5, wants: 0.3, savings: 0.2 } as const;
type Category = keyof typeof SHARES;
const LABEL: Record<Category, string> = { needs: 'Needs', wants: 'Wants', savings: 'Savings' };

/**
 * 50/30/20 split of monthly take-home pay, plus optional expense rows tagged by category.
 * Needs and wants are capped at their targets; savings should meet or beat its target.
 */
export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'income',
			label: 'Monthly take-home income',
			type: 'number',
			default: 4000,
			min: 0,
			max: 1_000_000_000,
			step: 100,
			prefix: '$',
			help: 'Pay you receive after tax and deductions.'
		},
		{
			id: 'expenses',
			label: 'Actual expenses',
			type: 'rows',
			columns: [
				{ id: 'name', label: 'Expense', type: 'text', default: '', placeholder: 'Expense name' },
				{ id: 'amount', label: 'Monthly amount', type: 'number', default: 0, min: 0, max: 1_000_000_000, prefix: '$' },
				{ id: 'category', label: 'Category', type: 'select', default: 'needs', options: categoryOptions }
			],
			default: [
				{ name: 'Rent', amount: 1400, category: 'needs' },
				{ name: 'Groceries', amount: 450, category: 'needs' },
				{ name: 'Utilities', amount: 180, category: 'needs' },
				{ name: 'Dining out', amount: 350, category: 'wants' },
				{ name: 'Streaming', amount: 60, category: 'wants' },
				{ name: 'Retirement and emergency fund', amount: 500, category: 'savings' }
			],
			maxRows: 40,
			addLabel: 'Add expense'
		}
	],
	calculate(v): CalculationResult {
		const income = Number(v.income);
		const rows = (v.expenses as RowValue[]) ?? [];
		const invalid = (): CalculationResult => ({
			primaryResult: DASH,
			primaryLabel: 'Monthly savings target',
			summary: 'Enter your take-home income, and an amount and category for each expense.'
		});

		if (!(income > 0)) return invalid();

		const spent: Record<Category, number> = { needs: 0, wants: 0, savings: 0 };
		for (const row of rows) {
			const amount = Number(row.amount);
			const category = String(row.category) as Category;
			if (!Number.isFinite(amount) || amount < 0 || !(category in SHARES)) return invalid();
			spent[category] += amount;
		}
		const entered = spent.needs + spent.wants + spent.savings;
		const target = (c: Category) => income * SHARES[c];

		const status = (c: Category): string => {
			const diff = spent[c] - target(c);
			if (Math.abs(diff) < 0.005) return 'On target';
			if (c === 'savings') return diff < 0 ? `${money(-diff)} short` : `${money(diff)} above`;
			return diff > 0 ? `${money(diff)} over` : `${money(-diff)} under`;
		};

		const hasExpenses = rows.length > 0;
		const summary = hasExpenses
			? `You are saving ${money(spent.savings)} against a target of ${money(target('savings'))}.`
			: `Your targets are ${money(target('needs'))} for needs, ${money(target('wants'))} for wants and ${money(target('savings'))} for savings.`;

		const table = {
			title: 'Targets compared with your expenses',
			columns: [
				{ key: 'category', label: 'Category' },
				{ key: 'share', label: 'Share', align: 'end' as const },
				{ key: 'target', label: 'Target', align: 'end' as const },
				{ key: 'actual', label: 'Actual', align: 'end' as const },
				{ key: 'status', label: 'Status', align: 'end' as const }
			],
			rows: (['needs', 'wants', 'savings'] as Category[]).map((c) => ({
				category: LABEL[c],
				share: `${Math.round(SHARES[c] * 100)}%`,
				target: money(target(c)),
				actual: money(spent[c]),
				status: status(c)
			}))
		};

		return {
			primaryResult: money(target('savings')),
			primaryLabel: 'Monthly savings target',
			summary,
			secondaryMetrics: [
				{ label: 'Needs target', value: money(target('needs')) },
				{ label: 'Wants target', value: money(target('wants')) },
				{ label: 'Total expenses entered', value: money(entered) },
				{
					label: entered <= income ? 'Left after expenses' : 'Over income by',
					value: money(Math.abs(income - entered))
				}
			],
			table
		};
	},
	content: {
		intro:
			'Split your monthly take-home pay with the 50/30/20 rule: half for needs, 30% for wants and 20% for savings or debt repayment. Add your real expenses to see how each category compares with its target.',
		howTo: [
			'Enter the take-home pay you receive each month, after tax.',
			'Add each regular expense and tag it as a need, a want or savings.',
			'Read your targets, then check the table to see which categories are over, under or short.',
			'Adjust the expenses until the table shows the categories you want.'
		],
		formulas: [
			{
				title: 'Category targets',
				expression: 'Needs = income × 50%,   Wants = income × 30%,   Savings = income × 20%',
				variables: [{ symbol: 'income', meaning: 'monthly take-home pay' }]
			},
			{
				title: 'Left after expenses',
				expression: 'Left = income − (needs + wants + savings expenses)',
				variables: [{ symbol: 'Left', meaning: 'money not yet spent or saved this month' }]
			}
		],
		example: {
			title: '$4,000 take-home pay with six monthly expenses',
			steps: [
				'Targets: needs $4,000 × 50% = $2,000, wants $1,200, savings $800',
				'Needs entered: rent $1,400 + groceries $450 + utilities $180 = $2,030, which is $30 over',
				'Wants entered: dining out $350 + streaming $60 = $410, which is $790 under',
				'Savings entered: $500, which is $300 short of the $800 target',
				'Total entered: $2,030 + $410 + $500 = $2,940, leaving $1,060'
			],
			result: 'Savings target: $800 a month. Your entered savings of $500 fall $300 short.'
		},
		faq: [
			{
				q: 'What is the 50/30/20 rule?',
				a: 'It is a simple budgeting guide. Spend about half of take-home pay on needs such as housing, food and transport, about 30% on wants, and put about 20% toward savings or paying down debt.'
			},
			{
				q: 'Should I use gross or take-home pay?',
				a: 'Use take-home pay, the amount that reaches your bank account after tax, retirement contributions and other deductions. Budget targets based on gross pay will overstate what you can spend.'
			},
			{
				q: 'Where do debt payments go?',
				a: 'Many people count minimum debt payments as needs and extra payments as savings. You can choose a different rule, as long as each expense is tagged the same way every month.'
			},
			{
				q: 'What if my needs are more than half of my pay?',
				a: 'The rule is a guide, not a requirement. Many households spend more than half on housing and food, especially in high-cost areas. The table shows the gap so you can decide where to cut.'
			}
		],
		sources: [{ title: 'Consumer Financial Protection Bureau', url: 'https://www.consumerfinance.gov' }],
		disclaimer:
			'Estimates only. Budget rules are general guides, not personal financial advice, and your costs and goals may call for a different split.'
	}
});
