import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './auto-loan-calculator.meta';

/** Fixed-rate payment: M = P·r(1+r)^n / ((1+r)^n − 1); r = 0 → P / n. */
function payment(principal: number, annualRatePct: number, months: number): number {
	const r = annualRatePct / 1200;
	if (r === 0) return principal / months;
	const f = Math.pow(1 + r, months);
	return (principal * r * f) / (f - 1);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'price', label: 'Vehicle price', type: 'number', default: 35000, min: 1, max: 10_000_000, step: 500, prefix: '$' },
		{ id: 'down', label: 'Down payment', type: 'number', default: 3000, min: 0, max: 10_000_000, step: 100, prefix: '$' },
		{ id: 'trade', label: 'Trade-in value', type: 'number', default: 5000, min: 0, max: 10_000_000, step: 100, prefix: '$', help: 'What the dealer gives for your current car' },
		{ id: 'tax', label: 'Sales tax', type: 'number', default: 7, min: 0, max: 30, step: 0.01, suffix: '%', help: 'Charged on the price after trade-in' },
		{ id: 'fees', label: 'Fees', type: 'number', default: 500, min: 0, max: 1_000_000, step: 50, prefix: '$', help: 'Registration, documents and other fees' },
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 6.9, min: 0, max: 100, step: 0.01, suffix: '%', help: 'Annual rate' },
		{
			id: 'term',
			label: 'Loan term',
			type: 'select',
			display: 'segmented',
			default: '60',
			options: [
				{ label: '36 mo', value: '36' },
				{ label: '48 mo', value: '48' },
				{ label: '60 mo', value: '60' },
				{ label: '72 mo', value: '72' },
				{ label: '84 mo', value: '84' }
			]
		}
	],
	calculate(v): CalculationResult {
		const price = Number(v.price);
		const down = Number(v.down) || 0;
		const trade = Number(v.trade) || 0;
		const taxPct = Number(v.tax) || 0;
		const fees = Number(v.fees) || 0;
		const rate = Number(v.rate);
		const n = Number(v.term);

		const tax = (taxPct / 100) * Math.max(0, price - trade);
		const loan = price - down - trade + tax + fees;

		if (
			!(price > 0) ||
			!Number.isFinite(price) ||
			!(down >= 0 && trade >= 0 && taxPct >= 0 && fees >= 0) ||
			!(rate >= 0 && rate <= 100) ||
			!(n >= 1) ||
			!(loan > 0) ||
			!Number.isFinite(loan)
		) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Monthly payment',
				summary: 'Enter a vehicle price, and make sure the down payment and trade-in do not cover the whole cost.'
			};
		}

		const monthly = payment(loan, rate, n);
		const totalPayments = monthly * n;
		const totalInterest = Math.max(0, totalPayments - loan);
		// Cash you put in plus every loan payment: the car's net price, tax, fees and interest.
		const totalCost = down + totalPayments;

		return {
			primaryResult: money(monthly),
			primaryLabel: 'Monthly payment',
			summary: `${money(loan, true)} financed for ${n} months at ${num(rate, 3)}%.`,
			secondaryMetrics: [
				{ label: 'Loan amount', value: money(loan) },
				{ label: 'Sales tax', value: money(tax) },
				{ label: 'Total interest', value: money(totalInterest) },
				{ label: 'Total of loan payments', value: money(totalPayments) },
				{ label: 'Total cost', value: money(totalCost) }
			]
		};
	},
	content: {
		intro:
			'Estimate your monthly car payment and what the loan will really cost once you add sales tax, fees and interest, and subtract any trade-in.',
		howTo: [
			'Enter the vehicle price and any cash down payment.',
			'Enter the trade-in value of your current car, if you have one.',
			'Add the sales tax rate and the fees your dealer lists.',
			'Enter the interest rate and choose a loan term, then read the monthly payment.'
		],
		formulas: [
			{
				title: 'Loan amount',
				expression: 'Loan = price − down payment − trade-in + tax + fees',
				variables: [
					{ symbol: 'Tax', meaning: 'sales tax % × (price − trade-in)' }
				]
			},
			{
				title: 'Monthly payment',
				expression: 'M = P × r(1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'M', meaning: 'monthly payment' },
					{ symbol: 'P', meaning: 'loan amount' },
					{ symbol: 'r', meaning: 'monthly interest rate (annual rate ÷ 12 ÷ 100)' },
					{ symbol: 'n', meaning: 'number of monthly payments (the loan term in months)' }
				]
			},
			{
				title: 'Total cost',
				expression: 'Total cost = down payment + M × n',
				variables: [
					{ symbol: 'Total cost', meaning: 'what you pay in cash and loan payments, after the trade-in is credited' }
				]
			}
		],
		example: {
			title: 'A $35,000 car with $3,000 down, a $5,000 trade-in, 7% tax and $500 fees at 6.9% for 60 months',
			steps: [
				'Tax: 7% × ($35,000 − $5,000) = $2,100',
				'Loan: $35,000 − $3,000 − $5,000 + $2,100 + $500 = $29,600',
				'Monthly rate: r = 6.9 ÷ 12 ÷ 100 = 0.00575, n = 60',
				'M = 29,600 × 0.00575 × (1.00575)⁶⁰ ÷ ((1.00575)⁶⁰ − 1) ≈ $584.72',
				'Total cost = $3,000 + 584.72 × 60 = $38,083.20'
			],
			result: 'Monthly payment of $584.72 on a $29,600 loan. Total interest is $5,483.20.'
		},
		faq: [
			{
				q: 'Why is sales tax added to the loan?',
				a: 'Many buyers roll tax and fees into the amount they finance. This calculator adds them to the loan so the payment includes them. If you pay them in cash, enter a bigger down payment instead.'
			},
			{
				q: 'Is the trade-in value taxed?',
				a: 'In many states the sales tax is charged only on the price after the trade-in is subtracted. This calculator works that way. Check your state rules, because some places do not follow this.'
			},
			{
				q: 'Why is the total cost higher than the price?',
				a: 'The total cost includes interest, tax and fees. It also counts your down payment, so it reflects everything you pay on the car, after the trade-in credit.'
			},
			{
				q: 'Does a longer term help?',
				a: 'A longer term lowers the monthly payment but adds more interest. Choose the shortest term whose payment fits your budget.'
			}
		],
		sources: [
			{
				title: 'Consumer Financial Protection Bureau',
				url: 'https://www.consumerfinance.gov/'
			}
		],
		disclaimer:
			'Estimates only. Your real tax, fees, trade-in value and loan rate depend on your state, dealer and lender.'
	}
});
