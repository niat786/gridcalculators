import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num } from '../format';
import meta from './oman-end-of-service-calculator.meta';
import { parseISO, serviceYears, yearsLabel } from '../data/service-years';
import {
	OM_LAW_EFFECTIVE_LABEL,
	OM_MONTHS_PER_YEAR_FULL,
	OM_OLD_FIRST_TIER_YEARS,
	OM_OLD_MONTHS_PER_YEAR_FIRST,
	OM_OLD_PERIOD_LAST_DAY,
	OM_SAVINGS_LATEST_START,
	OM_SAVINGS_RATE_PCT,
	OM_SOURCES
} from '../data/om-end-of-service';

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'basic',
			label: 'Last monthly basic wage',
			type: 'number',
			default: 500,
			min: 0,
			max: 10_000_000,
			prefix: '$',
			help: 'Basic wage only. Allowances are not included.'
		},
		{ id: 'start', label: 'First day of work', type: 'date', default: '2021-08-01' },
		{ id: 'end', label: 'Last day of work', type: 'date', default: 'today' }
	],
	calculate(v): CalculationResult {
		const label = 'End-of-service gratuity';
		const basic = Number(v.basic);
		const start = parseISO(String(v.start));
		const end = parseISO(String(v.end));
		const lastOld = parseISO(OM_OLD_PERIOD_LAST_DAY);
		if (!(basic > 0) || !Number.isFinite(basic) || !start || !end || !lastOld) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter a basic wage above zero and two valid dates.' };
		}
		const sy = serviceYears(start, end);
		if (!sy) return { primaryResult: DASH, primaryLabel: label, summary: 'The last day of work is before the first day.' };

		const years = sy.years;
		// Service up to and including 31 July 2023 is paid under the old law; the rest under Article 61.
		const oldEnd = end < lastOld ? end : lastOld;
		const oldYears = start <= oldEnd ? (serviceYears(start, oldEnd)?.years ?? 0) : 0;
		const newYears = Math.max(years - oldYears, 0);
		const oldMonths = Math.min(oldYears, OM_OLD_FIRST_TIER_YEARS) * OM_OLD_MONTHS_PER_YEAR_FIRST + Math.max(oldYears - OM_OLD_FIRST_TIER_YEARS, 0) * OM_MONTHS_PER_YEAR_FULL;
		const newMonths = newYears * OM_MONTHS_PER_YEAR_FULL;
		const totalMonths = oldMonths + newMonths;
		const total = totalMonths * basic;

		return {
			primaryResult: money(total),
			primaryLabel: label,
			summary: `${num(totalMonths, 3)} months of basic wage: ${num(oldMonths, 3)} for service up to ${OM_LAW_EFFECTIVE_LABEL} (old rates) and ${num(newMonths, 3)} after it (one basic wage a year). Your contract may pay more.`,
			secondaryMetrics: [
				{ label: 'Service counted', value: yearsLabel(years) },
				{ label: `Service up to ${OM_LAW_EFFECTIVE_LABEL}`, value: yearsLabel(oldYears) },
				{ label: 'Gratuity for service before', value: money(oldMonths * basic) },
				{ label: `Service after ${OM_LAW_EFFECTIVE_LABEL}`, value: yearsLabel(newYears) },
				{ label: 'Gratuity for service after', value: money(newMonths * basic) }
			]
		};
	},
	content: {
		intro:
			'Work out the end-of-service gratuity for a non-Omani private-sector worker in Oman under Article 61 of the Labour Law (Royal Decree 53/2023): at least one basic wage for every year of service, with the older, lower rate for service before 31 July 2023.',
		howTo: [
			'Enter your last monthly basic wage, without allowances.',
			'Enter your first and last day of work. Part years are counted pro rata.',
			'Read the gratuity and how much of it comes from service before and after 31 July 2023.'
		],
		formulas: [
			{
				title: 'Gratuity under Article 61, with the transition rule',
				expression: 'Gratuity = B × ( 0.5 × min(P, 3) + 1 × max(P − 3, 0) + N )',
				variables: [
					{ symbol: 'B', meaning: 'Last monthly basic wage.' },
					{ symbol: 'P', meaning: 'Years of service up to and including 31 July 2023 (old law: half a month a year for the first 3 years, then one month).' },
					{ symbol: 'N', meaning: 'Years of service after 31 July 2023: one basic wage per year (Article 61).' }
				]
			}
		],
		example: {
			title: 'RO 500 basic wage, 1 August 2021 to 31 July 2025 (the Ministry of Labour’s own example)',
			steps: [
				'Service: exactly 4 years. Two of them (1 Aug 2021 to 31 Jul 2023) fall under the old rate.',
				'Old-rate years: 2 × half a basic wage = 2 × OMR 250 = OMR 500.',
				'New-rate years: 2 × one basic wage = 2 × OMR 500 = OMR 1,000.',
				'Gratuity: 500 + 1,000 = OMR 1,500.'
			],
			result: 'OMR 1,500.000'
		},
		faq: [
			{
				q: 'Has the savings scheme for expatriates replaced gratuity yet?',
				a: `Not yet. The Social Protection Law replaces gratuity with an employer-funded savings system (${OM_SAVINGS_RATE_PCT}% of monthly basic wage) once the Social Protection Fund sets a start date, no later than ${OM_SAVINGS_LATEST_START} after Royal Decree 60/2025 added a year. Until then Article 61 applies, and gratuity earned before the start is still owed.`
			},
			{
				q: 'What changed in 2023?',
				a: 'The 2003 law paid 15 days of basic wage for each of the first three years and a month for each year after. The 2023 law, in force from 31 July 2023, pays at least one basic wage for every year. Service before that date keeps the old rate, so older employees get a blend.'
			},
			{
				q: 'Does resigning or having a short service affect it?',
				a: 'Article 61 has no resignation cut and no minimum service period; part years are paid pro rata. Gratuity can be withheld only where you are dismissed without notice for one of the nine serious reasons in Article 40, which this calculator does not model.'
			}
		],
		sources: OM_SOURCES,
		disclaimer:
			'Estimate of the statutory minimum for non-Omani workers who are not covered by the Social Protection Law. Your contract may pay more. This is not legal advice; confirm with the Ministry of Labour or your employer.'
	}
});
