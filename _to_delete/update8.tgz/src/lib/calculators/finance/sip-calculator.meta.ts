import { defineMeta } from '../types';

export default defineMeta({
	slug: 'sip-calculator',
	name: 'SIP Calculator',
	category: 'finance',
	shortDescription: 'Estimate the maturity value of a monthly SIP investment',
	metaTitle: 'SIP Calculator — Monthly Investment Growth',
	metaDescription:
		'Free SIP calculator. Enter a monthly investment, expected annual return and number of years to see the maturity value, amount invested and returns.',
	icon: 'wallet',
	keywords: ['sip calculator', 'sip return calculator', 'monthly investment calculator', 'mutual fund sip calculator', 'sip maturity value'],
	updated: '2026-10-28',
	money: 'any',
	defaultCurrency: 'INR'
});
