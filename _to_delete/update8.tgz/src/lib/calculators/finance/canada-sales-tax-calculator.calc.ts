import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, pct } from '../format';
import meta from './canada-sales-tax-calculator.meta';
import { SALES_TAX, SALES_TAX_SOURCE } from '../data/ca-tax-2026';

const OPTIONS = Object.entries(SALES_TAX)
	.map(([value, p]) => ({ value, label: p.name }))
	.sort((a, b) => a.label.localeCompare(b.label));

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'province', label: 'Province or territory', type: 'select', display: 'menu', default: 'ON', options: OPTIONS },
		{
			id: 'mode',
			label: 'What do you want to do?',
			type: 'select',
			display: 'segmented',
			default: 'add',
			options: [
				{ label: 'Add tax', value: 'add' },
				{ label: 'Remove tax', value: 'remove' }
			]
		},
		{ id: 'amount', label: 'Amount', type: 'number', default: 100, min: 0, max: 1_000_000_000, step: 1, prefix: '$', help: 'The price before tax to add tax to, or the total with tax to take it out of.' }
	],
	calculate(v): CalculationResult {
		const data = SALES_TAX[String(v.province)];
		const amount = Number(v.amount);
		const mode = v.mode === 'remove' ? 'remove' : 'add';
		if (!data || !Number.isFinite(amount) || amount < 0) {
			return { primaryResult: DASH, primaryLabel: 'Total with tax', summary: 'Enter an amount of zero or more and pick a province or territory.' };
		}
		const total = data.federal + data.provincial;
		// GST, HST, PST and QST are each a percentage of the pre-tax price, so they add up to one combined rate.
		const pre = mode === 'add' ? amount : amount / (1 + total / 100);
		const federal = (pre * data.federal) / 100;
		const provincial = (pre * data.provincial) / 100;
		const withTax = pre + federal + provincial;
		const federalLabel = data.kind === 'HST' ? 'Federal part of HST (5%)' : 'GST (5%)';
		const metrics = [
			{ label: 'Price before tax', value: money(pre) },
			{ label: federalLabel, value: money(federal) },
			...(data.provincial > 0 ? [{ label: `${data.provincialLabel} (${num(data.provincial, 3)}%)`, value: money(provincial) }] : []),
			{ label: 'Total tax', value: money(federal + provincial) },
			{ label: 'Combined rate', value: pct(total, 3) }
		];
		const kindText: Record<string, string> = {
			GST: '5% GST only',
			'GST+PST': `5% GST plus ${num(data.provincial, 3)}% ${data.provincialLabel}`,
			'GST+QST': '5% GST plus 9.975% QST, both on the pre-tax price',
			HST: `${num(total, 3)}% HST (5% federal + ${num(data.provincial, 3)}% provincial)`
		};
		return {
			primaryResult: mode === 'add' ? money(withTax) : money(pre),
			primaryLabel: mode === 'add' ? 'Total with tax' : 'Price before tax',
			summary: `${data.name}: ${kindText[data.kind]}.${mode === 'add' ? '' : ` ${money(amount)} includes ${money(federal + provincial)} of tax.`}`,
			secondaryMetrics: metrics
		};
	},
	content: {
		intro:
			'Add sales tax to a price, or take it out of a total, anywhere in Canada. It uses the 2026 rates for GST, HST, PST (British Columbia, Manitoba, Saskatchewan) and QST (Quebec), and shows the federal and provincial split.',
		howTo: [
			'Pick your province or territory.',
			'Choose Add tax to start from the price before tax, or Remove tax to start from a total.',
			'Enter the amount and read the total or the pre-tax price, with each tax shown.'
		],
		formulas: [
			{
				title: 'Adding and removing tax',
				expression: 'Total = Price × (1 + combined rate);  Price = Total ÷ (1 + combined rate)',
				variables: [
					{ symbol: 'Combined rate', meaning: 'GST 5% plus PST, RST or QST, or the single HST rate' },
					{ symbol: 'HST', meaning: 'Ontario 13%; New Brunswick, Newfoundland and Labrador, Prince Edward Island 15%; Nova Scotia 14% since April 1, 2025' },
					{ symbol: 'Other', meaning: 'B.C. 5% + 7% PST; Manitoba 5% + 7% RST; Saskatchewan 5% + 6% PST; Quebec 5% + 9.975% QST; AB, NT, NU, YT 5% GST' }
				]
			}
		],
		example: {
			title: 'A $200 purchase in Quebec',
			steps: ['GST = $200 × 5% = $10.00', 'QST = $200 × 9.975% = $19.95 (QST is charged on the price, not on the GST)', 'Total = $200 + $10.00 + $19.95'],
			result: 'The total with tax is $229.95, a combined rate of 14.975%.'
		},
		faq: [
			{
				q: 'What is the HST rate in Nova Scotia now?',
				a: 'It is 14% from April 1, 2025, down from 15%: 5% federal and 9% provincial.'
			},
			{
				q: 'Is PST charged on top of GST?',
				a: 'GST and PST (or QST) are each a percentage of the pre-tax price, so they add up to one combined rate. Since 2013 Quebec no longer charges QST on top of GST.'
			},
			{
				q: 'Are all items taxed at these rates?',
				a: 'No. Basic groceries, many medical items and some services are zero-rated or exempt, and some goods have different provincial treatment. These are the general rates for most purchases.'
			}
		],
		sources: [SALES_TAX_SOURCE],
		disclaimer: 'General rates for most purchases. Exemptions and special rules apply to some items. This is not tax advice.'
	}
});
