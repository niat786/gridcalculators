import { defineCalculator, type CalculationResult, type CalculatorInput, type InputValues } from '../types';
import { DASH, money, pct } from '../format';
import meta from './cpf-contribution-calculator.meta';
import {
	SG_CPF_ALLOCATION_SOURCE,
	SG_CPF_ANNUAL_CEILING,
	SG_CPF_BANDS,
	SG_CPF_FULL_RATE_ABOVE,
	SG_CPF_OW_CEILING,
	SG_CPF_OW_SOURCE,
	SG_CPF_SOURCE,
	SG_CPF_SOURCE_2,
	SG_CPF_SOURCE_3,
	SG_CPF_SOURCE_4,
	type SgCpfBand
} from '../data/sg-2026';

const sgd = (n: number) => money(n);
const dollars = (n: number) => money(n, true);

interface Split {
	total: number;
	employee: number;
	employer: number;
	oa: number;
	ra: number;
	ma: number;
}

/** CPF on one payment of wages: total rounded to the nearest dollar, employee's cents dropped, employer is the rest. */
export function cpfOn(wage: number, band: SgCpfBand): Split {
	const totalPct = band.employee + band.employer;
	const total = Math.round(Math.round(wage * totalPct * 1e4) / 1e6 + 1e-9);
	const employee = Math.floor(Math.round(wage * band.employee * 1e4) / 1e6 + 1e-9);
	// Allocation: MediSave first, then SA/RA, and OA takes the rest.
	const ma = Math.round((total * band.ma) / totalPct);
	const ra = Math.round((total * band.ra) / totalPct);
	return { total, employee, employer: total - employee, oa: total - ma - ra, ra, ma };
}

const inputs: CalculatorInput[] = [
	{ id: 'wage', label: 'Monthly ordinary wage', type: 'number', default: 5_000, min: 750.01, max: 10_000_000, step: 100, prefix: '$', help: `Salary before CPF. Only the first $${SG_CPF_OW_CEILING.toLocaleString('en-US')} a month counts. This tool covers wages above $${SG_CPF_FULL_RATE_ABOVE} a month.` },
	{
		id: 'age',
		label: 'Employee age',
		type: 'select',
		default: 'u35',
		display: 'menu',
		options: SG_CPF_BANDS.map((b) => ({ label: b.label, value: b.value })),
		help: 'Singapore citizens and PRs in their third year of PR or later.'
	},
	{ id: 'bonus', label: 'Yearly bonus (additional wage)', type: 'number', default: 0, min: 0, max: 1_000_000_000, step: 1000, prefix: '$', help: 'Optional. Bonuses count up to the yearly ceiling.' }
];

function calculate(v: InputValues): CalculationResult {
	const wage = Number(v.wage);
	const bonus = Number(v.bonus);
	const band = SG_CPF_BANDS.find((b) => b.value === v.age);
	if (!Number.isFinite(wage) || wage <= SG_CPF_FULL_RATE_ABOVE) {
		return { primaryResult: DASH, primaryLabel: 'Total CPF per month', summary: `Enter a monthly wage above $${SG_CPF_FULL_RATE_ABOVE}. Lower wages use different rates that this tool does not cover.` };
	}
	if (!Number.isFinite(bonus) || bonus < 0 || !band) {
		return { primaryResult: DASH, primaryLabel: 'Total CPF per month', summary: 'Choose an age group and enter any bonus as zero or more.' };
	}

	const owSubject = Math.min(wage, SG_CPF_OW_CEILING);
	const m = cpfOn(owSubject, band);
	// Additional wages: ceiling = 102,000 − the OW that counts for the year.
	const awCeiling = Math.max(0, SG_CPF_ANNUAL_CEILING - owSubject * 12);
	const awSubject = Math.min(bonus, awCeiling);
	const b = awSubject > 0 ? cpfOn(awSubject, band) : { total: 0, employee: 0, employer: 0, oa: 0, ra: 0, ma: 0 };

	const takeHome = wage - m.employee;
	const totalPct = band.employee + band.employer;
	const capped = wage > SG_CPF_OW_CEILING;
	const summary =
		`At ${pct(totalPct, 1)} of ${dollars(owSubject)}${capped ? ` (your wage is above the ${dollars(SG_CPF_OW_CEILING)} ceiling)` : ''}, ${sgd(m.employee)} comes from you and ${sgd(m.employer)} from your employer.` +
		(bonus > 0 ? ` On a ${dollars(bonus)} bonus the yearly CPF is ${sgd(b.total)}.` : '');

	return {
		primaryResult: sgd(m.total),
		primaryLabel: 'Total CPF per month',
		summary,
		secondaryMetrics: [
			{ label: `Employee share (${pct(band.employee, 1)})`, value: sgd(m.employee) },
			{ label: `Employer share (${pct(band.employer, 1)})`, value: sgd(m.employer) },
			{ label: 'Take-home pay before tax', value: sgd(takeHome) },
			{ label: 'Ordinary Account (OA)', value: sgd(m.oa) },
			{ label: band.raName === 'Special Account' ? 'Special Account (SA)' : 'Retirement Account (RA)', value: sgd(m.ra) },
			{ label: 'MediSave Account (MA)', value: sgd(m.ma) },
			{ label: 'CPF on the bonus (employee + employer)', value: sgd(b.total) }
		],
		table: {
			title: 'CPF split, monthly wage and yearly bonus',
			columns: [
				{ key: 'item', label: 'Item' },
				{ key: 'wage', label: 'Monthly wage', align: 'end' },
				{ key: 'bonus', label: 'Bonus', align: 'end' }
			],
			rows: [
				{ item: 'Wages that count', wage: sgd(owSubject), bonus: sgd(awSubject) },
				{ item: 'Employee', wage: sgd(m.employee), bonus: sgd(b.employee) },
				{ item: 'Employer', wage: sgd(m.employer), bonus: sgd(b.employer) },
				{ item: 'Total', wage: sgd(m.total), bonus: sgd(b.total) },
				{ item: 'Ordinary Account', wage: sgd(m.oa), bonus: sgd(b.oa) },
				{ item: band.raName, wage: sgd(m.ra), bonus: sgd(b.ra) },
				{ item: 'MediSave Account', wage: sgd(m.ma), bonus: sgd(b.ma) }
			]
		}
	};
}

export default defineCalculator({
	meta,
	inputs,
	calculate,
	content: {
		intro: 'See how much CPF you and your employer pay each month in Singapore in 2026, and how it is split between the Ordinary, Special or Retirement, and MediSave accounts. Rates are for citizens and PRs in their third year or later.',
		howTo: [
			'Enter your monthly ordinary wage and pick your age group.',
			'Add a yearly bonus if you want to see the CPF on it.',
			'Read the employee and employer shares and the split into OA, SA or RA, and MA.'
		],
		formulas: [
			{
				title: 'Rates from 1 January 2026 (employee + employer)',
				expression: '55 and below: 20% + 17% · above 55 to 60: 18% + 16% · above 60 to 65: 12.5% + 12.5% · above 65 to 70: 7.5% + 9% · above 70: 5% + 7.5%',
				variables: [
					{ symbol: 'OW ceiling', meaning: 'Only the first $8,000 of monthly ordinary wages attracts CPF from 1 January 2026' },
					{ symbol: 'AW ceiling', meaning: 'Bonuses count up to $102,000 minus the ordinary wages that count in the year' },
					{ symbol: 'Rounding', meaning: 'The total is rounded to the nearest dollar, the employee share drops the cents, and the employer pays the rest' }
				]
			},
			{
				title: 'Split between accounts (percentage of wages, age 35 and below)',
				expression: 'OA 23% · SA 6% · MA 8% (total 37%)',
				variables: [{ symbol: 'Older ages', meaning: 'The split shifts towards MediSave and the Retirement Account. From 55 the Special Account is replaced by the Retirement Account' }]
			}
		],
		example: {
			title: '$5,000 a month, age 35 and below',
			steps: [
				'Total: 37% × $5,000 = $1,850.',
				'Employee: 20% × $5,000 = $1,000. Employer: $1,850 − $1,000 = $850.',
				'Split: OA $1,150 (23%), SA $300 (6%), MA $400 (8%).'
			],
			result: 'Total CPF $1,850 a month; take-home before tax $4,000'
		},
		faq: [
			{ q: 'What changed in 2026?', a: 'The monthly ordinary wage ceiling rose to $8,000. Rates rose for workers above 55 to 60 (total 34%) and above 60 to 65 (total 25%), and the increase goes to the Retirement Account.' },
			{ q: 'Do bonuses attract CPF?', a: 'Yes, up to the additional wage ceiling: $102,000 minus the ordinary wages that count for CPF in the year. At the $8,000 ceiling that leaves $6,000 for bonuses.' },
			{ q: 'What is not included?', a: 'First- and second-year PRs (graduated rates), wages of $750 or less, the annual CPF limit, and caps on the MediSave and retirement accounts are not modelled.' }
		],
		sources: [SG_CPF_SOURCE, SG_CPF_OW_SOURCE, SG_CPF_ALLOCATION_SOURCE, SG_CPF_SOURCE_2, SG_CPF_SOURCE_3, SG_CPF_SOURCE_4],
		disclaimer: 'Estimate based on the published CPF rates. Your payslip and the CPF Board are the final word.'
	}
});
