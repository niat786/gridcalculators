import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, plural } from '../format';
import meta from './investment-calculator.meta';

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'start', label: 'Starting amount', type: 'number', default: 10000, min: 0, max: 100_000_000, step: 100, prefix: '$' },
		{
			id: 'monthly',
			label: 'Monthly contribution',
			type: 'number',
			default: 500,
			min: 0,
			max: 1_000_000,
			step: 10,
			prefix: '$',
			suffix: '/mo',
			help: 'Added at the end of each month.'
		},
		{
			id: 'rate',
			label: 'Expected annual return',
			type: 'number',
			default: 7,
			min: -50,
			max: 100,
			step: 0.01,
			suffix: '%',
			help: 'Applied monthly as one-twelfth of the yearly rate.'
		},
		{ id: 'years', label: 'Years', type: 'number', default: 20, min: 1, max: 100, step: 1, suffix: 'years', decimal: false },
		{
			id: 'raise',
			label: 'Yearly increase in contributions',
			type: 'number',
			default: 0,
			min: 0,
			max: 50,
			step: 0.1,
			suffix: '%',
			help: 'Raises your monthly contribution once a year.'
		}
	],
	calculate(v): CalculationResult {
		const start = Number(v.start);
		const monthly = Number(v.monthly);
		const rate = Number(v.rate);
		const years = Number(v.years);
		const raise = Number(v.raise);
		if (
			!(start >= 0) ||
			!(monthly >= 0) ||
			!(rate >= -50 && rate <= 100) ||
			!(Number.isInteger(years) && years >= 1 && years <= 100) ||
			!(raise >= 0 && raise <= 50)
		) {
			return { primaryResult: DASH, primaryLabel: 'Ending value', summary: 'Check the amounts, return and years.' };
		}

		const monthRate = rate / 100 / 12;
		const raiseFactor = 1 + raise / 100;
		let value = start;
		let contributed = start;
		let finalMonthly = monthly;
		const chartData: Record<string, number>[] = [{ year: 0, value, contributed }];
		const rows: Record<string, string>[] = [];

		for (let y = 1; y <= years; y++) {
			const yearlyMonthly = monthly * Math.pow(raiseFactor, y - 1);
			finalMonthly = yearlyMonthly;
			for (let m = 0; m < 12; m++) value = value * (1 + monthRate) + yearlyMonthly;
			contributed += yearlyMonthly * 12;
			const growth = value - contributed;
			chartData.push({ year: y, value, contributed });
			rows.push({
				year: String(y),
				contributed: money(contributed, true),
				growth: money(growth, true),
				value: money(value, true)
			});
		}

		const growth = value - contributed;

		return {
			primaryResult: money(value),
			primaryLabel: 'Ending value',
			summary: `${money(contributed, true)} of contributions grows by ${money(growth, true)} over ${plural(years, 'year')}.`,
			secondaryMetrics: [
				{ label: 'Total contributions', value: money(contributed) },
				{ label: 'Investment growth', value: money(growth) },
				{ label: 'Final-year monthly contribution', value: money(finalMonthly) }
			],
			chart: {
				type: 'line',
				title: 'Portfolio value compared with contributions',
				x: 'year',
				xLabel: 'Year',
				series: [
					{ key: 'value', label: 'Portfolio value' },
					{ key: 'contributed', label: 'Total contributed' }
				],
				data: chartData,
				valueFormat: 'currency'
			},
			table: {
				title: 'Yearly breakdown',
				collapsed: true,
				columns: [
					{ key: 'year', label: 'Year' },
					{ key: 'contributed', label: 'Contributed', align: 'end' },
					{ key: 'growth', label: 'Growth', align: 'end' },
					{ key: 'value', label: 'Value', align: 'end' }
				],
				rows
			}
		};
	},
	content: {
		intro:
			'Project how an investment could grow from a starting amount and monthly contributions. Add a yearly raise to your contributions to see the effect on the final value.',
		howTo: [
			'Enter your starting amount and how much you add each month.',
			'Enter the expected annual return and how many years you will invest.',
			'Optionally enter a yearly increase, such as 3%, to raise your contributions each year.',
			'Read the ending value, then check the chart and yearly breakdown.'
		],
		formulas: [
			{
				title: 'Monthly growth',
				expression: 'Each month: value = value × (1 + r ÷ 12) + contribution',
				variables: [
					{ symbol: 'r', meaning: 'expected annual return as a decimal (7% is 0.07)' },
					{ symbol: 'contribution', meaning: 'monthly amount for that year, added at the end of the month' }
				]
			},
			{
				title: 'Yearly contribution with an increase',
				expression: 'Contribution in year y = C × (1 + g)^(y − 1)',
				variables: [
					{ symbol: 'C', meaning: 'starting monthly contribution' },
					{ symbol: 'g', meaning: 'yearly increase as a decimal' },
					{ symbol: 'y', meaning: 'year number, starting at 1' }
				]
			}
		],
		example: {
			title: '$10,000 to start, $500 a month, 7% for 20 years, no yearly raise',
			steps: [
				'Monthly return: 0.07 ÷ 12 ≈ 0.0058333',
				'Months: 20 × 12 = 240',
				'Starting amount grows to: 10,000 × 1.0058333²⁴⁰ ≈ $40,387.39',
				'Contributions grow to: 500 × (1.0058333²⁴⁰ − 1) ÷ 0.0058333 ≈ $260,463.33',
				'Ending value: $40,387.39 + $260,463.33 ≈ $300,850.72',
				'Total contributions: $10,000 + $500 × 240 = $130,000, so growth is $170,850.72'
			],
			result: 'Ending value ≈ $300,850.72 from $130,000.00 of contributions.'
		},
		faq: [
			{
				q: 'What return should I expect?',
				a: 'No one can know future returns. Many people use a long-run average for a diversified portfolio, but returns vary from year to year and can be negative.'
			},
			{
				q: 'How does a yearly increase change the result?',
				a: 'Each year the monthly contribution rises by the percentage you enter. Even a small increase, such as 2% or 3%, can add a meaningful amount over 20 years.'
			},
			{
				q: 'Why are contributions added at the end of each month?',
				a: 'End-of-month contributions are a common convention for planning. Starting earlier in the month would add a little more growth.'
			},
			{
				q: 'Does this include fees, taxes or inflation?',
				a: 'No. Fund fees, trading costs, taxes and inflation are not included, and each one reduces what you keep.'
			}
		],
		sources: [{ title: 'U.S. Securities and Exchange Commission — Investor.gov', url: 'https://www.investor.gov' }],
		disclaimer:
			'Estimates only. Investment returns are not guaranteed and you can lose money. This is not investment advice.'
	}
});
