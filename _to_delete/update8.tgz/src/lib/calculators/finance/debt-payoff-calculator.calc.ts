import { defineCalculator, type CalculationResult, type RowValue } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './debt-payoff-calculator.meta';

/** Safety cap on the month-by-month loop (100 years). */
const MAX_MONTHS = 1200;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'debts',
			label: 'Debts',
			type: 'rows',
			columns: [
				{ id: 'name', label: 'Debt', type: 'text', default: '', placeholder: 'Debt name' },
				{ id: 'balance', label: 'Balance', type: 'number', default: 0, min: 0, max: 100_000_000, prefix: '$' },
				{ id: 'apr', label: 'APR', type: 'number', default: 0, min: 0, max: 100, suffix: '%' },
				{ id: 'minimum', label: 'Minimum', type: 'number', default: 0, min: 0, max: 100_000_000, prefix: '$' }
			],
			default: [
				{ name: 'Credit card', balance: 3200, apr: 21.5, minimum: 80 },
				{ name: 'Personal loan', balance: 900, apr: 15, minimum: 40 },
				{ name: 'Car loan', balance: 9500, apr: 6.9, minimum: 260 }
			],
			minRows: 1,
			maxRows: 10,
			addLabel: 'Add debt'
		},
		{
			id: 'extra',
			label: 'Extra each month',
			type: 'number',
			default: 150,
			min: 0,
			max: 100_000_000,
			step: 10,
			prefix: '$',
			help: 'Added on top of all the minimum payments'
		},
		{
			id: 'strategy',
			label: 'Payoff strategy',
			type: 'select',
			display: 'segmented',
			default: 'avalanche',
			options: [
				{ label: 'Avalanche', value: 'avalanche' },
				{ label: 'Snowball', value: 'snowball' }
			]
		}
	],
	calculate(v): CalculationResult {
		const rows = (v.debts as RowValue[]) ?? [];
		const extra = Number(v.extra);
		const snowball = String(v.strategy) === 'snowball';
		const strategyName = snowball ? 'Snowball' : 'Avalanche';

		const valid =
			rows.length >= 1 &&
			rows.length <= 10 &&
			rows.every((r) => {
				const balance = Number(r.balance);
				const apr = Number(r.apr);
				const minimum = Number(r.minimum);
				return balance > 0 && Number.isFinite(balance) && apr >= 0 && apr <= 100 && minimum > 0 && Number.isFinite(minimum);
			}) &&
			extra >= 0 &&
			Number.isFinite(extra);
		if (!valid) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Time to debt-free',
				summary: 'Add at least one debt with a balance, APR and minimum payment above zero, and an extra amount of zero or more.'
			};
		}

		const names = rows.map((r, i) => String(r.name).trim() || `Debt ${i + 1}`);
		const start = rows.map((r) => Number(r.balance));
		const monthlyRate = rows.map((r) => Number(r.apr) / 1200);
		const minimums = rows.map((r) => Number(r.minimum));
		const budget = minimums.reduce((s, x) => s + x, 0) + extra;

		// Payment order: avalanche = highest APR first, snowball = smallest balance first.
		// Ties keep the order the debts were entered.
		const priority = rows.map((_, i) => i);
		if (snowball) priority.sort((a, b) => start[a] - start[b] || a - b);
		else priority.sort((a, b) => monthlyRate[b] - monthlyRate[a] || a - b);

		const bal = [...start];
		const interest = rows.map(() => 0);
		const paidMonth = rows.map(() => 0);
		const open = () => bal.some((b) => b > 0.005);

		// Each month: interest is added, every open debt gets its minimum, and the rest of the
		// budget goes down the priority list. Minimums from cleared debts roll into the budget.
		let months = 0;
		while (open() && months < MAX_MONTHS) {
			months++;
			for (let i = 0; i < bal.length; i++) {
				if (bal[i] <= 0.005) continue;
				const it = bal[i] * monthlyRate[i];
				bal[i] += it;
				interest[i] += it;
			}
			let left = budget;
			for (let i = 0; i < bal.length; i++) {
				if (bal[i] <= 0.005) continue;
				const p = Math.min(minimums[i], bal[i]);
				bal[i] -= p;
				left -= p;
			}
			for (const i of priority) {
				if (left <= 1e-9) break;
				if (bal[i] <= 0.005) continue;
				const p = Math.min(left, bal[i]);
				bal[i] -= p;
				left -= p;
			}
			for (let i = 0; i < bal.length; i++) {
				if (bal[i] <= 0.005 && paidMonth[i] === 0) {
					bal[i] = 0;
					paidMonth[i] = months;
				}
			}
		}

		if (open()) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Time to debt-free',
				summary: 'At these payments the debts would take more than 100 years to clear. Raise the minimums or the extra amount.'
			};
		}

		const totalInterest = interest.reduce((s, x) => s + x, 0);
		const totalBalance = start.reduce((s, x) => s + x, 0);
		const payoffOrder = [...priority].sort((a, b) => paidMonth[a] - paidMonth[b]);

		return {
			primaryResult: plural(months, 'month'),
			primaryLabel: 'Time to debt-free',
			summary: `${strategyName} order with ${money(budget)} a month in total clears ${plural(rows.length, 'debt')} in ${plural(months, 'month')}.`,
			secondaryMetrics: [
				{ label: 'Total interest', value: money(totalInterest) },
				{ label: 'Total paid', value: money(totalBalance + totalInterest) },
				{ label: 'Monthly budget', value: money(budget) },
				{ label: 'Strategy', value: strategyName }
			],
			table: {
				title: 'Payoff order',
				columns: [
					{ key: 'order', label: 'Order', align: 'start' },
					{ key: 'debt', label: 'Debt' },
					{ key: 'paid', label: 'Paid off', align: 'end' },
					{ key: 'interest', label: 'Interest', align: 'end' }
				],
				rows: payoffOrder.map((i, k) => ({
					order: num(k + 1, 0),
					debt: names[i],
					paid: `Month ${num(paidMonth[i], 0)}`,
					interest: money(interest[i])
				}))
			}
		};
	},
	content: {
		intro:
			'See when you will be debt-free if you pay several debts at once. Add each debt with its balance, APR and minimum payment, plus any extra you can put in each month, and compare the avalanche and snowball orders.',
		howTo: [
			'List each debt with its balance, APR and minimum monthly payment.',
			'Enter the extra amount you can add to your payments each month.',
			'Choose Avalanche to clear the highest APR first, or Snowball to clear the smallest balance first.',
			'Read the debt-free time and total interest, then check the payoff order table.'
		],
		formulas: [
			{
				title: 'Monthly interest on each debt',
				expression: 'Interest = balance × APR ÷ 12 ÷ 100',
				variables: [{ symbol: 'APR', meaning: 'annual rate on that debt' }]
			},
			{
				title: 'Monthly budget and roll-over',
				expression: 'Budget = Σ minimums + extra. Each month, pay every open debt its minimum, then send what is left to the debt first in the order.',
				variables: [{ symbol: 'Σ', meaning: 'sum over all debts' }]
			},
			{
				title: 'Totals',
				expression: 'Total paid = Σ balances + Σ interest',
				variables: []
			}
		],
		example: {
			title: 'Three debts with $150 extra a month, avalanche',
			steps: [
				'Monthly budget: minimums of $80 + $40 + $260 = $380, plus $150 extra = $530',
				'Credit card (21.5%) is first in line, so it takes all the spare money until it is cleared in month 17',
				'Once the card is cleared, its $80 minimum and the extra go to the personal loan, which clears in month 18',
				'The car loan, paid at $260 plus the freed money, clears in month 29',
				'Total interest: $1,640.18. Total paid: $13,600 + $1,640.18 = $15,240.18'
			],
			result: 'Debt-free in 29 months with $1,640.18 of total interest.'
		},
		faq: [
			{
				q: 'Which is better, avalanche or snowball?',
				a: 'Avalanche usually costs less interest, because it clears the most expensive debt first. Snowball clears small debts sooner, which some people find motivating. Compare both to see the difference for your debts.'
			},
			{
				q: 'What does “rolling over” the minimums mean?',
				a: 'When a debt is cleared, the minimum you were paying on it is added to the money going to the next debt. The budget stays the same, so the payoff speeds up over time.'
			},
			{
				q: 'What if my minimums do not cover the interest?',
				a: 'If the total budget cannot clear the debts within 100 years, the calculator shows a dash. Raise the minimums or the extra amount.'
			},
			{
				q: 'Does this allow for new charges?',
				a: 'No. It assumes the APRs stay the same and that you add no new debt. New spending will lengthen the payoff time.'
			}
		],
		sources: [{ title: 'Consumer Financial Protection Bureau', url: 'https://www.consumerfinance.gov/' }],
		disclaimer:
			'Estimates only. Assumes fixed APRs, on-time payments and no new charges. Your lenders’ statements are the final word.'
	}
});
