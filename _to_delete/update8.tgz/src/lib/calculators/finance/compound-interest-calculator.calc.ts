import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct, plural } from '../format';
import meta from './compound-interest-calculator.meta';

/** Compounding periods per year. */
const PERIODS: Record<string, number> = { annually: 1, quarterly: 4, monthly: 12, daily: 365 };

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'principal', label: 'Initial deposit', type: 'number', default: 10000, min: 0, max: 100_000_000, step: 100, prefix: '$' },
		{
			id: 'monthly',
			label: 'Monthly contribution',
			type: 'number',
			default: 200,
			min: 0,
			max: 1_000_000,
			step: 10,
			prefix: '$',
			suffix: '/mo',
			help: 'Added at the end of each month.'
		},
		{ id: 'rate', label: 'Annual interest rate', type: 'number', default: 6, min: 0, max: 100, step: 0.01, suffix: '%' },
		{ id: 'years', label: 'Years', type: 'number', default: 10, min: 1, max: 100, step: 1, suffix: 'years', decimal: false },
		{
			id: 'compounding',
			label: 'Compounding',
			type: 'select',
			display: 'menu',
			default: 'monthly',
			options: [
				{ label: 'Annually', value: 'annually' },
				{ label: 'Quarterly', value: 'quarterly' },
				{ label: 'Monthly', value: 'monthly' },
				{ label: 'Daily', value: 'daily' }
			]
		}
	],
	calculate(v): CalculationResult {
		const principal = Number(v.principal);
		const monthly = Number(v.monthly);
		const rate = Number(v.rate);
		const years = Number(v.years);
		const n = PERIODS[String(v.compounding)];
		if (
			!(principal >= 0) ||
			!(monthly >= 0) ||
			!(rate >= 0 && rate <= 100) ||
			!(Number.isInteger(years) && years >= 1 && years <= 100) ||
			n === undefined
		) {
			return { primaryResult: DASH, primaryLabel: 'Future value', summary: 'Check the deposit, rate and years.' };
		}

		// Interest is compounded n times a year. Contributions arrive monthly, so convert the
		// schedule to an effective monthly rate: (1 + r ÷ n)^(n ÷ 12) − 1.
		const monthRate = Math.pow(1 + rate / 100 / n, n / 12) - 1;

		let balance = principal;
		let contributed = principal;
		const chartData: Record<string, number>[] = [{ year: 0, balance, contributed }];
		const rows: Record<string, string>[] = [];
		for (let y = 1; y <= years; y++) {
			for (let m = 0; m < 12; m++) balance = balance * (1 + monthRate) + monthly;
			contributed += monthly * 12;
			const interest = balance - contributed;
			chartData.push({ year: y, balance, contributed });
			rows.push({
				year: String(y),
				contributed: money(contributed, true),
				interest: money(interest, true),
				balance: money(balance, true)
			});
		}

		const interest = balance - contributed;
		const effectiveAnnual = Math.pow(1 + rate / 100 / n, n) - 1;

		return {
			primaryResult: money(balance),
			primaryLabel: 'Future value',
			summary: `After ${plural(years, 'year')} you put in ${money(contributed, true)} and earn ${money(interest, true)} in interest.`,
			secondaryMetrics: [
				{ label: 'Total contributions', value: money(contributed) },
				{ label: 'Total interest earned', value: money(interest) },
				{ label: 'Effective annual rate', value: pct(effectiveAnnual * 100, 3) }
			],
			chart: {
				type: 'line',
				title: 'Balance compared with total contributed',
				x: 'year',
				xLabel: 'Year',
				series: [
					{ key: 'balance', label: 'Balance' },
					{ key: 'contributed', label: 'Total contributed' }
				],
				data: chartData,
				valueFormat: 'currency'
			},
			table: {
				title: 'Yearly breakdown',
				collapsed: true,
				columns: [
					{ key: 'year', label: 'Year' },
					{ key: 'contributed', label: 'Contributed', align: 'end' },
					{ key: 'interest', label: 'Interest', align: 'end' },
					{ key: 'balance', label: 'Balance', align: 'end' }
				],
				rows
			}
		};
	},
	content: {
		intro:
			'See how a starting deposit and regular monthly contributions grow when interest compounds. Compare the final balance with the total you put in.',
		howTo: [
			'Enter your starting deposit and the amount you add each month.',
			'Enter the annual interest rate and how many years you plan to invest.',
			'Choose how often the interest is added to your balance.',
			'Read the future value, then open the yearly breakdown to see the growth year by year.'
		],
		formulas: [
			{
				title: 'Effective monthly rate',
				expression: 'i = (1 + r ÷ n)^(n ÷ 12) − 1',
				variables: [
					{ symbol: 'i', meaning: 'interest rate per month, adjusted for the compounding schedule' },
					{ symbol: 'r', meaning: 'annual interest rate as a decimal (6% is 0.06)' },
					{ symbol: 'n', meaning: 'compounding periods per year (1, 4, 12 or 365)' }
				]
			},
			{
				title: 'Future value',
				expression: 'FV = P × (1 + i)ᴺ + C × ((1 + i)ᴺ − 1) ÷ i',
				variables: [
					{ symbol: 'FV', meaning: 'balance at the end of the period' },
					{ symbol: 'P', meaning: 'initial deposit' },
					{ symbol: 'C', meaning: 'monthly contribution, added at the end of each month' },
					{ symbol: 'N', meaning: 'number of months (years × 12)' }
				]
			}
		],
		example: {
			title: '$10,000 to start, $200 a month, 6% for 10 years, compounded monthly',
			steps: [
				'Monthly rate: i = (1 + 0.06 ÷ 12)¹ − 1 = 0.005',
				'Months: N = 10 × 12 = 120',
				'Growth of the deposit: $10,000 × 1.005¹²⁰ ≈ $18,193.97',
				'Growth of contributions: $200 × (1.005¹²⁰ − 1) ÷ 0.005 ≈ $32,775.87',
				'Future value: $18,193.97 + $32,775.87 ≈ $50,969.84',
				'Total contributed: $10,000 + $200 × 120 = $34,000, so interest is $16,969.84'
			],
			result: 'Future value ≈ $50,969.84. You put in $34,000 and earn about $16,969.84 in interest.'
		},
		faq: [
			{
				q: 'How does compounding frequency change the result?',
				a: 'More frequent compounding adds interest to your balance sooner, so the balance grows a little faster. The difference between monthly and daily is small at normal rates, while the gap grows with higher rates and longer periods.'
			},
			{
				q: 'When are contributions added?',
				a: 'Each monthly contribution is added at the end of the month, so it starts earning interest from the next month.'
			},
			{
				q: 'What is the difference between simple and compound interest?',
				a: 'Simple interest is paid only on the original amount. Compound interest is also paid on interest you have already earned, so balances grow faster over long periods.'
			},
			{
				q: 'Does this include taxes or fees?',
				a: 'No. Taxes on interest or gains, account fees and inflation are not included. Real returns can be lower than the rate you enter.'
			}
		],
		sources: [{ title: 'U.S. Securities and Exchange Commission — Investor.gov', url: 'https://www.investor.gov' }],
		disclaimer:
			'Estimates only. Actual returns vary and this tool does not account for taxes, fees or inflation.'
	}
});
