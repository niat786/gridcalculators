import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct, plural } from '../format';
import meta from './rrsp-calculator.meta';
import { CRA_LIMITS_SOURCE, RRSP_DOLLAR_LIMIT_2026, RRSP_EARNED_INCOME_RATE } from '../data/ca-tax-2026';

/** Future value with annual compounding; contributions at the end (or start) of each year. */
export function rrspFutureValue(start: number, yearly: number, ratePct: number, years: number, atStart: boolean): number {
	const r = ratePct / 100;
	const growth = Math.pow(1 + r, years);
	const annuity = r === 0 ? yearly * years : (yearly * (growth - 1)) / r;
	return start * growth + annuity * (atStart ? 1 + r : 1);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'savings', label: 'Current RRSP savings', type: 'number', default: 10000, min: 0, max: 100_000_000, step: 1000, prefix: '$' },
		{ id: 'contribution', label: 'Yearly contribution', type: 'number', default: 6000, min: 0, max: 10_000_000, step: 500, prefix: '$', suffix: '/yr' },
		{ id: 'rate', label: 'Annual return', type: 'number', default: 6, min: 0, max: 30, step: 0.1, suffix: '%', help: 'Average yearly growth, after fund fees.' },
		{ id: 'years', label: 'Years to grow', type: 'number', default: 20, min: 1, max: 60, step: 1, suffix: 'years', decimal: false },
		{ id: 'marginal', label: 'Marginal tax rate', type: 'number', default: 30.5, min: 0, max: 60, step: 0.1, suffix: '%', help: 'Tax on your next dollar. The Canada Income Tax Calculator shows yours.' },
		{
			id: 'timing',
			label: 'Contributions made',
			type: 'select',
			display: 'segmented',
			default: 'end',
			options: [
				{ label: 'End of year', value: 'end' },
				{ label: 'Start of year', value: 'start' }
			]
		},
		{ id: 'earned', label: 'Last year’s earned income', type: 'number', default: 85000, min: 0, max: 100_000_000, step: 1000, prefix: '$', help: 'Your 2025 earned income (employment, self-employment, rental) for the 2026 limit.' },
		{ id: 'pa', label: 'Pension adjustment', type: 'number', default: 0, min: 0, max: 1_000_000, step: 100, prefix: '$', help: 'From your 2025 T4, if you are in a workplace pension.' },
		{ id: 'carry', label: 'Unused room carried forward', type: 'number', default: 0, min: 0, max: 10_000_000, step: 500, prefix: '$', help: 'From your latest CRA notice of assessment.' }
	],
	calculate(v): CalculationResult {
		const savings = Number(v.savings);
		const yearly = Number(v.contribution);
		const rate = Number(v.rate);
		const years = Number(v.years);
		const marginal = Number(v.marginal);
		const earned = Number(v.earned);
		const pa = Number(v.pa);
		const carry = Number(v.carry);
		const atStart = v.timing === 'start';
		const ok = [savings, yearly, rate, marginal, earned, pa, carry].every((n) => Number.isFinite(n) && n >= 0) && Number.isFinite(years) && years >= 1 && years <= 60 && rate <= 30 && marginal <= 60;
		if (!ok) {
			return { primaryResult: DASH, primaryLabel: 'RRSP value', summary: 'Enter amounts of zero or more, a return up to 30% and between 1 and 60 years.' };
		}
		const fv = rrspFutureValue(savings, yearly, rate, years, atStart);
		const contributed = savings + yearly * years;
		const growth = fv - contributed;
		const refundYear = (yearly * marginal) / 100;
		const newRoom = Math.min(earned * RRSP_EARNED_INCOME_RATE, RRSP_DOLLAR_LIMIT_2026);
		const totalRoom = Math.max(0, newRoom - pa + carry);
		const over = yearly > totalRoom;
		return {
			primaryResult: money(fv),
			primaryLabel: `RRSP value after ${plural(years, 'year')}`,
			summary: `${money(contributed)} put in grows by ${money(growth)} at ${pct(rate, 2)}. Each year’s contribution brings a tax refund of about ${money(refundYear)}.${
				over ? ' Your yearly contribution is more than your 2026 room, so check your CRA notice of assessment before contributing.' : ''
			}`,
			secondaryMetrics: [
				{ label: 'Total contributed (incl. savings)', value: money(contributed) },
				{ label: 'Investment growth', value: money(growth) },
				{ label: 'Tax refund per year', value: money(refundYear) },
				{ label: `Total refunds over ${plural(years, 'year')}`, value: money(refundYear * years) },
				{ label: 'New 2026 room (18% of earned income)', value: money(newRoom) },
				{ label: 'Total 2026 deduction limit', value: money(totalRoom) },
				{ label: 'Room left after this year’s contribution', value: money(Math.max(0, totalRoom - yearly)) }
			]
		};
	},
	content: {
		intro:
			'Project the value of your Registered Retirement Savings Plan (RRSP) and the tax refund your contributions create. It also works out your 2026 RRSP deduction limit: 18% of last year’s earned income, up to $33,810, plus unused room.',
		howTo: [
			'Enter your current RRSP savings, yearly contribution, expected return and years.',
			'Enter your marginal tax rate to see the refund each contribution brings.',
			'Enter last year’s earned income, any pension adjustment and carried-forward room to see your 2026 limit.'
		],
		formulas: [
			{
				title: 'Future value',
				expression: 'FV = S × (1 + r)ⁿ + C × ((1 + r)ⁿ − 1) ÷ r',
				variables: [
					{ symbol: 'S', meaning: 'current savings' },
					{ symbol: 'C', meaning: 'yearly contribution (made at the end of each year; × (1 + r) if at the start)' },
					{ symbol: 'r', meaning: 'annual return as a decimal' },
					{ symbol: 'n', meaning: 'number of years' }
				]
			},
			{
				title: '2026 deduction limit',
				expression: 'Limit = min(18% × 2025 earned income, $33,810) − pension adjustment + unused room',
				variables: [{ symbol: 'Refund', meaning: 'Contribution × marginal tax rate' }]
			}
		],
		example: {
			title: '$10,000 saved, $6,000 a year at 6% for 20 years',
			steps: [
				'Growth of savings: $10,000 × 1.06²⁰ = $32,071.35.',
				'Growth of contributions: $6,000 × (1.06²⁰ − 1) ÷ 0.06 = $220,713.55.',
				'Value = $32,071.35 + $220,713.55 = $252,784.90.',
				'Refund each year at 30.5%: $6,000 × 0.305 = $1,830.00.'
			],
			result: 'RRSP value $252,784.90 after 20 years; total refunds $36,600.00. With $85,000 of earned income the new 2026 room is $15,300.00.'
		},
		faq: [
			{
				q: 'What is the RRSP limit for 2026?',
				a: 'The RRSP dollar limit for 2026 is $33,810. Your own limit is 18% of your 2025 earned income up to that amount, less any pension adjustment, plus unused room from earlier years.'
			},
			{
				q: 'Do I get the whole tax refund back?',
				a: 'The refund is your contribution times your marginal tax rate, so it depends on your income. Withdrawals later are taxed as income, so an RRSP mainly shifts tax to a year when your rate may be lower.'
			},
			{
				q: 'Where do I find my unused room?',
				a: 'Your CRA notice of assessment and your My Account on the CRA site show your RRSP deduction limit and unused contributions.'
			}
		],
		sources: [CRA_LIMITS_SOURCE],
		disclaimer: 'Projections assume a steady return and are not guaranteed. Check your RRSP room with the CRA before contributing. This is not financial advice.'
	}
});
