import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct } from '../format';
import meta from './transfer-duty-calculator.meta';
import { SARS_TRANSFER_DUTY_SOURCE, ZA_TRANSFER_DUTY, zaBracketFor, zaTransferDuty } from '../data/za-2026-27';

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'price', label: 'Property purchase price', type: 'number', default: 2500000, min: 0, max: 10_000_000_000, step: 50000, prefix: '$', help: 'The price or market value, whichever is higher.' }
	],
	calculate(v): CalculationResult {
		const price = Number(v.price);
		if (!Number.isFinite(price) || price < 0) {
			return { primaryResult: DASH, primaryLabel: 'Transfer duty', summary: 'Enter a property price of zero or more.' };
		}
		const duty = zaTransferDuty(price);
		const b = zaBracketFor(ZA_TRANSFER_DUTY, price);
		const rate = Math.round(b.rate * 100);
		const summary =
			duty === 0
				? `No transfer duty is payable: the first ${money(ZA_TRANSFER_DUTY[0].upTo, true)} of a property’s value is exempt.`
				: `The part of the price in the ${rate}% bracket is taxed at ${rate}%, on top of ${money(b.base, true)} for the lower brackets.`;
		return {
			primaryResult: money(duty),
			primaryLabel: 'Transfer duty payable',
			summary,
			secondaryMetrics: [
				{ label: 'Purchase price', value: money(price) },
				{ label: 'Effective rate', value: pct(price > 0 ? (duty / price) * 100 : 0, 2) },
				{ label: 'Bracket rate on top rand', value: pct(b.rate * 100, 0) },
				{ label: 'Price plus transfer duty', value: money(price + duty) }
			],
			table: {
				title: 'Transfer duty table',
				collapsed: true,
				columns: [
					{ key: 'range', label: 'Property value' },
					{ key: 'rate', label: 'Rate', align: 'end' },
					{ key: 'base', label: 'Duty at start of bracket', align: 'end' }
				],
				rows: ZA_TRANSFER_DUTY.map((t) => ({
					range: t.upTo === Infinity ? `${money(t.from + 1, true)} and above` : `${money(t.from + 1, true)} to ${money(t.upTo, true)}`,
					rate: pct(t.rate * 100, 0),
					base: money(t.base, true)
				}))
			}
		};
	},
	content: {
		intro:
			'Find the transfer duty you pay SARS when you buy property in South Africa. The first R1,210,000 is exempt and higher values pay 3% to 13% on each slice.',
		howTo: [
			'Enter the purchase price of the property.',
			'Read the transfer duty and the effective rate.',
			'Open the table to see every bracket.'
		],
		formulas: [
			{
				title: 'Transfer duty',
				expression: 'Duty = fixed amount for the bracket + rate × (value − bracket start)',
				variables: [
					{ symbol: 'R0 to R1,210,000', meaning: '0%' },
					{ symbol: 'R1,210,001 to R1,663,800', meaning: '3% of the value above R1,210,000' },
					{ symbol: 'R1,663,801 to R2,329,300', meaning: 'R13,614 + 6% above R1,663,800' },
					{ symbol: 'R2,329,301 to R2,994,800', meaning: 'R53,544 + 8% above R2,329,300' },
					{ symbol: 'R2,994,801 to R13,310,000', meaning: 'R106,784 + 11% above R2,994,800' },
					{ symbol: 'Above R13,310,000', meaning: 'R1,241,456 + 13% above R13,310,000' }
				]
			}
		],
		example: {
			title: 'A R2,500,000 home',
			steps: [
				'R2,500,000 falls in the R2,329,301 to R2,994,800 bracket.',
				'Duty = R53,544 + 8% × (R2,500,000 − R2,329,300) = R53,544 + R13,656.',
				'Duty = R67,200.'
			],
			result: 'Transfer duty of R67,200, an effective rate of 2.69%.'
		},
		faq: [
			{
				q: 'Do I pay transfer duty on a new home?',
				a: 'Not if the seller is a VAT vendor and charges VAT on the sale. VAT is then paid instead of transfer duty, so this calculator does not apply.'
			},
			{
				q: 'Did the table change for 2026?',
				a: 'No. SARS shows the table effective from 1 April 2026 as unchanged from the one in force since 1 April 2025, with the first R1,210,000 exempt.'
			},
			{
				q: 'Is this all my buying cost?',
				a: 'No. Conveyancing fees, bond registration costs and deeds office fees are separate and not included here.'
			}
		],
		sources: [SARS_TRANSFER_DUTY_SOURCE],
		disclaimer: 'An estimate based on the SARS table, not legal or tax advice. Check with your conveyancer.'
	}
});
