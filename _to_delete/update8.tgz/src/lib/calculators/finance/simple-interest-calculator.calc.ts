import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, pct } from '../format';
import meta from './simple-interest-calculator.meta';

/** Days are counted on a 365-day year. Months are one-twelfth of a year. */
const UNITS_PER_YEAR: Record<string, number> = { days: 365, months: 12, years: 1 };
const UNIT_WORD: Record<string, string> = { days: 'day', months: 'month', years: 'year' };

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'principal', label: 'Principal', type: 'number', default: 2000, min: 0, max: 1_000_000_000, step: 100, prefix: '$' },
		{ id: 'rate', label: 'Interest rate per year', type: 'number', default: 5, min: 0, max: 100, step: 0.01, suffix: '%' },
		{ id: 'time', label: 'Time', type: 'number', default: 3, min: 0, max: 100_000, step: 1 },
		{
			id: 'unit',
			label: 'Time unit',
			type: 'select',
			display: 'segmented',
			default: 'years',
			options: [
				{ label: 'Days', value: 'days' },
				{ label: 'Months', value: 'months' },
				{ label: 'Years', value: 'years' }
			]
		}
	],
	calculate(v): CalculationResult {
		const principal = Number(v.principal);
		const rate = Number(v.rate);
		const time = Number(v.time);
		const unit = String(v.unit);
		const perYear = UNITS_PER_YEAR[unit];
		if (!(principal >= 0) || !(rate >= 0 && rate <= 100) || !(time >= 0) || perYear === undefined) {
			return { primaryResult: DASH, primaryLabel: 'Simple interest earned', summary: 'Check the principal, rate and time.' };
		}

		const years = time / perYear;
		const interest = principal * (rate / 100) * years;
		const total = principal + interest;
		const word = UNIT_WORD[unit];
		const unitText = `${num(time, 2)} ${time === 1 ? word : `${word}s`}`;

		return {
			primaryResult: money(interest),
			primaryLabel: 'Simple interest earned',
			summary: `${money(principal)} at ${num(rate, 2)}% for ${unitText} earns ${money(interest)}.`,
			secondaryMetrics: [
				{ label: 'Total amount', value: money(total) },
				{ label: 'Time in years', value: num(years, 4) },
				{ label: 'Interest per year', value: money(principal * (rate / 100)) }
			]
		};
	},
	content: {
		intro:
			'Calculate simple interest on a principal for a number of days, months or years. Simple interest is paid only on the original amount.',
		howTo: [
			'Enter the principal, the yearly interest rate and the length of time.',
			'Pick days, months or years for the time unit.',
			'Read the interest earned and the total amount at the end of the period.'
		],
		formulas: [
			{
				title: 'Simple interest',
				expression: 'I = P × r × t',
				variables: [
					{ symbol: 'I', meaning: 'simple interest earned' },
					{ symbol: 'P', meaning: 'principal' },
					{ symbol: 'r', meaning: 'interest rate per year as a decimal (5% is 0.05)' },
					{ symbol: 't', meaning: 'time in years' }
				]
			},
			{
				title: 'Time in years',
				expression: 't = days ÷ 365   or   t = months ÷ 12   or   t = years',
				variables: [
					{ symbol: '365', meaning: 'days in the year used for day counts' }
				]
			}
		],
		example: {
			title: '$1,500 at 6% for 90 days',
			steps: [
				'Time in years: t = 90 ÷ 365 ≈ 0.2466',
				'Interest: I = 1,500 × 0.06 × 0.2466 ≈ $22.19',
				'Total amount: $1,500 + $22.19 = $1,522.19'
			],
			result: 'Interest earned ≈ $22.19, for a total of $1,522.19.'
		},
		faq: [
			{
				q: 'Why does this calculator use 365 days for a year?',
				a: 'Day counts are converted to years by dividing by 365, which is the usual convention for simple interest. Leap years are not counted separately.'
			},
			{
				q: 'What is the difference between simple and compound interest?',
				a: 'Simple interest is calculated only on the original principal. Compound interest is also calculated on interest that has already been added.'
			},
			{
				q: 'How do I convert a monthly rate to a yearly rate?',
				a: 'Enter the yearly rate in the rate field and choose months as the time unit. The calculator divides the time by 12 for you.'
			},
			{
				q: 'Can this be used for loans?',
				a: 'Yes, for simple-interest loans where interest is charged only on the principal. Many loans use other methods, so check your loan agreement.'
			}
		],
		sources: [{ title: 'U.S. Securities and Exchange Commission — Investor.gov', url: 'https://www.investor.gov' }],
		disclaimer:
			'Estimates only. Your lender or bank may use a different day count or rounding method.'
	}
});
