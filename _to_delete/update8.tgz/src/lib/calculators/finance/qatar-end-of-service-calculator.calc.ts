import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num } from '../format';
import meta from './qatar-end-of-service-calculator.meta';
import { parseISO, serviceYears, yearsLabel } from '../data/service-years';
import {
	QA_MIN_SERVICE_YEARS,
	QA_MIN_WEEKS_PER_YEAR,
	QA_MONTHS_PER_YEAR,
	QA_MONTH_DAYS,
	QA_SOURCES,
	QA_WEEKS_PER_YEAR
} from '../data/qa-end-of-service';

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'basic',
			label: 'Last monthly basic wage',
			type: 'number',
			default: 10000,
			min: 0,
			max: 10_000_000,
			prefix: '$',
			help: 'Basic wage only, including any annual increment. Housing, transport and other allowances are not included.'
		},
		{ id: 'start', label: 'First day of work', type: 'date', default: '2018-01-01' },
		{ id: 'end', label: 'Last day of work', type: 'date', default: 'today' },
		{
			id: 'weeks',
			label: 'Weeks of wage per year',
			type: 'number',
			default: 3,
			min: 0,
			max: 52,
			step: 0.5,
			suffix: 'weeks',
			help: 'The law sets a floor of 3 weeks. Enter more only if your contract promises more.'
		},
		{
			id: 'method',
			label: 'Weekly wage method',
			type: 'select',
			display: 'segmented',
			default: '30',
			options: [
				{ label: 'Monthly ÷ 30 × 7', value: '30' },
				{ label: 'Yearly ÷ 52', value: '52' }
			],
			help: 'The law does not fix how to turn a monthly wage into a weekly one. ÷ 30 is the usual practice.'
		}
	],
	calculate(v): CalculationResult {
		const label = 'End-of-service gratuity';
		const basic = Number(v.basic);
		const weeks = Number(v.weeks);
		const start = parseISO(String(v.start));
		const end = parseISO(String(v.end));
		if (!(basic > 0) || !Number.isFinite(basic) || !start || !end) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter a basic wage above zero and two valid dates.' };
		}
		if (!Number.isFinite(weeks) || weeks < QA_MIN_WEEKS_PER_YEAR) {
			return { primaryResult: DASH, primaryLabel: label, summary: `Article 54 sets a floor of ${QA_MIN_WEEKS_PER_YEAR} weeks of wage per year. Enter ${QA_MIN_WEEKS_PER_YEAR} or more.` };
		}
		const sy = serviceYears(start, end);
		if (!sy) return { primaryResult: DASH, primaryLabel: label, summary: 'The last day of work is before the first day.' };

		const years = sy.years;
		const weekly = String(v.method) === '52' ? (basic * QA_MONTHS_PER_YEAR) / QA_WEEKS_PER_YEAR : (basic / QA_MONTH_DAYS) * 7;
		const perYear = weekly * weeks;
		const metrics = (total: number) => [
			{ label: 'Service counted', value: yearsLabel(years) },
			{ label: 'Weekly basic wage', value: money(weekly) },
			{ label: 'Weeks of wage per year', value: num(weeks, 2) },
			{ label: 'Gratuity for each full year', value: money(perYear) },
			{ label: 'Gratuity as months of basic wage', value: num(basic > 0 ? total / basic : 0, 2) }
		];

		if (years < QA_MIN_SERVICE_YEARS) {
			return {
				primaryResult: money(0),
				primaryLabel: label,
				summary: 'No gratuity is due under 1 year of continuous service (Article 54).',
				secondaryMetrics: metrics(0)
			};
		}
		const total = perYear * years;
		return {
			primaryResult: money(total),
			primaryLabel: label,
			summary: `${num(weeks, 2)} weeks of basic wage (${money(weekly)} a week) for each of ${yearsLabel(years)}, with the part year counted pro rata. This is the legal minimum; your contract may pay more.`,
			secondaryMetrics: metrics(total)
		};
	},
	content: {
		intro:
			'Work out the minimum end-of-service gratuity for a private-sector employee in Qatar under Article 54 of Labour Law No. 14 of 2004: at least three weeks of basic wage for every year of service, once you have completed one year.',
		howTo: [
			'Enter your last monthly basic wage, without housing, transport or other allowances.',
			'Enter your first and last day of work. Part years are counted pro rata.',
			'Leave the weeks at 3, or raise it if your contract gives more, then read the gratuity.'
		],
		formulas: [
			{
				title: 'Gratuity under Article 54',
				expression: 'Gratuity = Y × N × W, with no gratuity if Y < 1',
				variables: [
					{ symbol: 'Y', meaning: 'Years of continuous service, with the part year counted pro rata. At least 1 full year is needed.' },
					{ symbol: 'N', meaning: 'Weeks of wage per year: 3 is the legal minimum; a contract may give more.' },
					{ symbol: 'W', meaning: 'Weekly basic wage: monthly basic ÷ 30 × 7 (or monthly basic × 12 ÷ 52 if you pick that method).' }
				]
			}
		],
		example: {
			title: 'QAR 10,000 basic wage, 1 January 2018 to 31 December 2024',
			steps: [
				'Service: exactly 7 years.',
				'Weekly basic wage: 10,000 ÷ 30 × 7 = QAR 2,333.33.',
				'Gratuity for each year: 3 weeks × 2,333.33 = QAR 7,000.00.',
				'Gratuity: 7 years × 7,000 = QAR 49,000.00.'
			],
			result: 'QAR 49,000.00'
		},
		faq: [
			{
				q: 'Do I get gratuity if I resign?',
				a: 'Yes. Article 54 gives gratuity to anyone who has completed a year of continuous service. It is lost only if you are dismissed for one of the serious misconduct reasons listed in Article 61.'
			},
			{
				q: 'Which wage counts?',
				a: 'Your last basic wage, including annual increments. Housing, transport and other allowances and bonuses are left out. A contract or company policy can promise more than the legal floor.'
			},
			{
				q: 'Why can the result differ from my company’s figure?',
				a: 'The law fixes three weeks per year but not how to turn a monthly wage into a weekly one. Dividing by 30 and multiplying by 21 is the common practice; dividing the yearly wage by 52 gives a slightly lower week. Your contract and the Ministry of Labour decide in a dispute.'
			}
		],
		sources: QA_SOURCES,
		disclaimer:
			'Estimate of the statutory minimum only, for private-sector employees under Labour Law No. 14 of 2004. It does not model Article 61 dismissals, employer pension schemes (Article 56) or deductions for sums you owe your employer. This is not legal advice; confirm with the Ministry of Labour or your employer.'
	}
});
