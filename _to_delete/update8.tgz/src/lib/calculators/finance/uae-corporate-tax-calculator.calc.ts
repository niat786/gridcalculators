import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, pct } from '../format';
import meta from './uae-corporate-tax-calculator.meta';
import {
	AE_CT_RATE,
	AE_CT_SOURCES,
	AE_CT_ZERO_BAND,
	AE_DMTT_FROM,
	AE_DMTT_RATE_PCT,
	AE_DMTT_THRESHOLD_EUR_M,
	AE_QFZP_DE_MINIMIS_AED,
	AE_QFZP_DE_MINIMIS_PCT,
	AE_SBR_LAST_PERIOD_END,
	AE_SBR_LAST_PERIOD_END_LABEL,
	AE_SBR_REVENUE_LIMIT
} from '../data/ae-corporate-tax';

const valid = (n: number) => Number.isFinite(n) && n >= 0;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'status',
			label: 'Type of business',
			type: 'select',
			display: 'segmented',
			default: 'standard',
			options: [
				{ label: 'Standard', value: 'standard' },
				{ label: 'Qualifying free zone person', value: 'qfzp' }
			],
			help: 'A qualifying free zone person pays 0% only on qualifying income; the rest is taxed at 9%.'
		},
		{
			id: 'income',
			label: 'Taxable income',
			type: 'number',
			default: 1_000_000,
			min: 0,
			max: 100_000_000_000,
			prefix: '$',
			help: 'Accounting profit adjusted under the corporate tax rules, after allowed losses.',
			visibleWhen: (v) => String(v.status) !== 'qfzp'
		},
		{
			id: 'qualifying',
			label: 'Qualifying income',
			type: 'number',
			default: 5_000_000,
			min: 0,
			max: 100_000_000_000,
			prefix: '$',
			help: 'Taxable income that counts as qualifying income, taxed at 0%.',
			visibleWhen: (v) => String(v.status) === 'qfzp'
		},
		{
			id: 'nonqualifying',
			label: 'Non-qualifying income',
			type: 'number',
			default: 200_000,
			min: 0,
			max: 100_000_000_000,
			prefix: '$',
			help: 'All other taxable income, taxed at 9% from the first dirham.',
			visibleWhen: (v) => String(v.status) === 'qfzp'
		},
		{
			id: 'revenue',
			label: 'Revenue for the period',
			type: 'number',
			default: 2_500_000,
			min: 0,
			max: 100_000_000_000,
			prefix: '$',
			help: 'Total revenue, used only to test Small Business Relief.',
			visibleWhen: (v) => String(v.status) !== 'qfzp'
		},
		{
			id: 'periodEnd',
			label: 'Tax period ends on',
			type: 'date',
			default: '2026-12-31',
			visibleWhen: (v) => String(v.status) !== 'qfzp'
		},
		{
			id: 'earlierOk',
			label: 'Revenue was AED 3 million or less in every earlier tax period',
			type: 'toggle',
			default: true,
			visibleWhen: (v) => String(v.status) !== 'qfzp'
		},
		{
			id: 'elect',
			label: 'Elect Small Business Relief',
			type: 'toggle',
			default: false,
			visibleWhen: (v) => String(v.status) !== 'qfzp'
		},
		{
			id: 'mne',
			label: 'Part of a multinational group with revenue of EUR 750 million (AED 3.15 billion) or more',
			type: 'toggle',
			default: false
		}
	],
	calculate(v): CalculationResult {
		const label = 'UAE corporate tax';
		const qfzp = String(v.status) === 'qfzp';
		const mne = Boolean(v.mne);

		const dmtt = mne
			? `Not calculated: ${AE_DMTT_RATE_PCT}% minimum rate may add a top-up`
			: `Not applicable below EUR ${AE_DMTT_THRESHOLD_EUR_M}m group revenue`;

		if (qfzp) {
			const q = Number(v.qualifying);
			const n = Number(v.nonqualifying);
			if (!valid(q) || !valid(n)) {
				return { primaryResult: DASH, primaryLabel: label, summary: 'Enter qualifying and non-qualifying income of zero or more.' };
			}
			const total = q + n;
			const tax = n * AE_CT_RATE;
			return {
				primaryResult: money(tax),
				primaryLabel: label,
				summary: `0% on ${money(q)} of qualifying income and ${pct(AE_CT_RATE * 100, 0)} on ${money(n)} of non-qualifying income, with no 0% band. This assumes the free zone company meets every qualifying condition, including keeping non-qualifying revenue below the lower of AED ${num(AE_QFZP_DE_MINIMIS_AED, 0)} or ${AE_QFZP_DE_MINIMIS_PCT}% of revenue; if it does not, it loses the status and standard rates apply to all income.`,
				secondaryMetrics: [
					{ label: 'Taxable income', value: money(total) },
					{ label: 'Income taxed at 9%', value: money(n) },
					{ label: 'Effective tax rate', value: total > 0 ? pct((tax / total) * 100, 2) : pct(0) },
					{ label: 'Small Business Relief', value: 'Not available to qualifying free zone persons' },
					{ label: 'Top-up tax (DMTT)', value: dmtt }
				]
			};
		}

		const income = Number(v.income);
		const revenue = Number(v.revenue);
		const periodEnd = String(v.periodEnd);
		if (!valid(income) || !valid(revenue) || !/^\d{4}-\d{2}-\d{2}$/.test(periodEnd)) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter taxable income and revenue of zero or more, and a valid tax period end date.' };
		}

		const reasons: string[] = [];
		if (!(revenue <= AE_SBR_REVENUE_LIMIT)) reasons.push(`revenue is above AED ${num(AE_SBR_REVENUE_LIMIT, 0)}`);
		if (!v.earlierOk) reasons.push('an earlier period was above the limit');
		if (mne) reasons.push('members of large multinational groups are excluded');
		if (periodEnd > AE_SBR_LAST_PERIOD_END) reasons.push(`the relief covers periods ending on or before ${AE_SBR_LAST_PERIOD_END_LABEL}`);
		const eligible = reasons.length === 0;
		const elected = Boolean(v.elect);

		const taxableAt9 = Math.max(income - AE_CT_ZERO_BAND, 0);
		const normalTax = taxableAt9 * AE_CT_RATE;
		const relief = elected && eligible;
		const tax = relief ? 0 : normalTax;

		let reliefText: string;
		if (relief) reliefText = 'Elected: treated as having no taxable income';
		else if (elected) reliefText = `Elected but not eligible: ${reasons.join('; ')}`;
		else if (eligible) reliefText = `Eligible: electing would cut the tax to ${money(0)}`;
		else reliefText = `Not eligible: ${reasons.join('; ')}`;

		return {
			primaryResult: money(tax),
			primaryLabel: label,
			summary: relief
				? 'Small Business Relief is elected, so the business is treated as having no taxable income for this period. Other reliefs and deductions are not available with it.'
				: `0% on the first ${money(AE_CT_ZERO_BAND)} and ${pct(AE_CT_RATE * 100, 0)} on the ${money(taxableAt9)} above it.`,
			secondaryMetrics: [
				{ label: 'Taxable income', value: money(income) },
				{ label: 'Income taxed at 9%', value: money(relief ? 0 : taxableAt9) },
				{ label: 'Effective tax rate', value: income > 0 ? pct((tax / income) * 100, 2) : pct(0) },
				{ label: 'Small Business Relief', value: reliefText },
				{ label: 'Top-up tax (DMTT)', value: dmtt }
			]
		};
	},
	content: {
		intro:
			'Work out UAE federal corporate tax under Federal Decree-Law 47 of 2022: 0% on the first AED 375,000 of taxable income and 9% above it, with Small Business Relief, qualifying free zone persons and the 15% top-up tax for large multinational groups explained.',
		howTo: [
			'Choose Standard, or Qualifying free zone person if your free zone company meets the qualifying conditions.',
			'Enter your taxable income. For Small Business Relief also enter revenue, the period end date and the eligibility toggles.',
			'Read the tax, the effective rate and whether Small Business Relief or the top-up tax matters for you.'
		],
		formulas: [
			{
				title: 'Standard corporate tax',
				expression: 'Tax = 9% × max(Taxable income − 375,000, 0)',
				variables: [
					{ symbol: 'Taxable income', meaning: 'Adjusted profit for the tax period, after allowed losses and exemptions.' },
					{ symbol: '375,000', meaning: 'The 0% band in AED. Income above it is taxed at 9%.' }
				]
			},
			{
				title: 'Qualifying free zone person',
				expression: 'Tax = 9% × Non-qualifying income  (qualifying income at 0%)',
				variables: [{ symbol: 'Non-qualifying income', meaning: 'Taxed at 9% with no 0% band, as long as the company stays within the de minimis limits.' }]
			}
		],
		example: {
			title: 'Taxable income of AED 1,000,000, no relief',
			steps: [
				'The first AED 375,000 is taxed at 0%.',
				'Income above the band: 1,000,000 − 375,000 = AED 625,000.',
				'Tax: 9% × 625,000 = AED 56,250.',
				'Effective rate: 56,250 ÷ 1,000,000 = 5.63%.'
			],
			result: 'AED 56,250.00'
		},
		faq: [
			{
				q: 'Who can use Small Business Relief and until when?',
				a: 'A UAE resident business with revenue of AED 3 million or less in the current and every earlier period can elect it, and is then treated as having no taxable income. It was due to end with periods ending on 31 December 2026; Ministerial Decision 131 of 2026 extended it to periods ending on or before 31 December 2029. Qualifying free zone persons and members of large multinational groups cannot use it.'
			},
			{
				q: 'How is a qualifying free zone person taxed?',
				a: 'It pays 0% on qualifying income and 9% on everything else, without the AED 375,000 band. It must meet conditions such as the de minimis test (non-qualifying revenue under the lower of AED 5 million or 5% of revenue). Fail them and standard rates apply. This tool only splits the two kinds of income you enter.'
			},
			{
				q: 'What is the 15% top-up tax?',
				a: `The Domestic Minimum Top-up Tax applies to UAE entities of multinational groups with consolidated revenue of EUR ${AE_DMTT_THRESHOLD_EUR_M} million or more, for financial years starting on or after ${AE_DMTT_FROM}. It tops the group’s effective tax rate up to ${AE_DMTT_RATE_PCT}%. It needs a separate group-level calculation, so this tool only flags it and does not compute it.`
			}
		],
		sources: AE_CT_SOURCES,
		disclaimer:
			'Estimate only. It does not model losses, exempt income, tax groups, transfer pricing, withholding or the top-up tax calculation. This is not tax advice; confirm with the Federal Tax Authority or a tax adviser.'
	}
});
