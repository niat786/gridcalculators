import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, pct } from '../format';
import meta from './zakat-calculator.meta';
import { NISAB_GOLD_GRAMS, NISAB_SILVER_GRAMS, ZAKAT_RATE, ZAKAT_SOURCES } from '../data/zakat';

const cents = (n: number) => Math.round(n * 100 + 1e-9) / 100;
const asset = (id: string, label: string, def: number, help?: string) =>
	({ id, label, type: 'number', default: def, min: 0, max: 1_000_000_000_000, prefix: '$', help }) as const;

export default defineCalculator({
	meta,
	inputs: [
		asset('cash', 'Cash and bank balances', 20000),
		{ id: 'goldG', label: 'Gold you own', type: 'number', default: 0, min: 0, max: 1_000_000, suffix: 'grams', help: 'Gold held as savings. Scholars differ on jewellery worn regularly, so ask yours.' },
		{ id: 'goldP', label: 'Gold price per gram', type: 'number', default: 770, min: 0, max: 100_000_000, prefix: '$', help: 'Type today’s price in your currency. This tool has no live prices.' },
		{ id: 'silverG', label: 'Silver you own', type: 'number', default: 0, min: 0, max: 10_000_000, suffix: 'grams' },
		{ id: 'silverP', label: 'Silver price per gram', type: 'number', default: 15, min: 0, max: 100_000_000, prefix: '$', help: 'Type today’s price in your currency. This tool has no live prices.' },
		asset('invest', 'Investments and shares', 0, 'Market value of what you hold for investment.'),
		asset('stock', 'Business inventory', 0, 'Goods held for sale, at their market value.'),
		asset('owed', 'Money owed to you', 0, 'Only debts you expect to be repaid.'),
		asset('debts', 'Short-term debts you owe', 0, 'Debts due now or soon, such as this year’s instalments.'),
		{
			id: 'nisab',
			label: 'Nisab based on',
			type: 'select',
			display: 'segmented',
			default: 'silver',
			options: [
				{ label: 'Silver (595 g)', value: 'silver' },
				{ label: 'Gold (85 g)', value: 'gold' }
			],
			help: 'Scholars differ. Silver gives a lower threshold; others use gold.'
		},
		{ id: 'hawl', label: 'Held above nisab for one lunar year', type: 'toggle', default: true }
	],
	calculate(v): CalculationResult {
		const label = 'Zakat due';
		const num_ = (k: string) => Number(v[k]);
		const keys = ['cash', 'goldG', 'goldP', 'silverG', 'silverP', 'invest', 'stock', 'owed', 'debts'];
		if (keys.some((k) => !Number.isFinite(num_(k)) || num_(k) < 0)) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter zero or more in every box (use 0 for none).' };
		}
		const silverBased = String(v.nisab) !== 'gold';
		const price = silverBased ? num_('silverP') : num_('goldP');
		if (!(price > 0)) {
			return { primaryResult: DASH, primaryLabel: label, summary: `Enter today’s ${silverBased ? 'silver' : 'gold'} price per gram to find the nisab.` };
		}
		if ((num_('goldG') > 0 && !(num_('goldP') > 0)) || (num_('silverG') > 0 && !(num_('silverP') > 0))) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter a price per gram for the gold or silver you own.' };
		}

		const goldValue = num_('goldG') * num_('goldP');
		const silverValue = num_('silverG') * num_('silverP');
		const assets = num_('cash') + goldValue + silverValue + num_('invest') + num_('stock') + num_('owed');
		const net = assets - num_('debts');
		const nisabGrams = silverBased ? NISAB_SILVER_GRAMS : NISAB_GOLD_GRAMS;
		const nisabValue = nisabGrams * price;
		const metrics = [
			{ label: 'Total zakatable assets', value: money(assets) },
			{ label: 'Debts deducted', value: money(num_('debts')) },
			{ label: 'Net zakatable wealth', value: money(net) },
			{ label: `Nisab (${nisabGrams} g of ${silverBased ? 'silver' : 'gold'})`, value: money(nisabValue) },
			{ label: 'Zakat rate', value: pct(ZAKAT_RATE * 100) }
		];

		if (!(net >= nisabValue)) {
			return {
				primaryResult: money(0),
				primaryLabel: label,
				summary: `Your net wealth of ${money(net)} is below the nisab of ${money(nisabValue)}, so no zakat is due.`,
				secondaryMetrics: metrics
			};
		}
		if (!v.hawl) {
			return {
				primaryResult: money(0),
				primaryLabel: label,
				summary: `You are above the nisab, but zakat falls due only after your wealth has stayed at or above it for one lunar year. It would then be ${money(cents(net * ZAKAT_RATE))}.`,
				secondaryMetrics: metrics
			};
		}
		const zakat = cents(net * ZAKAT_RATE);
		return {
			primaryResult: money(zakat),
			primaryLabel: label,
			summary: `${pct(ZAKAT_RATE * 100)} of ${money(net)} net wealth, which is above the nisab of ${money(nisabValue)} (${num(nisabGrams, 0)} g of ${silverBased ? 'silver' : 'gold'}).`,
			secondaryMetrics: metrics
		};
	},
	content: {
		intro:
			'Add up your cash, gold, silver, investments, business stock and money owed to you, subtract the debts you must pay soon, and see whether you reach the nisab. If so, zakat is 2.5% of your net wealth.',
		howTo: [
			'Enter your wealth. For gold and silver, type the grams you own and today’s price per gram.',
			'Enter the short-term debts you owe, then choose whether the nisab is based on silver or gold.',
			'Keep “held for one lunar year” on if your wealth has stayed above the nisab for that long, and read the zakat due.'
		],
		formulas: [
			{
				expression: 'Net wealth = cash + gold + silver + investments + inventory + money owed − debts due.   Zakat = 2.5% × net wealth, if net wealth ≥ nisab',
				variables: [
					{ symbol: 'nisab', meaning: 'The value of 595 g of silver, or of 85 g of gold, at the price per gram you enter.' },
					{ symbol: 'lunar year', meaning: 'Zakat is due once your wealth has stayed at or above the nisab for one lunar year (about 354 days).' }
				]
			}
		],
		example: {
			title: 'Cash 20,000 in your currency, silver nisab at 15 per gram',
			steps: [
				'Nisab: 595 g × 15 = 8,925.',
				'Net wealth: 20,000, with no gold, shares or debts. It is above the nisab.',
				'Zakat: 2.5% × 20,000 = 500.'
			],
			result: '500.00'
		},
		faq: [
			{
				q: 'Should I use the gold or the silver nisab?',
				a: 'Scholars differ. The Hanafi school and many charities such as Islamic Relief use silver (595 g), a lower threshold that brings in more people who owe zakat; other schools use gold (85 g). Choose the view your own scholar follows.'
			},
			{
				q: 'Which debts can I subtract?',
				a: 'Debts that are due now or soon, such as bills and this year’s instalments. A long loan is usually not deducted in full, only the part that falls due. Ask a scholar if your situation is unusual.'
			},
			{
				q: 'Does this use live gold and silver prices?',
				a: 'No. Prices change daily and differ by country, so you type today’s price per gram yourself. The figures it starts with are only examples.'
			}
		],
		sources: ZAKAT_SOURCES,
		disclaimer:
			'A guide only, not a fatwa. Views differ on jewellery, pensions, property and debts, so please consult a trusted scholar about your own circumstances.'
	}
});
