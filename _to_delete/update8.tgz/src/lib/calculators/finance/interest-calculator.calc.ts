import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, money, num, pct } from '../format';
import meta from './interest-calculator.meta';

/** Compounding periods per year. */
const PERIODS: Record<string, number> = { annually: 1, quarterly: 4, monthly: 12, daily: 365 };

const compound = (v: InputValues) => v.method === 'compound';

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'principal', label: 'Principal', type: 'number', default: 5000, min: 0, max: 1_000_000_000, step: 100, prefix: '$' },
		{ id: 'rate', label: 'Annual interest rate', type: 'number', default: 5, min: 0, max: 100, step: 0.01, suffix: '%' },
		{ id: 'years', label: 'Term', type: 'number', default: 5, min: 0.01, max: 100, step: 0.5, suffix: 'years' },
		{
			id: 'method',
			label: 'Interest type',
			type: 'select',
			display: 'segmented',
			default: 'compound',
			options: [
				{ label: 'Simple', value: 'simple' },
				{ label: 'Compound', value: 'compound' }
			]
		},
		{
			id: 'compounding',
			label: 'Compounding',
			type: 'select',
			display: 'menu',
			default: 'monthly',
			visibleWhen: compound,
			options: [
				{ label: 'Annually', value: 'annually' },
				{ label: 'Quarterly', value: 'quarterly' },
				{ label: 'Monthly', value: 'monthly' },
				{ label: 'Daily', value: 'daily' }
			]
		}
	],
	calculate(v): CalculationResult {
		const principal = Number(v.principal);
		const rate = Number(v.rate);
		const years = Number(v.years);
		const method = String(v.method);
		const isCompound = method === 'compound';
		const n = PERIODS[String(v.compounding)];
		if (
			!(principal > 0) ||
			!(rate >= 0 && rate <= 100) ||
			!(years > 0 && years <= 100) ||
			(method !== 'simple' && method !== 'compound') ||
			(isCompound && n === undefined)
		) {
			return { primaryResult: DASH, primaryLabel: 'Ending balance', summary: 'Check the principal, rate and term.' };
		}

		let ending: number;
		if (isCompound) {
			ending = principal * Math.pow(1 + rate / 100 / n, n * years);
		} else {
			ending = principal + principal * (rate / 100) * years;
		}
		const interest = ending - principal;
		const methodLabel = isCompound ? `compounded ${String(v.compounding)}` : 'with simple interest';

		return {
			primaryResult: money(ending),
			primaryLabel: 'Ending balance',
			summary: `${money(principal)} at ${num(rate, 2)}% for ${num(years, 2)} years ${methodLabel}.`,
			secondaryMetrics: [
				{ label: 'Interest earned', value: money(interest) },
				{ label: 'Growth on principal', value: pct((interest / principal) * 100, 2) },
				{
					label: 'Compounding periods',
					value: isCompound ? `${num(n * years, 1)} periods` : 'Not compounded'
				}
			]
		};
	},
	content: {
		intro:
			'Work out the ending balance and interest earned on a deposit or loan, using either simple or compound interest over any term.',
		howTo: [
			'Enter the principal and the annual interest rate.',
			'Enter the term in years. Decimals work, so 6 months is 0.5.',
			'Choose simple or compound interest. For compound, pick how often interest is added.',
			'Read the ending balance and the interest earned.'
		],
		formulas: [
			{
				title: 'Simple interest',
				expression: 'I = P × r × t        A = P + I',
				variables: [
					{ symbol: 'P', meaning: 'principal' },
					{ symbol: 'r', meaning: 'annual interest rate as a decimal (5% is 0.05)' },
					{ symbol: 't', meaning: 'term in years' },
					{ symbol: 'A', meaning: 'ending balance' },
					{ symbol: 'I', meaning: 'interest earned' }
				]
			},
			{
				title: 'Compound interest',
				expression: 'A = P × (1 + r ÷ n)^(n × t)        I = A − P',
				variables: [
					{ symbol: 'n', meaning: 'compounding periods per year (1, 4, 12 or 365)' }
				]
			}
		],
		example: {
			title: '$5,000 at 5% for 5 years, compounded monthly',
			steps: [
				'Rate per month: 0.05 ÷ 12 ≈ 0.0041667',
				'Periods: 12 × 5 = 60',
				'Ending balance: 5,000 × (1.0041667)⁶⁰ ≈ $6,416.79',
				'Interest earned: $6,416.79 − $5,000 = $1,416.79',
				'For comparison, simple interest gives $5,000 × 0.05 × 5 = $1,250.00'
			],
			result: 'Ending balance ≈ $6,416.79, with $1,416.79 of interest earned. Simple interest would earn $1,250.00.'
		},
		faq: [
			{
				q: 'What is the difference between simple and compound interest?',
				a: 'Simple interest is calculated only on the principal. Compound interest is calculated on the principal plus any interest already added, so it grows faster over time.'
			},
			{
				q: 'Which compounding schedule should I choose?',
				a: 'Use the schedule in your account or loan terms. More frequent compounding, such as daily, earns slightly more than annual compounding at the same rate.'
			},
			{
				q: 'Can I enter a term shorter than one year?',
				a: 'Yes. Enter the fraction of a year, for example 0.5 for six months. The result is pro-rated for that part of the year.'
			},
			{
				q: 'Does this include fees or taxes?',
				a: 'No. Account fees, loan fees and taxes on interest are not included.'
			}
		],
		sources: [{ title: 'U.S. Securities and Exchange Commission — Investor.gov', url: 'https://www.investor.gov' }],
		disclaimer:
			'Estimates only. Your actual balance depends on your account or loan terms, fees and any taxes.'
	}
});
