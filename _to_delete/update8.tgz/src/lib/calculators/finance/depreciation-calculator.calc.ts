import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, plural } from '../format';
import meta from './depreciation-calculator.meta';

const methodOptions = [
	{ label: 'Straight-line', value: 'sl' },
	{ label: 'Double-declining balance', value: 'ddb' },
	{ label: "Sum-of-the-years' digits", value: 'syd' }
];

const METHOD_NAME: Record<string, string> = {
	sl: 'Straight-line depreciation',
	ddb: 'Double-declining balance',
	syd: "Sum-of-the-years' digits"
};

/**
 * Year-by-year depreciation of an asset down to its salvage value.
 * Double-declining balance uses twice the straight-line rate on the book value, switches to
 * straight-line when that gives a larger charge, and never goes below salvage value.
 */
export default defineCalculator({
	meta,
	inputs: [
		{ id: 'cost', label: 'Asset cost', type: 'number', default: 20000, min: 0, max: 1_000_000_000, step: 500, prefix: '$', help: 'What the asset cost to put into service.' },
		{ id: 'salvage', label: 'Salvage value', type: 'number', default: 2000, min: 0, max: 1_000_000_000, step: 100, prefix: '$', help: 'Estimated value at the end of its useful life.' },
		{ id: 'life', label: 'Useful life', type: 'number', default: 5, min: 1, max: 100, step: 1, decimal: false, suffix: 'years' },
		{ id: 'method', label: 'Method', type: 'select', display: 'menu', default: 'sl', options: methodOptions }
	],
	calculate(v): CalculationResult {
		const cost = Number(v.cost);
		const salvage = Number(v.salvage);
		const life = Number(v.life);
		const method = String(v.method);

		if (
			!(cost > 0) ||
			!(salvage >= 0) ||
			salvage > cost ||
			!(Number.isInteger(life) && life >= 1 && life <= 100) ||
			!['sl', 'ddb', 'syd'].includes(method)
		) {
			return { primaryResult: DASH, primaryLabel: 'First-year depreciation', summary: 'Check the cost, salvage value (not above cost) and useful life.' };
		}

		const depreciable = cost - salvage;
		const digits = (life * (life + 1)) / 2;
		let book = cost;
		let accumulated = 0;
		const charges: number[] = [];
		const rows: Record<string, string>[] = [];

		for (let t = 1; t <= life; t++) {
			const remainingLife = life - t + 1;
			let charge: number;
			if (method === 'sl') {
				charge = depreciable / life;
			} else if (method === 'ddb') {
				const declining = (book * 2) / life;
				const straight = (book - salvage) / remainingLife;
				charge = Math.min(Math.max(declining, straight), book - salvage);
			} else {
				charge = (depreciable * remainingLife) / digits;
			}
			charge = Math.max(0, Math.min(charge, book - salvage));

			charges.push(charge);
			accumulated += charge;
			book -= charge;
			rows.push({
				year: String(t),
				depreciation: money(charge),
				accumulated: money(accumulated),
				bookValue: money(book)
			});
		}

		return {
			primaryResult: money(charges[0]),
			primaryLabel: 'First-year depreciation',
			summary: `${METHOD_NAME[method]} spreads ${money(depreciable)} of cost over ${plural(life, 'year')}.`,
			secondaryMetrics: [
				{ label: 'Total depreciation', value: money(accumulated) },
				{ label: 'Largest yearly charge', value: money(Math.max(...charges)) },
				{ label: 'Book value at end', value: money(book) }
			],
			table: {
				title: 'Year-by-year schedule',
				collapsed: true,
				columns: [
					{ key: 'year', label: 'Year' },
					{ key: 'depreciation', label: 'Depreciation', align: 'end' },
					{ key: 'accumulated', label: 'Accumulated', align: 'end' },
					{ key: 'bookValue', label: 'Book value', align: 'end' }
				],
				rows
			}
		};
	},
	content: {
		intro:
			'Spread the cost of an asset over the years it is useful. Compare straight-line, double-declining balance and sum-of-the-years’ digits methods, and see the book value of the asset at the end of each year.',
		howTo: [
			'Enter the cost of the asset and its estimated salvage value at the end of its life.',
			'Enter the useful life in whole years.',
			'Choose a method. Straight-line is the simplest, and the other two charge more in the early years.',
			'Read the first-year charge, then open the schedule to see each year’s depreciation, accumulated total and book value.'
		],
		formulas: [
			{
				title: 'Straight-line',
				expression: 'Depreciation per year = (cost − salvage) ÷ life',
				variables: [{ symbol: 'life', meaning: 'useful life in years' }]
			},
			{
				title: 'Double-declining balance',
				expression: 'Depreciation = min( max(book × 2 ÷ life, (book − salvage) ÷ remaining years), book − salvage )',
				variables: [
					{ symbol: 'book', meaning: 'book value at the start of the year' },
					{ symbol: 'remaining years', meaning: 'years of life left, including this year' }
				]
			},
			{
				title: "Sum-of-the-years' digits",
				expression: 'Depreciation = (cost − salvage) × remaining years ÷ (life × (life + 1) ÷ 2)',
				variables: [{ symbol: 'remaining years', meaning: 'years of life left, including this year' }]
			}
		],
		example: {
			title: '$10,000 asset, $0 salvage, 5 years, double-declining balance',
			steps: [
				'Rate: 2 ÷ 5 = 40% of book value each year',
				'Year 1: 40% × $10,000 = $4,000, book value $6,000',
				'Year 2: 40% × $6,000 = $2,400, book value $3,600',
				'Year 3: 40% × $3,600 = $1,440, book value $2,160',
				'Year 4: 40% of $2,160 is $864, but straight-line on $2,160 over 2 years is $1,080, which is larger, so switch: $1,080',
				'Year 5: $2,160 − $1,080 = $1,080 left, spread over 1 year: $1,080'
			],
			result: 'Depreciation is $4,000, $2,400, $1,440, $1,080 and $1,080, totalling $10,000, with a book value of $0 at the end.'
		},
		faq: [
			{
				q: 'Which method should I use?',
				a: 'Straight-line gives the same charge every year and is the simplest. Declining methods charge more early on, which can match assets that lose value quickly. Tax rules may require a specific method, so check which one applies to you.'
			},
			{
				q: 'What is book value?',
				a: 'Book value is the cost minus the total depreciation taken so far. It is what the asset is worth on your accounts, which can differ from its market value.'
			},
			{
				q: 'Why does the declining method stop at salvage value?',
				a: 'An asset is never depreciated below its estimated salvage value. Once the book value reaches salvage value, no more depreciation is recorded.'
			},
			{
				q: 'Can depreciation be claimed on a tax return?',
				a: 'Some assets can be depreciated for tax purposes, often under special rules that differ from these methods. This calculator shows accounting depreciation only.'
			}
		],
		sources: [{ title: 'IRS Publication 946 — How to Depreciate Property', url: 'https://www.irs.gov/publications/p946' }],
		disclaimer:
			'Estimates for planning only. Tax depreciation rules differ from these accounting methods, so speak with an accountant before filing.'
	}
});
