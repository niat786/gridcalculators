import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct } from '../format';
import meta from './south-africa-income-tax-calculator.meta';
import {
	SARS_EMPLOYER_GUIDE_SOURCE,
	SARS_RATES_SOURCE,
	ZA_BRACKETS,
	ZA_TAX_YEAR_LABEL,
	ZA_TAX_YEAR_SHORT,
	zaIncomeTax,
	zaThreshold,
	type ZaAge
} from '../data/za-2026-27';

export const AGE_OPTIONS = [
	{ label: 'Under 65', value: 'under65' },
	{ label: '65 to 74', value: '65to74' },
	{ label: '75 or older', value: '75plus' }
];

export function isAge(v: unknown): v is ZaAge {
	return v === 'under65' || v === '65to74' || v === '75plus';
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'income', label: 'Annual taxable income', type: 'number', default: 500000, min: 0, max: 1_000_000_000, step: 10000, prefix: '$', suffix: '/yr', help: 'Income after deductions such as retirement fund contributions.' },
		{ id: 'age', label: 'Your age on 28 February 2027', type: 'select', display: 'segmented', default: 'under65', options: AGE_OPTIONS },
		{ id: 'members', label: 'Medical scheme members', type: 'number', default: 0, min: 0, max: 20, decimal: false, help: 'You plus every dependant on your scheme. Use 0 if you have no medical scheme.' }
	],
	calculate(v): CalculationResult {
		const income = Number(v.income);
		const members = Number(v.members);
		const age = v.age;
		if (!Number.isFinite(income) || income < 0 || !isAge(age) || !Number.isFinite(members) || members < 0 || members > 20) {
			return { primaryResult: DASH, primaryLabel: 'Income tax payable', summary: 'Enter taxable income of zero or more, pick your age group, and use 0 to 20 medical scheme members.' };
		}
		const r = zaIncomeTax(income, age, Math.floor(members));
		const rate = Math.round(r.bracketRate * 100);
		const summary =
			r.tax === 0
				? `Your rebates${r.medicalCredit > 0 ? ' and medical credit' : ''} cover all the tax on ${money(income)}, so no income tax is payable. The tax threshold for your age is ${money(zaThreshold(age))}.`
				: `Your income falls in the ${rate}% bracket. After rebates${r.medicalCredit > 0 ? ' and the medical credit' : ''} you pay ${money(r.tax)} for the ${ZA_TAX_YEAR_SHORT} tax year, which is ${pct(r.averageRate * 100, 2)} of your taxable income.`;
		return {
			primaryResult: money(r.tax),
			primaryLabel: 'Income tax payable for the year',
			summary,
			secondaryMetrics: [
				{ label: 'Average tax rate', value: pct(r.averageRate * 100, 2) },
				{ label: 'Marginal tax rate', value: pct(r.marginalRate * 100, 0) },
				{ label: 'Tax before rebates', value: money(r.taxBeforeRebates) },
				{ label: 'Rebates', value: money(r.rebates) },
				{ label: 'Medical scheme fees tax credit', value: money(r.medicalCredit) },
				{ label: 'Tax per month', value: money(r.tax / 12) },
				{ label: 'Tax threshold (before medical credit)', value: money(zaThreshold(age)) }
			],
			table: {
				title: `${ZA_TAX_YEAR_SHORT} tax brackets`,
				collapsed: true,
				columns: [
					{ key: 'range', label: 'Taxable income' },
					{ key: 'rate', label: 'Rate', align: 'end' },
					{ key: 'base', label: 'Tax at start of bracket', align: 'end' }
				],
				rows: ZA_BRACKETS.map((b) => ({
					range: b.upTo === Infinity ? `${money(b.from + 1, true)} and above` : `${money(b.from + 1, true)} to ${money(b.upTo, true)}`,
					rate: pct(b.rate * 100, 0),
					base: money(b.base, true)
				}))
			}
		};
	},
	content: {
		intro: `Work out your South African income tax for the ${ZA_TAX_YEAR_LABEL}. It applies the SARS brackets, the rebate for your age and the medical scheme fees tax credit.`,
		howTo: [
			'Enter your annual taxable income, which is your income after deductions such as retirement fund contributions.',
			'Choose your age group (your age on 28 February 2027) so the right rebates apply.',
			'Add the number of people on your medical scheme (you plus dependants) to include the monthly tax credit, then read your tax and rates.'
		],
		formulas: [
			{
				title: 'Normal tax',
				expression: 'Tax = max(0, bracket tax − rebates − medical credit × 12)',
				variables: [
					{ symbol: 'Bracket tax', meaning: '18% to R245,100; 26% to R383,100; 31% to R530,200; 36% to R695,800; 39% to R887,000; 41% to R1,878,600; 45% above' },
					{ symbol: 'Rebates', meaning: 'Primary R17,820; plus R9,765 at 65 or older; plus R3,249 at 75 or older' },
					{ symbol: 'Medical credit', meaning: 'R376 a month for you, R376 for the first dependant and R254 for each extra dependant' }
				]
			}
		],
		example: {
			title: 'R500,000 taxable income, under 65, no medical scheme',
			steps: [
				'The income falls in the 31% bracket: R79,998 + 31% × (R500,000 − R383,100) = R116,237.',
				'Less the primary rebate of R17,820.',
				'Tax payable = R116,237 − R17,820 = R98,417.'
			],
			result: 'Income tax of R98,417 a year, an average rate of 19.68%.'
		},
		faq: [
			{
				q: 'What is the tax-free threshold in 2026/27?',
				a: 'R99,000 if you are under 65, R153,250 from 65 to 74 and R171,300 from 75. Medical scheme credits raise your effective threshold further.'
			},
			{
				q: 'Which age counts for the rebates?',
				a: 'Your age on the last day of the tax year, 28 February 2027. If you turn 65 or 75 by then, you get the extra rebate for the whole year.'
			},
			{
				q: 'What does this calculator leave out?',
				a: 'It does not include the additional medical expenses credit, capital gains, interest and dividend exemptions or lump-sum tax. Enter income after your own deductions.'
			}
		],
		sources: [SARS_RATES_SOURCE, SARS_EMPLOYER_GUIDE_SOURCE],
		disclaimer: 'An estimate of normal tax for the 2026/27 tax year, not tax advice. Your SARS assessment may differ.'
	}
});
