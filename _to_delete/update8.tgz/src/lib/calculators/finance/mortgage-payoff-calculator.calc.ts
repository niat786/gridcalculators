import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './mortgage-payoff-calculator.meta';

/** Fixed-rate payment: M = P·r(1+r)^n / ((1+r)^n − 1); r = 0 → P / n. */
function payment(principal: number, annualRatePct: number, months: number): number {
	const r = annualRatePct / 1200;
	if (r === 0) return principal / months;
	const f = Math.pow(1 + r, months);
	return (principal * r * f) / (f - 1);
}

/** "20 years 3 months", "11 months", "5 years". */
function monthsText(months: number): string {
	const y = Math.floor(months / 12);
	const m = months % 12;
	return [y ? plural(y, 'year') : '', m ? plural(m, 'month') : ''].filter(Boolean).join(' ') || '0 months';
}

/** Balance after `months` standard payments, from the closed form. */
function balanceAfter(principal: number, annualRatePct: number, monthlyPayment: number, months: number): number {
	const r = annualRatePct / 1200;
	if (r === 0) return principal - monthlyPayment * months;
	const f = Math.pow(1 + r, months);
	return principal * f - (monthlyPayment * (f - 1)) / r;
}

/** Pays month by month at a fixed payment until the balance is gone. */
function payoffWith(balance: number, annualRatePct: number, monthlyPayment: number) {
	const r = annualRatePct / 1200;
	let left = balance;
	let months = 0;
	let interest = 0;
	while (left > 0.005 && months < 1200) {
		const charge = left * r;
		const principal = Math.min(monthlyPayment - charge, left);
		left -= principal;
		interest += charge;
		months++;
	}
	return { months, interest };
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'amount', label: 'Original loan amount', type: 'number', default: 300000, min: 1, max: 100_000_000, step: 1000, prefix: '$' },
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 6.25, min: 0, max: 100, step: 0.01, suffix: '%', help: 'Annual rate' },
		{ id: 'term', label: 'Original term', type: 'number', default: 30, min: 1, max: 50, step: 1, suffix: 'years', decimal: false },
		{ id: 'paid', label: 'Years already paid', type: 'number', default: 5, min: 0, max: 49, step: 1, suffix: 'years', decimal: false },
		{ id: 'extra', label: 'Extra monthly payment', type: 'number', default: 200, min: 0, max: 100_000, step: 25, prefix: '$', help: 'Added to your regular payment each month' }
	],
	calculate(v): CalculationResult {
		const original = Number(v.amount);
		const rate = Number(v.rate);
		const term = Number(v.term);
		const paidYears = Number(v.paid);
		const extra = Number(v.extra) || 0;

		if (
			!(original > 0) ||
			!Number.isFinite(original) ||
			!(rate >= 0 && rate <= 100) ||
			!Number.isInteger(term) ||
			!(term >= 1 && term <= 50) ||
			!Number.isInteger(paidYears) ||
			!(paidYears >= 0 && paidYears < term) ||
			!(extra >= 0)
		) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Remaining balance now',
				summary: 'Years already paid must be less than the original term, and the other amounts must be valid.'
			};
		}

		const n = term * 12;
		const paidMonths = paidYears * 12;
		const remainingMonths = n - paidMonths;
		const monthly = payment(original, rate, n);
		const balance = Math.max(0, balanceAfter(original, rate, monthly, paidMonths));
		const interestLeftNoExtra = Math.max(0, monthly * remainingMonths - balance);

		const withExtra = extra > 0 ? payoffWith(balance, rate, monthly + extra) : { months: remainingMonths, interest: interestLeftNoExtra };
		const monthsSaved = Math.max(0, remainingMonths - withExtra.months);
		const interestSaved = Math.max(0, interestLeftNoExtra - withExtra.interest);

		return {
			primaryResult: money(balance),
			primaryLabel: 'Remaining balance now',
			summary:
				extra > 0
					? `An extra ${money(extra)} a month pays off the loan ${monthsText(monthsSaved)} sooner.`
					: `${plural(paidYears, 'year')} paid, with ${monthsText(remainingMonths)} left on the original schedule.`,
			secondaryMetrics: [
				{ label: 'Monthly payment', value: money(monthly) },
				{ label: 'Original payoff time', value: monthsText(remainingMonths) },
				{ label: 'Payoff time with extra', value: monthsText(withExtra.months) },
				{ label: 'Time saved', value: monthsText(monthsSaved) },
				{ label: 'Interest left, no extra', value: money(interestLeftNoExtra) },
				{ label: 'Interest saved', value: money(interestSaved) }
			]
		};
	},
	content: {
		intro:
			'Find out what you still owe on a fixed-rate mortgage after a number of years, then see how much sooner and cheaper the loan ends if you add an extra amount each month.',
		howTo: [
			'Enter the original loan amount, the interest rate and the original term in years.',
			'Enter how many full years you have already paid.',
			'Enter an extra monthly payment, or leave it at 0 to see the normal schedule.',
			'Read the remaining balance, then compare the payoff time and interest saved.'
		],
		formulas: [
			{
				title: 'Monthly payment',
				expression: 'M = P × r(1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'M', meaning: 'standard monthly payment' },
					{ symbol: 'P', meaning: 'original loan amount' },
					{ symbol: 'r', meaning: 'monthly interest rate (annual rate ÷ 12 ÷ 100)' },
					{ symbol: 'n', meaning: 'original number of payments (term in years × 12)' }
				]
			},
			{
				title: 'Balance after k payments',
				expression: 'B = P(1 + r)ᵏ − M((1 + r)ᵏ − 1) ÷ r',
				variables: [
					{ symbol: 'B', meaning: 'remaining balance now' },
					{ symbol: 'k', meaning: 'payments made so far (years paid × 12)' }
				]
			}
		],
		example: {
			title: 'A $300,000 loan at 6.25% over 30 years, paid for 5 years, with $200 extra each month',
			steps: [
				'Monthly rate: r = 6.25 ÷ 12 ÷ 100 = 0.0052083. Payments: n = 360, k = 5 × 12 = 60',
				'Standard payment: M ≈ $1,847.15',
				'Balance now: B = 300,000 × (1.0052083)⁶⁰ − 1,847.15 × ((1.0052083)⁶⁰ − 1) ÷ 0.0052083 ≈ $280,011.72',
				'Paying $1,847.15 + $200 = $2,047.15 a month clears the balance in 240 payments, which is 60 months sooner than the 300 left',
				'Interest left with no extra = 1,847.1516 × 300 − $280,011.72 = $274,133.76. Interest saved = $274,133.76 − $211,082.41 = $63,051.35'
			],
			result: 'Remaining balance of $280,011.72. The $200 extra saves 5 years and $63,051.35 in interest.'
		},
		faq: [
			{
				q: 'Why use the balance now instead of the original amount?',
				a: 'Each payment has reduced your balance, and most of the early payments were interest. The balance now is what you would need to pay to clear the loan today, before any fees or penalties.'
			},
			{
				q: 'Does an extra payment always help?',
				a: 'It lowers the interest you pay and ends the loan sooner, provided your loan has no prepayment penalty and you are not losing money you need elsewhere. Check your loan terms first.'
			},
			{
				q: 'Are extra payments applied to principal?',
				a: 'Usually yes, but confirm with your servicer that extra money is applied to principal, not held for future payments.'
			},
			{
				q: 'Why is the number of years paid a whole number?',
				a: 'The calculator works in whole years. For a balance partway through a year, use the amortization calculator to see the balance month by month.'
			}
		],
		sources: [
			{
				title: 'Consumer Financial Protection Bureau — Explore interest rates',
				url: 'https://www.consumerfinance.gov/owning-a-home/explore-rates/'
			}
		],
		disclaimer:
			'Estimates only. Your lender’s payoff figure can differ because of fees, escrow and when payments are applied.'
	}
});
