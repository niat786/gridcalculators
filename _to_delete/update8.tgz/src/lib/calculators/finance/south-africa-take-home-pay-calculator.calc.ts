import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct } from '../format';
import meta from './south-africa-take-home-pay-calculator.meta';
import {
	SARS_EMPLOYER_GUIDE_SOURCE,
	SARS_RATES_SOURCE,
	SARS_UIF_SOURCE,
	ZA_RETIREMENT_CAP,
	ZA_RETIREMENT_RATE,
	ZA_TAX_YEAR_LABEL,
	ZA_TAX_YEAR_SHORT,
	ZA_UIF_MONTHLY_CEILING,
	ZA_UIF_RATE,
	zaIncomeTax,
	zaRetirementDeduction
} from '../data/za-2026-27';
import { AGE_OPTIONS, isAge } from './south-africa-income-tax-calculator.calc';

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'salary', label: 'Monthly gross salary', type: 'number', default: 35000, min: 0, max: 100_000_000, step: 1000, prefix: '$', suffix: '/month', help: 'Pay before PAYE, UIF and any other deductions.' },
		{ id: 'age', label: 'Your age on 28 February 2027', type: 'select', display: 'segmented', default: 'under65', options: AGE_OPTIONS },
		{ id: 'retirement', label: 'Retirement fund contribution', type: 'number', default: 0, min: 0, max: 100_000_000, step: 500, prefix: '$', suffix: '/month', help: 'Pension, provident or retirement annuity paid by you each month.' },
		{ id: 'members', label: 'Medical aid members', type: 'number', default: 0, min: 0, max: 20, decimal: false, help: 'You plus every dependant on your scheme. Use 0 if you have none.' },
		{ id: 'premium', label: 'Medical aid premium you pay', type: 'number', default: 0, min: 0, max: 10_000_000, step: 100, prefix: '$', suffix: '/month', help: 'Optional. Taken off your net pay; the tax credit comes from the number of members.' }
	],
	calculate(v): CalculationResult {
		const salary = Number(v.salary);
		const retirement = Number(v.retirement);
		const members = Number(v.members);
		const premium = Number(v.premium);
		const age = v.age;
		if (
			!(salary > 0) ||
			!Number.isFinite(salary) ||
			!isAge(age) ||
			!Number.isFinite(retirement) ||
			retirement < 0 ||
			!Number.isFinite(members) ||
			members < 0 ||
			members > 20 ||
			!Number.isFinite(premium) ||
			premium < 0
		) {
			return { primaryResult: DASH, primaryLabel: 'Net pay per month', summary: 'Enter a monthly salary above zero, pick your age group, and use zero or more for the other amounts.' };
		}
		if (retirement + premium > salary) {
			return { primaryResult: DASH, primaryLabel: 'Net pay per month', summary: 'Your retirement contribution and medical aid premium add up to more than your salary. Check the amounts.' };
		}
		const annual = salary * 12;
		const deduction = zaRetirementDeduction(retirement * 12, annual);
		const taxable = annual - deduction;
		const r = zaIncomeTax(taxable, age, Math.floor(members));
		const paye = r.tax / 12;
		const uif = ZA_UIF_RATE * Math.min(salary, ZA_UIF_MONTHLY_CEILING);
		const net = salary - paye - uif - retirement - premium;
		const capped = retirement * 12 > deduction + 0.005;
		const summary = `PAYE is worked out on your salary for the full year (${money(taxable)} taxable).${
			capped ? ` Only ${money(deduction / 12)} a month of your retirement contribution is deductible (27.5% of pay, up to R430,000 a year).` : ''
		} Net pay is ${pct((net / salary) * 100, 1)} of gross.`;
		return {
			primaryResult: money(net),
			primaryLabel: 'Net pay per month',
			summary,
			secondaryMetrics: [
				{ label: 'Gross salary per month', value: money(salary) },
				{ label: 'PAYE per month', value: money(paye) },
				{ label: 'UIF per month', value: money(uif) },
				{ label: 'Retirement contribution', value: money(retirement) },
				{ label: 'Medical aid premium', value: money(premium) },
				{ label: 'Medical tax credit per month', value: money(r.medicalCredit / 12) },
				{ label: 'Average tax rate', value: pct(r.averageRate * 100, 2) }
			],
			table: {
				title: 'Monthly payslip',
				collapsed: true,
				columns: [
					{ key: 'item', label: 'Item' },
					{ key: 'month', label: 'Per month', align: 'end' },
					{ key: 'year', label: 'Per year', align: 'end' }
				],
				rows: [
					{ item: 'Gross salary', month: money(salary), year: money(annual) },
					{ item: 'PAYE', month: money(-paye), year: money(-r.tax) },
					{ item: 'UIF', month: money(-uif), year: money(-uif * 12) },
					{ item: 'Retirement contribution', month: money(-retirement), year: money(-retirement * 12) },
					{ item: 'Medical aid premium', month: money(-premium), year: money(-premium * 12) },
					{ item: 'Net pay', month: money(net), year: money(net * 12) }
				]
			}
		};
	},
	content: {
		intro: `Estimate your monthly take-home pay in South Africa for the ${ZA_TAX_YEAR_LABEL}. It takes off PAYE, UIF and your own retirement and medical aid payments.`,
		howTo: [
			'Enter your monthly gross salary and your age group.',
			'Add what you pay into a pension, provident or retirement annuity fund each month, and the number of medical aid members.',
			'Optionally add your medical aid premium, then read your net pay and the payslip table.'
		],
		formulas: [
			{
				title: 'Net pay',
				expression: 'Net = salary − PAYE − UIF − retirement − medical premium',
				variables: [
					{ symbol: 'PAYE', meaning: '(tax on salary × 12 − retirement deduction, less rebates and medical credit) ÷ 12' },
					{ symbol: 'Retirement deduction', meaning: `Lesser of your contributions, ${ZA_RETIREMENT_RATE * 100}% of annual pay and R${ZA_RETIREMENT_CAP.toLocaleString('en-US')}` },
					{ symbol: 'UIF', meaning: `1% of salary up to R${ZA_UIF_MONTHLY_CEILING.toLocaleString('en-US')} a month (maximum R177.12)` }
				]
			}
		],
		example: {
			title: 'R35,000 a month, under 65, no retirement fund or medical aid',
			steps: [
				'Annual salary R420,000 falls in the 31% bracket: R79,998 + 31% × (R420,000 − R383,100) = R91,437.',
				'Less the R17,820 primary rebate: tax R73,617 a year, or R6,134.75 a month.',
				'UIF is 1% of R17,712 = R177.12 a month.',
				'Net = R35,000 − R6,134.75 − R177.12 = R28,688.13.'
			],
			result: 'Take-home pay of about R28,688.13 a month.'
		},
		faq: [
			{
				q: 'Why is my payslip different from this result?',
				a: 'Employers use SARS PAYE tables and may include fringe benefits, allowances, bonuses or other deductions. This tool annualises your salary, so small differences are normal.'
			},
			{
				q: 'Is UIF capped?',
				a: 'Yes. UIF is 1% of pay up to R17,712 a month, so the most you pay is R177.12. Your employer pays another 1%.'
			},
			{
				q: 'What is not included?',
				a: 'The Skills Development Levy (paid by your employer), fringe benefits, travel allowances, bonuses taxed on their own, the additional medical expenses credit and retirement contributions above the yearly cap are not included.'
			}
		],
		sources: [SARS_RATES_SOURCE, SARS_EMPLOYER_GUIDE_SOURCE, SARS_UIF_SOURCE],
		disclaimer: `An estimate for the ${ZA_TAX_YEAR_SHORT} tax year, not payroll or tax advice.`
	}
});
