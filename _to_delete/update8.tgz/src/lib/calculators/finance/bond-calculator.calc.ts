import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './bond-calculator.meta';

const frequencyOptions = [
	{ label: 'Annually (1)', value: '1' },
	{ label: 'Semiannually (2)', value: '2' },
	{ label: 'Quarterly (4)', value: '4' },
	{ label: 'Monthly (12)', value: '12' }
];

/**
 * Price of a fixed-coupon bond: the present value of every coupon plus the present value of
 * the face value, both discounted at the yield per period. Current yield is the annual coupon
 * divided by the price.
 */
export default defineCalculator({
	meta,
	inputs: [
		{ id: 'face', label: 'Face value', type: 'number', default: 1000, min: 1, max: 1_000_000_000, step: 100, prefix: '$', help: 'Amount repaid at maturity.' },
		{ id: 'coupon', label: 'Annual coupon rate', type: 'number', default: 5, min: 0, max: 100, step: 0.1, suffix: '%', help: 'Interest the bond pays, as a share of face value.' },
		{ id: 'ytm', label: 'Yield to maturity', type: 'number', default: 6, min: 0, max: 100, step: 0.05, suffix: '%', help: 'Annual return a buyer requires.' },
		{ id: 'years', label: 'Years to maturity', type: 'number', default: 10, min: 1, max: 100, step: 1, decimal: false, suffix: 'years' },
		{ id: 'freq', label: 'Payments per year', type: 'select', display: 'menu', default: '2', options: frequencyOptions }
	],
	calculate(v): CalculationResult {
		const face = Number(v.face);
		const coupon = Number(v.coupon);
		const ytm = Number(v.ytm);
		const years = Number(v.years);
		const freq = Number(v.freq);

		if (
			!(face > 0) ||
			!(coupon >= 0 && coupon <= 100) ||
			!(ytm >= 0 && ytm <= 100) ||
			!(Number.isInteger(years) && years >= 1 && years <= 100) ||
			![1, 2, 4, 12].includes(freq)
		) {
			return { primaryResult: DASH, primaryLabel: 'Bond price', summary: 'Check the face value, rates, years and payment frequency.' };
		}

		const annualCoupon = (face * coupon) / 100;
		const couponPayment = annualCoupon / freq;
		const y = ytm / 100 / freq;
		const n = years * freq;

		const pvCoupons = y === 0 ? couponPayment * n : (couponPayment * (1 - Math.pow(1 + y, -n))) / y;
		const pvFace = face * Math.pow(1 + y, -n);
		const price = pvCoupons + pvFace;
		const currentYield = (annualCoupon / price) * 100;

		const diff = price - face;
		const status = Math.abs(diff) < 0.005 ? 'At par' : diff > 0 ? 'At a premium' : 'At a discount';
		const summary =
			status === 'At par'
				? 'Trades at par, because the coupon rate equals the yield.'
				: diff > 0
					? `Trades ${money(diff)} above face value, because the coupon rate is above the yield.`
					: `Trades ${money(-diff)} below face value, because the coupon rate is below the yield.`;

		return {
			primaryResult: money(price),
			primaryLabel: 'Bond price',
			summary,
			secondaryMetrics: [
				{ label: 'Annual coupon income', value: money(annualCoupon) },
				{ label: 'Coupon per payment', value: money(couponPayment) },
				{ label: 'PV of coupons', value: money(pvCoupons) },
				{ label: 'PV of face value', value: money(pvFace) },
				{ label: 'Current yield', value: `${num(currentYield, 2, 2)}%` },
				{ label: 'Market status', value: status }
			]
		};
	},
	content: {
		intro:
			'Find the price a bond should sell for today, given its face value, coupon rate, the yield you want and the years left to maturity. The calculator also shows the current yield and whether the bond trades at a premium, a discount or at par.',
		howTo: [
			'Enter the face value and the annual coupon rate printed on the bond.',
			'Enter the yield to maturity, which is the annual return you want from the bond.',
			'Enter the years left to maturity and how often the coupons are paid.',
			'Read the price, the current yield and whether the bond trades above, below or at face value.'
		],
		formulas: [
			{
				title: 'Bond price',
				expression: 'Price = C × (1 − (1 + y)⁻ᴺ) ÷ y + F × (1 + y)⁻ᴺ',
				variables: [
					{ symbol: 'C', meaning: 'coupon payment per period: face value × annual coupon rate ÷ payments per year' },
					{ symbol: 'F', meaning: 'face value repaid at maturity' },
					{ symbol: 'y', meaning: 'yield per period: yield to maturity ÷ payments per year' },
					{ symbol: 'N', meaning: 'number of payments left: years × payments per year' }
				]
			},
			{
				title: 'Current yield',
				expression: 'Current yield = annual coupon ÷ price',
				variables: [{ symbol: 'Price', meaning: 'the price calculated above' }]
			}
		],
		example: {
			title: '$1,000 face value, 5% coupon, 6% yield, 10 years, paid twice a year',
			steps: [
				'Coupon per payment: C = 1,000 × 5% ÷ 2 = $25',
				'Yield per period: y = 6% ÷ 2 = 3%, with N = 10 × 2 = 20 payments',
				'PV of coupons: $25 × (1 − 1.03⁻²⁰) ÷ 0.03 ≈ $371.94',
				'PV of face value: $1,000 × 1.03⁻²⁰ ≈ $553.68',
				'Price: $371.94 + $553.68 ≈ $925.61',
				'Current yield: $50 ÷ $925.61 ≈ 5.40%'
			],
			result: 'The bond is worth about $925.61, which is a $74.39 discount to face value, with a current yield of 5.40%.'
		},
		faq: [
			{
				q: 'Why does a bond trade at a discount or premium?',
				a: 'Prices move so that the yield matches the market rate. If the coupon is below the yield, the price falls below face value (a discount). If the coupon is above the yield, the price rises above face value (a premium).'
			},
			{
				q: 'What is the difference between current yield and yield to maturity?',
				a: 'Current yield is the annual coupon divided by today’s price. Yield to maturity also counts the gain or loss from paying a price different from face value, and it assumes every coupon is reinvested at the same yield.'
			},
			{
				q: 'Why do payments per year change the price?',
				a: 'More frequent payments bring the cash forward slightly, and the yield is split into smaller periods. Use the schedule stated in the bond’s terms. Many U.S. Treasury notes and corporate bonds pay twice a year.'
			},
			{
				q: 'Does this include accrued interest?',
				a: 'No. The calculator prices the bond on a full-period basis. A bond sold between coupon dates also carries accrued interest, which is added to the quoted price.'
			}
		],
		sources: [{ title: 'U.S. Securities and Exchange Commission — Investor.gov', url: 'https://www.investor.gov' }],
		disclaimer:
			'Estimates only. Real bond prices depend on credit risk, market conditions, call features and the exact settlement date, and this calculator does not include them.'
	}
});
