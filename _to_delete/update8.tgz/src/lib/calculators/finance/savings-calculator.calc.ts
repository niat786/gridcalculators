import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct, plural } from '../format';
import meta from './savings-calculator.meta';

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'initial', label: 'Starting balance', type: 'number', default: 1000, min: 0, max: 100_000_000, step: 100, prefix: '$' },
		{
			id: 'monthly',
			label: 'Monthly deposit',
			type: 'number',
			default: 200,
			min: 0,
			max: 1_000_000,
			step: 10,
			prefix: '$',
			suffix: '/mo',
			help: 'Added at the end of each month.'
		},
		{ id: 'rate', label: 'Annual interest rate', type: 'number', default: 4.5, min: 0, max: 100, step: 0.01, suffix: '%', help: 'Compounded monthly.' },
		{ id: 'years', label: 'Years', type: 'number', default: 5, min: 1, max: 100, step: 1, suffix: 'years', decimal: false }
	],
	calculate(v): CalculationResult {
		const initial = Number(v.initial);
		const monthly = Number(v.monthly);
		const rate = Number(v.rate);
		const years = Number(v.years);
		if (
			!(initial >= 0) ||
			!(monthly >= 0) ||
			!(rate >= 0 && rate <= 100) ||
			!(Number.isInteger(years) && years >= 1 && years <= 100)
		) {
			return { primaryResult: DASH, primaryLabel: 'Ending balance', summary: 'Check the balance, deposit, rate and years.' };
		}

		// Interest compounds monthly; deposits are added at the end of each month.
		const monthRate = rate / 100 / 12;
		let balance = initial;
		let deposited = initial;
		const rows: Record<string, string>[] = [];
		for (let y = 1; y <= years; y++) {
			for (let m = 0; m < 12; m++) balance = balance * (1 + monthRate) + monthly;
			deposited += monthly * 12;
			const interest = balance - deposited;
			rows.push({
				year: String(y),
				deposited: money(deposited, true),
				interest: money(interest, true),
				balance: money(balance, true)
			});
		}

		const interest = balance - deposited;
		const effectiveAnnual = Math.pow(1 + monthRate, 12) - 1;

		return {
			primaryResult: money(balance),
			primaryLabel: 'Ending balance',
			summary: `You deposit ${money(deposited)} and earn ${money(interest)} in interest over ${plural(years, 'year')}.`,
			secondaryMetrics: [
				{ label: 'Total deposited', value: money(deposited) },
				{ label: 'Interest earned', value: money(interest) },
				{ label: 'Effective annual yield', value: pct(effectiveAnnual * 100, 3) }
			],
			table: {
				title: 'Yearly breakdown',
				collapsed: true,
				columns: [
					{ key: 'year', label: 'Year' },
					{ key: 'deposited', label: 'Deposited', align: 'end' },
					{ key: 'interest', label: 'Interest', align: 'end' },
					{ key: 'balance', label: 'Balance', align: 'end' }
				],
				rows
			}
		};
	},
	content: {
		intro:
			'Project how a savings account grows with a starting balance and regular monthly deposits. See your ending balance, the interest you earn and the year-by-year totals.',
		howTo: [
			'Enter your starting balance and the amount you deposit each month.',
			'Enter the annual interest rate your bank pays.',
			'Enter how many years you plan to save.',
			'Read the ending balance, then open the yearly breakdown.'
		],
		formulas: [
			{
				title: 'Monthly compounding with monthly deposits',
				expression: 'Each month: balance = balance × (1 + r ÷ 12) + deposit',
				variables: [
					{ symbol: 'r', meaning: 'annual interest rate as a decimal (4.5% is 0.045)' }
				]
			},
			{
				title: 'Effective annual yield',
				expression: 'APY = (1 + r ÷ 12)¹² − 1',
				variables: [
					{ symbol: 'APY', meaning: 'the yearly return after monthly compounding' }
				]
			}
		],
		example: {
			title: '$1,000 to start, $200 a month, 4.5% for 5 years',
			steps: [
				'Monthly rate: 0.045 ÷ 12 = 0.00375',
				'Months: 5 × 12 = 60',
				'Starting balance grows to: 1,000 × 1.00375⁶⁰ ≈ $1,251.80',
				'Deposits grow to: 200 × (1.00375⁶⁰ − 1) ÷ 0.00375 ≈ $13,429.11',
				'Ending balance: $1,251.80 + $13,429.11 ≈ $14,680.91',
				'Total deposited: $1,000 + $200 × 60 = $13,000, so interest is $1,680.91'
			],
			result: 'Ending balance ≈ $14,680.91, with $1,680.91 of interest earned.'
		},
		faq: [
			{
				q: 'Does the calculator assume monthly compounding?',
				a: 'Yes. The interest rate is applied to the balance every month, which is how most high-yield savings accounts pay interest. Check your bank for its exact schedule.'
			},
			{
				q: 'What is the difference between APY and the interest rate?',
				a: 'The interest rate is the yearly rate before compounding. The annual percentage yield (APY) includes the effect of compounding, so it is slightly higher when interest is added more than once a year.'
			},
			{
				q: 'What if I deposit at the start of the month instead?',
				a: 'Starting deposits earn one extra month of interest each time, so the balance is a little higher. This calculator uses end-of-month deposits.'
			},
			{
				q: 'Are savings accounts taxed on interest?',
				a: 'Interest is usually taxable income, and this calculator does not deduct taxes.'
			}
		],
		sources: [{ title: 'U.S. Securities and Exchange Commission — Investor.gov', url: 'https://www.investor.gov' }],
		disclaimer:
			'Estimates only. Bank rates change over time and this tool does not account for taxes or fees.'
	}
});
