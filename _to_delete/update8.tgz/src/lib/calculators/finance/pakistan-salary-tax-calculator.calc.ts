import { defineCalculator, type CalculationResult, type CalculatorInput, type InputValues } from '../types';
import { DASH, money, pct } from '../format';
import meta from './pakistan-salary-tax-calculator.meta';
import {
	PK_KPMG_SOURCE,
	PK_PREV_TAX_YEAR_LABEL,
	PK_PREV_YEAR_SOURCE,
	PK_PREV_YEAR_SOURCE_2,
	PK_PWC_SOURCE,
	PK_SALARIED_SLABS_2026,
	PK_SALARIED_SLABS_2027,
	PK_SURCHARGE_2026,
	PK_SURCHARGE_2027,
	PK_TAX_YEAR_LABEL,
	PK_TAX_YEAR_PERIOD,
	PK_VIALTO_SOURCE,
	type PkSlab
} from '../data/pk-tax-2027';

const rs = (n: number) => money(n, true);

/** Progressive tax on the slabs, then the surcharge (a percentage of the tax) above its income threshold. */
export function pkSalaryTax(income: number, slabs: PkSlab[], surcharge: { rate: number; threshold: number }) {
	let prev = 0;
	let slabTax = 0;
	for (const s of slabs) {
		const hi = s.upTo ?? Infinity;
		if (income > prev) slabTax += (Math.min(income, hi) - prev) * s.rate;
		prev = hi;
	}
	const sur = income > surcharge.threshold ? slabTax * surcharge.rate : 0;
	return { slabTax, surcharge: sur, total: slabTax + sur };
}

const inputs: CalculatorInput[] = [
	{
		id: 'period',
		label: 'Salary entered as',
		type: 'select',
		default: 'monthly',
		options: [
			{ label: 'Monthly', value: 'monthly' },
			{ label: 'Annual', value: 'annual' }
		],
		display: 'segmented'
	},
	{
		id: 'salary',
		label: 'Taxable salary',
		type: 'number',
		default: 250_000,
		min: 0,
		max: 100_000_000_000,
		step: 1000,
		prefix: '$',
		decimal: false,
		help: 'Gross taxable salary, before tax. Include bonuses; leave out exempt allowances.'
	}
];

const bandLabel = (slabs: PkSlab[], i: number) => {
	const from = i === 0 ? 0 : (slabs[i - 1].upTo as number);
	const to = slabs[i].upTo;
	return to === null ? `Over ${rs(from)}` : i === 0 ? `Up to ${rs(to)}` : `${rs(from)} to ${rs(to)}`;
};

function calculate(v: InputValues): CalculationResult {
	const amount = Number(v.salary);
	if (!Number.isFinite(amount) || amount < 0 || (v.period !== 'monthly' && v.period !== 'annual')) {
		return { primaryResult: DASH, primaryLabel: 'Monthly tax', summary: 'Enter your salary as zero or more.' };
	}
	const annual = v.period === 'monthly' ? amount * 12 : amount;
	if (annual > 1_000_000_000_000) {
		return { primaryResult: DASH, primaryLabel: 'Monthly tax', summary: 'That salary is too large to calculate.' };
	}
	const t27 = pkSalaryTax(annual, PK_SALARIED_SLABS_2027, PK_SURCHARGE_2027);
	const t26 = pkSalaryTax(annual, PK_SALARIED_SLABS_2026, PK_SURCHARGE_2026);
	const monthlyTax = t27.total / 12;
	const takeHome = (annual - t27.total) / 12;
	const effective = annual > 0 ? (t27.total / annual) * 100 : 0;
	const diff = t26.total - t27.total;

	// Tax falling in each slab (tax year 2027), shown next to both years' rates.
	let prev = 0;
	const rows = PK_SALARIED_SLABS_2027.map((s, i) => {
		const hi = s.upTo ?? Infinity;
		const inSlab = Math.max(0, Math.min(annual, hi) - prev);
		prev = hi;
		return {
			band: bandLabel(PK_SALARIED_SLABS_2027, i),
			r27: pct(s.rate * 100),
			r26: pct(PK_SALARIED_SLABS_2026[i].rate * 100),
			yours: rs(inSlab * s.rate)
		};
	});

	const summary =
		annual === 0
			? 'No salary entered, so no tax.'
			: t27.total === 0
				? `Annual salary of ${rs(annual)} is within the tax-free slab for ${PK_TAX_YEAR_LABEL}.`
				: `Annual tax on ${rs(annual)} is ${rs(t27.total)}, an effective rate of ${pct(effective)} for ${PK_TAX_YEAR_LABEL}.`;

	return {
		primaryResult: rs(monthlyTax),
		primaryLabel: `Monthly tax (${PK_TAX_YEAR_LABEL})`,
		summary,
		secondaryMetrics: [
			{ label: 'Annual taxable income', value: rs(annual) },
			{ label: 'Annual tax', value: rs(t27.total) },
			{ label: 'Monthly take-home', value: rs(takeHome) },
			{ label: 'Effective tax rate', value: pct(effective) },
			{ label: `Annual tax, ${PK_PREV_TAX_YEAR_LABEL}`, value: rs(t26.total) },
			{ label: diff >= 0 ? 'Saving vs last year' : 'Extra vs last year', value: rs(Math.abs(diff)) }
		],
		table: {
			title: `Salaried slabs, ${PK_TAX_YEAR_LABEL} vs ${PK_PREV_TAX_YEAR_LABEL}`,
			columns: [
				{ key: 'band', label: 'Annual income' },
				{ key: 'r27', label: 'Rate 2027', align: 'end' },
				{ key: 'r26', label: 'Rate 2026', align: 'end' },
				{ key: 'yours', label: 'Your 2027 tax in slab', align: 'end' }
			],
			rows
		}
	};
}

export default defineCalculator({
	meta,
	inputs,
	calculate,
	content: {
		intro: `Work out income tax on a salary in Pakistan for ${PK_TAX_YEAR_LABEL} (${PK_TAX_YEAR_PERIOD}), using the salaried-individual slabs set by the Finance Act 2026. It also shows last year's tax so you can compare.`,
		howTo: [
			'Choose whether you are entering a monthly or an annual salary.',
			'Enter your taxable salary before tax.',
			'Read the monthly tax and take-home pay, and the slab table with last year\'s rates beside it.'
		],
		formulas: [
			{
				title: `Salaried slabs, ${PK_TAX_YEAR_LABEL} (First Schedule, Part I, Division I)`,
				expression:
					'Up to 6,00,000: nil · to 12,00,000: 1% of excess · to 22,00,000: 6,000 + 11% · to 32,00,000: 116,000 + 20% · to 41,00,000: 316,000 + 25% · to 56,00,000: 541,000 + 29% · to 70,00,000: 976,000 + 32% · above: 1,424,000 + 35%',
				variables: [
					{ symbol: 'Surcharge', meaning: 'None for salaried people in tax year 2027. Tax year 2026 had 9% of the tax above Rs 10 million.' },
					{ symbol: 'Take-home', meaning: '(annual salary − annual tax) ÷ 12. EOBI, provident fund and loan deductions are not included.' },
					{ symbol: 'Who it applies to', meaning: 'Individuals whose salary is more than 75% of their taxable income. Others use the business slabs.' }
				]
			}
		],
		example: {
			title: 'Monthly salary of Rs 250,000',
			steps: [
				'Annual salary: 250,000 × 12 = Rs 3,000,000.',
				'Tax: 116,000 on the first Rs 2,200,000, plus 20% of the Rs 800,000 above it (Rs 160,000) = Rs 276,000.',
				'Monthly tax: 276,000 ÷ 12 = Rs 23,000. Monthly take-home: 250,000 − 23,000 = Rs 227,000.'
			],
			result: 'Rs 23,000 a month in tax; Rs 276,000 a year (9.2% effective).'
		},
		faq: [
			{ q: 'What changed for salaried people in tax year 2027?', a: 'The 23%, 30% and 35% slabs were replaced by 20%, 25%, 29% and 32% slabs, so the top rate of 35% now starts at Rs 7 million instead of Rs 4.1 million. The 9% surcharge on salaried income above Rs 10 million was withdrawn.' },
			{ q: 'What is the tax-free limit?', a: 'The first Rs 600,000 of annual taxable income is taxed at nil. Above it, the rate is 1% up to Rs 1.2 million.' },
			{ q: 'What does this not include?', a: 'Tax credits and deductions (for example on pension contributions, donations or investment), exempt allowances, non-salary income and non-residents. It assumes your whole taxable income is salary.' }
		],
		sources: [PK_KPMG_SOURCE, PK_PWC_SOURCE, PK_VIALTO_SOURCE, PK_PREV_YEAR_SOURCE, PK_PREV_YEAR_SOURCE_2],
		disclaimer: 'Estimate for a resident salaried individual. Check your figures with FBR or a tax adviser before filing.'
	}
});
