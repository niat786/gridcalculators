import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num } from '../format';
import { IRS_LIMITS_SOURCE, LIMIT_401K, limit401k, RETIREMENT_TAX_YEAR } from '../data/us-retirement';
import meta from './401k-calculator.meta';

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'age', label: 'Current age', type: 'number', default: 30, min: 18, max: 75, decimal: false, suffix: 'years', width: 'half' },
		{ id: 'retire', label: 'Retirement age', type: 'number', default: 65, min: 19, max: 80, decimal: false, suffix: 'years', width: 'half' },
		{ id: 'salary', label: 'Annual salary', type: 'number', default: 75000, min: 0, max: 10_000_000, prefix: '$' },
		{ id: 'contrib', label: 'Your contribution', type: 'number', default: 8, min: 0, max: 100, step: 0.5, suffix: '% of pay' },
		{ id: 'match', label: 'Employer match', type: 'number', default: 50, min: 0, max: 200, suffix: '% of yours', help: 'e.g. 50% means $0.50 per $1 you put in' },
		{ id: 'matchCap', label: 'Match limit', type: 'number', default: 6, min: 0, max: 100, step: 0.5, suffix: '% of pay', help: 'Your contributions above this aren’t matched' },
		{ id: 'balance', label: 'Current 401(k) balance', type: 'number', default: 25000, min: 0, max: 100_000_000, prefix: '$' },
		{ id: 'ret', label: 'Expected return', type: 'number', default: 7, min: -10, max: 20, step: 0.1, suffix: '% / yr', width: 'half' },
		{ id: 'raise', label: 'Salary increase', type: 'number', default: 2, min: 0, max: 20, step: 0.1, suffix: '% / yr', width: 'half' }
	],
	calculate(v): CalculationResult {
		const age = Number(v.age);
		const retire = Number(v.retire);
		const r = Number(v.ret) / 100;
		const g = Number(v.raise) / 100;
		let salary = Number(v.salary);
		const pct = Number(v.contrib) / 100;
		const matchRate = Number(v.match) / 100;
		const matchCap = Number(v.matchCap) / 100;
		let balance = Number(v.balance);
		const nums = [age, retire, r, g, salary, pct, matchRate, matchCap, balance];
		if (nums.some((x) => !Number.isFinite(x)) || retire <= age || retire - age > 62) {
			return { primaryResult: DASH, primaryLabel: 'Balance at retirement', summary: 'Retirement age must be after your current age.' };
		}

		let you = 0;
		let employer = 0;
		let cappedYears = 0;
		const rows: Record<string, string>[] = [];
		const chart: Record<string, number>[] = [{ age, balance, contributed: balance }];
		let contributed = balance;
		for (let a = age; a < retire; a++) {
			const wanted = salary * pct;
			const limit = limit401k(a);
			const yours = Math.min(wanted, limit);
			if (wanted > limit) cappedYears++;
			const matched = Math.min(yours, salary * matchCap) * matchRate;
			// Contributions spread through the year earn about half a year of growth.
			balance = balance * (1 + r) + (yours + matched) * (1 + r / 2);
			you += yours;
			employer += matched;
			contributed += yours + matched;
			rows.push({ age: String(a + 1), you: money(yours, true), employer: money(matched, true), balance: money(balance, true) });
			chart.push({ age: a + 1, balance, contributed });
			salary *= 1 + g;
		}

		const startSalary = Number(v.salary);
		const thisYear = Math.min(startSalary * pct, limit401k(age));
		const leftOnTable = pct < matchCap ? startSalary * (matchCap - pct) * matchRate : 0;

		return {
			primaryResult: money(balance, true),
			primaryLabel: `401(k) balance at age ${retire}`,
			summary:
				leftOnTable > 0
					? `Raising your contribution to ${num(matchCap * 100, 1)}% would capture ${money(leftOnTable, true)} more in matching this year.`
					: `You get the full employer match. ${RETIREMENT_TAX_YEAR} limit at age ${age}: ${money(limit401k(age), true)}.`,
			secondaryMetrics: [
				{ label: 'Your contributions', value: money(you, true) },
				{ label: 'Employer contributions', value: money(employer, true) },
				{ label: 'Investment growth', value: money(balance - you - employer - Number(v.balance), true) },
				{ label: 'Your contribution this year', value: money(thisYear, true) },
				{ label: `${RETIREMENT_TAX_YEAR} contribution limit (your age)`, value: money(limit401k(age), true) }
			],
			chart: {
				type: 'line',
				title: 'Balance and money put in',
				x: 'age',
				xLabel: 'Age',
				series: [
					{ key: 'balance', label: 'Balance' },
					{ key: 'contributed', label: 'Total put in' }
				],
				data: chart,
				valueFormat: 'currency'
			},
			table: {
				title: cappedYears ? `Year by year (limit reached in ${cappedYears} years)` : 'Year by year',
				collapsed: true,
				columns: [
					{ key: 'age', label: 'Age' },
					{ key: 'you', label: 'You', align: 'end' },
					{ key: 'employer', label: 'Employer', align: 'end' },
					{ key: 'balance', label: 'Balance', align: 'end' }
				],
				rows
			}
		};
	},
	content: {
		intro: `Project how your 401(k) could grow from your own contributions, your employer’s match and investment returns, using the ${RETIREMENT_TAX_YEAR} IRS contribution limits.`,
		howTo: [
			'Enter your age, retirement age and salary.',
			'Enter the percentage of pay you contribute and how your employer matches it.',
			'Add your current balance, an expected return and a typical yearly raise.',
			'Read your projected balance and whether you are getting the full match.'
		],
		formulas: [
			{
				title: 'Each year',
				expression: 'balance = balance × (1 + r) + (you + match) × (1 + r ÷ 2)',
				variables: [
					{ symbol: 'you', meaning: `salary × your % (capped at the IRS limit: $${num(LIMIT_401K.elective, 0)}, plus catch-up from age 50)` },
					{ symbol: 'match', meaning: 'min(you, salary × match limit %) × employer match %' },
					{ symbol: 'r', meaning: 'expected yearly return; contributions get half a year of growth' }
				]
			}
		],
		example: {
			title: 'Salary $75,000, you put in 8%, employer matches 50% up to 6%',
			steps: [
				'Your contribution: $75,000 × 8% = $6,000',
				'Matched part: the lower of $6,000 and $75,000 × 6% = $4,500',
				'Employer match: $4,500 × 50% = $2,250',
				'Total going in this year: $6,000 + $2,250 = $8,250'
			],
			result: 'Each year starts with $8,250 of new money, before growth and raises.'
		},
		faq: [
			{
				q: `What is the 401(k) contribution limit for ${RETIREMENT_TAX_YEAR}?`,
				a: `$${num(LIMIT_401K.elective, 0)} of your own pay. From age 50 you can add a $${num(LIMIT_401K.catchUp50, 0)} catch-up, and at ages 60 to 63 the catch-up rises to $${num(LIMIT_401K.catchUp60to63, 0)}. Employer contributions don’t count toward this limit.`
			},
			{
				q: 'Should I always get the full employer match?',
				a: 'If you can afford it, yes. The match is part of your pay: contributing less than the match limit leaves that money unclaimed.'
			},
			{
				q: 'Does this include taxes or fees?',
				a: 'No. Traditional 401(k) money is taxed when you withdraw it, and fund fees reduce returns. Treat the projection as a before-tax, before-fee estimate.'
			},
			{
				q: 'Does the calculator raise the limit in future years?',
				a: `No. It holds the ${RETIREMENT_TAX_YEAR} limits steady, which is conservative: the IRS usually raises them with inflation.`
			}
		],
		sources: [IRS_LIMITS_SOURCE],
		disclaimer: 'Projections, not guarantees. Returns vary, and taxes, fees and plan rules (such as vesting) are not included.'
	}
});
