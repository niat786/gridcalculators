import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './auto-lease-calculator.meta';

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'msrp', label: 'MSRP', type: 'number', default: 40000, min: 1, max: 100_000_000, step: 100, prefix: '$', help: 'Manufacturer’s suggested retail price' },
		{ id: 'price', label: 'Negotiated price', type: 'number', default: 36000, min: 1, max: 100_000_000, step: 100, prefix: '$' },
		{ id: 'down', label: 'Down payment', type: 'number', default: 2000, min: 0, max: 100_000_000, step: 100, prefix: '$', help: 'Capitalized cost reduction' },
		{ id: 'tradeIn', label: 'Trade-in value', type: 'number', default: 0, min: 0, max: 100_000_000, step: 100, prefix: '$' },
		{
			id: 'residualPct',
			label: 'Residual value',
			type: 'number',
			default: 60,
			min: 0,
			max: 100,
			step: 0.1,
			suffix: '%',
			help: 'Share of MSRP the car is expected to be worth at lease end'
		},
		{ id: 'months', label: 'Lease term (months)', type: 'number', default: 36, min: 1, max: 120, step: 1, suffix: 'months', decimal: false },
		{
			id: 'moneyMode',
			label: 'Finance rate',
			type: 'select',
			display: 'segmented',
			default: 'mf',
			options: [
				{ label: 'Money factor', value: 'mf' },
				{ label: 'APR', value: 'apr' }
			]
		},
		{
			id: 'moneyFactor',
			label: 'Money factor',
			type: 'number',
			default: 0.00125,
			min: 0,
			max: 0.1,
			step: 0.00001,
			help: 'Multiply by 2,400 to get the APR',
			visibleWhen: (v) => v.moneyMode !== 'apr'
		},
		{
			id: 'aprRate',
			label: 'APR',
			type: 'number',
			default: 3,
			min: 0,
			max: 100,
			step: 0.01,
			suffix: '%',
			help: 'Divide by 2,400 to get the money factor',
			visibleWhen: (v) => v.moneyMode === 'apr'
		},
		{ id: 'tax', label: 'Sales tax', type: 'number', default: 7, min: 0, max: 30, step: 0.01, suffix: '%', help: 'Applied to the monthly charge' }
	],
	calculate(v): CalculationResult {
		const msrp = Number(v.msrp);
		const price = Number(v.price);
		const down = Number(v.down);
		const tradeIn = Number(v.tradeIn);
		const residualPct = Number(v.residualPct);
		const months = Number(v.months);
		const taxPct = Number(v.tax);
		const useApr = String(v.moneyMode) === 'apr';
		const moneyFactor = useApr ? Number(v.aprRate) / 2400 : Number(v.moneyFactor);
		const aprOk = Number(v.aprRate) >= 0 && Number(v.aprRate) <= 100;

		const cap = price - down - tradeIn;
		const inputsOk =
			msrp > 0 &&
			Number.isFinite(msrp) &&
			price > 0 &&
			down >= 0 &&
			tradeIn >= 0 &&
			cap > 0 &&
			residualPct >= 0 &&
			residualPct <= 100 &&
			Number.isInteger(months) &&
			months >= 1 &&
			months <= 120 &&
			taxPct >= 0 &&
			taxPct <= 30 &&
			(useApr ? aprOk : moneyFactor >= 0 && moneyFactor <= 0.1);
		if (!inputsOk) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Monthly payment',
				summary: 'Check the prices (the down payment and trade-in must be less than the negotiated price), the residual, the term and the finance rate.'
			};
		}

		const residual = msrp * (residualPct / 100);
		const depreciation = (cap - residual) / months;
		const financeFee = (cap + residual) * moneyFactor;
		const subtotal = depreciation + financeFee;
		const salesTax = subtotal * (taxPct / 100);
		const monthly = subtotal + salesTax;

		return {
			primaryResult: money(monthly),
			primaryLabel: 'Monthly payment',
			summary: `Depreciation ${money(depreciation)} plus finance ${money(financeFee)} plus tax ${money(salesTax)} a month, over ${plural(months, 'month')}.`,
			secondaryMetrics: [
				{ label: 'Adjusted cap cost', value: money(cap) },
				{ label: 'Residual value', value: money(residual) },
				{ label: 'Depreciation fee', value: money(depreciation) },
				{ label: 'Finance fee', value: money(financeFee) },
				{ label: 'Sales tax per month', value: money(salesTax) },
				{ label: 'Total of payments', value: money(monthly * months) }
			]
		};
	},
	content: {
		intro:
			'Estimate a car lease payment from the negotiated price, your down payment and trade-in, the residual value and the lease finance rate. The payment is split into the depreciation fee, the finance fee and sales tax, so you can see what each part costs.',
		howTo: [
			'Enter the MSRP and the negotiated price you agreed with the dealer.',
			'Enter your down payment and any trade-in value. These reduce the amount you pay for.',
			'Enter the residual value as a percentage of MSRP, the lease term and the sales tax rate.',
			'Enter the money factor, or switch to APR and enter the rate, then read each part of the payment.'
		],
		formulas: [
			{
				title: 'Adjusted cap cost',
				expression: 'Cap = negotiated price − down payment − trade-in',
				variables: []
			},
			{
				title: 'Residual value',
				expression: 'Residual = MSRP × residual % ÷ 100',
				variables: []
			},
			{
				title: 'Monthly payment',
				expression: 'Payment = [(Cap − Residual) ÷ n + (Cap + Residual) × MF] × (1 + tax ÷ 100)',
				variables: [
					{ symbol: 'n', meaning: 'lease term in months' },
					{ symbol: 'MF', meaning: 'money factor. APR = MF × 2,400, so MF = APR ÷ 2,400' },
					{ symbol: 'tax', meaning: 'sales tax rate, applied to the monthly charge' }
				]
			}
		],
		example: {
			title: 'A $40,000 MSRP car at $36,000 over 36 months',
			steps: [
				'Cap cost: 36,000 − 2,000 down − 0 trade-in = $34,000',
				'Residual: 60% of $40,000 = $24,000',
				'Depreciation fee: (34,000 − 24,000) ÷ 36 = $277.78',
				'Finance fee: (34,000 + 24,000) × 0.00125 = $72.50',
				'Sales tax: (277.78 + 72.50) × 7% = $24.52',
				'Monthly payment: 277.78 + 72.50 + 24.52 = $374.80'
			],
			result: 'Monthly payment of $374.80, made up of $277.78 depreciation, $72.50 finance and $24.52 tax.'
		},
		faq: [
			{
				q: 'What is a money factor?',
				a: 'It is the lease version of an interest rate. It is a small decimal, and multiplying it by 2,400 gives the equivalent APR. A money factor of 0.00125 is about 3% APR.'
			},
			{
				q: 'Why does a higher residual value lower the payment?',
				a: 'The residual is what the car is worth at the end of the lease. You pay for the drop in value, so a higher residual means less depreciation to pay for.'
			},
			{
				q: 'Why are trade-in and down payment subtracted?',
				a: 'Both reduce the amount the lease is based on, which is called the capitalized cost. Less cost means a lower depreciation and finance charge.'
			},
			{
				q: 'Does this include lease fees or acquisition charges?',
				a: 'No. Acquisition fees, registration, and other charges are not included, so the dealer’s lease quote will show a slightly different total.'
			}
		],
		sources: [{ title: 'Consumer Financial Protection Bureau', url: 'https://www.consumerfinance.gov/' }],
		disclaimer:
			'Estimates only. Real lease payments depend on the dealer’s quote, fees, mileage allowance and local tax rules. Read your lease agreement before you sign.'
	}
});
