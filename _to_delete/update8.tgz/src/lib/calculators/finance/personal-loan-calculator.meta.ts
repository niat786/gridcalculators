import { defineMeta } from '../types';

export default defineMeta({
	slug: 'personal-loan-calculator',
	name: 'Personal Loan Calculator',
	category: 'finance',
	shortDescription: 'Monthly payment, origination fee and the net amount you receive.',
	metaTitle: 'Personal Loan Calculator — Payment & Fee Impact',
	metaDescription:
		'Free personal loan calculator. See your monthly payment, total interest and the net amount you receive after an origination fee is taken out.',
	icon: 'banknote',
	keywords: ['personal loan calculator', 'personal loan payment', 'origination fee', 'loan fee', 'personal loan interest'],
	money: 'any',
	updated: '2026-10-28'
});
