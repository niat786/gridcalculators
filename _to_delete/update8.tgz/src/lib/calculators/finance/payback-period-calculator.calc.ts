import { defineCalculator, type CalculationResult, type InputValues, type RowValue } from '../types';
import { DASH, money, num, pct } from '../format';
import meta from './payback-period-calculator.meta';

const mode = (m: string) => (v: InputValues) => v.mode === m;

const DEFAULT_FLOWS: RowValue[] = [
	{ label: 'Year 1', amount: 6000 },
	{ label: 'Year 2', amount: 9000 },
	{ label: 'Year 3', amount: 12000 },
	{ label: 'Year 4', amount: 15000 },
	{ label: 'Year 5', amount: 18000 },
	{ label: 'Year 6', amount: 20000 }
];

/**
 * Years until the running total of flows covers the investment, interpolated inside the year.
 * `flows[t]` is the cash inflow in year t + 1. Returns null when it is never reached.
 */
export function paybackYears(investment: number, flows: number[]): number | null {
	let cumulative = 0;
	for (let t = 0; t < flows.length; t++) {
		const cf = flows[t];
		if (cf > 0 && cumulative + cf >= investment) return t + (investment - cumulative) / cf;
		cumulative += cf;
	}
	return null;
}

const years = (x: number) => `${num(x, 2, 2)} years`;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Cash inflows',
			type: 'select',
			display: 'segmented',
			default: 'even',
			options: [
				{ label: 'Even each year', value: 'even' },
				{ label: 'Uneven each year', value: 'uneven' }
			]
		},
		{ id: 'investment', label: 'Initial investment', type: 'number', default: 50000, min: 0.01, max: 100_000_000, step: 500, prefix: '$' },
		{
			id: 'rate',
			label: 'Discount rate',
			type: 'number',
			default: 10,
			min: 0,
			max: 100,
			step: 0.1,
			suffix: '%',
			help: 'Yearly rate, used for discounted payback and NPV.'
		},
		{
			id: 'inflow',
			label: 'Yearly cash inflow',
			type: 'number',
			default: 15000,
			min: 0.01,
			max: 100_000_000,
			step: 500,
			prefix: '$',
			visibleWhen: mode('even')
		},
		{
			id: 'years',
			label: 'Years of cash inflow',
			type: 'number',
			default: 10,
			min: 1,
			max: 50,
			step: 1,
			suffix: 'years',
			decimal: false,
			visibleWhen: mode('even')
		},
		{
			id: 'flows',
			label: 'Yearly cash inflows',
			type: 'rows',
			columns: [
				{ id: 'label', label: 'Year', type: 'text', default: '', placeholder: 'Label' },
				{ id: 'amount', label: 'Cash inflow', type: 'number', default: 0, min: 0, prefix: '$' }
			],
			default: DEFAULT_FLOWS,
			minRows: 1,
			maxRows: 60,
			addLabel: 'Add year',
			help: 'One row per year, in order. Enter inflows as positive numbers.',
			visibleWhen: mode('uneven')
		}
	],
	calculate(v): CalculationResult {
		const investment = Number(v.investment);
		const rate = Number(v.rate);
		const primaryLabel = 'Simple payback period';
		const invalid = (summary: string): CalculationResult => ({ primaryResult: DASH, primaryLabel, summary });

		if (!Number.isFinite(investment) || !(investment > 0)) return invalid('Enter an initial investment above zero.');
		if (!(rate >= 0 && rate <= 100)) return invalid('Enter a discount rate between 0% and 100%.');

		let flows: number[];
		let simple: number | null;
		if (v.mode === 'uneven') {
			const rows = (v.flows as RowValue[]) ?? [];
			if (rows.length < 1) return invalid('Enter at least one yearly cash inflow.');
			flows = [];
			for (const row of rows) {
				const amount = Number(row.amount);
				if (!Number.isFinite(amount) || amount < 0) return invalid('Enter a cash inflow of zero or more for every year.');
				flows.push(amount);
			}
			simple = paybackYears(investment, flows);
		} else {
			const inflow = Number(v.inflow);
			const n = Number(v.years);
			if (!Number.isFinite(inflow) || !(inflow > 0)) return invalid('Enter a yearly cash inflow above zero.');
			if (!Number.isInteger(n) || n < 1 || n > 50) return invalid('Enter a whole number of years from 1 to 50.');
			flows = Array.from({ length: n }, () => inflow);
			simple = investment / inflow;
		}

		const d = rate / 100;
		const discounted = flows.map((cf, t) => cf / Math.pow(1 + d, t + 1));
		const discountedPayback = paybackYears(investment, discounted);
		const pvTotal = discounted.reduce((s, x) => s + x, 0);
		const npv = pvTotal - investment;
		const totalInflows = flows.reduce((s, x) => s + x, 0);

		let cumulative = 0;
		let cumulativePv = 0;
		const table = {
			title: 'Year by year',
			collapsed: true,
			columns: [
				{ key: 'year', label: 'Year' },
				{ key: 'inflow', label: 'Inflow', align: 'end' as const },
				{ key: 'running', label: 'Running total', align: 'end' as const },
				{ key: 'pv', label: 'Present value', align: 'end' as const },
				{ key: 'pvRunning', label: 'Running PV', align: 'end' as const }
			],
			rows: flows.map((cf, t) => {
				cumulative += cf;
				cumulativePv += discounted[t];
				return {
					year: `Year ${num(t + 1, 0)}`,
					inflow: money(cf),
					running: money(cumulative),
					pv: money(discounted[t]),
					pvRunning: money(cumulativePv)
				};
			})
		};

		const discText = discountedPayback === null ? 'Not reached' : years(discountedPayback);
		return {
			primaryResult: simple === null ? 'Not reached' : years(simple),
			primaryLabel,
			summary:
				discountedPayback === null
					? `At ${pct(rate, 2)} a year, the investment is not paid back within the cash inflows you entered.`
					: `At ${pct(rate, 2)} a year, the discounted payback is ${years(discountedPayback)}.`,
			secondaryMetrics: [
				{ label: 'Discounted payback period', value: discText },
				{ label: `Net present value at ${pct(rate, 2)}`, value: money(npv) },
				{ label: 'Total cash inflows', value: money(totalInflows) },
				{ label: 'Net profit (inflows less investment)', value: money(totalInflows - investment) }
			],
			table
		};
	},
	content: {
		intro:
			'Work out how long an investment takes to pay for itself. The calculator shows the simple payback, the discounted payback that counts the time value of money, and the net present value.',
		howTo: [
			'Choose whether the yearly cash inflows are the same each year or change.',
			'Enter the initial investment and the discount rate, then enter the cash inflows, or one row per year for uneven amounts.',
			'Read the simple payback first, then the discounted payback, which is always the same or longer.',
			'Check the net present value. A positive NPV means the investment earns more than the discount rate.'
		],
		formulas: [
			{
				title: 'Simple payback, even cash flows',
				expression: 'Payback = Investment ÷ Yearly cash inflow',
				variables: []
			},
			{
				title: 'Payback, uneven cash flows (interpolated)',
				expression: 'Payback = Full years before break-even + (Amount still to recover ÷ Inflow in the next year)',
				variables: []
			},
			{
				title: 'Discounted payback and net present value',
				expression: 'PVₜ = CFₜ ÷ (1 + r)ᵗ\nNPV = −Investment + Σ PVₜ',
				variables: [
					{ symbol: 'CFₜ', meaning: 'cash inflow in year t' },
					{ symbol: 'r', meaning: 'discount rate as a decimal' },
					{ symbol: 'Σ', meaning: 'sum over all years' }
				]
			}
		],
		example: {
			title: 'A $50,000 investment that returns $15,000 a year for 10 years at 10%',
			steps: [
				'Simple payback: 50,000 ÷ 15,000 = 3.33 years',
				'Present value of each year: 15,000 ÷ 1.10ᵗ, so the discounted amounts add up to $92,168.51 over 10 years',
				'Discounted payback: the running PV reaches $50,000 during year 5, at 4.26 years',
				'NPV: −50,000 + 92,168.51 = $42,168.51'
			],
			result:
				'Simple payback of 3.33 years and discounted payback of 4.26 years. NPV at 10% is $42,168.51.'
		},
		faq: [
			{
				q: 'What is the difference between simple and discounted payback?',
				a: 'Simple payback adds up the cash inflows as they are. Discounted payback first reduces each future inflow to its present value, so it always takes the same or longer.'
			},
			{
				q: 'What discount rate should I use?',
				a: 'Use the return you could earn on a similar investment with similar risk, or your cost of capital. A higher rate makes future cash worth less today.'
			},
			{
				q: 'What does a negative NPV mean?',
				a: 'It means the present value of the inflows is less than the investment at your discount rate. The investment earns less than the rate you entered.'
			},
			{
				q: 'Does payback show whether an investment is good?',
				a: 'Not on its own. Payback ignores cash after the break-even point. Use NPV alongside it for a fuller view.'
			}
		],
		sources: [
			{
				title: 'U.S. Securities and Exchange Commission, Investor.gov',
				url: 'https://www.investor.gov/'
			}
		],
		disclaimer:
			'Estimates from the cash flows you enter. Real payback depends on timing, taxes, costs and risk, and this is not investment advice.'
	}
});
