import { defineCalculator, type CalculationResult, type CalculatorInput, type InputValues } from '../types';
import { DASH, money, num, pct } from '../format';
import meta from './malaysia-epf-calculator.meta';
import {
	MY_EPF_BAND_LARGE,
	MY_EPF_BAND_LIMIT,
	MY_EPF_BAND_SMALL,
	MY_EPF_BAND_SMALL_LIMIT,
	MY_EPF_DIVIDEND_SOURCE,
	MY_EPF_DIVIDEND_SOURCE_2,
	MY_EPF_EMPLOYEE_PCT,
	MY_EPF_EMPLOYER_PCT_HIGH,
	MY_EPF_EMPLOYER_PCT_LOW,
	MY_EPF_EMPLOYER_THRESHOLD,
	MY_EPF_FOREIGN_PCT,
	MY_EPF_FOREIGN_SOURCE,
	MY_EPF_LATEST_DIVIDEND,
	MY_EPF_LATEST_DIVIDEND_YEAR,
	MY_EPF_SOURCE,
	MY_EPF_SOURCE_2,
	MY_EPF_SOURCE_3
} from '../data/my-2026';

const rm = (n: number) => money(n);
/** Round up to the next ringgit, ignoring floating-point noise. */
const ceilRinggit = (x: number) => Math.ceil(Math.round(x * 1e6) / 1e6 - 1e-9);

export interface EpfShare {
	employee: number;
	employer: number;
}

/**
 * Monthly EPF contribution. Citizens under 60: read from the Third Schedule band (RM20 bands up to RM5,000, RM100 bands
 * up to RM20,000), which equals the percentage of the band's upper limit; above RM20,000 the percentage applies to the
 * wage. Foreign employees: 2% each on the wage. Everything is rounded up to the next ringgit.
 */
export function epfMonthly(wage: number, category: string): EpfShare {
	if (category === 'foreign') {
		const c = ceilRinggit((wage * MY_EPF_FOREIGN_PCT) / 100);
		return { employee: c, employer: c };
	}
	const base =
		wage <= MY_EPF_BAND_SMALL_LIMIT
			? Math.ceil(wage / MY_EPF_BAND_SMALL - 1e-9) * MY_EPF_BAND_SMALL
			: wage <= MY_EPF_BAND_LIMIT
				? Math.ceil(wage / MY_EPF_BAND_LARGE - 1e-9) * MY_EPF_BAND_LARGE
				: wage;
	const employerPct = wage <= MY_EPF_EMPLOYER_THRESHOLD ? MY_EPF_EMPLOYER_PCT_LOW : MY_EPF_EMPLOYER_PCT_HIGH;
	return { employee: ceilRinggit((base * MY_EPF_EMPLOYEE_PCT) / 100), employer: ceilRinggit((base * employerPct) / 100) };
}

const inputs: CalculatorInput[] = [
	{ id: 'wage', label: 'Monthly wages', type: 'number', default: 4_000, min: 20, max: 10_000_000, step: 100, prefix: '$', help: 'Your basic pay plus regular allowances and commission, before deductions.' },
	{
		id: 'who',
		label: 'Employee type',
		type: 'select',
		default: 'citizen',
		display: 'segmented',
		options: [
			{ label: 'Malaysian under 60', value: 'citizen' },
			{ label: 'Foreign employee', value: 'foreign' }
		],
		help: 'Foreign employees (not domestic helpers) pay 2% each from October 2025 wages.'
	},
	{ id: 'age', label: 'Your age now', type: 'number', default: 30, min: 16, max: 59, step: 1, decimal: false, suffix: 'years' },
	{ id: 'retire', label: 'Project savings to age', type: 'select', default: '55', display: 'segmented', options: [{ label: '55', value: '55' }, { label: '60', value: '60' }] },
	{ id: 'balance', label: 'EPF savings now', type: 'number', default: 20_000, min: 0, max: 1_000_000_000, step: 1000, prefix: '$' },
	{ id: 'raise', label: 'Yearly pay rise', type: 'number', default: 3, min: 0, max: 30, step: 0.5, suffix: '%' },
	{ id: 'dividend', label: 'Yearly dividend rate', type: 'number', default: MY_EPF_LATEST_DIVIDEND, min: 0, max: 20, step: 0.05, suffix: '%', help: `${MY_EPF_LATEST_DIVIDEND}% was declared for ${MY_EPF_LATEST_DIVIDEND_YEAR}. Future rates are not guaranteed.` }
];

function calculate(v: InputValues): CalculationResult {
	const wage = Number(v.wage);
	const age = Number(v.age);
	const retire = Number(v.retire);
	const balance = Number(v.balance);
	const raise = Number(v.raise);
	const dividend = Number(v.dividend);
	const who = String(v.who);
	if (!Number.isFinite(wage) || wage < 20 || wage > 10_000_000) {
		return { primaryResult: DASH, primaryLabel: 'Projected EPF savings', summary: 'Enter monthly wages of at least RM20.' };
	}
	if (who !== 'citizen' && who !== 'foreign') {
		return { primaryResult: DASH, primaryLabel: 'Projected EPF savings', summary: 'Choose an employee type.' };
	}
	if (![balance, raise, dividend].every((x) => Number.isFinite(x) && x >= 0) || raise > 30 || dividend > 20) {
		return { primaryResult: DASH, primaryLabel: 'Projected EPF savings', summary: 'Enter savings, pay rise and dividend rate as zero or more.' };
	}
	if (!Number.isFinite(age) || age < 16 || !(retire === 55 || retire === 60)) {
		return { primaryResult: DASH, primaryLabel: 'Projected EPF savings', summary: 'Enter your age and choose 55 or 60.' };
	}

	const now = epfMonthly(wage, who);
	const monthlyTotal = now.employee + now.employer;
	const years = Math.floor(retire - age);
	const base = {
		secondary: [
			{ label: 'Your contribution per month (employee)', value: rm(now.employee) },
			{ label: 'Employer contribution per month', value: rm(now.employer) },
			{ label: 'Total going into EPF per month', value: rm(monthlyTotal) },
			{ label: 'Total going into EPF per year', value: rm(monthlyTotal * 12) }
		]
	};
	if (years < 1) {
		return {
			primaryResult: rm(monthlyTotal),
			primaryLabel: 'EPF contributions per month',
			summary: `You are already at or past ${retire}, so there is nothing to project. This is what goes into EPF each month on today's wages.`,
			secondaryMetrics: base.secondary
		};
	}

	let bal = balance;
	let accrued = 0;
	let contributed = 0;
	let wageNow = wage;
	let plain = balance; // savings with contributions only, no dividends
	const data: Record<string, number>[] = [{ age, balance: Math.round(bal), contributions: Math.round(plain) }];
	for (let m = 0; m < years * 12; m++) {
		if (m > 0 && m % 12 === 0) wageNow = wage * Math.pow(1 + raise / 100, m / 12);
		const share = epfMonthly(Math.round(wageNow * 100) / 100, who);
		const c = share.employee + share.employer;
		accrued += (bal * dividend) / 100 / 12;
		bal += c;
		plain += c;
		contributed += c;
		if (m % 12 === 11) {
			bal += accrued;
			accrued = 0;
			data.push({ age: age + (m + 1) / 12, balance: Math.round(bal), contributions: Math.round(plain) });
		}
	}
	const dividends = bal - balance - contributed;

	return {
		primaryResult: rm(bal),
		primaryLabel: `Projected EPF savings at ${retire}`,
		summary: `${years} years of contributions (starting at ${rm(monthlyTotal)} a month) plus ${rm(dividends)} of dividends at ${pct(dividend, 2)} a year.`,
		secondaryMetrics: [
			...base.secondary,
			{ label: 'Contributions over the period', value: rm(contributed) },
			{ label: 'Dividends over the period', value: rm(dividends) },
			{ label: 'Years to go', value: num(years, 0) }
		],
		chart: {
			type: 'line',
			title: 'EPF savings by age',
			x: 'age',
			xLabel: 'Age',
			series: [
				{ key: 'balance', label: 'With dividends' },
				{ key: 'contributions', label: 'Contributions only' }
			],
			data,
			valueFormat: 'currency'
		}
	};
}

export default defineCalculator({
	meta,
	inputs,
	calculate,
	content: {
		intro: 'See how much you and your employer pay into EPF (KWSP) each month, and project your savings to age 55 or 60. It follows the EPF Third Schedule for Malaysians under 60 and the 2% rule for foreign employees.',
		howTo: [
			'Enter your monthly wages and choose Malaysian under 60 or foreign employee.',
			'Add your age, current EPF savings, expected yearly pay rise and dividend rate.',
			'Read the monthly contributions and the projected savings at 55 or 60.'
		],
		formulas: [
			{
				title: 'Monthly contribution (Malaysian under 60)',
				expression: 'Employee = 11% × wage · Employer = 13% × wage (wage ≤ RM5,000) or 12% × wage (above RM5,000), rounded up to the next ringgit',
				variables: [
					{ symbol: 'Wage band', meaning: 'Up to RM5,000 wages sit in RM20 bands and up to RM20,000 in RM100 bands, and the percentage is applied to the top of the band. Above RM20,000 it is applied to the actual wage' },
					{ symbol: 'Foreign employee', meaning: '2% employee and 2% employer on wages from October 2025, rounded up to the next ringgit' }
				]
			},
			{
				title: 'Projection',
				expression: 'Each month: dividend accrues on the balance at rate ÷ 12, contributions are added; the accrued dividend is credited every 12 months',
				variables: [{ symbol: 'Dividend', meaning: 'EPF actually credits dividends once a year on daily balances; this is a close monthly approximation' }]
			}
		],
		example: {
			title: 'Wages of RM4,000, age 30 to 55, RM20,000 saved, 3% pay rise, 6.15% dividend',
			steps: [
				'Employee: 11% × RM4,000 = RM440. Employer: 13% × RM4,000 = RM520. Together RM960 a month, or RM11,520 a year.',
				'Wages rise 3% each year, so the contributions grow with them.',
				'Contributions and dividends are added month by month for 25 years, starting from RM20,000.'
			],
			result: 'Projected EPF savings at 55: RM957,290.39 (RM409,860 contributions plus RM527,430.39 dividends)'
		},
		faq: [
			{ q: 'What are the EPF rates?', a: 'For Malaysians under 60 the employee pays 11% and the employer pays 13% of wages up to RM5,000 or 12% above that. Foreign employees and their employers pay 2% each from October 2025.' },
			{ q: 'Which dividend rate should I use?', a: 'EPF declared 6.15% for 2025 (6.30% for 2024). The rate changes every year and is not guaranteed, so try a lower figure too.' },
			{ q: 'What is not included?', a: 'Malaysians aged 60 and over, permanent residents who chose a different rate, voluntary contributions, withdrawals and the split between EPF accounts are not modelled.' }
		],
		sources: [MY_EPF_SOURCE, MY_EPF_SOURCE_2, MY_EPF_SOURCE_3, MY_EPF_FOREIGN_SOURCE, MY_EPF_DIVIDEND_SOURCE, MY_EPF_DIVIDEND_SOURCE_2],
		disclaimer: 'Projection for illustration only. Your actual EPF statement and the dividends EPF declares will differ.'
	}
});
