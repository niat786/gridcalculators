import { defineCalculator, type InputValues } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './sip-calculator.meta';

/**
 * Future value of a monthly SIP (systematic investment plan) with contributions at the START of each month:
 * FV = P × ((1 + i)ⁿ − 1) ÷ i × (1 + i), where i = annual rate ÷ 12 and n = months. i = 0 → P × n.
 * Checked against Bajaj AMC's documented example (₹15,000 a month, 12%, 15 years → ₹75,68,640)
 * and against the same formula evaluated by hand for ₹10,000 a month, 12%, 10 years (₹23,23,391).
 */
export function sipFutureValue(monthly: number, annualPct: number, months: number): number {
	const i = annualPct / 100 / 12;
	if (i === 0) return monthly * months;
	return monthly * ((Math.pow(1 + i, months) - 1) / i) * (1 + i);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'monthly', label: 'Monthly investment', type: 'number', default: 10000, min: 100, max: 10_000_000, step: 500, prefix: '$', suffix: '/mo' },
		{ id: 'rate', label: 'Expected annual return', type: 'number', default: 12, min: 0, max: 50, step: 0.1, suffix: '%', help: 'Average yearly return you expect' },
		{ id: 'years', label: 'Investment period', type: 'number', default: 10, min: 1, max: 50, step: 1, decimal: false, suffix: 'years' }
	],
	calculate(v: InputValues) {
		const monthly = Number(v.monthly);
		const rate = Number(v.rate);
		const years = Number(v.years);
		if (!(monthly > 0) || !Number.isFinite(monthly) || !(rate >= 0 && rate <= 50) || !(years >= 1 && years <= 50) || !Number.isInteger(years)) {
			return { primaryResult: DASH, primaryLabel: 'Maturity value', summary: 'Enter a monthly amount above zero, a return from 0% to 50%, and 1 to 50 years.' };
		}

		const months = years * 12;
		const maturity = Math.round(sipFutureValue(monthly, rate, months));
		const invested = Math.round(monthly * months);
		const returns = maturity - invested;

		const rows: Record<string, string>[] = [];
		const chartData: Record<string, number>[] = [{ year: 0, invested: 0, value: 0 }];
		for (let y = 1; y <= years; y++) {
			const yInvested = Math.round(monthly * 12 * y);
			const yValue = Math.round(sipFutureValue(monthly, rate, 12 * y));
			chartData.push({ year: y, invested: yInvested, value: yValue });
			rows.push({
				year: String(y),
				invested: money(yInvested, true),
				value: money(yValue, true),
				returns: money(yValue - yInvested, true)
			});
		}

		return {
			primaryResult: money(maturity, true),
			primaryLabel: 'Estimated maturity value',
			summary: `${money(monthly, true)} a month for ${plural(years, 'year')} at ${num(rate, 2)}% a year.`,
			secondaryMetrics: [
				{ label: 'Amount invested', value: money(invested, true) },
				{ label: 'Estimated returns', value: money(returns, true) },
				{ label: 'Number of instalments', value: plural(months, 'instalment') },
				{ label: 'Returns as % of invested', value: `${num((returns / invested) * 100, 1)}%` }
			],
			chart: {
				type: 'line',
				title: 'Amount invested and maturity value over time',
				x: 'year',
				xLabel: 'Year',
				series: [
					{ key: 'invested', label: 'Amount invested' },
					{ key: 'value', label: 'Estimated value' }
				],
				data: chartData,
				valueFormat: 'currency'
			},
			table: {
				title: 'Year-by-year growth',
				collapsed: true,
				columns: [
					{ key: 'year', label: 'Year' },
					{ key: 'invested', label: 'Invested', align: 'end' },
					{ key: 'value', label: 'Value', align: 'end' },
					{ key: 'returns', label: 'Returns', align: 'end' }
				],
				rows
			}
		};
	},
	content: {
		intro:
			'Estimate how much a monthly SIP could grow into over time. Enter the amount you invest each month, the return you expect and how many years you plan to invest.',
		howTo: [
			'Enter the amount you plan to invest every month.',
			'Enter the average annual return you expect. Use a realistic figure, not the best year you have seen.',
			'Enter the number of years you will keep investing.',
			'Read the maturity value, then open the year-by-year table to see how it builds up.'
		],
		formulas: [
			{
				title: 'SIP future value',
				expression: 'FV = P × ((1 + i)ⁿ − 1) ÷ i × (1 + i)',
				variables: [
					{ symbol: 'FV', meaning: 'maturity value at the end of the period' },
					{ symbol: 'P', meaning: 'amount invested each month' },
					{ symbol: 'i', meaning: 'monthly return (annual return ÷ 12 ÷ 100)' },
					{ symbol: 'n', meaning: 'number of monthly instalments (years × 12)' }
				]
			},
			{
				expression: 'Estimated returns = maturity value − amount invested, where amount invested = P × n',
				variables: []
			}
		],
		example: {
			title: '₹10,000 a month for 10 years at 12% a year',
			steps: [
				'Monthly return: i = 12 ÷ 12 ÷ 100 = 0.01',
				'Number of instalments: n = 10 × 12 = 120',
				'Growth factor: (1.01)¹²⁰ ≈ 3.300387, so (3.300387 − 1) ÷ 0.01 ≈ 230.0387',
				'Start-of-month adjustment: 230.0387 × 1.01 ≈ 232.3391',
				'FV = ₹10,000 × 232.3391 ≈ ₹23,23,391',
				'Amount invested = ₹10,000 × 120 = ₹12,00,000'
			],
			result: 'Maturity value ₹23,23,391. Amount invested ₹12,00,000. Estimated returns ₹11,23,391.'
		},
		faq: [
			{
				q: 'What is a SIP?',
				a: 'A systematic investment plan (SIP) is a way to invest a fixed amount in a mutual fund at regular intervals, usually monthly. It spreads your purchases over time instead of investing one lump sum.'
			},
			{
				q: 'Why does the calculator assume contributions at the start of the month?',
				a: 'SIP instalments are usually debited at the start of the month, so each one earns a full month of growth. This matches the standard SIP formula used by Indian fund houses.'
			},
			{
				q: 'Are the returns guaranteed?',
				a: 'No. The expected return is an assumption. Market-linked returns can be higher or lower in any period, and a SIP does not protect you from losses.'
			}
		],
		sources: [
			{
				title: 'Bajaj AMC — SIP calculator: estimate the future value of your SIP investments',
				url: 'https://www.bajajamc.com/knowledge-centre/sip-calculator-estimate-the-future-value-of-your-sip-investments'
			},
			{
				title: 'Aditya Birla Capital — SIP calculator (investor education)',
				url: 'https://mutualfund.adityabirlacapital.com/investor-education/sip-calculator'
			}
		],
		disclaimer:
			'This is an estimate for illustration only. It is not investment advice, and mutual fund returns are not guaranteed.'
	}
});
