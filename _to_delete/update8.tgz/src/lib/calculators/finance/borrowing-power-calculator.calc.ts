import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, pct } from '../format';
import meta from './borrowing-power-calculator.meta';
import {
	APRA_BUFFER_SOURCE,
	ATO_CUTS_SOURCE,
	ATO_RATES_SOURCE,
	SERVICEABILITY_BUFFER,
	helpRepayment,
	medicareLevy,
	residentTax
} from '../data/au-tax-2026-27';

/** Assumption (common lender practice, not a legal rule): 3.8% of each credit card limit counts as a monthly commitment. */
export const CARD_COMMITMENT_RATE = 0.038;

/** Yearly take-home pay for a resident: income tax after LITO, Medicare levy, and HELP if selected. */
export function netIncome(gross: number, hasHelp: boolean): number {
	return gross - residentTax(gross) - medicareLevy(gross) - (hasHelp ? helpRepayment(gross) : 0);
}

/** Present value of `payment` a month over `months` at an annual rate (percent). */
export function loanFromPayment(payment: number, annualRatePct: number, months: number): number {
	const r = annualRatePct / 100 / 12;
	if (r === 0) return payment * months;
	return (payment * (1 - Math.pow(1 + r, -months))) / r;
}

export function paymentFor(loan: number, annualRatePct: number, months: number): number {
	const r = annualRatePct / 100 / 12;
	if (r === 0) return loan / months;
	return (loan * r) / (1 - Math.pow(1 + r, -months));
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'income1', label: 'Your income (before tax)', type: 'number', default: 100000, min: 0, max: 100_000_000, step: 1000, prefix: '$', suffix: '/yr' },
		{ id: 'help1', label: 'You have a HELP / HECS debt', type: 'toggle', default: false },
		{ id: 'income2', label: 'Partner or co-borrower income', type: 'number', default: 0, min: 0, max: 100_000_000, step: 1000, prefix: '$', suffix: '/yr' },
		{ id: 'help2', label: 'They have a HELP / HECS debt', type: 'toggle', default: false, visibleWhen: (v) => Number(v.income2) > 0 },
		{ id: 'dependants', label: 'Dependants', type: 'number', default: 0, min: 0, max: 10, step: 1, decimal: false },
		{ id: 'expenses', label: 'Living expenses', type: 'number', default: 3000, min: 0, max: 1_000_000, step: 100, prefix: '$', suffix: '/mo', help: 'Everyday costs: food, utilities, transport, insurance, entertainment. Not debts.' },
		{ id: 'perDependant', label: 'Extra cost per dependant', type: 'number', default: 400, min: 0, max: 100_000, step: 50, prefix: '$', suffix: '/mo', visibleWhen: (v) => Number(v.dependants) > 0, help: 'An assumption. Lenders use their own benchmarks.' },
		{ id: 'debts', label: 'Existing loan repayments', type: 'number', default: 0, min: 0, max: 1_000_000, step: 50, prefix: '$', suffix: '/mo', help: 'Car loans, personal loans, buy-now-pay-later and other debts.' },
		{ id: 'cards', label: 'Credit card limits (total)', type: 'number', default: 0, min: 0, max: 10_000_000, step: 500, prefix: '$', help: 'Counted at 3.8% of the limit a month, used or not.' },
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 6, min: 0, max: 25, step: 0.05, suffix: '%', help: 'The loan\'s advertised rate. The buffer is added for you.' },
		{ id: 'term', label: 'Loan term', type: 'number', default: 30, min: 1, max: 40, step: 1, decimal: false, suffix: 'years' }
	],
	calculate(v): CalculationResult {
		const income1 = Number(v.income1);
		const income2 = Number(v.income2) || 0;
		const deps = Number(v.dependants) || 0;
		const exp = Number(v.expenses);
		const perDep = Number(v.perDependant) || 0;
		const debts = Number(v.debts) || 0;
		const cards = Number(v.cards) || 0;
		const rate = Number(v.rate);
		const term = Number(v.term);
		if (
			![income1, income2, exp, rate, term, deps, perDep, debts, cards].every(Number.isFinite) ||
			!(income1 > 0) || income2 < 0 || exp < 0 || deps < 0 || debts < 0 || cards < 0 || perDep < 0 ||
			!(rate >= 0 && rate <= 50) || !(term >= 1 && term <= 50)
		) {
			return { primaryResult: DASH, primaryLabel: 'Estimated maximum loan', summary: 'Enter your income, expenses, interest rate and loan term.' };
		}
		const netAnnual = netIncome(income1, v.help1 === true) + (income2 > 0 ? netIncome(income2, v.help2 === true) : 0);
		const netMonthly = netAnnual / 12;
		const living = exp + deps * perDep;
		const cardCommit = cards * CARD_COMMITMENT_RATE;
		const commitments = debts + cardCommit;
		const surplus = netMonthly - living - commitments;
		const assessed = rate + SERVICEABILITY_BUFFER;
		const months = term * 12;
		const maxLoan = surplus > 0 ? loanFromPayment(surplus, assessed, months) : 0;
		const actualPayment = maxLoan > 0 ? paymentFor(maxLoan, rate, months) : 0;
		return {
			primaryResult: money(maxLoan, true),
			primaryLabel: 'Estimated maximum loan',
			summary:
				surplus > 0
					? `Assessed at ${pct(assessed, 2)} (your ${pct(rate, 2)} plus a ${SERVICEABILITY_BUFFER}% buffer), you could service about ${money(surplus)} a month. Lenders differ, so treat this as a rough guide.`
					: 'Your expenses and commitments use up your take-home pay at the assessed rate, so this method gives no borrowing capacity.',
			secondaryMetrics: [
				{ label: 'Take-home income', value: `${money(netMonthly)}/mo` },
				{ label: 'Living expenses', value: `${money(living)}/mo` },
				{ label: 'Debt and card commitments', value: `${money(commitments)}/mo` },
				{ label: 'Spare for repayments', value: `${money(Math.max(0, surplus))}/mo` },
				{ label: 'Assessment rate', value: pct(assessed, 2) },
				{ label: `Repayment at ${num(rate, 2)}%`, value: `${money(actualPayment)}/mo` }
			]
		};
	},
	content: {
		intro:
			'Estimate how much you could borrow for a home in Australia. It takes your take-home pay, subtracts expenses and debts, and sizes a loan at your rate plus the 3% serviceability buffer APRA expects lenders to use.',
		howTo: [
			'Enter your income, and a partner\'s if you are borrowing together. Tick HELP if either of you has a study debt.',
			'Add monthly living expenses, dependants, existing loan repayments and your total credit card limits.',
			'Enter the interest rate and term. The result is the loan your spare cash could repay at the rate plus 3%.'
		],
		formulas: [
			{
				title: 'Method',
				expression: 'Spare = take-home − expenses − dependants − debts − 3.8% × card limits;  Loan = Spare × (1 − (1 + i)⁻ⁿ) ÷ i',
				variables: [
					{ symbol: 'i', meaning: '(interest rate + 3%) ÷ 12, the assessment rate per month' },
					{ symbol: 'n', meaning: 'number of monthly repayments (term × 12)' },
					{ symbol: 'take-home', meaning: '2026-27 resident income tax after the low income offset, Medicare levy and HELP repayment' }
				]
			}
		],
		example: {
			title: 'Income $100,000, expenses $3,000 a month, 6% for 30 years',
			steps: [
				'Take-home: $100,000 − $20,520 tax − $2,000 Medicare = $77,480 a year, or $6,456.67 a month',
				'Spare after $3,000 of expenses: $3,456.67 a month',
				'Assessed at 6% + 3% = 9% over 360 months, that repayment supports a loan of about $429,601'
			],
			result: '$429,601'
		},
		faq: [
			{
				q: 'What is the 3% buffer?',
				a: 'APRA tells lenders to check that you could still afford the loan if the interest rate were at least 3.0 percentage points higher than the actual rate. This calculator applies that buffer to the rate you enter.'
			},
			{
				q: 'Why will my bank give a different figure?',
				a: 'Lenders use their own expense benchmarks, rate floors, income shading, debt-to-income limits and credit card treatment. Treating 3.8% of each card limit as a monthly cost is a common but not universal assumption.'
			},
			{
				q: 'Is this the amount I should borrow?',
				a: 'No. It is the most this method says you could service. Borrowing less leaves room for rate rises and life changes.'
			}
		],
		sources: [APRA_BUFFER_SOURCE, ATO_RATES_SOURCE, ATO_CUTS_SOURCE],
		disclaimer: 'An estimate only, not a loan approval or financial advice. Lenders assess applications on their own criteria, and assumptions here (dependant cost, 3.8% card rate) are editable guesses.'
	}
});
