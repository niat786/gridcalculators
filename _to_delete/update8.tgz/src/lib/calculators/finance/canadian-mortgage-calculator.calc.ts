import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct, plural, num } from '../format';
import meta from './canadian-mortgage-calculator.meta';

type Frequency = 'monthly' | 'semi-monthly' | 'biweekly' | 'accel-biweekly' | 'weekly' | 'accel-weekly';

interface Schedule {
	label: string;
	/** Payments per year. */
	perYear: number;
	/** Accelerated plans pay the monthly amount divided by this number each payment. */
	accelDivisor?: number;
}

const SCHEDULES: Record<Frequency, Schedule> = {
	monthly: { label: 'Monthly', perYear: 12 },
	'semi-monthly': { label: 'Semi-monthly', perYear: 24 },
	biweekly: { label: 'Bi-weekly', perYear: 26 },
	'accel-biweekly': { label: 'Accelerated bi-weekly', perYear: 26, accelDivisor: 2 },
	weekly: { label: 'Weekly', perYear: 52 },
	'accel-weekly': { label: 'Accelerated weekly', perYear: 52, accelDivisor: 4 }
};

const AMORTIZATIONS = [15, 20, 25, 30];

/** Canadian fixed rates compound twice a year, so one period of t years grows by (1 + r/2)^(2t). */
function periodicRate(annualPct: number, paymentsPerYear: number): number {
	return Math.pow(1 + annualPct / 200, 2 / paymentsPerYear) - 1;
}

/** Payment that clears principal P at periodic rate i over n periods. */
function payment(principal: number, i: number, n: number): number {
	if (i === 0) return principal / n;
	return (principal * i) / (1 - Math.pow(1 + i, -n));
}

const isNum = (x: number, lo: number, hi: number) => Number.isFinite(x) && x >= lo && x <= hi;

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'price', label: 'Home price (CAD)', type: 'number', default: 500000, min: 1, max: 100_000_000, step: 1000, prefix: '$' },
		{ id: 'down', label: 'Down payment', type: 'number', default: 20, min: 0, max: 99.99, step: 0.5, suffix: '%' },
		{
			id: 'rate',
			label: 'Interest rate',
			type: 'number',
			default: 5,
			min: 0,
			max: 30,
			step: 0.01,
			suffix: '%',
			help: 'Annual rate, compounded semi-annually'
		},
		{
			id: 'amort',
			label: 'Amortization',
			type: 'select',
			display: 'segmented',
			default: '25',
			options: [
				{ label: '15 yr', value: '15' },
				{ label: '20 yr', value: '20' },
				{ label: '25 yr', value: '25' },
				{ label: '30 yr', value: '30' }
			]
		},
		{
			id: 'frequency',
			label: 'Payment frequency',
			type: 'select',
			display: 'menu',
			default: 'monthly',
			options: [
				{ label: 'Monthly', value: 'monthly' },
				{ label: 'Semi-monthly', value: 'semi-monthly' },
				{ label: 'Bi-weekly', value: 'biweekly' },
				{ label: 'Accelerated bi-weekly', value: 'accel-biweekly' },
				{ label: 'Weekly', value: 'weekly' },
				{ label: 'Accelerated weekly', value: 'accel-weekly' }
			]
		}
	],
	calculate(v): CalculationResult {
		const price = Number(v.price);
		const downPct = Number(v.down);
		const rate = Number(v.rate);
		const years = Number(v.amort);
		const sched = SCHEDULES[String(v.frequency) as Frequency];

		if (
			!isNum(price, 1, 1e9) ||
			!isNum(downPct, 0, 99.99) ||
			!isNum(rate, 0, 30) ||
			!AMORTIZATIONS.includes(years) ||
			!sched
		) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Estimated payment',
				summary: 'Enter a home price, a down payment below 100%, and an interest rate.'
			};
		}

		const loan = price * (1 - downPct / 100);
		const iMonthly = periodicRate(rate, 12);
		const monthly = payment(loan, iMonthly, years * 12);
		const i = periodicRate(rate, sched.perYear);
		const pay = sched.accelDivisor ? monthly / sched.accelDivisor : payment(loan, i, years * sched.perYear);

		// Walk the schedule so accelerated plans, which pay off early, report the real totals.
		const maxPeriods = years * sched.perYear;
		let balance = loan;
		let totalPaid = 0;
		let count = 0;
		while (count < maxPeriods && balance > 0.005) {
			const interest = balance * i;
			const paid = Math.min(pay, balance + interest);
			totalPaid += paid;
			balance = balance + interest - paid;
			count++;
		}
		const totalInterest = totalPaid - loan;
		const effectiveAnnual = (Math.pow(1 + rate / 200, 2) - 1) * 100;

		return {
			primaryResult: money(pay),
			primaryLabel: `${sched.label} payment`,
			summary: `CAD ${money(loan)} loan over ${plural(years, 'year')} at ${pct(rate, 2)}, compounded semi-annually.`,
			secondaryMetrics: [
				{ label: 'Loan amount (CAD)', value: money(loan) },
				{ label: 'Mortgage insurance (CMHC)', value: downPct < 20 ? 'Required, not included' : 'Not required' },
				{ label: 'Payments per year', value: num(sched.perYear) },
				{ label: 'Number of payments', value: num(count) },
				{ label: 'Total interest', value: money(totalInterest) },
				{ label: 'Total paid', value: money(totalPaid) },
				{ label: 'Effective annual rate', value: pct(effectiveAnnual, 2) }
			]
		};
	},
	content: {
		intro:
			'Estimate your Canadian mortgage payment in Canadian dollars. Compare monthly, bi-weekly and weekly schedules, including accelerated options, and see how much interest each one costs.',
		howTo: [
			'Enter the home price in Canadian dollars and the down payment as a percentage.',
			'Enter the fixed rate your lender quoted and choose an amortization period.',
			'Pick how often you will pay. Accelerated options pay off the loan sooner.',
			'Read the payment, then check the total interest and whether mortgage insurance applies.'
		],
		formulas: [
			{
				title: 'Effective monthly rate',
				expression: 'i = (1 + r ÷ 2)^(1/6) − 1',
				variables: [
					{ symbol: 'r', meaning: 'annual rate as a decimal, such as 0.05' },
					{ symbol: 'i', meaning: 'effective rate for one month, after semi-annual compounding' }
				]
			},
			{
				title: 'Payment for any frequency',
				expression: 'M = P × i ÷ (1 − (1 + i)⁻ⁿ)    where i = (1 + r ÷ 2)^(2 ÷ k) − 1',
				variables: [
					{ symbol: 'P', meaning: 'loan amount after the down payment' },
					{ symbol: 'k', meaning: 'payments per year (12 monthly, 24 semi-monthly, 26 bi-weekly, 52 weekly)' },
					{ symbol: 'n', meaning: 'amortization years multiplied by k' }
				]
			},
			{
				title: 'Accelerated payments',
				expression: 'Accelerated bi-weekly = monthly payment ÷ 2        Accelerated weekly = monthly payment ÷ 4',
				variables: [{ symbol: 'monthly payment', meaning: 'the payment for the same loan on a monthly schedule' }]
			}
		],
		example: {
			title: 'A $500,000 home with 20% down, 5% for 25 years, paid monthly',
			steps: [
				'Loan = $500,000 × (1 − 0.20) = $400,000',
				'Monthly rate: i = (1 + 0.05 ÷ 2)^(1/6) − 1 ≈ 0.41239%',
				'Payment: M = $400,000 × 0.0041239 ÷ (1 − 1.0041239⁻³⁰⁰) ≈ $2,326.42',
				'Total paid = $2,326.42 × 300 payments ≈ $697,925.98, so interest ≈ $297,925.98'
			],
			result: 'A monthly payment of $2,326.42 and total interest of $297,925.98 over 300 payments.'
		},
		faq: [
			{
				q: 'Why does semi-annual compounding matter?',
				a: 'Canadian fixed mortgage rates are usually quoted compounded semi-annually. That makes the effective rate slightly higher than the same rate compounded monthly, so this calculator uses that convention.'
			},
			{
				q: 'What is an accelerated payment?',
				a: 'An accelerated plan pays half the monthly amount every two weeks, or a quarter every week. Over a year that adds up to one extra monthly payment, which shortens the loan and cuts the interest.'
			},
			{
				q: 'When do I need CMHC mortgage insurance?',
				a: 'Mortgage default insurance, from CMHC or another approved insurer, is generally required when the down payment is less than 20% of the purchase price. The premium is not included in this estimate.'
			},
			{
				q: 'What is not included in the estimate?',
				a: 'Property tax, home insurance, closing costs and mortgage insurance premiums are not included. Add them to your budget when you plan a purchase.'
			}
		],
		sources: [
			{ title: 'Canada Mortgage and Housing Corporation', url: 'https://www.cmhc-schl.gc.ca/' },
			{ title: 'Government of Canada', url: 'https://www.canada.ca/' }
		],
		disclaimer:
			'Estimates only. Your lender sets the final rate, payment schedule and insurance premium, and property tax and fees are not included.'
	}
});
