import { defineCalculator, type InputValues } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './lumpsum-calculator.meta';

/**
 * Lumpsum future value with annual compounding: FV = P × (1 + r)ⁿ.
 * Bajaj AMC's documented example: ₹1,00,000 for 5 years at 12% → about ₹1.76 lakh (₹1,76,234 exact).
 */
export function lumpsumFutureValue(principal: number, annualPct: number, years: number): number {
	return principal * Math.pow(1 + annualPct / 100, years);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'amount', label: 'Amount invested', type: 'number', default: 100000, min: 1, max: 1_000_000_000_000, step: 1000, prefix: '$' },
		{ id: 'rate', label: 'Expected annual return', type: 'number', default: 12, min: 0, max: 50, step: 0.1, suffix: '%', help: 'Assumed yearly return, compounded once a year' },
		{ id: 'years', label: 'Investment period', type: 'number', default: 10, min: 1, max: 50, step: 1, decimal: false, suffix: 'years' }
	],
	calculate(v: InputValues) {
		const amount = Number(v.amount);
		const rate = Number(v.rate);
		const years = Number(v.years);
		if (!(amount > 0) || !Number.isFinite(amount) || !(rate >= 0 && rate <= 50) || !(years >= 1 && years <= 50) || !Number.isInteger(years)) {
			return { primaryResult: DASH, primaryLabel: 'Value at maturity', summary: 'Enter an amount above zero, a return from 0% to 50%, and 1 to 50 years.' };
		}

		const value = Math.round(lumpsumFutureValue(amount, rate, years));
		const invested = Math.round(amount);
		const gain = value - invested;

		const rows: Record<string, string>[] = [];
		const chartData: Record<string, number>[] = [];
		let prev = invested;
		for (let y = 0; y <= years; y++) {
			const yValue = y === 0 ? invested : Math.round(lumpsumFutureValue(amount, rate, y));
			chartData.push({ year: y, invested, value: yValue });
			if (y > 0) {
				rows.push({
					year: String(y),
					value: money(yValue, true),
					growth: money(yValue - prev, true)
				});
			}
			prev = yValue;
		}

		return {
			primaryResult: money(value, true),
			primaryLabel: 'Value at maturity',
			summary: `${money(invested, true)} left to grow for ${plural(years, 'year')} at ${num(rate, 2)}% a year.`,
			secondaryMetrics: [
				{ label: 'Amount invested', value: money(invested, true) },
				{ label: 'Estimated gain', value: money(gain, true) },
				{ label: 'Growth multiple', value: `${num(value / invested, 2)}×` },
				{ label: 'Total return', value: `${num((gain / invested) * 100, 1)}%` }
			],
			chart: {
				type: 'line',
				title: 'Amount invested and value over time',
				x: 'year',
				xLabel: 'Year',
				series: [
					{ key: 'invested', label: 'Amount invested' },
					{ key: 'value', label: 'Estimated value' }
				],
				data: chartData,
				valueFormat: 'currency'
			},
			table: {
				title: 'Year-by-year growth',
				collapsed: true,
				columns: [
					{ key: 'year', label: 'Year' },
					{ key: 'value', label: 'Value at year end', align: 'end' },
					{ key: 'growth', label: 'Growth in year', align: 'end' }
				],
				rows
			}
		};
	},
	content: {
		intro:
			'Estimate what a one-time investment could be worth after a number of years at a steady annual return. Use it for a single deposit or fund purchase, not a series of monthly payments.',
		howTo: [
			'Enter the amount you invest once, at the start.',
			'Enter the average annual return you expect.',
			'Enter how many years the money will stay invested.',
			'Read the value at maturity, then open the table to see the growth each year.'
		],
		formulas: [
			{
				title: 'Lumpsum future value',
				expression: 'FV = P × (1 + r)ⁿ',
				variables: [
					{ symbol: 'FV', meaning: 'value at the end of the period' },
					{ symbol: 'P', meaning: 'amount invested once' },
					{ symbol: 'r', meaning: 'annual return as a decimal (12% = 0.12)' },
					{ symbol: 'n', meaning: 'number of years' }
				]
			}
		],
		example: {
			title: '₹1,00,000 invested for 5 years at 12% a year',
			steps: [
				'Growth factor: (1 + 0.12)⁵ = 1.12⁵ ≈ 1.762342',
				'Value: FV = ₹1,00,000 × 1.762342 ≈ ₹1,76,234',
				'Estimated gain = ₹1,76,234 − ₹1,00,000 = ₹76,234'
			],
			result: 'Value at maturity ₹1,76,234. Estimated gain ₹76,234.'
		},
		faq: [
			{
				q: 'What is the difference between a lumpsum and a SIP?',
				a: 'A lumpsum is one investment made at the start. A SIP invests a smaller amount at regular intervals. A lumpsum has more time in the market from day one, while a SIP spreads the entry price over time.'
			},
			{
				q: 'Why is the return compounded once a year here?',
				a: 'The formula uses one annual rate and whole years, so each year the value grows by the full return. Investments that compound more often can end slightly higher at the same rate.'
			},
			{
				q: 'Does this include tax or fees?',
				a: 'No. The calculator does not deduct taxes, exit loads, charges or inflation. Subtract those yourself if you need a net figure.'
			}
		],
		sources: [
			{
				title: 'Bajaj AMC — Everything you must know about a lumpsum calculator',
				url: 'https://www.bajajamc.com/knowledge-centre/articles/everything-you-must-know-about-a-lumpsum-calculator'
			}
		],
		disclaimer:
			'This is an estimate for illustration only. It is not investment advice, and returns are not guaranteed.'
	}
});
