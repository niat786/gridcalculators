import { defineCalculator } from '../types';
import meta from './scientific-calculator.meta';

export default defineCalculator({
	meta,
	widget: { name: 'keypad', props: { mode: 'scientific' } },
	inputs: [],
	calculate: () => ({ primaryResult: '', primaryLabel: '' }),
	content: {
		intro:
			'A full scientific calculator in your browser: trigonometry in degrees or radians, logarithms, powers, roots, factorials and constants.',
		howTo: [
			'Choose DEG or RAD for angles (top right).',
			'Tap a function such as sin or √. It opens a bracket: type the value, then continue.',
			'Use xʸ for powers, x! for factorials and Ans to reuse the last answer.',
			'Press = or Enter. Missing closing brackets at the end are added for you.'
		],
		formulas: [
			{
				title: 'Degrees and radians',
				expression: 'radians = degrees × π ÷ 180',
				variables: []
			},
			{
				title: 'Logarithms',
				expression: 'log(x) = log₁₀(x)     ln(x) = logₑ(x)     logₐ(x) = ln(x) ÷ ln(a)',
				variables: []
			},
			{
				title: 'Factorial',
				expression: 'n! = n × (n − 1) × … × 2 × 1,   0! = 1',
				variables: []
			}
		],
		example: {
			title: 'Find the height of a ramp 10 m long at 30°',
			steps: ['Height = length × sin(angle)', 'Make sure the angle mode is DEG', 'Type 10 × sin(30) = 10 × 0.5'],
			result: 'The ramp rises 5 m.'
		},
		faq: [
			{
				q: 'Why does sin(30) give a strange answer?',
				a: 'Check the angle mode. In DEG mode sin(30) = 0.5. In RAD mode the 30 is read as 30 radians, giving about −0.988.'
			},
			{
				q: 'What is the difference between log and ln?',
				a: 'log is the base-10 logarithm (log(100) = 2). ln is the natural logarithm, base e ≈ 2.71828 (ln(e) = 1).'
			},
			{
				q: 'How do I calculate a cube or any power?',
				a: 'Use xʸ: type the base, tap xʸ, then the exponent. For example 2 xʸ 10 = 1,024. For squares, tap x².'
			},
			{
				q: 'What is the largest factorial it can calculate?',
				a: '170! is the largest factorial that fits in standard floating-point numbers (about 7.26 × 10³⁰⁶). Anything larger shows ∞.'
			}
		]
	}
});
