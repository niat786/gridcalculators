import { defineCalculator, type CalculationResult } from '../types';
import { DASH, num } from '../format';
import meta from './permutation-and-combination-calculator.meta';

const LIMIT = 1000;
const SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹';
const sup = (n: number) =>
	String(n)
		.split('')
		.map((d) => SUP[Number(d)])
		.join('');

/** nPr = n! ÷ (n − r)!, the product of the r largest factors of n. Exact. */
function perm(n: number, r: number): bigint {
	let p = BigInt(1);
	for (let i = 0; i < r; i++) p *= BigInt(n - i);
	return p;
}

/** nCr = n! ÷ (r! × (n − r)!), built up step by step so every step stays a whole number. */
function choose(m: number, k: number): bigint {
	if (k < 0 || k > m) return BigInt(0);
	const j = Math.min(k, m - k);
	let c = BigInt(1);
	for (let i = 1; i <= j; i++) c = (c * BigInt(m - j + i)) / BigInt(i);
	return c;
}

/** base^exp for whole numbers, exact. */
function power(base: number, exp: number): bigint {
	let p = BigInt(1);
	const b = BigInt(base);
	for (let i = 0; i < exp; i++) p *= b;
	return p;
}

/** Scientific form with four significant figures, e.g. 2.4329 × 10¹⁸. */
function sci(x: bigint): string {
	const s = x.toString();
	const frac = s.slice(1, 5).replace(/0+$/, '');
	return `${s[0]}${frac ? `.${frac}` : ''} × 10${sup(s.length - 1)}`;
}

/** Plain digits with commas up to 15 digits; scientific form beyond that. */
function show(x: bigint): string {
	const s = x.toString();
	return s.length > 15 ? sci(x) : num(Number(s), 0);
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'kind',
			label: 'Count',
			type: 'select',
			display: 'menu',
			default: 'perm',
			options: [
				{ label: 'Permutations, nPr (order matters, no repeats)', value: 'perm' },
				{ label: 'Combinations, nCr (order ignored, no repeats)', value: 'comb' },
				{ label: 'Permutations with repetition, nʳ', value: 'permRep' },
				{ label: 'Combinations with repetition', value: 'combRep' }
			]
		},
		{
			id: 'n',
			label: 'Total items n',
			type: 'number',
			default: 10,
			min: 0,
			max: LIMIT,
			decimal: false,
			help: 'A whole number from 0 to 1,000.'
		},
		{
			id: 'r',
			label: 'Items chosen r',
			type: 'number',
			default: 3,
			min: 0,
			max: LIMIT,
			decimal: false,
			help: 'A whole number from 0 up to n.'
		}
	],
	calculate(v): CalculationResult {
		const kind = String(v.kind);
		const n = Number(v.n);
		const r = Number(v.r);
		const labels: Record<string, string> = {
			perm: 'Permutations (nPr)',
			comb: 'Combinations (nCr)',
			permRep: 'Permutations with repetition (nʳ)',
			combRep: 'Combinations with repetition'
		};
		const fail = (summary: string): CalculationResult => ({
			primaryResult: DASH,
			primaryLabel: labels[kind] ?? labels.perm,
			summary
		});

		if (!(kind in labels)) return fail('Pick a kind of count.');
		const repeats = kind === 'permRep' || kind === 'combRep';
		if (!Number.isInteger(n) || !Number.isInteger(r) || n < 0 || n > LIMIT || r < 0 || r > LIMIT)
			return fail(`Enter whole numbers from 0 to ${num(LIMIT, 0)}.`);
		// Without repetition you can't pick more items than exist; with repetition you can.
		if (r > n && !repeats) return fail('Without repetition, r can’t be larger than n. Choose a “with repetition” option to pick items more than once.');

		const values = {
			perm: r > n ? BigInt(0) : perm(n, r),
			comb: r > n ? BigInt(0) : choose(n, r),
			permRep: power(n, r),
			combRep: r === 0 ? BigInt(1) : n === 0 ? BigInt(0) : choose(n + r - 1, r)
		};
		const working: Record<string, string> = {
			perm: `${num(n, 0)}! ÷ (${num(n, 0)} − ${num(r, 0)})!`,
			comb: `${num(n, 0)}! ÷ (${num(r, 0)}! × (${num(n, 0)} − ${num(r, 0)})!)`,
			permRep: `${num(n, 0)}^${num(r, 0)}`,
			combRep: `C(${num(n, 0)} + ${num(r, 0)} − 1, ${num(r, 0)})`
		};

		const chosen = values[kind as keyof typeof values];
		const exact = chosen.toString();
		const big = exact.length > 15;

		return {
			primaryResult: big ? exact : show(chosen),
			primaryLabel: labels[kind],
			...(big ? { long: true } : {}),
			summary: big ? `${working[kind]} is about ${sci(chosen)}` : `${working[kind]} = ${show(chosen)}`,
			secondaryMetrics: [
				{ label: 'Permutations nPr', value: show(values.perm) },
				{ label: 'Combinations nCr', value: show(values.comb) },
				{ label: 'With repetition nʳ', value: show(values.permRep) },
				{ label: 'With repetition C(n + r − 1, r)', value: show(values.combRep) }
			]
		};
	},
	content: {
		intro:
			'Count the arrangements or selections you can make from a set. Enter the total number of items and how many you pick, and get permutations (order matters) and combinations (order does not matter), with or without repetition.',
		howTo: [
			'Choose the kind of count: permutations if the order matters, combinations if it does not, and the repetition options if an item can be picked more than once.',
			'Enter n, the total number of items, as a whole number from 0 to 1,000.',
			'Enter r, how many you choose, as a whole number from 0 up to n. Read the result and the other three counts.'
		],
		formulas: [
			{
				title: 'Permutations',
				expression: 'nPr = n! ÷ (n − r)!',
				variables: [
					{ symbol: 'n', meaning: 'total number of items' },
					{ symbol: 'r', meaning: 'number of items chosen, in order' },
					{ symbol: '!', meaning: 'factorial, so 5! = 5 × 4 × 3 × 2 × 1 = 120' }
				]
			},
			{
				title: 'Combinations',
				expression: 'nCr = n! ÷ (r! × (n − r)!)',
				variables: [{ symbol: 'nCr', meaning: 'the number of ways to choose r items with the order ignored' }]
			},
			{
				title: 'With repetition',
				expression: 'nʳ = n × n × … × n (r times),   C(n + r − 1, r) = (n + r − 1)! ÷ (r! × (n − 1)!)',
				variables: [{ symbol: 'nʳ', meaning: 'ordered picks where an item can be chosen again each time' }]
			}
		],
		example: {
			title: 'Five-card hands from a 52-card deck',
			steps: [
				'Combinations: C(52, 5) = 52! ÷ (5! × 47!)',
				'Multiply the top five factors and divide by 5! = 120: (52 × 51 × 50 × 49 × 48) ÷ 120 = 2,598,960',
				'For comparison, the ordered count is 52 × 51 × 50 × 49 × 48 = 311,875,200 permutations'
			],
			result: 'There are 2,598,960 different five-card hands when order does not matter, and 311,875,200 when the order of the cards is counted.'
		},
		faq: [
			{
				q: 'What is the difference between a permutation and a combination?',
				a: 'A permutation counts arrangements where the order matters, such as first, second and third place. A combination counts groups where the order does not matter, such as a team.'
			},
			{
				q: 'Why does the calculator only accept r up to n?',
				a: 'Without repetition you cannot pick more items than you have, so r must be at most n. With repetition you can: choosing 3 scoops from 2 flavours with repeats allowed gives C(4, 3) = 4 options. n and r can each go up to 1,000.'
			},
			{
				q: 'Why does a large result show in scientific form?',
				a: 'Results with more than 15 digits are too long to read comfortably. The calculator shows the scientific form, and the exact digits below it, computed with whole-number arithmetic so nothing is rounded.'
			},
			{
				q: 'What does 0! equal?',
				a: 'By definition, 0! equals 1. That is why nPr and nCr equal 1 when r is 0: there is exactly one way to choose nothing.'
			}
		]
	}
});
