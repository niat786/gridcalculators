import { defineCalculator, type CalculationResult, type InputValues, type Table } from '../types';
import { DASH } from '../format';
import meta from './factor-calculator.meta';

const MAX_VALUE = 1e12;
/** Pairs shown in the table. A highly composite number can have thousands. */
const TABLE_LIMIT = 50;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'n',
			label: 'Whole number',
			type: 'number',
			default: 360,
			min: 1,
			max: MAX_VALUE,
			step: 1,
			decimal: false,
			help: 'From 1 to 1,000,000,000,000.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const n = Number(v.n);
		const label = 'All factors';
		if (!Number.isInteger(n) || n < 1 || n > MAX_VALUE) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter a whole number from 1 to 1,000,000,000,000.' };
		}

		// Trial division up to the square root finds every factor in pairs (i, n ÷ i).
		let root = Math.floor(Math.sqrt(n));
		while (root * root > n) root--;
		while ((root + 1) * (root + 1) <= n) root++;

		const small: number[] = [];
		const large: number[] = [];
		for (let i = 1; i <= root; i++) {
			if (n % i !== 0) continue;
			small.push(i);
			if (i * i !== n) large.push(n / i);
		}
		const factors = [...small, ...large.reverse()];
		const count = factors.length;
		const pairCount = small.length;
		const isPrime = count === 2;
		const isSquare = root * root === n;

		const rows = small.slice(0, TABLE_LIMIT).map((i) => ({ small: String(i), large: String(n / i) }));
		const table: Table = {
			title: `Factor pairs (${pairCount.toLocaleString('en-US')} in total${pairCount > TABLE_LIMIT ? `, first ${TABLE_LIMIT} shown` : ''})`,
			columns: [
				{ key: 'small', label: 'Smaller factor', align: 'end' },
				{ key: 'large', label: 'Larger factor', align: 'end' }
			],
			rows,
			collapsed: true
		};

		let summary: string;
		if (n === 1) summary = '1 is not prime. Its only factor is itself.';
		else if (isPrime) summary = `${n} is prime. Its only factors are 1 and ${n}.`;
		else summary = `${n} is composite. It has ${count.toLocaleString('en-US')} factors, which form ${pairCount.toLocaleString('en-US')} pairs whose product is ${n}.`;

		return {
			primaryResult: factors.join(', '),
			primaryLabel: label,
			long: count > 12,
			summary,
			secondaryMetrics: [
				{ label: 'Number of factors', value: String(count) },
				{ label: 'Factor pairs', value: String(pairCount) },
				{ label: 'Prime?', value: isPrime ? 'Yes' : 'No' },
				{ label: 'Perfect square?', value: isSquare ? 'Yes' : 'No' }
			],
			table
		};
	},
	content: {
		intro:
			'List every factor of a whole number, the numbers that divide it with no remainder. The calculator also shows the factor pairs, how many factors there are, and whether the number is prime.',
		howTo: [
			'Type a whole number from 1 up to 1,000,000,000,000.',
			'Read the full list of factors in ascending order, with the count and whether the number is prime.',
			'Open the factor pairs table to see each pair of factors that multiply to your number.'
		],
		formulas: [
			{
				title: 'Factor pairs',
				expression: 'If i × j = n, then i and j are a factor pair of n. Check each i from 1 up to √n.',
				variables: [
					{ symbol: 'n', meaning: 'The number you entered' },
					{ symbol: 'i', meaning: 'A candidate factor. It divides n when n ÷ i has no remainder' },
					{ symbol: '√n', meaning: 'The square root. Every pair has one factor at or below it, so you never need to test past it' }
				]
			},
			{
				title: 'Number of factors from prime factorization',
				expression: 'If n = p₁ᵃ × p₂ᵇ × … then the number of factors is (a + 1)(b + 1) …',
				variables: [
					{ symbol: 'p', meaning: 'A prime factor of n' },
					{ symbol: 'a, b', meaning: 'How many times each prime appears' }
				]
			}
		],
		example: {
			title: 'Factors of 36',
			steps: [
				'Test each i up to √36 = 6: 1, 2, 3, 4 and 6 divide 36 with no remainder.',
				'Each one gives a pair: 1 × 36, 2 × 18, 3 × 12, 4 × 9 and 6 × 6.',
				'The factors are 1, 2, 3, 4, 6, 9, 12, 18 and 36, so there are 9.',
				'36 is not prime, but it is a perfect square because 6 × 6 = 36.'
			],
			result: '36 has 9 factors: 1, 2, 3, 4, 6, 9, 12, 18, 36. It is not prime.'
		},
		faq: [
			{
				q: 'What is a factor?',
				a: 'A factor of a number is a whole number that divides it exactly, with no remainder. For example, 4 is a factor of 36 because 36 ÷ 4 = 9.'
			},
			{
				q: 'Is 1 a prime number?',
				a: 'No. A prime has exactly two factors, 1 and itself. The number 1 has only one factor, so it is not prime.'
			},
			{
				q: 'What is a factor pair?',
				a: 'A factor pair is two factors that multiply to give the number. For 36, the pairs are 1 × 36, 2 × 18, 3 × 12, 4 × 9 and 6 × 6.'
			}
		]
	}
});
