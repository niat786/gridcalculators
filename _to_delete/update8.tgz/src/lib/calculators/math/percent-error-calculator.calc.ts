import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num, pct } from '../format';
import meta from './percent-error-calculator.meta';

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'measured',
			label: 'Experimental (measured) value',
			type: 'number',
			default: 9.8,
			help: 'The value you got from your measurement.'
		},
		{
			id: 'accepted',
			label: 'Theoretical (true) value',
			type: 'number',
			default: 9.81,
			help: 'The accepted or expected value. It cannot be 0.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const m = Number(v.measured);
		const t = Number(v.accepted);
		const label = 'Percent error';

		if (!Number.isFinite(m) || !Number.isFinite(t)) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter a measured value and a theoretical value.' };
		}
		if (t === 0) {
			return {
				primaryResult: DASH,
				primaryLabel: label,
				summary: 'The theoretical value can’t be zero, because the error is divided by it.'
			};
		}

		const absolute = Math.abs(m - t);
		const error = (absolute / Math.abs(t)) * 100;
		const signed = ((m - t) / Math.abs(t)) * 100;

		return {
			primaryResult: pct(error, 4),
			primaryLabel: label,
			summary: `|${num(m, 6)} − ${num(t, 6)}| ÷ |${num(t, 6)}| × 100 = ${pct(error, 4)}`,
			secondaryMetrics: [
				{ label: 'Absolute error', value: num(absolute, 6) },
				{ label: 'Signed percent error', value: `${signed > 0 ? '+' : ''}${pct(signed, 4)}` },
				{
					label: 'Direction',
					value: m > t ? 'Measured value is higher' : m < t ? 'Measured value is lower' : 'Matches the true value'
				}
			]
		};
	},
	content: {
		intro:
			'Compare an experimental value with the true or accepted value. The percent error tells you how far off your measurement is, relative to the true value.',
		howTo: [
			'Enter the value you measured in the experimental box.',
			'Enter the accepted or theoretical value in the second box.',
			'Read the percent error. The signed value shows whether you were above or below the true value.'
		],
		formulas: [
			{
				title: 'Percent error',
				expression: 'Percent error = |Measured − True| ÷ |True| × 100',
				variables: [
					{ symbol: 'Measured', meaning: 'The experimental value' },
					{ symbol: 'True', meaning: 'The theoretical or accepted value' },
					{ symbol: '| |', meaning: 'Absolute value, which removes any minus sign' }
				]
			}
		],
		example: {
			title: 'Measured g of 9.8 m/s² against 9.81 m/s²',
			steps: [
				'Absolute error: |9.8 − 9.81| = 0.01',
				'Divide by the true value: 0.01 ÷ 9.81 = 0.00101937',
				'Multiply by 100: 0.00101937 × 100 = 0.1019%'
			],
			result: 'The percent error is 0.1019%.'
		},
		faq: [
			{
				q: 'What is a good percent error?',
				a: 'It depends on the experiment. A small percent error means the measurement is close to the accepted value. Acceptable limits depend on the equipment and the field, so check your course or lab guidelines.'
			},
			{
				q: 'What is the difference between percent error and percent difference?',
				a: 'Percent error compares a measurement with a known true value. Percent difference compares two measured values with each other, and uses their average as the base.'
			},
			{
				q: 'Why are the vertical bars used?',
				a: 'The bars make the error a size, not a direction. A reading 2 too high and a reading 2 too low both have an absolute error of 2.'
			}
		]
	}
});
