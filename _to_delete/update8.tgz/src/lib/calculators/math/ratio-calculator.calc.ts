import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num, pct } from '../format';
import meta from './ratio-calculator.meta';

const mode = (m: string) => (v: InputValues) => v.mode === m;

function gcd(a: number, b: number): number {
	let x = Math.abs(a);
	let y = Math.abs(b);
	while (y !== 0) {
		const t = x % y;
		x = y;
		y = t;
	}
	return x;
}

/**
 * Scale two positive numbers (up to six decimal places) to whole numbers, then divide out
 * their greatest common factor. Returns null when the values need more decimal places.
 */
function simplestRatio(a: number, b: number) {
	for (let k = 0; k <= 6; k++) {
		const scale = 10 ** k;
		const x = Math.round(a * scale);
		const y = Math.round(b * scale);
		if (Math.abs(x - a * scale) < 1e-7 && Math.abs(y - b * scale) < 1e-7) {
			const g = gcd(x, y);
			return { scale, x, y, g, p: x / g, q: y / g };
		}
	}
	return null;
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'What do you want to do?',
			type: 'select',
			display: 'segmented',
			default: 'simplify',
			options: [
				{ label: 'Simplify A : B', value: 'simplify' },
				{ label: 'Solve A : B = C : ?', value: 'solve' }
			]
		},
		{ id: 'a', label: 'Value A', type: 'number', default: 12, min: 0, help: 'Whole numbers or decimals.' },
		{ id: 'b', label: 'Value B', type: 'number', default: 18, min: 0 },
		{
			id: 'c',
			label: 'Value C',
			type: 'number',
			default: 8,
			min: 0,
			help: 'The first value of the second ratio. Its partner is the missing value.',
			visibleWhen: mode('solve')
		}
	],
	calculate(v: InputValues): CalculationResult {
		const a = Number(v.a);
		const b = Number(v.b);
		const solve = v.mode === 'solve';
		const label = solve ? 'Missing value (?)' : 'Simplest ratio';

		if (!Number.isFinite(a) || !Number.isFinite(b) || a <= 0 || b <= 0) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter two values greater than zero.' };
		}

		if (solve) {
			const c = Number(v.c);
			if (!Number.isFinite(c) || c < 0) {
				return { primaryResult: DASH, primaryLabel: label, summary: 'Enter a value for C, zero or more.' };
			}
			const d = (b * c) / a;
			const simple = simplestRatio(a, b);
			return {
				primaryResult: num(d, 6),
				primaryLabel: label,
				summary: `${num(a, 6)} : ${num(b, 6)} = ${num(c, 6)} : ?, so ? = ${num(b, 6)} × ${num(c, 6)} ÷ ${num(a, 6)} = ${num(d, 6)}.`,
				secondaryMetrics: [
					{ label: 'Completed ratio', value: `${num(a, 6)} : ${num(b, 6)} = ${num(c, 6)} : ${num(d, 6)}` },
					{ label: 'Scale factor (C ÷ A)', value: num(c / a, 6) },
					{ label: 'A : B simplified', value: simple ? `${simple.p} : ${simple.q}` : DASH }
				]
			};
		}

		const simple = simplestRatio(a, b);
		if (!simple) return { primaryResult: DASH, primaryLabel: label, summary: 'Use no more than six decimal places.' };
		const { scale, x, y, g, p, q } = simple;

		let summary: string;
		if (scale === 1 && g === 1) summary = 'Both values are whole and already share no common factor.';
		else if (scale === 1) summary = `Divide both values by their greatest common factor, ${num(g, 0)}.`;
		else if (g === 1) summary = `Multiply both by ${num(scale, 0)} to get ${num(x, 0)} : ${num(y, 0)}, which has no common factor.`;
		else summary = `Multiply both by ${num(scale, 0)} to get ${num(x, 0)} : ${num(y, 0)}, then divide both by ${num(g, 0)}.`;

		return {
			primaryResult: `${p}:${q}`,
			primaryLabel: label,
			summary,
			secondaryMetrics: [
				{ label: 'Decimal (A ÷ B)', value: num(a / b, 6) },
				{ label: 'Share of A', value: pct((a / (a + b)) * 100, 2) },
				{ label: 'Share of B', value: pct((b / (a + b)) * 100, 2) }
			]
		};
	},
	content: {
		intro:
			'Simplify a ratio to its lowest whole-number terms, or solve a proportion to find the missing value. Works with whole numbers and decimals.',
		howTo: [
			'Choose whether you want to simplify A : B or solve A : B = C : ?.',
			'Enter Value A and Value B. For a proportion, also enter Value C.',
			'The simplest ratio, or the missing value, updates as you type.'
		],
		formulas: [
			{
				title: 'Simplify a ratio',
				expression: 'A : B = (A ÷ g) : (B ÷ g), where g is the greatest common factor of A and B',
				variables: [{ symbol: 'g', meaning: 'The largest whole number that divides both A and B' }]
			},
			{
				title: 'Solve a proportion',
				expression: 'A : B = C : D, so D = B × C ÷ A',
				variables: [
					{ symbol: 'D', meaning: 'The missing value' },
					{ symbol: 'C', meaning: 'The first value of the second ratio' }
				]
			}
		],
		example: {
			title: 'Simplify 12 : 18',
			steps: ['The greatest common factor of 12 and 18 is 6.', '12 ÷ 6 = 2 and 18 ÷ 6 = 3', 'So 12 : 18 is the same ratio as 2 : 3.'],
			result: 'The simplest form of 12 : 18 is 2 : 3.'
		},
		faq: [
			{
				q: 'How do I simplify a ratio with decimals?',
				a: 'Multiply both numbers by a power of 10 until they are whole, then divide both by their greatest common factor. For example, 0.5 : 0.75 becomes 50 : 75, and dividing by 25 gives 2 : 3.'
			},
			{
				q: 'How do I solve a proportion?',
				a: 'Cross-multiply. If A : B = C : D, then A × D = B × C, so D = B × C ÷ A. For example, in 2 : 3 = 4 : ?, the missing value is 3 × 4 ÷ 2 = 6.'
			},
			{
				q: 'Is a ratio the same as a fraction?',
				a: 'They are related but not the same. A ratio compares two quantities, such as 2 boys to 3 girls. A fraction describes one part of a whole. Both can be simplified in the same way.'
			}
		]
	}
});
