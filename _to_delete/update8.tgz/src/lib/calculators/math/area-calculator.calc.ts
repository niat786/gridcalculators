import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './area-calculator.meta';

const is = (...shapes: string[]) => (v: InputValues) => shapes.includes(String(v.shape));
const positive = (...xs: number[]) => xs.every((x) => Number.isFinite(x) && x > 0);

const ramanujanPerimeter = (a: number, b: number) =>
	Math.PI * (3 * (a + b) - Math.sqrt((3 * a + b) * (a + 3 * b)));

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'shape',
			label: 'Shape',
			type: 'select',
			display: 'menu',
			default: 'rectangle',
			options: [
				{ label: 'Rectangle', value: 'rectangle' },
				{ label: 'Square', value: 'square' },
				{ label: 'Triangle', value: 'triangle' },
				{ label: 'Circle', value: 'circle' },
				{ label: 'Ellipse', value: 'ellipse' },
				{ label: 'Trapezoid', value: 'trapezoid' },
				{ label: 'Parallelogram', value: 'parallelogram' },
				{ label: 'Sector (pie slice)', value: 'sector' }
			]
		},
		{ id: 'length', label: 'Length', type: 'number', default: 12, min: 0, visibleWhen: is('rectangle') },
		{ id: 'width', label: 'Width', type: 'number', default: 8, min: 0, visibleWhen: is('rectangle') },
		{ id: 'side', label: 'Side', type: 'number', default: 6, min: 0, visibleWhen: is('square') },
		{
			id: 'base',
			label: 'Base',
			type: 'number',
			default: 10,
			min: 0,
			visibleWhen: is('triangle', 'parallelogram')
		},
		{
			id: 'height',
			label: 'Height',
			type: 'number',
			default: 6,
			min: 0,
			help: 'Perpendicular height, measured straight up from the base.',
			visibleWhen: is('triangle', 'parallelogram', 'trapezoid')
		},
		{ id: 'p1', label: 'Parallel side 1', type: 'number', default: 12, min: 0, visibleWhen: is('trapezoid') },
		{ id: 'p2', label: 'Parallel side 2', type: 'number', default: 8, min: 0, visibleWhen: is('trapezoid') },
		{ id: 'radius', label: 'Radius', type: 'number', default: 5, min: 0, visibleWhen: is('circle', 'sector') },
		{
			id: 'semiMajor',
			label: 'Semi-major axis',
			type: 'number',
			default: 8,
			min: 0,
			help: 'Half of the longest width.',
			visibleWhen: is('ellipse')
		},
		{
			id: 'semiMinor',
			label: 'Semi-minor axis',
			type: 'number',
			default: 5,
			min: 0,
			help: 'Half of the shortest width.',
			visibleWhen: is('ellipse')
		},
		{
			id: 'angle',
			label: 'Angle',
			type: 'number',
			default: 90,
			min: 0,
			max: 360,
			suffix: '°',
			visibleWhen: is('sector')
		}
	],
	calculate(v): CalculationResult {
		const shape = String(v.shape);
		const n = (k: string) => Number(v[k]);
		const pi = Math.PI;
		const NEEDS_SIDES = 'Needs all side lengths';

		let area: number;
		let perimeter: number | undefined;
		let working: string;

		switch (shape) {
			case 'rectangle': {
				const l = n('length');
				const w = n('width');
				if (!positive(l, w)) return fail('Enter a length and width greater than zero.');
				area = l * w;
				perimeter = 2 * (l + w);
				working = `${num(l, 4)} × ${num(w, 4)} = ${num(area, 4)}`;
				break;
			}
			case 'square': {
				const s = n('side');
				if (!positive(s)) return fail('Enter a side length greater than zero.');
				area = s * s;
				perimeter = 4 * s;
				working = `${num(s, 4)}² = ${num(area, 4)}`;
				break;
			}
			case 'triangle': {
				const b = n('base');
				const h = n('height');
				if (!positive(b, h)) return fail('Enter a base and height greater than zero.');
				area = (b * h) / 2;
				working = `½ × ${num(b, 4)} × ${num(h, 4)} = ${num(area, 4)}`;
				break;
			}
			case 'circle': {
				const r = n('radius');
				if (!positive(r)) return fail('Enter a radius greater than zero.');
				area = pi * r * r;
				perimeter = 2 * pi * r;
				working = `π × ${num(r, 4)}² = ${num(area, 4)}`;
				break;
			}
			case 'ellipse': {
				const a = n('semiMajor');
				const b = n('semiMinor');
				if (!positive(a, b)) return fail('Enter both axes greater than zero.');
				area = pi * a * b;
				perimeter = ramanujanPerimeter(a, b);
				working = `π × ${num(a, 4)} × ${num(b, 4)} = ${num(area, 4)}`;
				break;
			}
			case 'trapezoid': {
				const p1 = n('p1');
				const p2 = n('p2');
				const h = n('height');
				if (!positive(p1, p2, h)) return fail('Enter both parallel sides and the height.');
				area = ((p1 + p2) / 2) * h;
				working = `½ × (${num(p1, 4)} + ${num(p2, 4)}) × ${num(h, 4)} = ${num(area, 4)}`;
				break;
			}
			case 'parallelogram': {
				const b = n('base');
				const h = n('height');
				if (!positive(b, h)) return fail('Enter a base and height greater than zero.');
				area = b * h;
				working = `${num(b, 4)} × ${num(h, 4)} = ${num(area, 4)}`;
				break;
			}
			case 'sector': {
				const r = n('radius');
				const t = n('angle');
				if (!positive(r)) return fail('Enter a radius greater than zero.');
				if (!(t > 0 && t <= 360)) return fail('Enter an angle above 0° and up to 360°.');
				area = (t / 360) * pi * r * r;
				perimeter = 2 * r + (t / 360) * 2 * pi * r;
				working = `(${num(t, 4)} ÷ 360) × π × ${num(r, 4)}² = ${num(area, 4)}`;
				break;
			}
			default:
				return fail('Pick a shape.');
		}

		return {
			primaryResult: num(area, 4),
			primaryLabel: 'Area',
			summary: working,
			secondaryMetrics: [
				{ label: 'Perimeter', value: perimeter === undefined ? NEEDS_SIDES : num(perimeter, 4) }
			]
		};
	},
	content: {
		intro:
			'Work out the area and, where it applies, the perimeter of common flat shapes. Pick a shape, enter its measurements, and the working appears as you type.',
		howTo: [
			'Choose the shape from the list.',
			'Enter the measurements that the form asks for. Use the same unit for every length.',
			'Read the area in square units, and the perimeter in the same units as the lengths.'
		],
		formulas: [
			{ title: 'Rectangle', expression: 'Area = length × width,   Perimeter = 2 × (length + width)', variables: [] },
			{ title: 'Square', expression: 'Area = side²,   Perimeter = 4 × side', variables: [] },
			{ title: 'Triangle', expression: 'Area = ½ × base × height', variables: [] },
			{ title: 'Circle', expression: 'Area = π × r²,   Perimeter = 2 × π × r', variables: [{ symbol: 'r', meaning: 'radius' }] },
			{
				title: 'Ellipse',
				expression: 'Area = π × a × b,   Perimeter ≈ π × [3(a + b) − √((3a + b)(a + 3b))]',
				variables: [
					{ symbol: 'a', meaning: 'semi-major axis' },
					{ symbol: 'b', meaning: 'semi-minor axis' }
				]
			},
			{ title: 'Trapezoid', expression: 'Area = ½ × (a + b) × height', variables: [{ symbol: 'a, b', meaning: 'the two parallel sides' }] },
			{ title: 'Parallelogram', expression: 'Area = base × height', variables: [] },
			{
				title: 'Sector',
				expression: 'Area = (θ ÷ 360) × π × r²,   Perimeter = 2r + (θ ÷ 360) × 2 × π × r',
				variables: [{ symbol: 'θ', meaning: 'angle in degrees' }]
			}
		],
		example: {
			title: 'A rectangular patio that is 4.5 m by 3.2 m',
			steps: ['Area: 4.5 × 3.2 = 14.4', 'Perimeter: 2 × (4.5 + 3.2) = 15.4'],
			result: 'The patio covers 14.4 square metres and needs 15.4 metres of edging.'
		},
		faq: [
			{
				q: 'What is the difference between area and perimeter?',
				a: 'Area measures the space inside a shape, in square units. Perimeter measures the distance around its outside edge, in ordinary units.'
			},
			{
				q: 'Why is the triangle height not the slanted side?',
				a: 'The height is measured straight up from the base at a right angle. A slanted side is longer than the height unless the triangle is a right triangle.'
			},
			{
				q: 'Why does the calculator not show a perimeter for a triangle or trapezoid?',
				a: 'Those perimeters need every side length, and the base and height alone do not give them. Enter all sides yourself to work the perimeter out by adding them up.'
			}
		]
	}
});

function fail(summary: string): CalculationResult {
	return { primaryResult: DASH, primaryLabel: 'Area', summary };
}
