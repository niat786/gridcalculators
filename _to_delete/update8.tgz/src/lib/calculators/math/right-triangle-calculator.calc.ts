import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './right-triangle-calculator.meta';

const DEG = 180 / Math.PI;
const RAD = Math.PI / 180;

const is = (...modes: string[]) => (v: InputValues) => modes.includes(String(v.known));
const positive = (...xs: number[]) => xs.every((x) => Number.isFinite(x) && x > 0);
const acute = (x: number) => Number.isFinite(x) && x > 0 && x < 90;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'known',
			label: 'I know',
			type: 'select',
			display: 'menu',
			default: 'legs',
			options: [
				{ label: 'Two legs', value: 'legs' },
				{ label: 'A leg and the hypotenuse', value: 'legHyp' },
				{ label: 'A leg and an acute angle', value: 'legAngle' },
				{ label: 'The hypotenuse and an acute angle', value: 'hypAngle' }
			]
		},
		{ id: 'a', label: 'Leg a', type: 'number', default: 3, min: 0, visibleWhen: is('legs') },
		{ id: 'b', label: 'Leg b', type: 'number', default: 4, min: 0, visibleWhen: is('legs') },
		{
			id: 'legSide',
			label: 'Known leg',
			type: 'select',
			display: 'segmented',
			default: 'a',
			options: [
				{ label: 'Leg a', value: 'a' },
				{ label: 'Leg b', value: 'b' }
			],
			visibleWhen: is('legHyp', 'legAngle')
		},
		{
			id: 'leg',
			label: 'Known leg length',
			type: 'number',
			default: 3,
			min: 0,
			visibleWhen: is('legHyp', 'legAngle')
		},
		{
			id: 'c',
			label: 'Hypotenuse c',
			type: 'number',
			default: 5,
			min: 0,
			help: 'The longest side, opposite the right angle.',
			visibleWhen: is('legHyp', 'hypAngle')
		},
		{
			id: 'angle',
			label: 'Angle A',
			type: 'number',
			default: 30,
			min: 0,
			max: 90,
			suffix: '°',
			help: 'Acute angle A, opposite leg a. Enter a value above 0 and below 90.',
			visibleWhen: is('legAngle', 'hypAngle')
		}
	],
	calculate(v): CalculationResult {
		const known = String(v.known);
		const n = (k: string) => Number(v[k]);
		const fail = (summary: string): CalculationResult => ({
			primaryResult: DASH,
			primaryLabel: 'Hypotenuse c',
			summary
		});

		let a: number;
		let b: number;
		let c: number;
		let working: string;
		const angleIn = n('angle');
		const leg = n('leg');
		const legIsB = String(v.legSide) === 'b';

		switch (known) {
			case 'legs': {
				a = n('a');
				b = n('b');
				if (!positive(a, b)) return fail('Enter both legs greater than zero.');
				c = Math.hypot(a, b);
				working = `√(${num(a, 4)}² + ${num(b, 4)}²) = ${num(c, 4)}`;
				break;
			}
			case 'legHyp': {
				c = n('c');
				if (!positive(leg, c)) return fail('Enter the known leg and the hypotenuse, both greater than zero.');
				if (c <= leg) return fail('The hypotenuse must be longer than the leg you know.');
				const other = Math.sqrt(c * c - leg * leg);
				if (legIsB) {
					b = leg;
					a = other;
					working = `Missing leg a: √(${num(c, 4)}² − ${num(leg, 4)}²) = ${num(other, 4)}`;
				} else {
					a = leg;
					b = other;
					working = `Missing leg b: √(${num(c, 4)}² − ${num(leg, 4)}²) = ${num(other, 4)}`;
				}
				break;
			}
			case 'legAngle': {
				if (!positive(leg) || !acute(angleIn)) return fail('Enter a leg above zero and an angle between 0° and 90°.');
				const t = angleIn * RAD;
				if (legIsB) {
					b = leg;
					a = leg * Math.tan(t);
					c = leg / Math.cos(t);
					working = `Hypotenuse: ${num(leg, 4)} ÷ cos ${num(angleIn, 4)}° = ${num(c, 4)}`;
				} else {
					a = leg;
					b = leg / Math.tan(t);
					c = leg / Math.sin(t);
					working = `Hypotenuse: ${num(leg, 4)} ÷ sin ${num(angleIn, 4)}° = ${num(c, 4)}`;
				}
				break;
			}
			case 'hypAngle': {
				c = n('c');
				if (!positive(c) || !acute(angleIn)) return fail('Enter a hypotenuse above zero and an angle between 0° and 90°.');
				const t = angleIn * RAD;
				a = c * Math.sin(t);
				b = c * Math.cos(t);
				working = `Legs: ${num(c, 4)} × sin ${num(angleIn, 4)}° = ${num(a, 4)} and ${num(c, 4)} × cos ${num(angleIn, 4)}° = ${num(b, 4)}`;
				break;
			}
			default:
				return fail('Pick what you know about the triangle.');
		}

		const angleA = Math.atan2(a, b) * DEG;
		const angleB = Math.atan2(b, a) * DEG;
		const area = (a * b) / 2;
		const perimeter = a + b + c;
		const height = (a * b) / c;

		return {
			primaryResult: num(c, 4),
			primaryLabel: 'Hypotenuse c',
			summary: working,
			secondaryMetrics: [
				{ label: 'Leg a', value: num(a, 4) },
				{ label: 'Leg b', value: num(b, 4) },
				{ label: 'Angle A (opposite a)', value: `${num(angleA, 4)}°` },
				{ label: 'Angle B (opposite b)', value: `${num(angleB, 4)}°` },
				{ label: 'Area', value: num(area, 4) },
				{ label: 'Perimeter', value: num(perimeter, 4) },
				{ label: 'Height to hypotenuse', value: num(height, 4) }
			]
		};
	},
	content: {
		intro:
			'Solve a right triangle, a triangle with one 90° angle. Pick what you already know, enter it, and get every side, both acute angles, the area, the perimeter and the height to the hypotenuse.',
		howTo: [
			'Choose what you know: two legs, a leg and the hypotenuse, a leg and an acute angle, or the hypotenuse and an acute angle.',
			'Enter the measurements. For a leg, pick whether it is leg a or leg b. Angles are in degrees.',
			'Read the hypotenuse, the missing leg, both acute angles, the area, the perimeter and the height to the hypotenuse.'
		],
		formulas: [
			{
				title: 'Pythagorean theorem',
				expression: 'a² + b² = c²',
				variables: [
					{ symbol: 'a, b', meaning: 'the two legs, which meet at the right angle' },
					{ symbol: 'c', meaning: 'the hypotenuse, opposite the right angle' }
				]
			},
			{
				title: 'Acute angles',
				expression: 'tan A = a ÷ b,   sin A = a ÷ c,   cos A = b ÷ c,   A + B = 90°',
				variables: [
					{ symbol: 'A, B', meaning: 'the two acute angles; A is opposite leg a and B is opposite leg b' }
				]
			},
			{
				title: 'Area, perimeter and height',
				expression: 'Area = ½ × a × b,   Perimeter = a + b + c,   Height to hypotenuse h = a × b ÷ c',
				variables: [{ symbol: 'h', meaning: 'the distance from the right-angle corner to the hypotenuse' }]
			}
		],
		example: {
			title: 'A roof brace with legs of 8 ft and 15 ft',
			steps: [
				'Hypotenuse: c = √(8² + 15²) = √289 = 17',
				'Angle A: arctan(8 ÷ 15) = 28.0725°. Angle B = 90° − 28.0725° = 61.9275°',
				'Area: ½ × 8 × 15 = 60. Perimeter: 8 + 15 + 17 = 40',
				'Height to hypotenuse: 8 × 15 ÷ 17 = 7.0588'
			],
			result:
				'The brace is 17 ft long. Its acute angles are 28.0725° and 61.9275°, its area is 60 square ft and its perimeter is 40 ft.'
		},
		faq: [
			{
				q: 'Which side is the hypotenuse?',
				a: 'The hypotenuse is the side opposite the right angle. It is always the longest side, so it is the only side that can be longer than both legs.'
			},
			{
				q: 'Why does a known leg need a longer hypotenuse?',
				a: 'A leg is always shorter than the hypotenuse. If the hypotenuse you enter is not longer than the known leg, no right triangle can exist and the calculator says so.'
			},
			{
				q: 'Do the two acute angles add up to 90 degrees?',
				a: 'Yes. The two acute angles in any right triangle always add up to 90°, so the calculator shows them to four decimal places and they sum to 90.'
			},
			{
				q: 'What is the height to the hypotenuse?',
				a: 'It is the perpendicular distance from the right-angle corner to the hypotenuse. It equals the area times 2, divided by the hypotenuse.'
			}
		]
	}
});
