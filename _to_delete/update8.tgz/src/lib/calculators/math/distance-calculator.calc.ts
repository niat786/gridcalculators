import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './distance-calculator.meta';

const is3d = (v: InputValues) => String(v.mode) === '3d';

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Dimensions',
			type: 'select',
			display: 'segmented',
			default: '2d',
			options: [
				{ label: '2D', value: '2d' },
				{ label: '3D', value: '3d' }
			]
		},
		{ id: 'x1', label: 'x₁', type: 'number', default: 1, width: 'half' },
		{ id: 'y1', label: 'y₁', type: 'number', default: 2, width: 'half' },
		{ id: 'z1', label: 'z₁', type: 'number', default: 3, width: 'half', visibleWhen: is3d },
		{ id: 'x2', label: 'x₂', type: 'number', default: 4, width: 'half' },
		{ id: 'y2', label: 'y₂', type: 'number', default: 6, width: 'half' },
		{ id: 'z2', label: 'z₂', type: 'number', default: 15, width: 'half', visibleWhen: is3d }
	],
	calculate(v): CalculationResult {
		const threeD = is3d(v);
		const n = (k: string) => Number(v[k]);
		const fail = (summary: string): CalculationResult => ({
			primaryResult: DASH,
			primaryLabel: 'Distance',
			summary
		});

		const x1 = n('x1');
		const y1 = n('y1');
		const x2 = n('x2');
		const y2 = n('y2');
		const z1 = threeD ? n('z1') : 0;
		const z2 = threeD ? n('z2') : 0;
		const all = threeD ? [x1, y1, z1, x2, y2, z2] : [x1, y1, x2, y2];
		if (!all.every(Number.isFinite)) return fail('Enter a number for every coordinate.');

		const dx = x2 - x1;
		const dy = y2 - y1;
		const dz = z2 - z1;
		const distance = threeD ? Math.hypot(dx, dy, dz) : Math.hypot(dx, dy);
		const mid = threeD
			? `(${num((x1 + x2) / 2, 4)}, ${num((y1 + y2) / 2, 4)}, ${num((z1 + z2) / 2, 4)})`
			: `(${num((x1 + x2) / 2, 4)}, ${num((y1 + y2) / 2, 4)})`;

		const working = threeD
			? `√(${num(Math.abs(dx), 4)}² + ${num(Math.abs(dy), 4)}² + ${num(Math.abs(dz), 4)}²) = ${num(distance, 4)}`
			: `√(${num(Math.abs(dx), 4)}² + ${num(Math.abs(dy), 4)}²) = ${num(distance, 4)}`;

		const slope = dx === 0 ? 'Undefined (vertical line)' : num(dy / dx, 4);

		return {
			primaryResult: num(distance, 4),
			primaryLabel: 'Distance',
			summary: working,
			secondaryMetrics: threeD
				? [
						{ label: 'Change in x (Δx)', value: num(dx, 4) },
						{ label: 'Change in y (Δy)', value: num(dy, 4) },
						{ label: 'Change in z (Δz)', value: num(dz, 4) },
						{ label: 'Midpoint', value: mid }
					]
				: [
						{ label: 'Change in x (Δx)', value: num(dx, 4) },
						{ label: 'Change in y (Δy)', value: num(dy, 4) },
						{ label: 'Midpoint', value: mid },
						{ label: 'Slope', value: slope }
					]
		};
	},
	content: {
		intro:
			'Find the straight-line distance between two points. Enter their coordinates in 2D or 3D to get the distance, the midpoint and, for 2D points, the slope of the line between them.',
		howTo: [
			'Choose 2D for points on a flat plane, or 3D for points in space.',
			'Enter the x and y coordinates of the first and second point. In 3D, also enter the z coordinates.',
			'Read the distance, the midpoint and the change in each coordinate. The slope appears in 2D.'
		],
		formulas: [
			{
				title: 'Distance in 2D',
				expression: 'd = √((x₂ − x₁)² + (y₂ − y₁)²)',
				variables: [{ symbol: 'x₁, y₁', meaning: 'coordinates of the first point' }]
			},
			{
				title: 'Distance in 3D',
				expression: 'd = √((x₂ − x₁)² + (y₂ − y₁)² + (z₂ − z₁)²)',
				variables: [{ symbol: 'z₁, z₂', meaning: 'the depth or height coordinate of each point' }]
			},
			{
				title: 'Midpoint',
				expression: 'M = ((x₁ + x₂) ÷ 2, (y₁ + y₂) ÷ 2, (z₁ + z₂) ÷ 2)',
				variables: [{ symbol: 'M', meaning: 'the point halfway between the two points' }]
			},
			{
				title: 'Slope (2D only)',
				expression: 'm = (y₂ − y₁) ÷ (x₂ − x₁)',
				variables: [{ symbol: 'm', meaning: 'rise over run; undefined when x₁ = x₂' }]
			}
		],
		example: {
			title: 'The points (−3, −1) and (2, 11) on a flat plane',
			steps: [
				'Change in x: 2 − (−3) = 5. Change in y: 11 − (−1) = 12',
				'Distance: √(5² + 12²) = √169 = 13',
				'Midpoint: ((−3 + 2) ÷ 2, (−1 + 11) ÷ 2) = (−0.5, 5)',
				'Slope: 12 ÷ 5 = 2.4'
			],
			result: 'The points are 13 units apart. Their midpoint is (−0.5, 5) and the line through them has a slope of 2.4.'
		},
		faq: [
			{
				q: 'Why is the distance formula based on the Pythagorean theorem?',
				a: 'The change in x and the change in y form the two legs of a right triangle, and the straight line between the points is its hypotenuse. In 3D, the same idea is applied twice.'
			},
			{
				q: 'What does an undefined slope mean?',
				a: 'When the two points share the same x value, the line is vertical. Dividing by a change of zero is not possible, so the slope is undefined.'
			},
			{
				q: 'Does the order of the two points matter?',
				a: 'No. Swapping the points changes the sign of each change, but squaring removes the sign, so the distance and midpoint stay the same.'
			}
		]
	}
});
