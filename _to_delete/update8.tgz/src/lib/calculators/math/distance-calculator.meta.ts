import { defineMeta } from '../types';

export default defineMeta({
	slug: 'distance-calculator',
	name: 'Distance Calculator',
	category: 'math',
	shortDescription: 'Distance, midpoint and slope between two points in 2D or 3D.',
	metaTitle: 'Distance Calculator — Between Two Points, 2D & 3D',
	metaDescription:
		'Free distance calculator for two points in 2D or 3D. Enter the coordinates to get the straight-line distance, the midpoint and, in 2D, the slope.',
	icon: 'ruler',
	keywords: ['distance between two points', 'distance formula calculator', 'midpoint calculator', 'slope calculator', '3d distance calculator'],
	updated: '2026-10-28'
});
