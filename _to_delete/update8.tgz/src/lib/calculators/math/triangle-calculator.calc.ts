import { defineCalculator, type CalculationResult, type InputValues, type Table } from '../types';
import { DASH, num } from '../format';
import meta from './triangle-calculator.meta';

const RAD = Math.PI / 180;
const deg = (r: number) => (r * 180) / Math.PI;
const clamp = (x: number) => Math.min(1, Math.max(-1, x));
const pos = (x: number) => Number.isFinite(x) && x > 0;
const angleOk = (x: number) => Number.isFinite(x) && x > 0 && x < 180;
const is = (...modes: string[]) => (v: InputValues) => modes.includes(String(v.mode));

/** One solved triangle. Side a is opposite angle A, and so on. */
interface Tri {
	a: number;
	b: number;
	c: number;
	A: number;
	B: number;
	C: number;
}
interface Solved {
	tris: Tri[];
	method: string;
}
type Outcome = Solved | { error: string };

function sss(a: number, b: number, c: number): Outcome {
	if (![a, b, c].every(pos)) return { error: 'Enter three sides greater than zero.' };
	if (a + b <= c || a + c <= b || b + c <= a)
		return { error: 'No triangle has these sides. The two shorter sides must add up to more than the longest side.' };
	const A = deg(Math.acos(clamp((b * b + c * c - a * a) / (2 * b * c))));
	const B = deg(Math.acos(clamp((a * a + c * c - b * b) / (2 * a * c))));
	return { tris: [{ a, b, c, A, B, C: 180 - A - B }], method: 'Law of cosines for angles A and B, then C from the angle sum' };
}

function sas(a: number, b: number, C: number): Outcome {
	if (!pos(a) || !pos(b) || !angleOk(C)) return { error: 'Enter two sides above zero and an angle between 0° and 180°.' };
	const c = Math.sqrt(a * a + b * b - 2 * a * b * Math.cos(C * RAD));
	const A = deg(Math.acos(clamp((b * b + c * c - a * a) / (2 * b * c))));
	return { tris: [{ a, b, c, A, B: 180 - A - C, C }], method: 'Law of cosines for side c, then for angle A' };
}

function asa(A: number, B: number, c: number): Outcome {
	if (!pos(c) || !angleOk(A) || !angleOk(B)) return { error: 'Enter a side above zero and two angles between 0° and 180°.' };
	if (A + B >= 180) return { error: 'Angles A and B must add up to less than 180°.' };
	const C = 180 - A - B;
	const a = (c * Math.sin(A * RAD)) / Math.sin(C * RAD);
	const b = (c * Math.sin(B * RAD)) / Math.sin(C * RAD);
	return { tris: [{ a, b, c, A, B, C }], method: 'Angle C = 180° − A − B, then the law of sines' };
}

function aas(A: number, B: number, a: number): Outcome {
	if (!pos(a) || !angleOk(A) || !angleOk(B)) return { error: 'Enter a side above zero and two angles between 0° and 180°.' };
	if (A + B >= 180) return { error: 'Angles A and B must add up to less than 180°.' };
	const C = 180 - A - B;
	const b = (a * Math.sin(B * RAD)) / Math.sin(A * RAD);
	const c = (a * Math.sin(C * RAD)) / Math.sin(A * RAD);
	return { tris: [{ a, b, c, A, B, C }], method: 'Angle C = 180° − A − B, then the law of sines' };
}

function ssa(a: number, b: number, A: number): Outcome {
	if (!pos(a) || !pos(b) || !angleOk(A)) return { error: 'Enter two sides above zero and an angle between 0° and 180°.' };
	const method = 'Law of sines for angle B, checking for a second triangle';
	const s = (b * Math.sin(A * RAD)) / a;
	if (s > 1 + 1e-12) return { tris: [], method };
	const B1 = deg(Math.asin(Math.min(1, s)));
	// When sin B is 1 the two angles are the same (a right angle), so only one triangle exists.
	const candidates = Math.abs(s - 1) < 1e-12 ? [B1] : [B1, 180 - B1];
	const tris: Tri[] = [];
	for (const B of candidates) {
		const C = 180 - A - B;
		if (C <= 1e-9) continue;
		const c = (a * Math.sin(C * RAD)) / Math.sin(A * RAD);
		tris.push({ a, b, c, A, B, C });
	}
	return { tris, method };
}

const area = (t: Tri) => {
	const s = (t.a + t.b + t.c) / 2;
	return Math.sqrt(Math.max(0, s * (s - t.a) * (s - t.b) * (s - t.c)));
};

const byAngles = (t: Tri) => {
	const largest = Math.max(t.A, t.B, t.C);
	if (Math.abs(largest - 90) < 1e-9) return 'Right';
	return largest < 90 ? 'Acute' : 'Obtuse';
};

const bySides = (t: Tri) => {
	const same = (x: number, y: number) => Math.abs(x - y) < 1e-9;
	if (same(t.a, t.b) && same(t.b, t.c)) return 'Equilateral';
	if (same(t.a, t.b) || same(t.b, t.c) || same(t.a, t.c)) return 'Isosceles';
	return 'Scalene';
};

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Known measurements',
			type: 'select',
			display: 'menu',
			default: 'sss',
			options: [
				{ label: 'Three sides (SSS)', value: 'sss' },
				{ label: 'Two sides and the angle between them (SAS)', value: 'sas' },
				{ label: 'Two angles and the side between them (ASA)', value: 'asa' },
				{ label: 'Two angles and a side (AAS)', value: 'aas' },
				{ label: 'Two sides and an angle opposite one (SSA)', value: 'ssa' }
			]
		},
		{ id: 'sideA', label: 'Side a', type: 'number', default: 5, min: 0, help: 'Opposite angle A.', visibleWhen: is('sss', 'sas', 'aas', 'ssa') },
		{ id: 'sideB', label: 'Side b', type: 'number', default: 7, min: 0, help: 'Opposite angle B.', visibleWhen: is('sss', 'sas', 'ssa') },
		{
			id: 'sideC',
			label: 'Side c',
			type: 'number',
			default: 8,
			min: 0,
			help: 'Opposite angle C. In ASA, the side between angles A and B.',
			visibleWhen: is('sss', 'asa')
		},
		{ id: 'angleA', label: 'Angle A', type: 'number', default: 40, min: 0, max: 180, suffix: '°', visibleWhen: is('asa', 'aas', 'ssa') },
		{ id: 'angleB', label: 'Angle B', type: 'number', default: 60, min: 0, max: 180, suffix: '°', visibleWhen: is('asa', 'aas') },
		{
			id: 'angleC',
			label: 'Angle C',
			type: 'number',
			default: 60,
			min: 0,
			max: 180,
			suffix: '°',
			help: 'The angle between sides a and b.',
			visibleWhen: is('sas')
		}
	],
	calculate(v): CalculationResult {
		const mode = String(v.mode);
		const n = (k: string) => Number(v[k]);
		const stop = (summary: string): CalculationResult => ({ primaryResult: DASH, primaryLabel: 'Area', summary });

		let outcome: Outcome;
		switch (mode) {
			case 'sss':
				outcome = sss(n('sideA'), n('sideB'), n('sideC'));
				break;
			case 'sas':
				outcome = sas(n('sideA'), n('sideB'), n('angleC'));
				break;
			case 'asa':
				outcome = asa(n('angleA'), n('angleB'), n('sideC'));
				break;
			case 'aas':
				outcome = aas(n('angleA'), n('angleB'), n('sideA'));
				break;
			case 'ssa':
				outcome = ssa(n('sideA'), n('sideB'), n('angleA'));
				break;
			default:
				return stop('Pick which sides and angles you know.');
		}
		if ('error' in outcome) return stop(outcome.error);

		const { tris, method } = outcome;
		if (tris.length === 0)
			return stop('No triangle fits these measurements. Side a is too short to reach the third side at angle A.');

		const two = tris.length === 2;
		const areas = tris.map(area);
		const join = (xs: string[]) => xs.join(' and ');
		const sum = tris[0].A + tris[0].B + tris[0].C;

		const rows: [string, (t: Tri) => string][] = [
			['Side a', (t) => num(t.a, 4)],
			['Side b', (t) => num(t.b, 4)],
			['Side c', (t) => num(t.c, 4)],
			['Angle A', (t) => `${num(t.A, 4)}°`],
			['Angle B', (t) => `${num(t.B, 4)}°`],
			['Angle C', (t) => `${num(t.C, 4)}°`]
		];
		const table: Table = {
			title: 'Sides and angles',
			columns: two
				? [
						{ key: 'measure', label: 'Measure' },
						{ key: 't1', label: 'Triangle 1', align: 'end' },
						{ key: 't2', label: 'Triangle 2', align: 'end' }
					]
				: [
						{ key: 'measure', label: 'Measure' },
						{ key: 't1', label: 'Value', align: 'end' }
					],
			rows: rows.map(([measure, f]) => {
				const row: Record<string, string> = { measure, t1: f(tris[0]) };
				if (two) row.t2 = f(tris[1]);
				return row;
			})
		};

		return {
			primaryResult: two ? '2 triangles' : num(areas[0], 4),
			primaryLabel: two ? 'Possible triangles' : 'Area',
			summary: two
				? `${method}. Two triangles fit these measurements, so both are shown.`
				: `${method}. The angles add up to ${num(sum, 4)}°.`,
			secondaryMetrics: [
				{ label: 'Area (Heron)', value: join(areas.map((x) => num(x, 4))) },
				{ label: 'Perimeter', value: join(tris.map((t) => num(t.a + t.b + t.c, 4))) },
				{ label: 'Type by angles', value: join(tris.map(byAngles)) },
				{ label: 'Type by sides', value: join(tris.map(bySides)) }
			],
			table
		};
	},
	content: {
		intro:
			'Solve any triangle. Enter three measurements that include at least one side, and get all three sides, all three angles, the area, the perimeter and the triangle type.',
		howTo: [
			'Choose the set of measurements you know: three sides, two sides with the angle between them, two angles with the side between them, two angles with a side, or two sides with an angle opposite one of them.',
			'Enter the values. Angles are in degrees. Side a is opposite angle A, side b is opposite angle B, and side c is opposite angle C.',
			'Read the sides, angles, area and type. If two triangles fit (the SSA case), both appear in the table.'
		],
		formulas: [
			{
				title: 'Law of cosines',
				expression: 'c² = a² + b² − 2ab × cos C,   cos A = (b² + c² − a²) ÷ (2bc)',
				variables: [{ symbol: 'C', meaning: 'the angle between sides a and b' }]
			},
			{
				title: 'Law of sines',
				expression: 'a ÷ sin A = b ÷ sin B = c ÷ sin C',
				variables: [{ symbol: 'A, B, C', meaning: 'the angles, each opposite the side with the same letter' }]
			},
			{
				title: 'Angle sum',
				expression: 'A + B + C = 180°',
				variables: []
			},
			{
				title: 'Area (Heron’s formula)',
				expression: 's = (a + b + c) ÷ 2,   Area = √(s(s − a)(s − b)(s − c))',
				variables: [{ symbol: 's', meaning: 'the semi-perimeter, half the perimeter' }]
			}
		],
		example: {
			title: 'Two sides of 5 and 7 with a 60° angle between them',
			steps: [
				'Third side: c² = 5² + 7² − 2 × 5 × 7 × cos 60° = 39, so c = 6.245',
				'Angle A: cos A = (7² + 6.245² − 5²) ÷ (2 × 7 × 6.245), so A = 43.8979°',
				'Angle B = 180° − 60° − 43.8979° = 76.1021°',
				'Area: s = 18.245 ÷ 2 = 9.1225, so the area is √(9.1225 × 4.1225 × 2.1225 × 2.8775) = 15.1554'
			],
			result:
				'The third side is 6.245, the angles are 43.8979°, 76.1021° and 60°, the area is 15.1554 square units and the perimeter is 18.245.'
		},
		faq: [
			{
				q: 'Why can a triangle have two solutions?',
				a: 'When you know two sides and an angle opposite one of them (SSA), the other side can swing to two positions and still reach the base. Both triangles are shown when both fit.'
			},
			{
				q: 'What is the triangle inequality?',
				a: 'Any two sides of a triangle must add up to more than the third side. If three sides break this rule, no triangle can be drawn and the calculator says so.'
			},
			{
				q: 'Which law does the calculator use?',
				a: 'It uses the law of cosines when two sides and an angle between them are known, or when all three sides are known. It uses the law of sines when angles and sides are opposite each other.'
			},
			{
				q: 'How is the triangle type decided?',
				a: 'By angles, a triangle is acute if all angles are under 90°, right if one is exactly 90°, and obtuse if one is over 90°. By sides, it is equilateral if all sides match, isosceles if two match, and scalene if none match.'
			}
		]
	}
});
