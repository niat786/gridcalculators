import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './log-calculator.meta';

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'x',
			label: 'Number (x)',
			type: 'number',
			default: 1000,
			min: 0,
			help: 'Must be greater than 0.'
		},
		{
			id: 'b',
			label: 'Base (b)',
			type: 'number',
			default: 10,
			min: 0,
			help: 'Must be greater than 0 and not equal to 1. Use 10 for common logs, 2 for binary, or e for natural logs.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const x = Number(v.x);
		const b = Number(v.b);
		const label = 'Logarithm';
		if (!Number.isFinite(x) || x <= 0) {
			return {
				primaryResult: DASH,
				primaryLabel: label,
				summary: 'The number must be greater than 0. The log of zero or a negative number is not a real number.'
			};
		}
		if (!Number.isFinite(b) || b <= 0 || b === 1) {
			return {
				primaryResult: DASH,
				primaryLabel: label,
				summary: 'The base must be greater than 0 and not equal to 1.'
			};
		}

		const lnX = Math.log(x);
		const lnB = Math.log(b);
		const result = lnX / lnB;

		return {
			primaryResult: num(result, 6),
			primaryLabel: `Logarithm, base ${num(b, 6)}`,
			summary: `Change of base: log_b(x) = ln(x) ÷ ln(b) = ${num(lnX, 6)} ÷ ${num(lnB, 6)} = ${num(result, 6)}, because ${num(b, 6)} raised to that power gives ${num(x, 6)}.`,
			secondaryMetrics: [
				{ label: 'Natural log, ln(x)', value: num(lnX, 6) },
				{ label: 'Common log, log₁₀(x)', value: num(Math.log10(x), 6) },
				{ label: 'Binary log, log₂(x)', value: num(Math.log2(x), 6) },
				{ label: 'Check: b to the power of the result', value: num(Math.pow(b, result), 6) }
			]
		};
	},
	content: {
		intro:
			'Find the logarithm of a positive number in any base. The log answers the question “what power do I raise the base to, to get this number?” The calculator also shows the natural log, common log and binary log of the same number.',
		howTo: [
			'Type the number x. It must be greater than 0.',
			'Type the base b. It must be greater than 0 and not equal to 1. The default is 10.',
			'Read the logarithm. The metrics show ln, log base 10 and log base 2 of the same number, plus a check.'
		],
		formulas: [
			{
				title: 'Definition',
				expression: 'logᵦ(x) = y   means   bʸ = x',
				variables: [
					{ symbol: 'b', meaning: 'The base, greater than 0 and not 1' },
					{ symbol: 'x', meaning: 'The number, greater than 0' },
					{ symbol: 'y', meaning: 'The power the base must be raised to' }
				]
			},
			{
				title: 'Change of base',
				expression: 'logᵦ(x) = ln(x) ÷ ln(b)   and   logᵦ(x) = log₁₀(x) ÷ log₁₀(b)',
				variables: [
					{ symbol: 'ln', meaning: 'The natural log, which uses base e (about 2.71828)' },
					{ symbol: 'log₁₀', meaning: 'The common log, which uses base 10' }
				]
			}
		],
		example: {
			title: 'Log base 3 of 81',
			steps: [
				'Use change of base: log₃(81) = ln(81) ÷ ln(3).',
				'ln(81) ≈ 4.394449 and ln(3) ≈ 1.098612.',
				'4.394449 ÷ 1.098612 ≈ 4.',
				'Check: 3⁴ = 81.'
			],
			result: 'log₃(81) = 4, because 3 raised to the power 4 is 81.'
		},
		faq: [
			{
				q: 'Why must the base not be 1?',
				a: 'Raising 1 to any power always gives 1, so it can never produce a number other than 1. Also ln(1) is 0 for every base, so the answer would not be unique.'
			},
			{
				q: 'Why can’t the number be zero or negative?',
				a: 'A positive base raised to any real power always gives a positive result. So no real power produces 0 or a negative number, and the log is undefined there.'
			},
			{
				q: 'What is the difference between ln and log?',
				a: 'Written without a base, “log” usually means base 10 in calculators, and “ln” means the natural log, base e. Both are logs, so the change of base formula converts between any pair.'
			}
		]
	}
});
