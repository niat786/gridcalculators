import { defineCalculator } from '../types';
import meta from './basic-calculator.meta';

export default defineCalculator({
	meta,
	widget: { name: 'keypad', props: { mode: 'basic' } },
	inputs: [],
	calculate: () => ({ primaryResult: '', primaryLabel: '' }),
	content: {
		intro:
			'A clean online calculator for everyday math. Type with your keyboard or tap the keys, and switch to scientific mode for powers, roots and trigonometry.',
		howTo: [
			'Tap the keys or type on your keyboard: numbers, + − × ÷, and Enter for equals.',
			'The answer updates as you type, so you see the result before pressing =.',
			'Press ⌫ (or Backspace) to delete, and AC (or Esc) to clear.',
			'Open History to reuse an earlier sum, or switch to Scientific for more functions.'
		],
		formulas: [
			{
				title: 'Order of operations',
				expression: 'Parentheses → Powers → × and ÷ (left to right) → + and − (left to right)',
				variables: []
			},
			{
				title: 'Percent key',
				expression: 'x% = x ÷ 100     e.g. 200 × 15% = 30',
				variables: []
			}
		],
		example: {
			title: 'Work out 12 + 3 × (8 − 2)',
			steps: ['Parentheses first: 8 − 2 = 6', 'Then multiplication: 3 × 6 = 18', 'Then addition: 12 + 18 = 30'],
			result: 'The answer is 30, not 90: multiplication comes before addition.'
		},
		faq: [
			{
				q: 'Does this calculator follow the order of operations?',
				a: 'Yes. It applies the standard order: parentheses, then powers, then multiplication and division, then addition and subtraction. Type the whole sum and it gives the mathematically correct answer.'
			},
			{
				q: 'Can I use my keyboard?',
				a: 'Yes. Type numbers and + - * / ^ ( ) directly. Enter or = calculates, Backspace deletes and Esc clears.'
			},
			{
				q: 'How does the % key work?',
				a: 'The % key divides the number before it by 100. So 15% becomes 0.15, and 200 × 15% gives 30.'
			},
			{
				q: 'Is anything I type saved or sent anywhere?',
				a: 'No. All calculations happen in your browser. Your history disappears when you close the page.'
			}
		]
	}
});
