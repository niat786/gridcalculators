import { defineMeta } from '../types';

export default defineMeta({
	slug: 'standard-deviation-calculator',
	name: 'Standard Deviation Calculator',
	category: 'math',
	shortDescription: 'Sample or population standard deviation, variance and standard error.',
	metaTitle: 'Standard Deviation Calculator — Sample & Population',
	metaDescription:
		'Free standard deviation calculator. Enter a list of numbers to get the sample or population standard deviation, variance, mean and standard error of the mean.',
	icon: 'sigma',
	keywords: [
		'standard deviation calculator',
		'sample standard deviation',
		'population standard deviation',
		'variance calculator',
		'standard error of the mean'
	],
	updated: '2026-10-28'
});
