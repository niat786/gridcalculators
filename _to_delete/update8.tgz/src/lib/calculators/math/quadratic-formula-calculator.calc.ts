import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './quadratic-formula-calculator.meta';

/** Round to six decimal places and remove a negative zero. */
const f = (x: number) => num(Math.round(x * 1e6) / 1e6 || 0, 6);

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'a',
			label: 'Coefficient a (x² term)',
			type: 'number',
			default: 1,
			step: 1,
			help: 'The equation is ax² + bx + c = 0. a cannot be 0.'
		},
		{ id: 'b', label: 'Coefficient b (x term)', type: 'number', default: -3, step: 1 },
		{ id: 'c', label: 'Constant c', type: 'number', default: 2, step: 1 }
	],
	calculate(v: InputValues): CalculationResult {
		const a = Number(v.a);
		const b = Number(v.b);
		const c = Number(v.c);
		const label = 'Roots (x)';

		if (!Number.isFinite(a) || !Number.isFinite(b) || !Number.isFinite(c)) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter a, b and c as numbers.' };
		}
		if (a === 0) {
			return {
				primaryResult: DASH,
				primaryLabel: label,
				summary: 'a can’t be 0, because the equation would no longer be quadratic.'
			};
		}

		const disc = b * b - 4 * a * c;
		const axis = -b / (2 * a);
		const vertexY = -disc / (4 * a);
		const common = [
			{ label: 'Discriminant (b² − 4ac)', value: f(disc) },
			{ label: 'Vertex (x, y)', value: `(${f(axis)}, ${f(vertexY)})` },
			{ label: 'Axis of symmetry', value: `x = ${f(axis)}` },
			{ label: 'Parabola opens', value: a > 0 ? 'Upward' : 'Downward' }
		];

		if (disc > 0) {
			const root = Math.sqrt(disc);
			const r1 = (-b + root) / (2 * a);
			const r2 = (-b - root) / (2 * a);
			return {
				primaryResult: `${f(Math.min(r1, r2))} and ${f(Math.max(r1, r2))}`,
				primaryLabel: 'Two real roots (x)',
				summary: `The discriminant ${f(disc)} is positive, so x = (−b ± √Δ) ÷ 2a gives two different real roots.`,
				secondaryMetrics: common
			};
		}

		if (disc === 0) {
			return {
				primaryResult: f(axis),
				primaryLabel: 'One repeated root (x)',
				summary: 'The discriminant is 0, so both roots are the same: x = −b ÷ 2a.',
				secondaryMetrics: common
			};
		}

		const imaginary = Math.sqrt(-disc) / (2 * Math.abs(a));
		return {
			primaryResult: `${f(axis)} ± ${f(imaginary)}i`,
			primaryLabel: 'Complex roots (p ± qi)',
			summary: `The discriminant ${f(disc)} is negative, so there are no real roots. Here p = −b ÷ 2a and q = √(−Δ) ÷ 2|a|.`,
			secondaryMetrics: common
		};
	},
	content: {
		intro:
			'Solve a quadratic equation ax² + bx + c = 0 with the quadratic formula. The calculator finds real or complex roots, and also the vertex and axis of symmetry of the parabola.',
		howTo: [
			'Write your equation as ax² + bx + c = 0 and enter a, b and c. The value of a cannot be 0.',
			'Read the roots. The discriminant tells you whether they are two real numbers, one repeated number, or a complex pair.',
			'Use the vertex and axis of symmetry to locate the turning point of the graph.'
		],
		formulas: [
			{
				title: 'Quadratic formula',
				expression: 'x = (−b ± √(b² − 4ac)) ÷ 2a',
				variables: [
					{ symbol: 'a, b, c', meaning: 'The coefficients of ax² + bx + c = 0' },
					{ symbol: '±', meaning: 'Gives two roots: one with plus, one with minus' }
				]
			},
			{
				title: 'Discriminant',
				expression: 'Δ = b² − 4ac. Δ > 0: two real roots. Δ = 0: one repeated root. Δ < 0: complex roots.',
				variables: [{ symbol: 'Δ', meaning: 'The discriminant, the value under the square root' }]
			},
			{
				title: 'Vertex and axis of symmetry',
				expression: 'Axis: x = −b ÷ 2a.   Vertex: (−b ÷ 2a, −Δ ÷ 4a)',
				variables: [{ symbol: 'x', meaning: 'The x-coordinate of the turning point, which is also the axis of symmetry' }]
			}
		],
		example: {
			title: 'Solve x² − 3x + 2 = 0',
			steps: [
				'a = 1, b = −3, c = 2',
				'Discriminant: (−3)² − 4 × 1 × 2 = 9 − 8 = 1',
				'Roots: (3 ± √1) ÷ 2 = (3 ± 1) ÷ 2',
				'So x = 2 or x = 1'
			],
			result: 'The roots are 1 and 2. The vertex is (1.5, -0.25).'
		},
		faq: [
			{
				q: 'What does a negative discriminant mean?',
				a: 'It means the parabola never crosses the x-axis, so there are no real roots. The roots are complex numbers written as p ± qi, where i is the square root of −1.'
			},
			{
				q: 'Why can a not be zero?',
				a: 'If a is 0, the x² term disappears and the equation becomes linear, so the quadratic formula does not apply. The formula also divides by 2a, which would be division by zero.'
			},
			{
				q: 'How do I find the vertex of a parabola?',
				a: 'The x-coordinate of the vertex is −b ÷ 2a. Put that value back into the equation to get the y-coordinate. The axis of symmetry is the vertical line through the vertex.'
			}
		]
	}
});
