import { defineCalculator, type CalculationResult } from '../types';
import { DASH, num } from '../format';
import meta from './exponent-calculator.meta';

const SUPERSCRIPT: Record<string, string> = {
	'0': '⁰',
	'1': '¹',
	'2': '²',
	'3': '³',
	'4': '⁴',
	'5': '⁵',
	'6': '⁶',
	'7': '⁷',
	'8': '⁸',
	'9': '⁹',
	'-': '⁻',
	'+': ''
};

/** Number with a true minus sign (−) for negatives, for display. */
const sgn = (x: number) => (x < 0 ? '−' : '') + num(Math.abs(x), 6);

/** Scientific notation, e.g. 1024 → "1.024 × 10³". Six decimals in the mantissa. */
function sci(x: number): string {
	if (x === 0) return '0';
	const [mantissa, exponent] = x.toExponential(6).split('e');
	const sup = String(Number(exponent))
		.split('')
		.map((c) => SUPERSCRIPT[c])
		.join('');
	return `${sgn(Number(mantissa))} × 10${sup}`;
}

/** Plain digits for everyday sizes; scientific notation for very large or very small results. */
function show(x: number): string {
	if (x !== 0 && (Math.abs(x) >= 1e6 || Math.abs(x) < 1e-4)) return sci(x);
	return (x < 0 ? '−' : '') + num(Math.abs(x), 6);
}

function fail(summary: string): CalculationResult {
	return { primaryResult: DASH, primaryLabel: 'Result', summary };
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'base', label: 'Base', type: 'number', default: 2, help: 'The number being multiplied by itself.' },
		{
			id: 'exponent',
			label: 'Exponent',
			type: 'number',
			default: 10,
			help: 'How many times to multiply. Negative and fractional exponents work too.'
		}
	],
	calculate(v): CalculationResult {
		const b = Number(v.base);
		const e = Number(v.exponent);
		if (!Number.isFinite(b) || !Number.isFinite(e)) return fail('Enter a base and an exponent.');
		if (b === 0 && e < 0) return fail('Zero cannot be raised to a negative power, because that would mean 1 ÷ 0.');
		if (b < 0 && !Number.isInteger(e)) {
			return fail('A negative base with a fractional exponent has no real answer here. Try a whole-number exponent.');
		}

		const r = Math.pow(b, e) + 0;
		if (!Number.isFinite(r)) return fail('The result is too large to display.');
		if (r === 0 && b !== 0) return fail('The result is too small to display.');

		const baseText = b < 0 ? `(${sgn(b)})` : sgn(b);
		const note = b === 0 && e === 0 ? ' By convention, 0⁰ is taken as 1.' : '';
		return {
			primaryResult: show(r),
			primaryLabel: 'Result',
			summary: `${baseText}^${sgn(e)} = ${show(r)}.${note}`,
			secondaryMetrics: [
				{ label: 'Scientific notation', value: sci(r) },
				{ label: 'Reciprocal (1 ÷ result)', value: r === 0 ? 'Undefined' : show(1 / r) }
			]
		};
	},
	content: {
		intro:
			'Raise a base number to an exponent. Works for whole, negative and fractional exponents, and shows very large or very small results in scientific notation.',
		howTo: [
			'Enter the base, the number you are multiplying.',
			'Enter the exponent, how many times it multiplies itself.',
			'Read the result, and its scientific notation below it.'
		],
		formulas: [
			{
				title: 'Power',
				expression: 'Result = bⁿ = b × b × … × b   (n times)',
				variables: [
					{ symbol: 'b', meaning: 'base' },
					{ symbol: 'n', meaning: 'exponent' }
				]
			},
			{ title: 'Negative exponent', expression: 'b⁻ⁿ = 1 ÷ bⁿ', variables: [] },
			{ title: 'Fractional exponent', expression: 'b^(1/n) = ⁿ√b', variables: [{ symbol: 'ⁿ√b', meaning: 'the n-th root of b' }] },
			{
				title: 'Scientific notation',
				expression: 'x = m × 10ᵏ,   where 1 ≤ |m| < 10',
				variables: [
					{ symbol: 'm', meaning: 'mantissa, the leading digits' },
					{ symbol: 'k', meaning: 'the power of ten' }
				]
			}
		],
		example: {
			title: 'Two to the power of ten',
			steps: ['Multiply 2 by itself 10 times: 2 × 2 × … × 2', '2¹⁰ = 1,024', 'In scientific notation: 1.024 × 10³'],
			result: 'Two to the power of ten is 1,024, or 1.024 × 10³.'
		},
		faq: [
			{
				q: 'What does a negative exponent mean?',
				a: 'It means one divided by the base raised to the positive exponent. For example, 2⁻³ = 1 ÷ 2³ = 1 ÷ 8 = 0.125.'
			},
			{
				q: 'Why can a negative number not be raised to a fractional power?',
				a: 'A fraction such as 1/2 means a square root, and a negative number has no real square root. Some fractional powers of negative numbers are real when the root is odd, but this calculator only handles whole-number exponents for negative bases.'
			},
			{
				q: 'Why is zero to a negative power not allowed?',
				a: 'Zero to a negative power would equal 1 ÷ 0, and division by zero has no answer.'
			}
		]
	}
});
