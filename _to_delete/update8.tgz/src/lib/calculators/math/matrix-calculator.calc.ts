import { defineCalculator, type CalculationResult, type InputValues, type Table } from '../types';
import { DASH, num } from '../format';
import meta from './matrix-calculator.meta';

const MAX_SIZE = 6;
const NBSP = ' ';

type Matrix = number[][];

const fail = (summary: string): CalculationResult => ({ primaryResult: DASH, primaryLabel: 'Result', summary });

/** Reads "1 2 3" or "1, 2, 3" per line. Returns the matrix or an error message naming the matrix. */
function parseMatrix(raw: string, name: string): Matrix | string {
	const lines = raw
		.split(/\r?\n/)
		.map((l) => l.trim())
		.filter((l) => l !== '');
	if (lines.length === 0) return `Enter the rows of matrix ${name}, one row per line.`;
	if (lines.length > MAX_SIZE) return `Matrix ${name} has ${lines.length} rows. The limit is ${MAX_SIZE}.`;
	const rows: Matrix = [];
	for (const line of lines) {
		const tokens = line.split(/[\s,]+/).filter((t) => t !== '');
		const row = tokens.map((t) => Number(t));
		const bad = tokens.find((t, i) => !Number.isFinite(row[i]));
		if (bad !== undefined) return `Matrix ${name} has a value that is not a number: “${bad}”.`;
		if (row.length > MAX_SIZE) return `Matrix ${name} has ${row.length} columns. The limit is ${MAX_SIZE}.`;
		rows.push(row);
	}
	const cols = rows[0].length;
	const ragged = rows.findIndex((r) => r.length !== cols);
	if (ragged !== -1) {
		return `Matrix ${name} is uneven: row 1 has ${cols} numbers and row ${ragged + 1} has ${rows[ragged].length}. Every row needs the same count.`;
	}
	return rows;
}

const dims = (m: Matrix): string => `${m.length} × ${m[0].length}`;

/** Treat tiny floating-point noise as zero so results never show −0 or 1e-16. */
const clean = (x: number): number => (Math.abs(x) < 1e-12 ? 0 : x);
const fmt = (x: number): string => num(clean(x), 6);

function multiply(a: Matrix, b: Matrix): Matrix {
	return a.map((row) =>
		Array.from({ length: b[0].length }, (_, j) => row.reduce((acc, x, k) => acc + x * b[k][j], 0))
	);
}

function transpose(m: Matrix): Matrix {
	return m[0].map((_, j) => m.map((row) => row[j]));
}

/** Determinant by Gaussian elimination with partial pivoting. */
function determinant(m: Matrix): number {
	const a = m.map((r) => [...r]);
	const n = a.length;
	let det = 1;
	for (let k = 0; k < n; k++) {
		let p = k;
		for (let i = k + 1; i < n; i++) if (Math.abs(a[i][k]) > Math.abs(a[p][k])) p = i;
		if (a[p][k] === 0) return 0;
		if (p !== k) {
			[a[p], a[k]] = [a[k], a[p]];
			det = -det;
		}
		det *= a[k][k];
		for (let i = k + 1; i < n; i++) {
			const f = a[i][k] / a[k][k];
			for (let j = k; j < n; j++) a[i][j] -= f * a[k][j];
		}
	}
	return det;
}

/**
 * Inverse by Gauss–Jordan elimination with partial pivoting. Returns null when the matrix is
 * singular (a pivot is zero to within rounding), because then no inverse exists.
 */
function inverse(m: Matrix): Matrix | null {
	const n = m.length;
	const scale = Math.max(1, ...m.flat().map(Math.abs));
	const a = m.map((r, i) => [...r, ...Array.from({ length: n }, (_, j) => (i === j ? 1 : 0))]);
	for (let k = 0; k < n; k++) {
		let p = k;
		for (let i = k + 1; i < n; i++) if (Math.abs(a[i][k]) > Math.abs(a[p][k])) p = i;
		if (Math.abs(a[p][k]) < 1e-12 * scale) return null;
		[a[p], a[k]] = [a[k], a[p]];
		const pivot = a[k][k];
		for (let j = 0; j < 2 * n; j++) a[k][j] /= pivot;
		for (let i = 0; i < n; i++) {
			if (i === k) continue;
			const f = a[i][k];
			for (let j = 0; j < 2 * n; j++) a[i][j] -= f * a[k][j];
		}
	}
	return a.map((r) => r.slice(n));
}

/** Plain-text grid: non-breaking spaces keep columns lined up even where the browser collapses line breaks. */
function gridText(m: Matrix): string {
	const cells = m.map((r) => r.map(fmt));
	const widths = cells[0].map((_, j) => Math.max(...cells.map((r) => r[j].length)));
	return cells
		.map((r) => `[${r.map((c, j) => NBSP.repeat(widths[j] - c.length) + c).join(NBSP.repeat(2))}]`)
		.join('\n');
}

function gridTable(m: Matrix): Table {
	return {
		title: 'Result as a table',
		columns: [
			{ key: 'row', label: 'Row' },
			...m[0].map((_, j) => ({ key: `c${j + 1}`, label: `c${j + 1}`, align: 'end' as const }))
		],
		rows: m.map((r, i) => {
			const row: Record<string, string> = { row: `r${i + 1}` };
			r.forEach((x, j) => (row[`c${j + 1}`] = fmt(x)));
			return row;
		})
	};
}

const NEEDS_B = ['add', 'subtract', 'multiply'];

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'a',
			label: 'Matrix A',
			type: 'text',
			multiline: true,
			monospace: true,
			default: '2 1 0\n1 3 1\n0 1 4',
			maxLength: 600,
			pattern: /^[\s\d.,+\-]*$/,
			patternMessage: 'Use numbers, spaces, commas, decimal points and minus signs. One row per line.',
			help: 'One row per line. Separate numbers with spaces or commas. Up to 6 × 6.'
		},
		{
			id: 'b',
			label: 'Matrix B',
			type: 'text',
			multiline: true,
			monospace: true,
			default: '1 0 2\n0 1 3\n4 0 1',
			maxLength: 600,
			pattern: /^[\s\d.,+\-]*$/,
			patternMessage: 'Use numbers, spaces, commas, decimal points and minus signs. One row per line.',
			help: 'Used for add, subtract and multiply.',
			visibleWhen: (v: InputValues) => NEEDS_B.includes(String(v.op))
		},
		{
			id: 'op',
			label: 'Operation',
			type: 'select',
			display: 'menu',
			default: 'multiply',
			options: [
				{ label: 'A + B', value: 'add' },
				{ label: 'A − B', value: 'subtract' },
				{ label: 'A × B', value: 'multiply' },
				{ label: 'Transpose of A (Aᵀ)', value: 'transpose' },
				{ label: 'Determinant of A', value: 'determinant' },
				{ label: 'Inverse of A (A⁻¹)', value: 'inverse' },
				{ label: 'A × scalar', value: 'scale' }
			]
		},
		{
			id: 'scalar',
			label: 'Scalar (k)',
			type: 'number',
			default: 2,
			help: 'Every entry of A is multiplied by this number.',
			visibleWhen: (v: InputValues) => v.op === 'scale'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const op = String(v.op);
		const a = parseMatrix(String(v.a), 'A');
		if (typeof a === 'string') return fail(a);
		const sizeA = dims(a);

		if (op === 'transpose') {
			const t = transpose(a);
			return matrixResult('Transpose of A', t, sizeA, 'Not used');
		}
		if (op === 'determinant') {
			if (a.length !== a[0].length) {
				return fail(`The determinant needs a square matrix. A is ${sizeA}, so enter the same number of rows and columns.`);
			}
			const d = clean(determinant(a));
			return {
				primaryResult: fmt(d),
				primaryLabel: 'Determinant of A',
				summary:
					d === 0
						? 'The determinant is 0, so this matrix has no inverse.'
						: 'A non-zero determinant means the matrix has an inverse.',
				secondaryMetrics: [
					{ label: 'Size of A', value: sizeA },
					{ label: 'Size of B', value: 'Not used' },
					{ label: 'Result size', value: 'Single number' }
				]
			};
		}
		if (op === 'inverse') {
			if (a.length !== a[0].length) {
				return fail(`An inverse needs a square matrix. A is ${sizeA}, so enter the same number of rows and columns.`);
			}
			const inv = inverse(a);
			if (inv === null) {
				return {
					primaryResult: DASH,
					primaryLabel: 'Inverse of A',
					summary:
						'This matrix is singular: its determinant is zero, so no inverse exists. Check that the rows are not multiples of each other.',
					secondaryMetrics: [
						{ label: 'Size of A', value: sizeA },
						{ label: 'Size of B', value: 'Not used' },
						{ label: 'Result size', value: 'None' }
					]
				};
			}
			return matrixResult('Inverse of A', inv, sizeA, 'Not used');
		}
		if (op === 'scale') {
			const k = Number(v.scalar);
			if (!Number.isFinite(k)) return fail('Enter a scalar number.');
			return matrixResult(
				`A × ${fmt(k)}`,
				a.map((r) => r.map((x) => x * k)),
				sizeA,
				'Not used'
			);
		}

		if (!NEEDS_B.includes(op)) return fail('Choose an operation.');
		const b = parseMatrix(String(v.b), 'B');
		if (typeof b === 'string') return fail(b);
		const sizeB = dims(b);

		if (op === 'multiply') {
			if (a[0].length !== b.length) {
				return fail(
					`To multiply, the columns of A must match the rows of B. A is ${sizeA} and B is ${sizeB}. Make A's columns equal to B's rows.`
				);
			}
			return matrixResult('A × B', multiply(a, b), sizeA, sizeB);
		}
		if (sizeA !== sizeB) {
			return fail(`To ${op === 'add' ? 'add' : 'subtract'}, A and B must be the same size. A is ${sizeA} and B is ${sizeB}.`);
		}
		const sign = op === 'add' ? 1 : -1;
		return matrixResult(
			op === 'add' ? 'A + B' : 'A − B',
			a.map((r, i) => r.map((x, j) => x + sign * b[i][j])),
			sizeA,
			sizeB
		);
	},
	content: {
		intro:
			'Work with matrices up to 6 by 6. Enter matrix A, and matrix B if the operation needs it, then add, subtract, multiply, transpose, scale, or find the determinant or inverse.',
		howTo: [
			'Type matrix A with one row per line. Separate the numbers with spaces or commas.',
			'For add, subtract or multiply, type matrix B the same way.',
			'Choose an operation. For a scalar, enter the number that every entry of A is multiplied by.',
			'Read the result grid and the table. A singular matrix has no inverse, and the calculator says so.'
		],
		formulas: [
			{
				title: 'Matrix product',
				expression: 'Cᵢⱼ = Σₖ Aᵢₖ × Bₖⱼ.  A is m × p, B is p × n, and C is m × n.',
				variables: [
					{ symbol: 'Cᵢⱼ', meaning: 'The entry in row i and column j of the product' },
					{ symbol: 'Σₖ', meaning: 'Add over the shared index k, the columns of A matched with the rows of B' }
				]
			},
			{
				title: 'Determinant of a 2 × 2 matrix',
				expression: 'det = ad − bc for [[a, b], [c, d]]. Larger matrices use Gaussian elimination.',
				variables: [{ symbol: 'det', meaning: 'A single number that is 0 exactly when the matrix has no inverse' }]
			},
			{
				title: 'Inverse',
				expression: 'A⁻¹ × A = I, where I is the identity matrix with 1s on the diagonal and 0s elsewhere.',
				variables: [
					{ symbol: 'A⁻¹', meaning: 'The inverse of A' },
					{ symbol: 'I', meaning: 'The identity matrix' }
				]
			},
			{
				title: 'Transpose',
				expression: '(Aᵀ)ᵢⱼ = Aⱼᵢ. Rows become columns.',
				variables: [{ symbol: 'Aᵀ', meaning: 'The transpose of A' }]
			}
		],
		example: {
			title: 'Determinant of [[4, 7], [2, 6]]',
			steps: [
				'Multiply the diagonals: 4 × 6 = 24 and 7 × 2 = 14',
				'Subtract: 24 − 14 = 10',
				'The inverse is (1 ÷ 10) × [[6, −7], [−2, 4]]'
			],
			result: 'The determinant is 10, and the inverse is [[0.6, −0.7], [−0.2, 0.4]].'
		},
		faq: [
			{
				q: 'When does a matrix have no inverse?',
				a: 'A square matrix has no inverse when its determinant is 0. This is called a singular matrix. Its rows, or its columns, are then linked, so no matrix can undo it.'
			},
			{
				q: 'Why can I only multiply some matrices?',
				a: 'The number of columns in the first matrix must equal the number of rows in the second. A 2 × 3 matrix times a 3 × 4 matrix gives a 2 × 4 result.'
			},
			{
				q: 'Does order matter when multiplying matrices?',
				a: 'Yes. In general A × B is not the same as B × A, so check the order before you calculate.'
			}
		]
	}
});

function matrixResult(label: string, m: Matrix, sizeA: string, sizeB: string): CalculationResult {
	return {
		primaryResult: gridText(m),
		primaryLabel: label,
		long: true,
		summary: `${label}, shown as a grid. The result is ${dims(m)}.`,
		secondaryMetrics: [
			{ label: 'Size of A', value: sizeA },
			{ label: 'Size of B', value: sizeB },
			{ label: 'Result size', value: dims(m) }
		],
		table: gridTable(m)
	};
}
