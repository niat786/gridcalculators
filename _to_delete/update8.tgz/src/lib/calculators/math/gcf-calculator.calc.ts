import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './gcf-calculator.meta';

const MAX_VALUE = 1e12;
const MAX_COUNT = 20;

/** Euclid's algorithm on whole numbers. */
function gcd(a: number, b: number): number {
	let x = a;
	let y = b;
	while (y !== 0) {
		const r = x % y;
		x = y;
		y = r;
	}
	return x;
}

/** The Euclid steps for two numbers, larger first: "180 = 3 × 48 + 36; …". */
function euclidSteps(a: number, b: number): string[] {
	const steps: string[] = [];
	let x = Math.max(a, b);
	let y = Math.min(a, b);
	while (y !== 0) {
		const q = Math.floor(x / y);
		const r = x % y;
		steps.push(`${num(x, 0)} = ${num(q, 0)} × ${num(y, 0)} + ${num(r, 0)}`);
		x = y;
		y = r;
	}
	return steps;
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'values',
			label: 'Whole numbers',
			type: 'list',
			default: '12, 18, 24',
			minCount: 2,
			maxCount: MAX_COUNT,
			placeholder: 'e.g. 12, 18, 24',
			help: 'Two to twenty whole numbers from 1 to 1,000,000,000,000, separated by commas.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const xs = v.values as number[];
		const label = 'Greatest common factor';
		if (xs.length < 2 || xs.length > MAX_COUNT) {
			return { primaryResult: DASH, primaryLabel: label, summary: `Enter between 2 and ${MAX_COUNT} numbers.` };
		}
		if (xs.some((x) => !Number.isInteger(x) || x < 1 || x > MAX_VALUE)) {
			return {
				primaryResult: DASH,
				primaryLabel: label,
				summary: 'Use whole numbers from 1 to 1,000,000,000,000 only. Decimals and zero are not allowed.'
			};
		}

		const result = xs.reduce((g, x) => gcd(g, x));
		let summary: string;
		if (xs.length === 2) {
			const [a, b] = [xs[0], xs[1]];
			const steps = euclidSteps(a, b);
			summary = `Euclid’s method: ${steps.join('; ')}. The last nonzero remainder, ${num(result, 0)}, is the greatest common factor.`;
		} else {
			const parts: string[] = [];
			let g = xs[0];
			for (let i = 1; i < xs.length; i++) {
				const next = gcd(g, xs[i]);
				parts.push(`gcf(${num(g, 0)}, ${num(xs[i], 0)}) = ${num(next, 0)}`);
				g = next;
			}
			summary = `Combine the numbers two at a time: ${parts.join(', then ')}.`;
		}

		return {
			primaryResult: num(result, 0),
			primaryLabel: label,
			summary,
			secondaryMetrics: [
				{ label: 'Count', value: num(xs.length, 0) },
				{ label: 'Smallest number', value: num(Math.min(...xs), 0) },
				{ label: 'Largest number', value: num(Math.max(...xs), 0) },
				{ label: 'Relatively prime?', value: result === 1 ? 'Yes' : 'No' }
			]
		};
	},
	content: {
		intro:
			'Find the greatest common factor (GCF), also called the greatest common divisor, of two or more whole numbers. It is the largest number that divides every number in your list without a remainder.',
		howTo: [
			'Type two to twenty whole numbers, separated by commas or spaces.',
			'Use whole numbers from 1 up to 1,000,000,000,000. Decimals and zero are not accepted.',
			'Read the greatest common factor. For two numbers, the steps show Euclid’s method.'
		],
		formulas: [
			{
				title: 'Euclid’s method for two numbers',
				expression: 'gcf(a, b) = gcf(b, a mod b), and gcf(a, 0) = a',
				variables: [
					{ symbol: 'a, b', meaning: 'The two numbers, with a at least as large as b' },
					{ symbol: 'a mod b', meaning: 'The remainder when a is divided by b' }
				]
			},
			{
				title: 'More than two numbers',
				expression: 'gcf(a, b, c) = gcf(gcf(a, b), c)',
				variables: [{ symbol: 'gcf(a, b)', meaning: 'The result of the previous pair, which then pairs with the next number' }]
			}
		],
		example: {
			title: 'GCF of 48 and 180',
			steps: [
				'Divide 180 by 48: 180 = 3 × 48 + 36.',
				'Divide 48 by 36: 48 = 1 × 36 + 12.',
				'Divide 36 by 12: 36 = 3 × 12 + 0.',
				'The last nonzero remainder is 12.'
			],
			result: 'The greatest common factor of 48 and 180 is 12.'
		},
		faq: [
			{
				q: 'What is the difference between GCF and LCM?',
				a: 'The greatest common factor is the largest number that divides every value in the list. The least common multiple is the smallest number that every value divides into. Use the LCM calculator for that.'
			},
			{
				q: 'What does it mean when the GCF is 1?',
				a: 'The numbers share no factor other than 1. They are called relatively prime, or coprime. For example, 17 and 31 are both prime, so their GCF is 1.'
			},
			{
				q: 'Why does Euclid’s method work?',
				a: 'Any number that divides both a and b also divides the remainder a − b × q. So the pair (a, b) and the pair (b, remainder) have the same common factors, and the process keeps shrinking the numbers until the remainder is 0.'
			}
		]
	}
});
