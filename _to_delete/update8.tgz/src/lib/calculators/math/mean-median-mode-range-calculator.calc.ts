import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './mean-median-mode-range-calculator.meta';

/** "1", "1 and 2", or "1, 2 and 3". */
const joinNames = (items: string[]) =>
	items.length <= 2 ? items.join(' and ') : `${items.slice(0, -1).join(', ')} and ${items[items.length - 1]}`;

/** Values that occur most often. Empty when every value occurs only once. */
function modesOf(xs: number[]): number[] {
	const counts = new Map<number, number>();
	for (const x of xs) counts.set(x, (counts.get(x) ?? 0) + 1);
	const top = Math.max(...Array.from(counts.values()));
	if (top === 1) return [];
	return Array.from(counts.entries())
		.filter(([, count]) => count === top)
		.map(([x]) => x)
		.sort((p, q) => p - q);
}

function median(sorted: number[]): number {
	const n = sorted.length;
	const mid = Math.floor(n / 2);
	return n % 2 === 1 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'values',
			label: 'Numbers',
			type: 'list',
			default: '10, 2, 38, 23, 38, 23, 21',
			minCount: 1,
			placeholder: 'e.g. 4, 8, 15, 16',
			help: 'Separate the numbers with commas or spaces.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const xs = v.values as number[];
		const label = 'Mean';

		if (xs.length === 0 || xs.some((x) => !Number.isFinite(x))) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter one or more numbers, separated by commas.' };
		}

		const sorted = [...xs].sort((p, q) => p - q);
		const n = xs.length;
		const sum = xs.reduce((acc, x) => acc + x, 0);
		const mean = sum / n;
		const modes = modesOf(xs);
		const min = sorted[0];
		const max = sorted[n - 1];

		return {
			primaryResult: num(mean, 6),
			primaryLabel: label,
			summary: `Sum ${num(sum, 6)} ÷ ${num(n, 0)} numbers = ${num(mean, 6)}.`,
			secondaryMetrics: [
				{ label: 'Median', value: num(median(sorted), 6) },
				{ label: 'Mode(s)', value: modes.length ? joinNames(modes.map((x) => num(x, 6))) : 'none' },
				{ label: 'Range', value: num(max - min, 6) },
				{ label: 'Minimum', value: num(min, 6) },
				{ label: 'Maximum', value: num(max, 6) },
				{ label: 'Count', value: num(n, 0) },
				{ label: 'Sum', value: num(sum, 6) }
			]
		};
	},
	content: {
		intro:
			'Describe a list of numbers with its mean, median, mode, range, minimum, maximum, count and sum, all from one list. Each measure shows a different side of the data.',
		howTo: [
			'Type your numbers into the box, separated by commas or spaces.',
			'Read the mean first. It is the main average of the list.',
			'Check the median, mode, range and the minimum and maximum for the rest of the picture.'
		],
		formulas: [
			{
				title: 'Mean',
				expression: 'Mean = (x₁ + x₂ + … + xₙ) ÷ n',
				variables: [{ symbol: 'n', meaning: 'How many numbers there are' }]
			},
			{
				title: 'Median',
				expression: 'Sort the numbers. For an odd count, take the middle one. For an even count, take the mean of the two middle ones.',
				variables: []
			},
			{
				title: 'Mode',
				expression: 'The value that occurs most often. If every value occurs once, the list has no mode.',
				variables: []
			},
			{
				title: 'Range',
				expression: 'Range = maximum − minimum',
				variables: [{ symbol: 'max, min', meaning: 'The largest and smallest values in the list' }]
			}
		],
		example: {
			title: 'Describe 10, 2, 38, 23, 38, 23, 21',
			steps: [
				'Sum: 155, count: 7, so mean = 155 ÷ 7 = 22.142857',
				'Sorted: 2, 10, 21, 23, 23, 38, 38. The middle value is 23, so the median is 23.',
				'38 and 23 each appear twice, so the modes are 23 and 38.',
				'Range: 38 − 2 = 36'
			],
			result: 'Mean 22.142857, median 23, modes 23 and 38, range 36.'
		},
		faq: [
			{
				q: 'When is the median better than the mean?',
				a: 'The median is less affected by a few very large or very small values. For example, incomes or house prices often have a median that better shows a typical value.'
			},
			{
				q: 'What does it mean when there is no mode?',
				a: 'It means no value repeats more than the others. Every value occurs the same number of times, so no single value is the most common.'
			},
			{
				q: 'How is the range different from the standard deviation?',
				a: 'The range uses only the largest and smallest values. The standard deviation uses every value and shows how far the values typically sit from the mean.'
			}
		]
	}
});
