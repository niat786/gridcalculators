import { defineCalculator, type CalculationResult, type InputValues, type Table } from '../types';
import { DASH, num } from '../format';
import meta from './prime-factorization-calculator.meta';

const MAX_VALUE = 1e12;
const SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹';
const sup = (n: number) =>
	String(n)
		.split('')
		.map((d) => SUP[Number(d)])
		.join('');

/** Trial division: divide out each prime p while it fits, stopping once p² is larger than what is left. */
function primeFactors(n: number): number[] {
	const out: number[] = [];
	let m = n;
	for (let p = 2; p * p <= m; p++) {
		while (m % p === 0) {
			out.push(p);
			m /= p;
		}
	}
	if (m > 1) out.push(m);
	return out;
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'n',
			label: 'Whole number',
			type: 'number',
			default: 360,
			min: 2,
			max: MAX_VALUE,
			step: 1,
			decimal: false,
			help: 'From 2 to 1,000,000,000,000.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const n = Number(v.n);
		const label = 'Prime factorization';
		if (!Number.isInteger(n) || n < 2 || n > MAX_VALUE) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter a whole number from 2 to 1,000,000,000,000.' };
		}

		const factors = primeFactors(n);
		const counts = new Map<number, number>();
		for (const p of factors) counts.set(p, (counts.get(p) ?? 0) + 1);
		const exponentForm = [...counts.entries()].map(([p, k]) => `${p}${k > 1 ? sup(k) : ''}`).join(' × ');
		const isPrime = factors.length === 1;

		let rest = n;
		const rows = factors.map((p, i) => {
			rest /= p;
			return { step: String(i + 1), divide: String(p), quotient: num(rest, 0) };
		});
		const table: Table = {
			title: 'Factor tree, as repeated division',
			columns: [
				{ key: 'step', label: 'Step', align: 'start' },
				{ key: 'divide', label: 'Divide by', align: 'end' },
				{ key: 'quotient', label: 'Quotient', align: 'end' }
			],
			rows
		};

		const summary = isPrime
			? `${num(n, 0)} is prime, so its only prime factor is itself.`
			: `${num(n, 0)} = ${factors.join(' × ')}. Keep dividing by the smallest prime that fits until the quotient is 1.`;

		return {
			primaryResult: exponentForm,
			primaryLabel: label,
			summary,
			secondaryMetrics: [
				{ label: 'Distinct primes', value: String(counts.size) },
				{ label: 'Prime factors, with repeats', value: String(factors.length) },
				{ label: 'Largest prime factor', value: num(factors[factors.length - 1], 0) },
				{ label: 'Is it prime?', value: isPrime ? 'Yes' : 'No' }
			],
			table
		};
	},
	content: {
		intro:
			'Break a whole number into the prime numbers that multiply together to make it. The result is shown in exponent form, such as 2³ × 3² × 5, along with each division step of the factor tree.',
		howTo: [
			'Type a whole number from 2 up to 1,000,000,000,000.',
			'Read the answer in exponent form. The small raised number shows how many times that prime appears.',
			'Open the factor tree table to see each prime you divided by and what was left.'
		],
		formulas: [
			{
				title: 'Fundamental theorem of arithmetic',
				expression: 'n = p₁ᵃ × p₂ᵇ × … × pₖᶜ',
				variables: [
					{ symbol: 'p', meaning: 'A distinct prime number, listed from smallest to largest' },
					{ symbol: 'a, b, c', meaning: 'How many times each prime appears. Every whole number above 1 has exactly one such form' }
				]
			},
			{
				title: 'Trial division',
				expression: 'Divide n by 2, then 3, 5, 7 and so on, repeating each prime while it fits. Stop when p² is greater than what is left.',
				variables: [
					{ symbol: 'p', meaning: 'The candidate divisor' },
					{ symbol: 'p²', meaning: 'If no prime up to √(what is left) divides it, what is left is itself prime' }
				]
			}
		],
		example: {
			title: 'Prime factors of 360',
			steps: [
				'360 ÷ 2 = 180, then 180 ÷ 2 = 90, then 90 ÷ 2 = 45.',
				'45 ÷ 3 = 15, then 15 ÷ 3 = 5.',
				'5 is prime, so the last division is 5 ÷ 5 = 1.',
				'Collect the primes: 2, 2, 2, 3, 3, 5. Write repeats as powers: 2³ × 3² × 5.'
			],
			result: '360 = 2³ × 3² × 5, which has 6 prime factors counted with repeats.'
		},
		faq: [
			{
				q: 'What is exponent form?',
				a: 'Exponent form writes each repeated prime as a power. For example, 2 × 2 × 2 is written 2³, which means 2 multiplied by itself three times.'
			},
			{
				q: 'Is the prime factorization of a number unique?',
				a: 'Yes. Apart from the order of the factors, every whole number above 1 has exactly one way to be written as a product of primes. That is the fundamental theorem of arithmetic.'
			},
			{
				q: 'What is a factor tree?',
				a: 'A factor tree splits a number into two factors, then splits each factor again until every branch ends in a prime. This calculator shows the same process as a list of divisions.'
			}
		]
	}
});
