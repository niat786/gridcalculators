import { defineCalculator, type CalculationResult, type InputValues, type Table } from '../types';
import { DASH, num } from '../format';
import meta from './statistics-calculator.meta';

/** Median of an already sorted array. */
function medianSorted(xs: number[]): number {
	const n = xs.length;
	const mid = Math.floor(n / 2);
	return n % 2 ? xs[mid] : (xs[mid - 1] + xs[mid]) / 2;
}

/**
 * Inclusive median-of-halves quartiles. The lower half is the first ⌈n ÷ 2⌉ sorted values and the
 * upper half is the last ⌈n ÷ 2⌉ values. When n is odd the median sits in both halves.
 * Q1 is the median of the lower half and Q3 is the median of the upper half.
 */
function quartiles(sorted: number[]): { q1: number; q3: number } {
	const n = sorted.length;
	const lower = sorted.slice(0, Math.ceil(n / 2));
	const upper = sorted.slice(Math.floor(n / 2));
	return { q1: medianSorted(lower), q3: medianSorted(upper) };
}

/** Most common value(s). Returns null when every value occurs once. */
function modes(xs: number[]): number[] | null {
	const counts = new Map<number, number>();
	for (const x of xs) counts.set(x, (counts.get(x) ?? 0) + 1);
	let best = 0;
	for (const c of counts.values()) best = Math.max(best, c);
	if (best <= 1) return null;
	return [...counts.entries()]
		.filter(([, c]) => c === best)
		.map(([x]) => x)
		.sort((a, b) => a - b);
}

const fmt = (x: number): string => (Number.isFinite(x) ? num(x, 6) : DASH);

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'values',
			label: 'Numbers',
			type: 'list',
			default: '4, 8, 15, 16, 23, 42',
			minCount: 1,
			maxCount: 10000,
			placeholder: 'e.g. 4, 8, 15, 16',
			help: 'Separate the numbers with commas or spaces.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const xs = v.values as number[];
		const label = 'Mean';
		if (xs.some((x) => !Number.isFinite(x))) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter numbers only, separated by commas.' };
		}
		const n = xs.length;
		if (n === 0) return { primaryResult: DASH, primaryLabel: label, summary: 'Enter at least one number.' };

		const sorted = [...xs].sort((a, b) => a - b);
		const sum = sorted.reduce((acc, x) => acc + x, 0);
		const mean = sum / n;
		const median = medianSorted(sorted);
		const mode = modes(sorted);
		const min = sorted[0];
		const max = sorted[n - 1];
		const range = max - min;
		const { q1, q3 } = quartiles(sorted);
		const iqr = q3 - q1;

		const squares = sorted.reduce((acc, x) => acc + (x - mean) ** 2, 0);
		const popVar = squares / n;
		const popSd = Math.sqrt(popVar);
		const sampleVar = n >= 2 ? squares / (n - 1) : NaN;
		const sampleSd = Math.sqrt(sampleVar);
		const sem = n >= 2 ? sampleSd / Math.sqrt(n) : NaN;

		// Adjusted Fisher–Pearson sample skewness G1 and sample excess kurtosis G2 (the Excel SKEW and KURT forms).
		let m3 = 0;
		let m4 = 0;
		for (const x of sorted) {
			const d = x - mean;
			m3 += d ** 3;
			m4 += d ** 4;
		}
		m3 /= n;
		m4 /= n;
		const skew =
			n >= 3 && popVar > 0 ? ((m3 / popVar ** 1.5) * Math.sqrt(n * (n - 1))) / (n - 2) : NaN;
		const kurt =
			n >= 4 && popVar > 0
				? ((n + 1) * (m4 / (popVar * popVar) - 3) + 6) * ((n - 1) / ((n - 2) * (n - 3)))
				: NaN;

		const modeText = mode === null ? 'None (every value occurs once)' : mode.map((x) => num(x, 6)).join(', ');
		const rows: Record<string, string>[] = [
			{ measure: 'Count (n)', value: num(n, 0) },
			{ measure: 'Sum', value: fmt(sum) },
			{ measure: 'Mean', value: fmt(mean) },
			{ measure: 'Median', value: fmt(median) },
			{ measure: 'Mode', value: modeText },
			{ measure: 'Minimum', value: fmt(min) },
			{ measure: 'Maximum', value: fmt(max) },
			{ measure: 'Range (max − min)', value: fmt(range) },
			{ measure: 'Q1 (lower quartile)', value: fmt(q1) },
			{ measure: 'Q3 (upper quartile)', value: fmt(q3) },
			{ measure: 'Interquartile range (Q3 − Q1)', value: fmt(iqr) },
			{ measure: 'Sample variance (n − 1)', value: fmt(sampleVar) },
			{ measure: 'Sample standard deviation', value: fmt(sampleSd) },
			{ measure: 'Population variance (n)', value: fmt(popVar) },
			{ measure: 'Population standard deviation', value: fmt(popSd) },
			{ measure: 'Standard error of the mean', value: fmt(sem) },
			{ measure: 'Skewness (sample, adjusted)', value: fmt(skew) },
			{ measure: 'Excess kurtosis (sample, adjusted)', value: fmt(kurt) }
		];
		const table: Table = {
			title: 'All statistics (quartiles by the inclusive median-of-halves method)',
			columns: [
				{ key: 'measure', label: 'Measure' },
				{ key: 'value', label: 'Value', align: 'end' }
			],
			rows
		};

		return {
			primaryResult: fmt(mean),
			primaryLabel: label,
			summary: `Sum ${fmt(sum)} ÷ count ${num(n, 0)} = mean. Skewness and kurtosis need at least 3 and 4 values.`,
			secondaryMetrics: [
				{ label: 'Median', value: fmt(median) },
				{ label: 'Sample standard deviation', value: fmt(sampleSd) },
				{ label: 'Count', value: num(n, 0) },
				{ label: 'Range', value: fmt(range) }
			],
			table
		};
	},
	content: {
		intro:
			'Summarise a list of numbers in one place. Paste your values and get the mean, middle value, spread, quartiles, skewness and kurtosis together in a single table.',
		howTo: [
			'Type or paste your numbers, separated by commas or spaces. One number is enough.',
			'Read the mean at the top, then scroll the table for the median, mode, spread and shape measures.',
			'Use the sample rows when your list is a sample of a larger group, and the population rows when it is the whole group.'
		],
		formulas: [
			{
				title: 'Mean and median',
				expression: 'x̄ = Σx ÷ n.   Median: the middle value of the sorted list, or the average of the two middle values when n is even.',
				variables: [
					{ symbol: 'x̄', meaning: 'The mean' },
					{ symbol: 'n', meaning: 'The number of values' }
				]
			},
			{
				title: 'Quartiles (inclusive median-of-halves)',
				expression: 'Q1 = median of the lower ⌈n ÷ 2⌉ values.   Q3 = median of the upper ⌈n ÷ 2⌉ values.   IQR = Q3 − Q1',
				variables: [
					{ symbol: 'IQR', meaning: 'Interquartile range, the spread of the middle half of the data' }
				]
			},
			{
				title: 'Variance and standard deviation',
				expression: 'Sample: s² = Σ(x − x̄)² ÷ (n − 1).   Population: σ² = Σ(x − x̄)² ÷ n.   Standard deviation = √variance',
				variables: [{ symbol: 'Σ', meaning: 'Add over all values' }]
			},
			{
				title: 'Skewness (sample, adjusted Fisher–Pearson)',
				expression: 'G1 = g1 × √(n(n − 1)) ÷ (n − 2),   where g1 = [Σ(x − x̄)³ ÷ n] ÷ [Σ(x − x̄)² ÷ n]^(3/2)',
				variables: [{ symbol: 'g1', meaning: 'Moment-based skewness before the sample correction' }]
			},
			{
				title: 'Excess kurtosis (sample, adjusted)',
				expression: 'G2 = [(n + 1) × g2 + 6] × (n − 1) ÷ ((n − 2)(n − 3)),   where g2 = [Σ(x − x̄)⁴ ÷ n] ÷ [Σ(x − x̄)² ÷ n]² − 3',
				variables: [
					{ symbol: 'g2', meaning: 'Moment-based excess kurtosis; 0 for a normal curve' }
				]
			},
			{
				title: 'Standard error of the mean',
				expression: 'SE = s ÷ √n',
				variables: [{ symbol: 's', meaning: 'The sample standard deviation' }]
			}
		],
		example: {
			title: 'Mean of 4, 8, 15, 16, 23, 42',
			steps: [
				'Sum: 4 + 8 + 15 + 16 + 23 + 42 = 108',
				'Mean: 108 ÷ 6 = 18',
				'Median: (15 + 16) ÷ 2 = 15.5',
				'Sample variance: 910 ÷ 5 = 182, so the sample standard deviation is 13.490738'
			],
			result: 'The mean is 18. The median is 15.5, the sample standard deviation is 13.490738, and the skewness is 1.242611.'
		},
		faq: [
			{
				q: 'What is the difference between sample and population standard deviation?',
				a: 'Use the population version when your list is every member of the group. Use the sample version when the list is a subset, because dividing by n − 1 gives a better estimate of the spread.'
			},
			{
				q: 'What does skewness tell me?',
				a: 'Positive skew means a long tail to the right, with a few large values pulling the mean up. Negative skew means a long tail to the left. Values near 0 suggest a roughly symmetrical spread.'
			},
			{
				q: 'Why do I see no mode?',
				a: 'When every value occurs only once, no value is more common than the rest, so the calculator shows None. When several values tie for the most common, all of them are listed.'
			}
		],
		sources: [{ title: 'NIST/SEMATECH e-Handbook of Statistical Methods', url: 'https://www.itl.nist.gov/div898/handbook/' }]
	}
});
