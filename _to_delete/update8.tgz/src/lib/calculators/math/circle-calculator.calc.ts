import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './circle-calculator.meta';

const known = (value: string) => (v: InputValues) => v.known === value;

/** Radius from whichever measurement the person knows. NaN when it cannot be found. */
function radiusFrom(known: string, v: InputValues): number {
	const x = Number(v[known]);
	if (!Number.isFinite(x) || x <= 0) return NaN;
	switch (known) {
		case 'radius':
			return x;
		case 'diameter':
			return x / 2;
		case 'circumference':
			return x / (2 * Math.PI);
		case 'area':
			return Math.sqrt(x / Math.PI);
		default:
			return NaN;
	}
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'known',
			label: 'I know the',
			type: 'select',
			display: 'segmented',
			default: 'radius',
			options: [
				{ label: 'Radius', value: 'radius' },
				{ label: 'Diameter', value: 'diameter' },
				{ label: 'Circumference', value: 'circumference' },
				{ label: 'Area', value: 'area' }
			]
		},
		{ id: 'radius', label: 'Radius', type: 'number', default: 5, min: 0, visibleWhen: known('radius') },
		{ id: 'diameter', label: 'Diameter', type: 'number', default: 10, min: 0, visibleWhen: known('diameter') },
		{
			id: 'circumference',
			label: 'Circumference',
			type: 'number',
			default: 31.4159,
			min: 0,
			visibleWhen: known('circumference')
		},
		{ id: 'area', label: 'Area', type: 'number', default: 78.5398, min: 0, visibleWhen: known('area') }
	],
	calculate(v): CalculationResult {
		const r = radiusFrom(String(v.known), v);
		if (!Number.isFinite(r)) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Area',
				summary: 'Enter a value greater than zero in the field you chose.'
			};
		}
		const d = 2 * r;
		const c = 2 * Math.PI * r;
		const a = Math.PI * r * r;
		return {
			primaryResult: num(a, 6),
			primaryLabel: 'Area',
			summary: `π × ${num(r, 6)}² = ${num(a, 6)}`,
			secondaryMetrics: [
				{ label: 'Radius', value: num(r, 6) },
				{ label: 'Diameter', value: num(d, 6) },
				{ label: 'Circumference', value: num(c, 6) }
			]
		};
	},
	content: {
		intro:
			'Enter one measurement of a circle and get the other three: radius, diameter, circumference and area. Choose the value you already know first.',
		howTo: [
			'Choose which measurement you know: radius, diameter, circumference or area.',
			'Type that one value into the field that appears.',
			'Read the radius, diameter, circumference and area below.'
		],
		formulas: [
			{ title: 'Diameter', expression: 'd = 2 × r', variables: [{ symbol: 'd', meaning: 'diameter' }, { symbol: 'r', meaning: 'radius' }] },
			{
				title: 'Circumference',
				expression: 'C = 2 × π × r = π × d',
				variables: [{ symbol: 'C', meaning: 'circumference, the distance around the circle' }, { symbol: 'π', meaning: 'about 3.14159' }]
			},
			{ title: 'Area', expression: 'A = π × r²', variables: [{ symbol: 'A', meaning: 'area inside the circle' }] },
			{
				title: 'Finding the radius',
				expression: 'From diameter: r = d ÷ 2.   From circumference: r = C ÷ (2 × π).   From area: r = √(A ÷ π)',
				variables: []
			}
		],
		example: {
			title: 'A circle with a radius of 5 cm',
			steps: ['Diameter: 2 × 5 = 10', 'Circumference: 2 × π × 5 = 31.415927', 'Area: π × 5² = 78.539816'],
			result: 'The circle is 10 cm across, 31.415927 cm around and covers 78.539816 square cm.'
		},
		faq: [
			{
				q: 'How do I find the radius if I only know the area?',
				a: 'Divide the area by π, then take the square root. For an area of 78.54, the radius is √(78.54 ÷ 3.14159) ≈ 5.'
			},
			{
				q: 'Is π exactly 3.14?',
				a: 'No. π is an irrational number that starts 3.14159265. The calculator uses the full value of π, so results are more precise than 3.14.'
			},
			{
				q: 'What is the difference between circumference and area?',
				a: 'Circumference is the length of the outer edge, measured in units such as centimetres. Area is the flat space inside, measured in square units.'
			}
		]
	}
});
