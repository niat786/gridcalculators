import { defineCalculator, type CalculationResult, type InputValues, type Table } from '../types';
import { DASH, num } from '../format';
import meta from './number-sequence-calculator.meta';

const MAX_TERM = 1000;
const FIRST_TERMS = 10;

const fail = (summary: string): CalculationResult => ({ primaryResult: DASH, primaryLabel: 'Sequence', summary });

/** Decimal number for display. Very large or small values switch to scientific notation. */
function fmt(x: number): string {
	if (!Number.isFinite(x)) return DASH;
	if (Math.abs(x) >= 1e15) return x.toExponential(6).replace(/e\+?(-?\d+)/, ' × 10^$1');
	return num(x, 6);
}

/** Groups the digits of a whole number in threes, e.g. 12586269025 → 12,586,269,025. */
const group = (digits: string): string => digits.replace(/\B(?=(\d{3})+(?!\d))/g, ',');

/** Fibonacci numbers with F₁ = 1 and F₂ = 1, exact with BigInt. Returns [F(n − 1), F(n)]. */
function fibPair(n: number): [bigint, bigint] {
	let prev = 0n;
	let cur = 1n;
	for (let i = 1; i < n; i++) [prev, cur] = [cur, prev + cur];
	return [prev, cur];
}

function firstTermsTable(label: string, terms: string[]): Table {
	return {
		title: label,
		columns: [
			{ key: 'term', label: 'Term' },
			{ key: 'value', label: 'Value', align: 'end' }
		],
		rows: terms.map((value, i) => ({ term: num(i + 1, 0), value }))
	};
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Sequence type',
			type: 'select',
			display: 'segmented',
			default: 'arithmetic',
			options: [
				{ label: 'Arithmetic', value: 'arithmetic' },
				{ label: 'Geometric', value: 'geometric' },
				{ label: 'Fibonacci', value: 'fibonacci' }
			]
		},
		{
			id: 'a1',
			label: 'First term (a₁)',
			type: 'number',
			default: 2,
			visibleWhen: (v: InputValues) => v.mode !== 'fibonacci'
		},
		{
			id: 'd',
			label: 'Common difference (d)',
			type: 'number',
			default: 3,
			help: 'Added to each term to get the next one.',
			visibleWhen: (v: InputValues) => v.mode === 'arithmetic'
		},
		{
			id: 'r',
			label: 'Common ratio (r)',
			type: 'number',
			default: 0.5,
			help: 'Each term is the previous term times r.',
			visibleWhen: (v: InputValues) => v.mode === 'geometric'
		},
		{
			id: 'n',
			label: 'Term number (n)',
			type: 'number',
			default: 10,
			min: 1,
			max: MAX_TERM,
			decimal: false,
			help: 'Whole number from 1 to 1,000.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const mode = String(v.mode);
		const n = Number(v.n);
		if (!Number.isInteger(n) || n < 1 || n > MAX_TERM) return fail('Enter a whole term number from 1 to 1,000.');

		if (mode === 'fibonacci') {
			const [prev, cur] = fibPair(n);
			const digits = cur.toString().length;
			const terms: string[] = [];
			let [a, b] = [0n, 1n];
			for (let i = 1; i <= FIRST_TERMS; i++) {
				terms.push(group(b.toString()));
				[a, b] = [b, a + b];
			}
			const ratio = n >= 2 ? fmt(Number(cur) / Number(prev)) : DASH;
			return {
				primaryResult: group(cur.toString()),
				primaryLabel: `Fibonacci number F(${num(n, 0)})`,
				long: digits > 15,
				summary: `F(n) = F(n − 1) + F(n − 2), with F₁ = 1 and F₂ = 1. This number has ${num(digits, 0)} digits.`,
				secondaryMetrics: [
					{ label: 'Digits in the number', value: num(digits, 0) },
					{ label: 'Previous term F(n − 1)', value: group(prev.toString()) },
					{ label: 'Ratio F(n) ÷ F(n − 1)', value: ratio }
				],
				table: firstTermsTable('First 10 terms', terms)
			};
		}

		const a1 = Number(v.a1);
		if (!Number.isFinite(a1)) return fail('Enter a first term.');

		if (mode === 'arithmetic') {
			const d = Number(v.d);
			if (!Number.isFinite(d)) return fail('Enter a common difference.');
			const nth = a1 + (n - 1) * d;
			const sum = (n * (2 * a1 + (n - 1) * d)) / 2;
			const next = nth + d;
			const terms = Array.from({ length: FIRST_TERMS }, (_, i) => fmt(a1 + i * d));
			return {
				primaryResult: fmt(nth),
				primaryLabel: `Term ${num(n, 0)} of the arithmetic sequence`,
				summary: `aₙ = a₁ + (n − 1) × d = ${fmt(a1)} + ${num(n - 1, 0)} × ${fmt(d)} = ${fmt(nth)}.`,
				secondaryMetrics: [
					{ label: 'Sum of the first n terms', value: fmt(sum) },
					{ label: 'Next term (n + 1)', value: fmt(next) },
					{ label: 'Common difference (d)', value: fmt(d) }
				],
				table: firstTermsTable('First 10 terms', terms)
			};
		}

		if (mode === 'geometric') {
			const r = Number(v.r);
			if (!Number.isFinite(r)) return fail('Enter a common ratio.');
			const nth = a1 * Math.pow(r, n - 1);
			const sum = r === 1 ? n * a1 : (a1 * (1 - Math.pow(r, n))) / (1 - r);
			const next = a1 * Math.pow(r, n);
			if (![nth, sum, next].every((x) => Number.isFinite(x))) {
				return fail('Those numbers are too large to calculate. Try a smaller term number or ratio.');
			}
			const infinite =
				Math.abs(r) < 1 ? fmt(a1 / (1 - r)) : a1 === 0 ? '0' : 'Not defined, because |r| is 1 or more';
			const terms = Array.from({ length: FIRST_TERMS }, (_, i) => fmt(a1 * Math.pow(r, i)));
			return {
				primaryResult: fmt(nth),
				primaryLabel: `Term ${num(n, 0)} of the geometric sequence`,
				summary: `aₙ = a₁ × rⁿ⁻¹ = ${fmt(a1)} × ${fmt(r)}^${num(n - 1, 0)} = ${fmt(nth)}.`,
				secondaryMetrics: [
					{ label: 'Sum of the first n terms', value: fmt(sum) },
					{ label: 'Infinite sum', value: infinite },
					{ label: 'Next term (n + 1)', value: fmt(next) }
				],
				table: firstTermsTable('First 10 terms', terms)
			};
		}

		return fail('Choose arithmetic, geometric or Fibonacci.');
	},
	content: {
		intro:
			'Find any term of a number sequence and the sum of its terms. Choose arithmetic for a constant difference, geometric for a constant ratio, or Fibonacci for the sequence where each number is the sum of the two before it.',
		howTo: [
			'Choose the sequence type.',
			'Enter the first term and the common difference or ratio. Fibonacci needs only the term number.',
			'Enter the term number n, then read the nth term, the sum and the first ten terms.'
		],
		formulas: [
			{
				title: 'Arithmetic sequence',
				expression: 'aₙ = a₁ + (n − 1)d.   Sum: Sₙ = n(2a₁ + (n − 1)d) ÷ 2',
				variables: [
					{ symbol: 'a₁', meaning: 'The first term' },
					{ symbol: 'd', meaning: 'The common difference' },
					{ symbol: 'n', meaning: 'The term number' }
				]
			},
			{
				title: 'Geometric sequence',
				expression: 'aₙ = a₁ × rⁿ⁻¹.   Sum: Sₙ = a₁(1 − rⁿ) ÷ (1 − r).   Infinite sum: a₁ ÷ (1 − r), only when |r| < 1',
				variables: [
					{ symbol: 'r', meaning: 'The common ratio' },
					{ symbol: '|r|', meaning: 'The size of r, ignoring the sign' }
				]
			},
			{
				title: 'Fibonacci sequence',
				expression: 'F₁ = 1, F₂ = 1, Fₙ = Fₙ₋₁ + Fₙ₋₂',
				variables: [{ symbol: 'Fₙ', meaning: 'The nth Fibonacci number' }]
			}
		],
		example: {
			title: 'Arithmetic sequence with a₁ = 2, d = 3, n = 10',
			steps: [
				'Term 10: 2 + 9 × 3 = 29',
				'Sum of 10 terms: 10 × (2 × 2 + 9 × 3) ÷ 2 = 155'
			],
			result: 'The 10th term is 29, and the first 10 terms add up to 155.'
		},
		faq: [
			{
				q: 'How do I know if a sequence is arithmetic or geometric?',
				a: 'An arithmetic sequence adds the same number each step. A geometric sequence multiplies by the same number each step. Divide a term by the one before it to check the ratio, or subtract to check the difference.'
			},
			{
				q: 'When does a geometric series have an infinite sum?',
				a: 'Only when the absolute value of the ratio is less than 1. Then the terms shrink toward zero and the sum settles at a₁ ÷ (1 − r). Otherwise the sum grows without limit.'
			},
			{
				q: 'Why does the Fibonacci ratio approach 1.618?',
				a: 'Divide each Fibonacci number by the one before it and the answers settle near 1.6180339887, the golden ratio. Larger term numbers give closer values.'
			}
		],
		sources: [{ title: 'OEIS A000045: Fibonacci numbers', url: 'https://oeis.org/A000045' }]
	}
});
