import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num, pct } from '../format';
import meta from './percentage-calculator.meta';

const mode = (m: string) => (v: InputValues) => v.mode === m;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'What do you want to find?',
			type: 'select',
			display: 'segmented',
			default: 'of',
			options: [
				{ label: '% of a number', value: 'of' },
				{ label: '% change', value: 'change' },
				{ label: 'X is what %', value: 'ratio' }
			]
		},
		{ id: 'p', label: 'Percent', type: 'number', default: 20, suffix: '%', visibleWhen: mode('of') },
		{ id: 'x', label: 'Of number', type: 'number', default: 150, visibleWhen: mode('of') },
		{ id: 'from', label: 'From (old value)', type: 'number', default: 80, visibleWhen: mode('change') },
		{ id: 'to', label: 'To (new value)', type: 'number', default: 100, visibleWhen: mode('change') },
		{ id: 'part', label: 'Value', type: 'number', default: 30, visibleWhen: mode('ratio') },
		{ id: 'whole', label: 'Is what percent of', type: 'number', default: 120, visibleWhen: mode('ratio') }
	],
	calculate(v): CalculationResult {
		if (v.mode === 'change') {
			const a = Number(v.from);
			const b = Number(v.to);
			if (!Number.isFinite(a) || !Number.isFinite(b) || a === 0) {
				return { primaryResult: DASH, primaryLabel: 'Percent change', summary: 'The old value can’t be zero.' };
			}
			const c = ((b - a) / Math.abs(a)) * 100;
			const sign = c > 0 ? '+' : '';
			return {
				primaryResult: `${sign}${pct(c, 4)}`,
				primaryLabel: 'Percent change',
				summary: `(${num(b, 4)} − ${num(a, 4)}) ÷ |${num(a, 4)}| × 100 = ${sign}${pct(c, 4)}`,
				secondaryMetrics: [
					{ label: 'Direction', value: c > 0 ? 'Increase' : c < 0 ? 'Decrease' : 'No change' },
					{ label: 'Difference', value: num(b - a, 4) }
				]
			};
		}
		if (v.mode === 'ratio') {
			const a = Number(v.part);
			const b = Number(v.whole);
			if (!Number.isFinite(a) || !Number.isFinite(b) || b === 0) {
				return { primaryResult: DASH, primaryLabel: 'Percentage', summary: 'The whole can’t be zero.' };
			}
			const q = (a / b) * 100;
			return {
				primaryResult: pct(q, 4),
				primaryLabel: 'Percentage',
				summary: `${num(a, 4)} ÷ ${num(b, 4)} × 100 = ${pct(q, 4)}`
			};
		}
		const p = Number(v.p);
		const x = Number(v.x);
		if (!Number.isFinite(p) || !Number.isFinite(x)) {
			return { primaryResult: DASH, primaryLabel: 'Result', summary: 'Enter a percent and a number.' };
		}
		const r = (p / 100) * x;
		return {
			primaryResult: num(r, 4),
			primaryLabel: `${num(p, 4)}% of ${num(x, 4)}`,
			summary: `${num(p, 4)} ÷ 100 × ${num(x, 4)} = ${num(r, 4)}`,
			secondaryMetrics: [
				{ label: `${num(x, 4)} plus ${num(p, 4)}%`, value: num(x + r, 4) },
				{ label: `${num(x, 4)} minus ${num(p, 4)}%`, value: num(x - r, 4) }
			]
		};
	},
	content: {
		intro:
			'Solve the three everyday percentage problems: a percent of a number, the percent change between two numbers, and what percent one number is of another.',
		howTo: [
			'Pick the kind of problem at the top.',
			'Enter your two numbers.',
			'The answer and the working update as you type.'
		],
		formulas: [
			{ title: 'Percent of a number', expression: 'Result = P ÷ 100 × X', variables: [] },
			{ title: 'Percent change', expression: 'Change = (New − Old) ÷ |Old| × 100', variables: [] },
			{ title: 'What percent A is of B', expression: 'Percent = A ÷ B × 100', variables: [] }
		],
		example: {
			title: 'A price rises from $80 to $100',
			steps: ['Difference: 100 − 80 = 20', 'Divide by the old value: 20 ÷ 80 = 0.25', 'Multiply by 100: 0.25 × 100 = 25'],
			result: 'The price went up by 25%.'
		},
		faq: [
			{
				q: 'How do I calculate a percentage of a number?',
				a: 'Divide the percentage by 100 and multiply by the number. For example, 20% of 150 is 0.20 × 150 = 30.'
			},
			{
				q: 'What is the difference between percent change and percentage points?',
				a: 'Percent change is relative to the starting value. Percentage points are a simple difference between two percentages: going from 10% to 15% is a 5 percentage point rise, but a 50% increase.'
			},
			{
				q: 'Why is a 50% drop not undone by a 50% rise?',
				a: 'Because each change is measured from a different starting value. $100 falls 50% to $50, but a 50% rise on $50 only brings it back to $75.'
			}
		]
	}
});
