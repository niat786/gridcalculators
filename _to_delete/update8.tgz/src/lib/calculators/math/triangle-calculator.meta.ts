import { defineMeta } from '../types';

export default defineMeta({
	slug: 'triangle-calculator',
	name: 'Triangle Calculator',
	category: 'math',
	shortDescription: 'Solve any triangle: all sides, angles, area, perimeter and type.',
	metaTitle: 'Triangle Calculator — SSS, SAS, ASA, AAS & SSA',
	metaDescription:
		'Free triangle solver. Enter three sides, two sides and an angle, or two angles and a side to get every side, every angle, the area and the triangle type.',
	icon: 'triangle',
	keywords: ['triangle calculator', 'triangle solver', 'law of cosines calculator', 'law of sines calculator', 'triangle area calculator'],
	updated: '2026-10-28'
});
