import { defineMeta } from '../types';

export default defineMeta({
	slug: 'p-value-calculator',
	name: 'P-Value Calculator',
	category: 'math',
	shortDescription: 'Find a p-value from a z, t, chi-square or F test statistic.',
	metaTitle: 'P-Value Calculator — z, t, Chi-Square and F',
	metaDescription:
		'Free p-value calculator. Enter a z, t, chi-square or F statistic and its degrees of freedom to get a left, right or two-tailed p-value and a significance check.',
	icon: 'scale',
	keywords: [
		'p-value calculator',
		'p value from z score',
		'p value from t statistic',
		'chi-square p-value calculator',
		'F test p-value'
	],
	updated: '2026-10-28'
});
