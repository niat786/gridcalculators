import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num, pct, plural } from '../format';
import meta from './probability-calculator.meta';

/** Probabilities are entered and shown as percentages (30 means 30%). */
const P = (p: number): string => pct(p * 100, p * 100 < 0.0001 ? 10 : 4);

const fail = (summary: string): CalculationResult => ({ primaryResult: DASH, primaryLabel: 'Result', summary });

/**
 * Binomial probability P(X = k) for n trials with success chance p, computed in log space
 * so large n does not overflow. Log factorials are passed in as a table.
 */
function binomPmf(n: number, k: number, p: number, logFact: number[]): number {
	if (p === 0) return k === 0 ? 1 : 0;
	if (p === 1) return k === n ? 1 : 0;
	return Math.exp(logFact[n] - logFact[k] - logFact[n - k] + k * Math.log(p) + (n - k) * Math.log(1 - p));
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Type of problem',
			type: 'select',
			display: 'segmented',
			default: 'events',
			options: [
				{ label: 'Two events', value: 'events' },
				{ label: 'Repeated trials', value: 'trials' }
			]
		},
		{
			id: 'pA',
			label: 'Probability of A',
			type: 'number',
			default: 30,
			min: 0,
			max: 100,
			suffix: '%',
			help: 'Enter a percentage, such as 30 for 30%.',
			visibleWhen: (v: InputValues) => v.mode === 'events'
		},
		{
			id: 'pB',
			label: 'Probability of B',
			type: 'number',
			default: 50,
			min: 0,
			max: 100,
			suffix: '%',
			visibleWhen: (v: InputValues) => v.mode === 'events'
		},
		{
			id: 'pTrial',
			label: 'Probability per trial',
			type: 'number',
			default: 10,
			min: 0,
			max: 100,
			suffix: '%',
			help: 'The chance of success on each trial. Each trial is assumed independent.',
			visibleWhen: (v: InputValues) => v.mode === 'trials'
		},
		{
			id: 'trials',
			label: 'Number of trials (n)',
			type: 'number',
			default: 5,
			min: 1,
			max: 1000,
			decimal: false,
			visibleWhen: (v: InputValues) => v.mode === 'trials'
		},
		{
			id: 'k',
			label: 'Number of successes (k)',
			type: 'number',
			default: 2,
			min: 0,
			max: 1000,
			decimal: false,
			visibleWhen: (v: InputValues) => v.mode === 'trials'
		}
	],
	calculate(v: InputValues): CalculationResult {
		if (String(v.mode) === 'trials') {
			const p = Number(v.pTrial) / 100;
			const n = Number(v.trials);
			const k = Number(v.k);
			const label = 'Probability of exactly k successes';
			if (!(p >= 0 && p <= 1) || !Number.isFinite(n) || !Number.isFinite(k)) {
				return fail('Enter a chance between 0% and 100%, and whole numbers for trials and successes.');
			}
			if (!Number.isInteger(n) || n < 1 || n > 1000) return fail('Enter a whole number of trials from 1 to 1,000.');
			if (!Number.isInteger(k) || k < 0 || k > n) return fail('Successes must be a whole number from 0 up to the number of trials.');

			const logFact = [0];
			for (let i = 1; i <= n; i++) logFact[i] = logFact[i - 1] + Math.log(i);

			const exactly = binomPmf(n, k, p, logFact);
			const none = Math.pow(1 - p, n);
			const atLeastOne = 1 - none;
			let atMost = 0;
			for (let i = 0; i <= k; i++) atMost += binomPmf(n, i, p, logFact);

			return {
				primaryResult: P(exactly),
				primaryLabel: `Probability of exactly ${plural(k, 'success', 'successes')}`,
				summary: `${num(n, 0)} independent trials, each with a ${P(p)} chance of success.`,
				secondaryMetrics: [
					{ label: 'P(at least one success)', value: P(atLeastOne) },
					{ label: 'P(no successes)', value: P(none) },
					{ label: 'P(at most k successes)', value: P(atMost) },
					{ label: 'Expected successes (n × p)', value: num(n * p, 4) }
				]
			};
		}

		const pa = Number(v.pA) / 100;
		const pb = Number(v.pB) / 100;
		if (!(pa >= 0 && pa <= 1) || !(pb >= 0 && pb <= 1)) {
			return fail('Enter a probability from 0% to 100% for both A and B.');
		}
		const both = pa * pb;
		return {
			primaryResult: P(both),
			primaryLabel: 'P(A and B)',
			summary: `For independent events, P(A and B) = P(A) × P(B) = ${P(pa)} × ${P(pb)}.`,
			secondaryMetrics: [
				{ label: 'P(A or B)', value: P(pa + pb - both) },
				{ label: 'P(A but not B)', value: P(pa * (1 - pb)) },
				{ label: 'P(neither A nor B)', value: P((1 - pa) * (1 - pb)) },
				{ label: 'P(not A)', value: P(1 - pa) },
				{ label: 'P(not B)', value: P(1 - pb) }
			]
		};
	},
	content: {
		intro:
			'Work out the chance of combined outcomes. Enter the chances of two independent events to see both, either, or neither, or enter one chance and a number of repeated trials to see the odds of getting a given number of successes.',
		howTo: [
			'Choose Two events or Repeated trials.',
			'Enter each probability as a percentage, such as 30 for 30%. For trials, also enter how many trials you have and how many successes you want.',
			'Read the main result, then the related outcomes in the list below it.'
		],
		formulas: [
			{
				title: 'Two independent events',
				expression: 'P(A and B) = P(A) × P(B)     P(A or B) = P(A) + P(B) − P(A) × P(B)',
				variables: [
					{ symbol: 'P(A)', meaning: 'The probability that event A happens' },
					{ symbol: 'P(B)', meaning: 'The probability that event B happens' }
				]
			},
			{
				title: 'Complements',
				expression: 'P(not A) = 1 − P(A)     P(neither) = (1 − P(A)) × (1 − P(B))',
				variables: [{ symbol: '1 −', meaning: 'The chance that an event does not happen' }]
			},
			{
				title: 'Exactly k successes in n trials (binomial)',
				expression: 'P(X = k) = C(n, k) × pᵏ × (1 − p)ⁿ⁻ᵏ,   where C(n, k) = n! ÷ (k! × (n − k)!)',
				variables: [
					{ symbol: 'n', meaning: 'The number of trials' },
					{ symbol: 'k', meaning: 'The number of successes you want' },
					{ symbol: 'p', meaning: 'The chance of success on one trial' },
					{ symbol: 'C(n, k)', meaning: 'The number of ways to choose which k trials succeed' }
				]
			}
		],
		example: {
			title: 'A = 30% and B = 50%, two independent events',
			steps: [
				'Both: 0.30 × 0.50 = 0.15',
				'Either: 0.30 + 0.50 − 0.15 = 0.65',
				'A but not B: 0.30 × (1 − 0.50) = 0.15'
			],
			result: 'P(A and B) is 15%, and P(A or B) is 65%.'
		},
		faq: [
			{
				q: 'What does independent mean here?',
				a: 'Two events are independent when one happening does not change the chance of the other. Coin flips and separate dice rolls are independent. Drawing two cards without replacement is not.'
			},
			{
				q: 'What is the difference between A or B and A and B?',
				a: 'A or B counts outcomes where at least one event happens, including the case where both do. A and B counts only the cases where both happen.'
			},
			{
				q: 'How do I find the chance of at least one success?',
				a: 'Use the repeated trials mode and read P(at least one success). It equals 1 minus the chance of no successes at all, which is (1 − p) raised to the number of trials.'
			}
		]
	}
});
