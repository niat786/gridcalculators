import { defineCalculator, type CalculationResult } from '../types';
import { DASH, num } from '../format';
import meta from './root-calculator.meta';

/** Number with a true minus sign (−) for negatives, for display. */
const sgn = (x: number) => (x < 0 ? '−' : '') + num(Math.abs(x), 6);

/** 2 → "2nd", 3 → "3rd", 4 → "4th", 11 → "11th", 21 → "21st". */
function ordinal(n: number): string {
	const suffixes = ['th', 'st', 'nd', 'rd'];
	const v = n % 100;
	return n + (suffixes[(v - 20) % 10] ?? suffixes[v] ?? 'th');
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'x', label: 'Number', type: 'number', default: 16, help: 'The number to take the root of. Negative numbers work with odd roots.' },
		{
			id: 'n',
			label: 'Root degree',
			type: 'number',
			default: 2,
			min: 2,
			max: 100,
			decimal: false,
			help: '2 for a square root, 3 for a cube root, and so on.'
		}
	],
	calculate(v): CalculationResult {
		const x = Number(v.x);
		const n = Number(v.n);
		if (!Number.isFinite(x)) return { primaryResult: DASH, primaryLabel: 'Root', summary: 'Enter a number.' };
		if (!Number.isInteger(n) || n < 2) {
			return { primaryResult: DASH, primaryLabel: 'Root', summary: 'The root degree must be a whole number, 2 or more.' };
		}
		if (x < 0 && n % 2 === 0) {
			return {
				primaryResult: DASH,
				primaryLabel: `${ordinal(n)} root`,
				summary: `A negative number has no real root of even degree. Try an odd degree, such as 3.`,
				secondaryMetrics: [
					{ label: 'Square root', value: 'Not real' },
					{ label: 'Cube root', value: sgn(Math.cbrt(x)) },
					{ label: 'Check (root to the power n)', value: DASH }
				]
			};
		}

		const r = x < 0 ? -Math.pow(-x, 1 / n) : Math.pow(x, 1 / n);
		const label = n === 2 ? 'Square root' : n === 3 ? 'Cube root' : `${ordinal(n)} root`;
		return {
			primaryResult: sgn(r + 0),
			primaryLabel: label,
			summary: `The ${ordinal(n)} root of ${sgn(x)} is ${sgn(r + 0)}, because ${sgn(r + 0)}^${n} = ${sgn(Math.pow(r, n) + 0)}.`,
			secondaryMetrics: [
				{ label: 'Square root', value: x < 0 ? 'Not real' : sgn(Math.sqrt(x)) },
				{ label: 'Cube root', value: sgn(Math.cbrt(x) + 0) },
				{ label: 'Check (root to the power n)', value: sgn(Math.pow(r, n) + 0) }
			]
		};
	},
	content: {
		intro:
			'Find the root of a number: the square root, the cube root, or any root of a chosen degree. The square and cube roots of the number are always shown alongside.',
		howTo: [
			'Enter the number.',
			'Enter the root degree. Use 2 for a square root, 3 for a cube root, and so on.',
			'Read the root, then check it: the result raised to the degree gives back your number.'
		],
		formulas: [
			{
				title: 'Nth root',
				expression: 'ⁿ√x = x^(1/n)',
				variables: [
					{ symbol: 'x', meaning: 'the number' },
					{ symbol: 'n', meaning: 'the root degree' }
				]
			},
			{ title: 'Square root', expression: '√x = x^(1/2)', variables: [] },
			{ title: 'Cube root', expression: '∛x = x^(1/3)', variables: [] },
			{
				title: 'Check',
				expression: '(ⁿ√x)ⁿ = x',
				variables: []
			}
		],
		example: {
			title: 'The fourth root of 81',
			steps: ['Find r where r⁴ = 81', '81^(1/4) = 3', 'Check: 3⁴ = 3 × 3 × 3 × 3 = 81'],
			result: 'The fourth root of 81 is 3.'
		},
		faq: [
			{
				q: 'Can you take the square root of a negative number?',
				a: 'Not with a real number. The square of any real number is zero or positive, so a negative number has no real square root. Its square root is an imaginary number.'
			},
			{
				q: 'Why does a cube root of a negative number work?',
				a: 'Multiplying three negative numbers gives a negative result, so the cube root of −27 is −3. Any odd root of a negative number is a real number.'
			},
			{
				q: 'Why does the result show a value like 2.519842 for the cube root of 16?',
				a: 'Most roots are irrational numbers that never end. The calculator rounds the answer to six decimal places, so the check step may show the original number exactly or very close to it.'
			}
		]
	}
});
