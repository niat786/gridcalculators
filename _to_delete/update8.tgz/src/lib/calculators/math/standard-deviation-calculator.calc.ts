import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './standard-deviation-calculator.meta';

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'values',
			label: 'Numbers',
			type: 'list',
			default: '10, 2, 38, 23, 38, 23, 21',
			minCount: 2,
			placeholder: 'e.g. 4, 8, 15, 16',
			help: 'Separate the numbers with commas or spaces.'
		},
		{
			id: 'kind',
			label: 'Type of data',
			type: 'select',
			display: 'segmented',
			default: 'sample',
			options: [
				{ label: 'Sample (n − 1)', value: 'sample' },
				{ label: 'Population (n)', value: 'population' }
			],
			help: 'Use sample when your numbers are a subset of a larger group.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const xs = v.values as number[];
		const isSample = v.kind !== 'population';
		const label = isSample ? 'Standard deviation (sample)' : 'Standard deviation (population)';
		const n = xs.length;

		if (xs.some((x) => !Number.isFinite(x))) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter numbers only, separated by commas.' };
		}
		if (n === 0 || (isSample && n < 2)) {
			return {
				primaryResult: DASH,
				primaryLabel: label,
				summary: isSample
					? 'A sample needs at least two numbers. Add one more, or choose population.'
					: 'Enter at least one number.'
			};
		}

		const sum = xs.reduce((acc, x) => acc + x, 0);
		const mean = sum / n;
		const squares = xs.reduce((acc, x) => acc + (x - mean) ** 2, 0);
		const divisor = isSample ? n - 1 : n;
		const variance = squares / divisor;
		const sd = Math.sqrt(variance);
		// The standard error always uses the sample standard deviation, so it needs two or more numbers.
		const sem = n >= 2 ? Math.sqrt(squares / (n - 1)) / Math.sqrt(n) : NaN;

		return {
			primaryResult: num(sd, 6),
			primaryLabel: label,
			summary: `Sum of squared differences ${num(squares, 6)} ÷ ${isSample ? `(${n} − 1)` : n} = variance ${num(variance, 6)}, then take the square root.`,
			secondaryMetrics: [
				{ label: 'Variance', value: num(variance, 6) },
				{ label: 'Mean', value: num(mean, 6) },
				{ label: 'Count', value: num(n, 0) },
				{ label: 'Sum', value: num(sum, 6) },
				{ label: 'Standard error of the mean', value: num(sem, 6) }
			]
		};
	},
	content: {
		intro:
			'Measure how spread out a list of numbers is around its mean. Choose sample when your numbers are a subset of a larger group, or population when they are every value in the group.',
		howTo: [
			'Type your numbers, separated by commas or spaces. You need at least two for a sample.',
			'Choose Sample (n − 1) or Population (n).',
			'Read the standard deviation. The variance, mean, count, sum and standard error show the working.'
		],
		formulas: [
			{
				title: 'Mean',
				expression: 'μ = (x₁ + x₂ + … + xₙ) ÷ n',
				variables: [{ symbol: 'μ', meaning: 'The mean of the numbers' }]
			},
			{
				title: 'Variance',
				expression: 'Sample: s² = Σ(xᵢ − μ)² ÷ (n − 1).   Population: σ² = Σ(xᵢ − μ)² ÷ n',
				variables: [
					{ symbol: 'Σ', meaning: 'Add up over all the numbers' },
					{ symbol: 'n − 1', meaning: 'Used for a sample to correct for estimating the mean from the same data' }
				]
			},
			{
				title: 'Standard deviation',
				expression: 's = √s²   or   σ = √σ²',
				variables: [{ symbol: '√', meaning: 'The square root' }]
			},
			{
				title: 'Standard error of the mean',
				expression: 'SEM = s ÷ √n',
				variables: [
					{ symbol: 's', meaning: 'The sample standard deviation' },
					{ symbol: 'n', meaning: 'The number of values' }
				]
			}
		],
		example: {
			title: 'Sample standard deviation of 1, 2, 3, 4, 5',
			steps: [
				'Mean: (1 + 2 + 3 + 4 + 5) ÷ 5 = 3',
				'Squared differences: 4 + 1 + 0 + 1 + 4 = 10',
				'Variance: 10 ÷ (5 − 1) = 2.5',
				'Standard deviation: √2.5 = 1.581139'
			],
			result: 'The sample standard deviation is 1.581139. The standard error of the mean is 0.707107.'
		},
		faq: [
			{
				q: 'When should I use sample or population?',
				a: 'Use population when your list includes every member of the group you care about. Use sample when the list is a subset, such as survey answers from some of the people you wanted to study. The sample version divides by n − 1, which gives a fairer estimate of the spread.'
			},
			{
				q: 'What is the difference between standard deviation and variance?',
				a: 'Variance is the average of the squared distances from the mean. Standard deviation is its square root, so it is in the same units as your data.'
			},
			{
				q: 'What is the standard error of the mean?',
				a: 'It estimates how much the sample mean would vary between samples. It equals the sample standard deviation divided by the square root of n, so larger samples give smaller standard errors.'
			}
		]
	}
});
