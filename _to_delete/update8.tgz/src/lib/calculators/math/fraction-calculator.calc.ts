import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './fraction-calculator.meta';

interface Frac {
	n: number;
	d: number;
}

const LABEL = 'Simplified fraction';
const SYMBOL: Record<string, string> = { add: '+', sub: '−', mul: '×', div: '÷' };

export function gcd(a: number, b: number): number {
	let x = Math.abs(a);
	let y = Math.abs(b);
	while (y !== 0) {
		const t = x % y;
		x = y;
		y = t;
	}
	return x;
}

/** Keep the sign on the top number and the denominator positive. */
function normalize(f: Frac): Frac {
	return f.d < 0 ? { n: -f.n, d: -f.d } : f;
}

function simplify(f: Frac): Frac {
	const s = normalize(f);
	const g = gcd(s.n, s.d) || 1;
	return { n: s.n / g || 0, d: s.d / g };
}

/** "5/6", or "3" when the denominator is 1. */
function fracText(f: Frac): string {
	const s = normalize(f);
	return s.d === 1 ? String(s.n) : `${s.n}/${s.d}`;
}

/** "1 3/4", "5/6" or "-1/4". Expects a simplified fraction. */
function mixedText(f: Frac): string {
	const s = simplify(f);
	if (s.d === 1) return String(s.n);
	const whole = Math.trunc(s.n / s.d);
	const rest = Math.abs(s.n % s.d);
	if (whole === 0) return `${s.n < 0 ? '-' : ''}${rest}/${s.d}`;
	return `${whole} ${rest}/${s.d}`;
}

const decimal = (f: Frac) => num(f.n / f.d || 0, 6);

/** Whole part plus numerator over denominator, written as one fraction. */
function improper(w: number, n: number, d: number): Frac {
	return normalize({ n: w * d + n, d });
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'whole1',
			label: 'First whole number',
			type: 'number',
			default: 0,
			min: 0,
			max: 1000,
			step: 1,
			decimal: false,
			help: 'Use 0 for a plain fraction.'
		},
		{ id: 'num1', label: 'First numerator', type: 'number', default: 1, min: -10000, max: 10000, step: 1, decimal: false, width: 'half' },
		{ id: 'den1', label: 'First denominator', type: 'number', default: 2, min: -10000, max: 10000, step: 1, decimal: false, width: 'half' },
		{
			id: 'op',
			label: 'Operation',
			type: 'select',
			display: 'segmented',
			default: 'add',
			options: [
				{ label: '+', value: 'add' },
				{ label: '−', value: 'sub' },
				{ label: '×', value: 'mul' },
				{ label: '÷', value: 'div' }
			]
		},
		{
			id: 'whole2',
			label: 'Second whole number',
			type: 'number',
			default: 0,
			min: 0,
			max: 1000,
			step: 1,
			decimal: false,
			help: 'Use 0 for a plain fraction.'
		},
		{ id: 'num2', label: 'Second numerator', type: 'number', default: 1, min: -10000, max: 10000, step: 1, decimal: false, width: 'half' },
		{ id: 'den2', label: 'Second denominator', type: 'number', default: 3, min: -10000, max: 10000, step: 1, decimal: false, width: 'half' }
	],
	calculate(v: InputValues): CalculationResult {
		const [w1, n1, d1, w2, n2, d2] = [v.whole1, v.num1, v.den1, v.whole2, v.num2, v.den2].map(Number);
		const op = String(v.op);

		if (![w1, n1, d1, w2, n2, d2].every(Number.isInteger)) {
			return {
				primaryResult: DASH,
				primaryLabel: LABEL,
				summary: 'Use whole numbers only for the whole part, numerator and denominator.'
			};
		}
		if (d1 === 0 || d2 === 0) return { primaryResult: DASH, primaryLabel: LABEL, summary: 'A denominator can’t be zero.' };
		if (!['add', 'sub', 'mul', 'div'].includes(op)) return { primaryResult: DASH, primaryLabel: LABEL, summary: 'Pick an operation.' };

		const a = improper(w1, n1, d1);
		const b = improper(w2, n2, d2);
		const steps: string[] = [];
		if (w1 !== 0) steps.push(`${w1} ${n1}/${d1} = ${fracText(a)}.`);
		if (w2 !== 0) steps.push(`${w2} ${n2}/${d2} = ${fracText(b)}.`);

		let raw: Frac;
		if (op === 'add' || op === 'sub') {
			const sign = op === 'add' ? 1 : -1;
			const L = (a.d / gcd(a.d, b.d)) * b.d;
			const na = a.n * (L / a.d);
			const nb = b.n * (L / b.d);
			const total = na + sign * nb;
			raw = { n: total, d: L };
			steps.push(`Common denominator ${L}: ${fracText(a)} = ${na}/${L} and ${fracText(b)} = ${nb}/${L}.`);
			steps.push(`Then ${na} ${SYMBOL[op]} ${nb < 0 ? `(${nb})` : nb} = ${total}, so the result is ${total}/${L}.`);
		} else if (op === 'mul') {
			raw = { n: a.n * b.n, d: a.d * b.d };
			steps.push(`Multiply the tops and the bottoms: ${fracText(a)} × ${fracText(b)} = ${fracText(raw)}.`);
		} else {
			if (b.n === 0) {
				return {
					primaryResult: DASH,
					primaryLabel: LABEL,
					summary: 'You can’t divide by zero. The second fraction’s top number must not be 0.'
				};
			}
			const reciprocal: Frac = { n: b.d, d: b.n };
			raw = { n: a.n * b.d, d: a.d * b.n };
			steps.push(
				`Dividing by a fraction means multiplying by its reciprocal: ${fracText(a)} × ${fracText(reciprocal)} = ${fracText(raw)}.`
			);
		}

		const result = simplify(raw);
		const shown = fracText(result);
		if (fracText(raw) !== shown) steps.push(`Simplified: ${fracText(raw)} = ${shown}.`);

		return {
			primaryResult: shown,
			primaryLabel: LABEL,
			summary: steps.join(' '),
			secondaryMetrics: [
				{ label: 'Mixed number', value: mixedText(result) },
				{ label: 'Decimal', value: decimal(result) },
				{ label: 'Before simplifying', value: fracText(raw) }
			]
		};
	},
	content: {
		intro:
			'Add, subtract, multiply or divide two fractions or mixed numbers. The answer comes back as a simplified fraction, a mixed number and a decimal.',
		howTo: [
			'Enter the whole number part of each fraction. Use 0 if there is none.',
			'Enter the numerator (top) and denominator (bottom) of each fraction. The denominator cannot be 0.',
			'Pick an operation. The answer and the working update as you type.'
		],
		formulas: [
			{
				title: 'Add or subtract',
				expression: 'a/b ± c/d = (a × (L ÷ b) ± c × (L ÷ d)) ÷ L',
				variables: [{ symbol: 'L', meaning: 'The common denominator: the smallest number that both b and d divide into' }]
			},
			{
				title: 'Multiply',
				expression: 'a/b × c/d = (a × c) ÷ (b × d)',
				variables: [{ symbol: 'a, c', meaning: 'The numerators (tops)' }, { symbol: 'b, d', meaning: 'The denominators (bottoms)' }]
			},
			{
				title: 'Divide',
				expression: 'a/b ÷ c/d = a/b × d/c = (a × d) ÷ (b × c)',
				variables: [{ symbol: 'd/c', meaning: 'The reciprocal of c/d: swap its top and bottom' }]
			},
			{
				title: 'Mixed number to fraction',
				expression: 'W n/d = (W × d + n) ÷ d',
				variables: [{ symbol: 'W', meaning: 'The whole number part' }, { symbol: 'n/d', meaning: 'The fraction part' }]
			}
		],
		example: {
			title: 'Add 1/2 and 1/3',
			steps: [
				'Common denominator: the smallest number that 2 and 3 both divide into is 6.',
				'1/2 = 3/6 and 1/3 = 2/6',
				'3/6 + 2/6 = 5/6',
				'5/6 cannot be reduced, so it is already simplified.'
			],
			result: '1/2 + 1/3 = 5/6, which is 0.833333 as a decimal.'
		},
		faq: [
			{
				q: 'How do I simplify a fraction?',
				a: 'Divide the top and bottom by their greatest common divisor, the largest whole number that divides both. For example, 6/8 has a common divisor of 2, so it simplifies to 3/4.'
			},
			{
				q: 'How do I add fractions with different denominators?',
				a: 'Rewrite each fraction over a common denominator, then add the tops and keep the bottom. The least common denominator keeps the numbers small.'
			},
			{
				q: 'How do I divide fractions?',
				a: 'Multiply the first fraction by the reciprocal of the second, which means swapping the top and bottom of the second. So 1/2 ÷ 1/4 becomes 1/2 × 4/1 = 2.'
			},
			{
				q: 'Why can a denominator not be zero?',
				a: 'Division by zero has no answer, so a fraction with a zero denominator is undefined. A fraction with a zero top number is fine, but you cannot divide by one.'
			}
		]
	}
});
