import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './volume-calculator.meta';

const is = (...shapes: string[]) => (v: InputValues) => shapes.includes(String(v.shape));
const positive = (...xs: number[]) => xs.every((x) => Number.isFinite(x) && x > 0);

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'shape',
			label: 'Shape',
			type: 'select',
			display: 'menu',
			default: 'cylinder',
			options: [
				{ label: 'Cube', value: 'cube' },
				{ label: 'Rectangular box', value: 'box' },
				{ label: 'Cylinder', value: 'cylinder' },
				{ label: 'Cone', value: 'cone' },
				{ label: 'Sphere', value: 'sphere' },
				{ label: 'Hemisphere', value: 'hemisphere' },
				{ label: 'Square pyramid', value: 'pyramid' },
				{ label: 'Capsule', value: 'capsule' }
			]
		},
		{ id: 'edge', label: 'Edge length', type: 'number', default: 4, min: 0, visibleWhen: is('cube') },
		{ id: 'length', label: 'Length', type: 'number', default: 6, min: 0, visibleWhen: is('box') },
		{ id: 'width', label: 'Width', type: 'number', default: 4, min: 0, visibleWhen: is('box') },
		{
			id: 'height',
			label: 'Height',
			type: 'number',
			default: 10,
			min: 0,
			visibleWhen: is('box', 'cylinder', 'cone', 'pyramid')
		},
		{
			id: 'radius',
			label: 'Radius',
			type: 'number',
			default: 3,
			min: 0,
			visibleWhen: is('cylinder', 'cone', 'sphere', 'hemisphere', 'capsule')
		},
		{
			id: 'baseEdge',
			label: 'Base edge',
			type: 'number',
			default: 4,
			min: 0,
			help: 'Side length of the square base.',
			visibleWhen: is('pyramid')
		},
		{
			id: 'straight',
			label: 'Straight length',
			type: 'number',
			default: 5,
			min: 0,
			help: 'Length of the middle tube, not counting the two rounded ends.',
			visibleWhen: is('capsule')
		}
	],
	calculate(v): CalculationResult {
		const shape = String(v.shape);
		const n = (k: string) => Number(v[k]);
		const pi = Math.PI;
		const fail = (summary: string): CalculationResult => ({ primaryResult: DASH, primaryLabel: 'Volume', summary });
		let volume: number;
		let area: number | undefined;
		let working: string;

		switch (shape) {
			case 'cube': {
				const a = n('edge');
				if (!positive(a)) return fail('Enter an edge length greater than zero.');
				volume = a ** 3;
				area = 6 * a * a;
				working = `${num(a, 4)}³ = ${num(volume, 4)}`;
				break;
			}
			case 'box': {
				const l = n('length');
				const w = n('width');
				const h = n('height');
				if (!positive(l, w, h)) return fail('Enter a length, width and height greater than zero.');
				volume = l * w * h;
				area = 2 * (l * w + l * h + w * h);
				working = `${num(l, 4)} × ${num(w, 4)} × ${num(h, 4)} = ${num(volume, 4)}`;
				break;
			}
			case 'cylinder': {
				const r = n('radius');
				const h = n('height');
				if (!positive(r, h)) return fail('Enter a radius and height greater than zero.');
				volume = pi * r * r * h;
				area = 2 * pi * r * r + 2 * pi * r * h;
				working = `π × ${num(r, 4)}² × ${num(h, 4)} = ${num(volume, 4)}`;
				break;
			}
			case 'cone': {
				const r = n('radius');
				const h = n('height');
				if (!positive(r, h)) return fail('Enter a radius and height greater than zero.');
				volume = (pi * r * r * h) / 3;
				working = `⅓ × π × ${num(r, 4)}² × ${num(h, 4)} = ${num(volume, 4)}`;
				break;
			}
			case 'sphere': {
				const r = n('radius');
				if (!positive(r)) return fail('Enter a radius greater than zero.');
				volume = (4 / 3) * pi * r ** 3;
				area = 4 * pi * r * r;
				working = `4/3 × π × ${num(r, 4)}³ = ${num(volume, 4)}`;
				break;
			}
			case 'hemisphere': {
				const r = n('radius');
				if (!positive(r)) return fail('Enter a radius greater than zero.');
				volume = (2 / 3) * pi * r ** 3;
				working = `2/3 × π × ${num(r, 4)}³ = ${num(volume, 4)}`;
				break;
			}
			case 'pyramid': {
				const s = n('baseEdge');
				const h = n('height');
				if (!positive(s, h)) return fail('Enter a base edge and height greater than zero.');
				volume = (s * s * h) / 3;
				working = `⅓ × ${num(s, 4)}² × ${num(h, 4)} = ${num(volume, 4)}`;
				break;
			}
			case 'capsule': {
				const r = n('radius');
				const h = n('straight');
				if (!positive(r, h)) return fail('Enter a radius and straight length greater than zero.');
				volume = pi * r * r * h + (4 / 3) * pi * r ** 3;
				working = `π × ${num(r, 4)}² × ${num(h, 4)} + 4/3 × π × ${num(r, 4)}³ = ${num(volume, 4)}`;
				break;
			}
			default:
				return fail('Pick a shape.');
		}

		const metrics = area === undefined ? [] : [{ label: 'Surface area', value: num(area, 4) }];
		return {
			primaryResult: num(volume, 4),
			primaryLabel: 'Volume',
			summary: working,
			secondaryMetrics: metrics
		};
	},
	content: {
		intro:
			'Find the volume of a solid, the amount of space it fills. Pick a shape and enter its measurements. Cubes, boxes, cylinders and spheres also show the surface area.',
		howTo: [
			'Choose the shape.',
			'Enter its measurements, all in the same unit.',
			'Read the volume in cubic units. Surface area, where shown, is in square units.'
		],
		formulas: [
			{ title: 'Cube', expression: 'Volume = a³,   Surface area = 6 × a²', variables: [{ symbol: 'a', meaning: 'edge length' }] },
			{
				title: 'Rectangular box',
				expression: 'Volume = l × w × h,   Surface area = 2 × (lw + lh + wh)',
				variables: [
					{ symbol: 'l, w, h', meaning: 'length, width and height' }
				]
			},
			{
				title: 'Cylinder',
				expression: 'Volume = π × r² × h,   Surface area = 2 × π × r² + 2 × π × r × h',
				variables: [{ symbol: 'r', meaning: 'radius of the round base' }, { symbol: 'h', meaning: 'height' }]
			},
			{ title: 'Cone', expression: 'Volume = ⅓ × π × r² × h', variables: [{ symbol: 'r', meaning: 'radius of the base' }] },
			{
				title: 'Sphere',
				expression: 'Volume = 4/3 × π × r³,   Surface area = 4 × π × r²',
				variables: [{ symbol: 'r', meaning: 'radius' }]
			},
			{ title: 'Hemisphere', expression: 'Volume = 2/3 × π × r³', variables: [{ symbol: 'r', meaning: 'radius' }] },
			{ title: 'Square pyramid', expression: 'Volume = ⅓ × b² × h', variables: [{ symbol: 'b', meaning: 'side of the square base' }] },
			{
				title: 'Capsule',
				expression: 'Volume = π × r² × h + 4/3 × π × r³',
				variables: [{ symbol: 'h', meaning: 'length of the straight middle section, not the total length' }]
			}
		],
		example: {
			title: 'A cylindrical can, 3 cm radius and 10 cm tall',
			steps: [
				'Volume: π × 3² × 10 = 282.7433',
				'Surface area: 2 × π × 3² + 2 × π × 3 × 10 = 245.0442'
			],
			result: 'The can holds about 282.74 cubic cm and its surface area is about 245.04 square cm.'
		},
		faq: [
			{
				q: 'What is the difference between volume and surface area?',
				a: 'Volume is the space inside the solid, in cubic units. Surface area is the total area of its outside faces, in square units.'
			},
			{
				q: 'How many litres is a cubic metre?',
				a: 'One cubic metre is 1,000 litres. For smaller shapes, 1 cubic centimetre is 1 millilitre.'
			},
			{
				q: 'Why is the capsule height not its total length?',
				a: 'A capsule has two hemispherical ends. The straight length is the middle section only, so the total length is the straight length plus two radii.'
			}
		]
	}
});
