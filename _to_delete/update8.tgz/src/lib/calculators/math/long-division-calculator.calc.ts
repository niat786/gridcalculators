import { defineCalculator, type CalculationResult, type InputValues, type Table } from '../types';
import { DASH, num } from '../format';
import meta from './long-division-calculator.meta';

const MAX_DIVIDEND = 1_000_000_000_000;
const MAX_DIVISOR = 1_000_000;
const DECIMAL_PLACES = 10;
/** Longest repeating block written out in full; longer blocks are cut with an ellipsis. */
const MAX_SHOWN_BLOCK = 40;

export interface DivisionStep {
	/** 1-based position of the digit brought down. */
	step: number;
	digit: number;
	/** Previous remainder × 10 + the digit brought down. */
	partial: number;
	quotientDigit: number;
	product: number;
	remainder: number;
}

/** Digit-by-digit long division of whole numbers. One step per digit of the dividend. */
export function longDivide(dividend: number, divisor: number) {
	const steps: DivisionStep[] = [];
	let remainder = 0;
	let quotientText = '';
	[...String(dividend)].forEach((ch, i) => {
		const digit = Number(ch);
		const partial = remainder * 10 + digit;
		const quotientDigit = Math.floor(partial / divisor);
		const product = quotientDigit * divisor;
		remainder = partial - product;
		steps.push({ step: i + 1, digit, partial, quotientDigit, product, remainder });
		quotientText += String(quotientDigit);
	});
	return { quotient: Number(quotientText), remainder, steps };
}

export interface DecimalForm {
	/** Digits after the decimal point, up to the end of the first repeating block. */
	digits: number[];
	/** Index in `digits` where the repeating block starts, or -1 when the decimal ends. */
	repeatStart: number;
	/** Length of the repeating block; 0 when the decimal ends. */
	period: number;
}

/**
 * Digits of remainder ÷ divisor. A remainder that comes back to one already seen means the
 * digits from there on repeat. Remainders are below the divisor, so this always stops.
 */
export function decimalForm(remainder: number, divisor: number): DecimalForm {
	const digits: number[] = [];
	if (remainder === 0) return { digits, repeatStart: -1, period: 0 };
	const seen = new Map<number, number>([[remainder, 0]]);
	let r = remainder;
	for (;;) {
		r *= 10;
		digits.push(Math.floor(r / divisor));
		r %= divisor;
		if (r === 0) return { digits, repeatStart: -1, period: 0 };
		const first = seen.get(r);
		if (first !== undefined) return { digits, repeatStart: first, period: digits.length - first };
		seen.set(r, digits.length);
	}
}

function digitAt(form: DecimalForm, i: number): number {
	if (form.repeatStart < 0) return form.digits[i] ?? 0;
	if (i < form.repeatStart) return form.digits[i];
	return form.digits[form.repeatStart + ((i - form.repeatStart) % form.period)];
}

function repeatingNotation(intText: string, form: DecimalForm): string {
	if (form.repeatStart < 0) return form.digits.length ? `${intText}.${form.digits.join('')}` : intText;
	const before = form.digits.slice(0, form.repeatStart).join('');
	const block = form.digits.slice(form.repeatStart);
	const shown = block.length > MAX_SHOWN_BLOCK ? `${block.slice(0, MAX_SHOWN_BLOCK).join('')}…` : block.join('');
	return `${intText}.${before}(${shown})`;
}

function gcd(a: number, b: number): number {
	return b === 0 ? a : gcd(b, a % b);
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'dividend',
			label: 'Dividend (number to divide)',
			type: 'number',
			default: 1234,
			min: 0,
			max: MAX_DIVIDEND,
			decimal: false,
			help: 'A whole number from 0 to 1,000,000,000,000.'
		},
		{
			id: 'divisor',
			label: 'Divisor (divide by)',
			type: 'number',
			default: 7,
			min: 1,
			max: MAX_DIVISOR,
			decimal: false,
			help: 'A whole number from 1 to 1,000,000.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const n = Number(v.dividend);
		const d = Number(v.divisor);
		const valid =
			Number.isInteger(n) && n >= 0 && n <= MAX_DIVIDEND && Number.isInteger(d) && d >= 1 && d <= MAX_DIVISOR;
		if (!valid) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Quotient and remainder',
				summary: `Enter whole numbers: dividend 0 to ${num(MAX_DIVIDEND)}, divisor 1 to ${num(MAX_DIVISOR)}.`
			};
		}

		const { quotient, remainder, steps } = longDivide(n, d);
		const form = decimalForm(remainder, d);
		const intText = num(quotient, 0);
		const tenPlaces = Array.from({ length: DECIMAL_PLACES }, (_, i) => digitAt(form, i)).join('');
		const g = gcd(remainder, d);
		const mixed = remainder === 0 ? intText : `${intText} ${remainder / g}/${d / g}`;

		const table: Table = {
			title: `Long division: ${n} ÷ ${d}`,
			columns: [
				{ key: 'step', label: 'Step' },
				{ key: 'bring', label: 'Bring down', align: 'end' },
				{ key: 'partial', label: 'Partial dividend', align: 'end' },
				{ key: 'divide', label: 'Divide' },
				{ key: 'multiply', label: 'Multiply' },
				{ key: 'subtract', label: 'Subtract' }
			],
			rows: steps.map((s) => ({
				step: String(s.step),
				bring: String(s.digit),
				partial: String(s.partial),
				divide: `${s.partial} ÷ ${d} = ${s.quotientDigit} R ${s.remainder}`,
				multiply: `${s.quotientDigit} × ${d} = ${s.product}`,
				subtract: `${s.partial} − ${s.product} = ${s.remainder}`
			}))
		};

		return {
			primaryResult: `${intText} R ${remainder}`,
			primaryLabel: 'Quotient and remainder',
			summary: `${num(n, 0)} ÷ ${d} = ${intText} with a remainder of ${remainder}. Check: ${d} × ${intText} + ${remainder} = ${num(n, 0)}.`,
			secondaryMetrics: [
				{ label: 'Decimal (first 10 places)', value: `${intText}.${tenPlaces}` },
				{ label: 'Exact or repeating form', value: repeatingNotation(intText, form) },
				{
					label: 'Repeating block',
					value: form.period ? `${num(form.period, 0)} ${form.period === 1 ? 'digit' : 'digits'}` : 'None, the decimal ends'
				},
				{ label: 'Mixed number', value: mixed }
			],
			table
		};
	},
	content: {
		intro:
			'Long division shows how many times one whole number fits into another and what is left over. This tool works through the dividend one digit at a time, the way you would on paper.',
		howTo: [
			'Enter the dividend, the number you want to divide, as a whole number up to 1,000,000,000,000.',
			'Enter the divisor, the number you divide by, as a whole number from 1 to 1,000,000. Decimals are not accepted.',
			'Read the quotient and remainder first, then the decimal form. Repeating digits are shown in brackets.',
			'Follow the table to see each step, with one row for every digit of the dividend.'
		],
		formulas: [
			{
				title: 'Quotient and remainder',
				expression: 'dividend = divisor × quotient + remainder, with 0 ≤ remainder < divisor',
				variables: [
					{ symbol: 'dividend', meaning: 'The number being divided' },
					{ symbol: 'divisor', meaning: 'The number you divide by' },
					{ symbol: 'quotient', meaning: 'Whole groups of the divisor that fit' },
					{ symbol: 'remainder', meaning: 'What is left over' }
				]
			},
			{
				title: 'Each long division step',
				expression: 'partial = previous remainder × 10 + next digit, quotient digit = ⌊partial ÷ divisor⌋, new remainder = partial − divisor × quotient digit',
				variables: []
			},
			{
				title: 'Decimal digits',
				expression: 'next digit = ⌊10 × remainder ÷ divisor⌋, new remainder = 10 × remainder mod divisor',
				variables: [{ symbol: 'remainder', meaning: 'The remainder from the previous digit' }]
			}
		],
		example: {
			title: 'Divide 1,234 by 7',
			steps: [
				'Bring down the 1. 1 is smaller than 7, so the first quotient digit is 0.',
				'Bring down the 2. 12 ÷ 7 = 1 remainder 5. Write 1 in the quotient.',
				'Bring down the 3. 53 ÷ 7 = 7 remainder 4. Write 7 in the quotient.',
				'Bring down the 4. 44 ÷ 7 = 6 remainder 2. Write 6 in the quotient.',
				'The quotient is 176 with a remainder of 2. As a decimal, 2 ÷ 7 = 0.285714 repeating, so the answer is 176.(285714).'
			],
			result: '1,234 ÷ 7 = 176 R 2, or 176.(285714) as a repeating decimal.'
		},
		faq: [
			{
				q: 'What is a remainder?',
				a: 'The remainder is what is left after you take out as many whole groups of the divisor as you can. For 17 ÷ 5, five fits three times with 2 left over, so the remainder is 2.'
			},
			{
				q: 'How are repeating decimals written?',
				a: 'Digits that repeat forever are put in brackets. 1 ÷ 6 = 0.1666…, which is written 0.1(6). When a remainder returns to a value already seen, the digits from that point repeat.'
			},
			{
				q: 'Why does the table include a row with a 0 digit?',
				a: 'A digit too small to hold a whole group of the divisor gives a quotient digit of 0. The row is kept so every digit of the dividend is shown.'
			},
			{
				q: 'Can I divide decimal numbers here?',
				a: 'Not directly. Multiply both numbers by the same power of 10 until they are whole numbers. For 12.5 ÷ 5, use 125 ÷ 50, which gives 2.5.'
			}
		]
	}
});
