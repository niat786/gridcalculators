import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH } from '../format';
import meta from './scientific-notation-calculator.meta';

/** Guards against inputs such as "1e99999999" that would make a huge plain-decimal string. */
const MAX_EXPONENT = 10000;
const MINUS = '−';
const SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹';

const supDigits = (n: number) =>
	String(n)
		.split('')
		.map((d) => SUP[Number(d)])
		.join('');
const supExp = (e: number) => (e < 0 ? '⁻' : '') + supDigits(Math.abs(e));

interface Parsed {
	neg: boolean;
	/** Significant digits with no leading zeros. Empty for zero. */
	D: string;
	/** Value = 0.D × 10^point. */
	point: number;
}

/**
 * Reads the text as digits and a power of ten, without floating-point math, so long inputs stay exact.
 * Commas and spaces are ignored. Trailing zeros are dropped unless the number has a decimal point.
 */
function parse(text: string): Parsed | null {
	const cleaned = text.replace(/[,\s_]/g, '');
	const m = /^([+-]?)(\d*)(?:\.(\d*))?(?:[eE]([+-]?\d+))?$/.exec(cleaned);
	if (!m) return null;
	const ip = m[2];
	const fp = m[3] ?? '';
	if (ip.length + fp.length === 0) return null;
	const e10 = m[4] === undefined ? 0 : Number(m[4]);
	if (!Number.isFinite(e10) || Math.abs(e10) > MAX_EXPONENT) return null;

	let D = ip + fp;
	let point = ip.length + e10;
	const lead = D.length - D.replace(/^0+/, '').length;
	D = D.slice(lead);
	point -= lead;
	if (D === '') return { neg: m[1] === '-', D: '', point: 0 };
	if (fp === '') D = D.replace(/0+$/, '');
	return { neg: m[1] === '-', D, point };
}

/** Round half up to n significant digits. A carry such as 999.6 → 1000 moves the point. */
function roundTo(D: string, point: number, n: number): { D: string; point: number } {
	if (D.length <= n) return { D: D.padEnd(n, '0'), point };
	const head = D.slice(0, n);
	if (D.charAt(n) < '5') return { D: head, point };
	const up = (BigInt(head) + BigInt(1)).toString();
	if (up.length > n) return { D: up.slice(0, n), point: point + 1 };
	return { D: up, point };
}

/** Plain decimal from digits and the point position, e.g. ("123", -3) → "0.000123". */
function toPlain(D: string, point: number): string {
	if (point <= 0) return `0.${'0'.repeat(-point)}${D}`;
	if (point >= D.length) return D + '0'.repeat(point - D.length);
	return `${D.slice(0, point)}.${D.slice(point)}`;
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'value',
			label: 'Number',
			type: 'text',
			default: '0.000123',
			monospace: true,
			maxLength: 400,
			placeholder: 'e.g. 0.000123 or 1.23e-4',
			pattern: /^[\s\d,._+\-eE]*$/,
			patternMessage: 'Use digits, a decimal point, commas or an exponent such as 1.23e-4.',
			help: 'Commas and spaces are ignored. An exponent such as e-4 or E6 is allowed.'
		},
		{
			id: 'sig',
			label: 'Significant figures',
			type: 'select',
			default: 'auto',
			options: [
				{ label: 'Auto (keep the digits entered)', value: 'auto' },
				{ label: '1', value: '1' },
				{ label: '2', value: '2' },
				{ label: '3', value: '3' },
				{ label: '4', value: '4' },
				{ label: '5', value: '5' },
				{ label: '6', value: '6' },
				{ label: '7', value: '7' },
				{ label: '8', value: '8' },
				{ label: '9', value: '9' },
				{ label: '10', value: '10' }
			],
			help: 'Round the coefficient to this many significant digits, or keep every digit you typed.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const label = 'Scientific notation';
		const parsed = parse(String(v.value));
		if (!parsed) {
			return {
				primaryResult: DASH,
				primaryLabel: label,
				summary: 'Enter a number, such as 0.000123, 1.23e-4 or 1,230,000.'
			};
		}

		if (parsed.D === '') {
			return {
				primaryResult: `0 × 10⁰`,
				primaryLabel: label,
				summary: 'Zero is written as 0 × 10⁰.',
				secondaryMetrics: [
					{ label: 'E notation', value: '0E0' },
					{ label: 'Engineering notation', value: '0E0' },
					{ label: 'Plain decimal', value: '0' },
					{ label: 'Significant figures', value: DASH }
				]
			};
		}

		const sigRaw = String(v.sig);
		// Only 1–10 are valid; anything else falls back to Auto.
		const sigOpt = /^(10|[1-9])$/.test(sigRaw) ? sigRaw : 'auto';
		let { D, point } = parsed;
		if (sigOpt !== 'auto') ({ D, point } = roundTo(D, point, Number(sigOpt)));

		const sign = parsed.neg ? MINUS : '';
		const exp = point - 1;
		const mantissa = D.length > 1 ? `${D[0]}.${D.slice(1)}` : D;

		// Engineering notation: the exponent is a multiple of 3, and the coefficient runs from 1 to 999.
		const e3 = Math.floor(exp / 3) * 3;
		const before = exp - e3 + 1;
		const padded = D.padEnd(before, '0');
		const engMantissa = padded.slice(0, before) + (padded.length > before ? `.${padded.slice(before)}` : '');

		const shift = Math.abs(exp);
		const summary =
			exp === 0
				? 'The number is already between 1 and 10, so the exponent is 0.'
				: `Move the decimal point ${shift} place${shift === 1 ? '' : 's'} to the ${exp < 0 ? 'right' : 'left'}, so one digit sits before it.`;
		const rounded =
			sigOpt === 'auto' ? '' : ` Rounded half up to ${sigOpt} significant figure${sigOpt === '1' ? '' : 's'}.`;

		return {
			primaryResult: `${sign}${mantissa} × 10${supExp(exp)}`,
			primaryLabel: label,
			summary: summary + rounded,
			secondaryMetrics: [
				{ label: 'E notation', value: `${sign}${mantissa}E${exp}` },
				{ label: 'Engineering notation', value: `${sign}${engMantissa}E${e3}` },
				{ label: 'Plain decimal', value: `${sign}${toPlain(D, point)}` },
				{ label: 'Significant figures', value: String(D.length) }
			]
		};
	},
	content: {
		intro:
			'Write any number in scientific notation, which is a number from 1 up to 10 multiplied by a power of ten. The calculator also gives E notation, engineering notation and the plain decimal form, and can round to a set number of significant figures.',
		howTo: [
			'Type a number. You can use a decimal point, commas (1,230,000), or an exponent (1.23e-4).',
			'Choose how many significant figures to keep, or leave it on Auto to keep the digits you typed.',
			'Read the scientific form first, then the E, engineering and plain decimal versions.'
		],
		formulas: [
			{
				title: 'Scientific notation',
				expression: 'x = a × 10ⁿ, where 1 ≤ |a| < 10',
				variables: [
					{ symbol: 'a', meaning: 'The coefficient, with exactly one non-zero digit before the decimal point' },
					{ symbol: 'n', meaning: 'The exponent: how many places the decimal point moves to reach a' }
				]
			},
			{
				title: 'Engineering notation',
				expression: 'x = a × 10ᵐ, where m is a multiple of 3 and 1 ≤ |a| < 1000',
				variables: [{ symbol: 'm', meaning: 'An exponent that is a multiple of 3, such as −6, 3 or 9' }]
			},
			{
				title: 'Rounding to significant figures',
				expression: 'Keep the first k non-zero digits. If the next digit is 5 or more, round up.',
				variables: [{ symbol: 'k', meaning: 'The number of significant figures you choose' }]
			}
		],
		example: {
			title: 'Write 0.000123 in scientific notation',
			steps: [
				'Move the decimal point 4 places to the right: 0.000123 becomes 1.23.',
				'Moving right makes the exponent negative, so the exponent is −4.',
				'Check: 1.23 × 10⁻⁴ = 1.23 ÷ 10000 = 0.000123.',
				'In engineering notation the exponent must be a multiple of 3, so 123 × 10⁻⁶.'
			],
			result: '0.000123 = 1.23 × 10⁻⁴, which is 1.23E-4 in E notation.'
		},
		faq: [
			{
				q: 'What is the difference between E notation and scientific notation?',
				a: 'They describe the same value. E notation writes the power of ten with the letter E, so 1.23 × 10⁻⁴ is written 1.23E-4. Calculators and spreadsheets usually display E notation.'
			},
			{
				q: 'When should I use engineering notation?',
				a: 'Use it when you want the power of ten to match a unit prefix. Exponents that are multiples of 3 line up with kilo, mega, milli and micro, so 123 × 10⁻⁶ is easy to read as 123 micro-units.'
			},
			{
				q: 'What are significant figures?',
				a: 'They are the digits that carry meaning in a number: all non-zero digits, zeros between them, and trailing zeros after a decimal point. Choosing fewer significant figures rounds the number to that precision.'
			},
			{
				q: 'Can I enter numbers with commas?',
				a: 'Yes. Commas and spaces are ignored, so 1,230,000 and 1230000 give the same result, 1.23 × 10⁶.'
			}
		]
	}
});
