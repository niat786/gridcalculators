import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './lcm-calculator.meta';

const MAX_VALUE = 1e12;
const MAX_COUNT = 20;

/** Euclid's algorithm with BigInt, so the products used by the LCM never overflow. */
function gcdBig(a: bigint, b: bigint): bigint {
	let x = a;
	let y = b;
	while (y !== BigInt(0)) {
		const r = x % y;
		x = y;
		y = r;
	}
	return x;
}

const lcmBig = (a: bigint, b: bigint) => (a / gcdBig(a, b)) * b;
const text = (n: bigint) => n.toLocaleString('en-US');

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'values',
			label: 'Whole numbers',
			type: 'list',
			default: '12, 18, 24',
			minCount: 2,
			maxCount: MAX_COUNT,
			placeholder: 'e.g. 4, 6, 10',
			help: 'Two to twenty whole numbers from 1 to 1,000,000,000,000, separated by commas.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const xs = v.values as number[];
		const label = 'Least common multiple';
		if (xs.length < 2 || xs.length > MAX_COUNT) {
			return { primaryResult: DASH, primaryLabel: label, summary: `Enter between 2 and ${MAX_COUNT} numbers.` };
		}
		if (xs.some((x) => !Number.isInteger(x) || x < 1 || x > MAX_VALUE)) {
			return {
				primaryResult: DASH,
				primaryLabel: label,
				summary: 'Use whole numbers from 1 to 1,000,000,000,000 only. Decimals and zero are not allowed.'
			};
		}

		const big = xs.map((x) => BigInt(x));
		let l = big[0];
		const parts: string[] = [];
		for (let i = 1; i < big.length; i++) {
			const g = gcdBig(l, big[i]);
			const next = (l / g) * big[i];
			parts.push(
				big.length === 2
					? `lcm(${text(l)}, ${text(big[i])}) = ${text(l)} × ${text(big[i])} ÷ ${text(g)} = ${text(next)}`
					: `lcm(${text(l)}, ${text(big[i])}) = ${text(next)}`
			);
			l = next;
		}

		const product = big.reduce((p, x) => p * x, BigInt(1));
		const gcfAll = big.reduce((g, x) => gcdBig(g, x));
		const digits = text(l);
		const summary =
			big.length === 2
				? `Use lcm(a, b) = a × b ÷ gcf(a, b): ${parts[0]}.`
				: `Combine the numbers two at a time: ${parts.join(', then ')}.`;

		return {
			primaryResult: digits,
			primaryLabel: label,
			long: digits.length > 18,
			summary,
			secondaryMetrics: [
				{ label: 'Count', value: num(xs.length, 0) },
				{ label: 'Largest number', value: num(Math.max(...xs), 0) },
				{ label: 'Greatest common factor', value: text(gcfAll) },
				{ label: 'Product of all numbers', value: text(product) }
			]
		};
	},
	content: {
		intro:
			'Find the least common multiple (LCM) of two or more whole numbers. It is the smallest positive number that every number in your list divides into evenly.',
		howTo: [
			'Type two to twenty whole numbers, separated by commas or spaces.',
			'Use whole numbers from 1 up to 1,000,000,000,000. Decimals and zero are not accepted.',
			'Read the least common multiple. Very large results are shown in full, so you can copy them exactly.'
		],
		formulas: [
			{
				title: 'Two numbers',
				expression: 'lcm(a, b) = a × b ÷ gcf(a, b)',
				variables: [
					{ symbol: 'a, b', meaning: 'The two numbers' },
					{ symbol: 'gcf(a, b)', meaning: 'Their greatest common factor. Divide by it first to avoid a larger product than needed' }
				]
			},
			{
				title: 'More than two numbers',
				expression: 'lcm(a, b, c) = lcm(lcm(a, b), c)',
				variables: [{ symbol: 'lcm(a, b)', meaning: 'The result of the previous pair, which then pairs with the next number' }]
			}
		],
		example: {
			title: 'LCM of 4 and 6',
			steps: [
				'The greatest common factor of 4 and 6 is 2.',
				'Multiply the numbers: 4 × 6 = 24.',
				'Divide by the GCF: 24 ÷ 2 = 12.',
				'Check: 12 ÷ 4 = 3 and 12 ÷ 6 = 2, both whole numbers.'
			],
			result: 'The least common multiple of 4 and 6 is 12.'
		},
		faq: [
			{
				q: 'How is the LCM used in fractions?',
				a: 'The least common denominator of fractions is the LCM of their denominators. For 1/4 and 1/6, the LCM of 4 and 6 is 12, so you rewrite them as 3/12 and 2/12.'
			},
			{
				q: 'What is the difference between LCM and GCF?',
				a: 'The LCM is the smallest number that all the inputs divide into. The GCF is the largest number that divides all the inputs. The LCM is always at least as large as each input, and the GCF is never larger than the smallest input.'
			},
			{
				q: 'Why is the LCM sometimes very large?',
				a: 'Numbers that share few factors multiply to a large product. The LCM of two coprime numbers equals their product, so a list of big, unrelated numbers gives a very large LCM.'
			}
		]
	}
});
