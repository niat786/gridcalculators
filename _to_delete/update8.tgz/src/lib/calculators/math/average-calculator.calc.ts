import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './average-calculator.meta';

/** "1", "1 and 2", or "1, 2 and 3". */
const joinNames = (items: string[]) =>
	items.length <= 2 ? items.join(' and ') : `${items.slice(0, -1).join(', ')} and ${items[items.length - 1]}`;

/** Values that occur most often. Empty when every value occurs only once. */
function modesOf(xs: number[]): number[] {
	const counts = new Map<number, number>();
	for (const x of xs) counts.set(x, (counts.get(x) ?? 0) + 1);
	const top = Math.max(...Array.from(counts.values()));
	if (top === 1) return [];
	return Array.from(counts.entries())
		.filter(([, count]) => count === top)
		.map(([x]) => x)
		.sort((p, q) => p - q);
}

function median(sorted: number[]): number {
	const n = sorted.length;
	const mid = Math.floor(n / 2);
	return n % 2 === 1 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'values',
			label: 'Numbers',
			type: 'list',
			default: '10, 2, 38, 23, 38, 23, 21',
			minCount: 1,
			placeholder: 'e.g. 4, 8, 15, 16',
			help: 'Separate the numbers with commas or spaces.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const xs = v.values as number[];
		const label = 'Mean (average)';

		if (xs.length === 0 || xs.some((x) => !Number.isFinite(x))) {
			return { primaryResult: DASH, primaryLabel: label, summary: 'Enter one or more numbers, separated by commas.' };
		}

		const n = xs.length;
		const sum = xs.reduce((acc, x) => acc + x, 0);
		const mean = sum / n;
		const modes = modesOf(xs);

		return {
			primaryResult: num(mean, 6),
			primaryLabel: label,
			summary: `Sum ${num(sum, 6)} ÷ ${num(n, 0)} numbers = ${num(mean, 6)}.`,
			secondaryMetrics: [
				{ label: 'Count', value: num(n, 0) },
				{ label: 'Sum', value: num(sum, 6) },
				{ label: 'Median', value: num(median([...xs].sort((p, q) => p - q)), 6) },
				{ label: 'Mode', value: modes.length ? joinNames(modes.map((x) => num(x, 6))) : 'none' }
			]
		};
	},
	content: {
		intro:
			'Find the average of a list of numbers. The mean adds the values and divides by how many there are, and the median and mode show the middle and most common values.',
		howTo: [
			'Type your numbers into the box, separated by commas or spaces.',
			'Read the mean, which is the average. The count and sum show the working.',
			'Check the median and mode if you want to know the middle value or the most common value.'
		],
		formulas: [
			{
				title: 'Mean (average)',
				expression: 'Mean = (x₁ + x₂ + … + xₙ) ÷ n',
				variables: [
					{ symbol: 'xᵢ', meaning: 'Each number in the list' },
					{ symbol: 'n', meaning: 'How many numbers there are' }
				]
			},
			{
				title: 'Median',
				expression: 'Sort the numbers. For an odd count, take the middle one. For an even count, take the mean of the two middle ones.',
				variables: []
			},
			{
				title: 'Mode',
				expression: 'The value that occurs most often. If every value occurs once, there is no mode.',
				variables: []
			}
		],
		example: {
			title: 'Average of 10, 2, 38, 23, 38, 23, 21',
			steps: [
				'Sum: 10 + 2 + 38 + 23 + 38 + 23 + 21 = 155',
				'Count: 7 numbers',
				'Mean: 155 ÷ 7 = 22.142857',
				'Median: sorted list 2, 10, 21, 23, 23, 38, 38, so the middle value is 23'
			],
			result: 'The mean is 22.142857, the median is 23 and the modes are 23 and 38.'
		},
		faq: [
			{
				q: 'What is the difference between mean, median and mode?',
				a: 'The mean is the arithmetic average. The median is the middle value when the numbers are sorted. The mode is the value that appears most often.'
			},
			{
				q: 'Can a list have more than one mode?',
				a: 'Yes. If two or more values tie for the most occurrences, they are all modes. A list where every value appears once has no mode.'
			},
			{
				q: 'Why is my mean not a whole number?',
				a: 'The mean is often a fraction of the list total. For example, 155 divided by 7 is 22.142857…, so the result is shown to six decimal places.'
			}
		]
	}
});
