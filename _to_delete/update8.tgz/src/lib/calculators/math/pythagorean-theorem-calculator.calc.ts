import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './pythagorean-theorem-calculator.meta';

/** Show a field unless it is the side being solved for. */
const notSolving = (side: string) => (v: InputValues) => v.solve !== side;

const ok = (x: number) => Number.isFinite(x) && x > 0;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'solve',
			label: 'Solve for',
			type: 'select',
			display: 'segmented',
			default: 'c',
			options: [
				{ label: 'Hypotenuse c', value: 'c' },
				{ label: 'Leg a', value: 'a' },
				{ label: 'Leg b', value: 'b' }
			]
		},
		{ id: 'a', label: 'Leg a', type: 'number', default: 3, min: 0, visibleWhen: notSolving('a') },
		{ id: 'b', label: 'Leg b', type: 'number', default: 4, min: 0, visibleWhen: notSolving('b') },
		{
			id: 'c',
			label: 'Hypotenuse c',
			type: 'number',
			default: 5,
			min: 0,
			help: 'The longest side, opposite the right angle.',
			visibleWhen: notSolving('c')
		}
	],
	calculate(v): CalculationResult {
		const solve = String(v.solve);
		const given = (k: string) => Number(v[k]);
		const fail = (summary: string): CalculationResult => ({
			primaryResult: DASH,
			primaryLabel: solve === 'c' ? 'Hypotenuse c' : solve === 'a' ? 'Leg a' : 'Leg b',
			summary
		});

		let a: number;
		let b: number;
		let c: number;
		switch (solve) {
			case 'c':
				a = given('a');
				b = given('b');
				if (!ok(a) || !ok(b)) return fail('Enter both legs greater than zero.');
				c = Math.sqrt(a * a + b * b);
				break;
			case 'a':
				b = given('b');
				c = given('c');
				if (!ok(b) || !ok(c)) return fail('Enter leg b and the hypotenuse, both greater than zero.');
				if (c <= b) return fail('The hypotenuse must be longer than leg b, so no leg a exists.');
				a = Math.sqrt(c * c - b * b);
				break;
			case 'b':
				a = given('a');
				c = given('c');
				if (!ok(a) || !ok(c)) return fail('Enter leg a and the hypotenuse, both greater than zero.');
				if (c <= a) return fail('The hypotenuse must be longer than leg a, so no leg b exists.');
				b = Math.sqrt(c * c - a * a);
				break;
			default:
				return fail('Pick the side to solve for.');
		}

		const angleA = (Math.atan2(a, b) * 180) / Math.PI;
		const angleB = (Math.atan2(b, a) * 180) / Math.PI;
		const area = (a * b) / 2;
		const label = solve === 'c' ? 'Hypotenuse c' : solve === 'a' ? 'Leg a' : 'Leg b';
		const solved = solve === 'c' ? c : solve === 'a' ? a : b;
		const working =
			solve === 'c'
				? `√(${num(a, 4)}² + ${num(b, 4)}²) = ${num(c, 4)}`
				: solve === 'a'
					? `√(${num(c, 4)}² − ${num(b, 4)}²) = ${num(a, 4)}`
					: `√(${num(c, 4)}² − ${num(a, 4)}²) = ${num(b, 4)}`;

		return {
			primaryResult: num(solved, 4),
			primaryLabel: label,
			summary: working,
			secondaryMetrics: [
				{ label: 'Leg a', value: num(a, 4) },
				{ label: 'Leg b', value: num(b, 4) },
				{ label: 'Hypotenuse c', value: num(c, 4) },
				{ label: 'Angle opposite a', value: `${num(angleA, 4)}°` },
				{ label: 'Angle opposite b', value: `${num(angleB, 4)}°` },
				{ label: 'Area', value: num(area, 4) }
			]
		};
	},
	content: {
		intro:
			'Solve a right triangle with the Pythagorean theorem. Enter two sides to find the third, then read off all three sides, both acute angles and the area.',
		howTo: [
			'Choose the side you want to find: the hypotenuse c, or leg a or leg b.',
			'Enter the two sides you know. The hypotenuse is always the longest side.',
			'Read the missing side, the two acute angles in degrees and the area.'
		],
		formulas: [
			{
				title: 'Pythagorean theorem',
				expression: 'a² + b² = c²',
				variables: [
					{ symbol: 'a, b', meaning: 'the two legs, which meet at the right angle' },
					{ symbol: 'c', meaning: 'the hypotenuse, opposite the right angle' }
				]
			},
			{ title: 'Hypotenuse', expression: 'c = √(a² + b²)', variables: [] },
			{ title: 'A missing leg', expression: 'a = √(c² − b²)   or   b = √(c² − a²)', variables: [] },
			{
				title: 'Angles and area',
				expression: 'Angle opposite a = arctan(a ÷ b).   Area = ½ × a × b',
				variables: [{ symbol: 'arctan', meaning: 'inverse tangent, giving an angle in degrees' }]
			}
		],
		example: {
			title: 'A ladder against a wall, with legs of 5 m and 12 m',
			steps: [
				'Hypotenuse: c = √(5² + 12²) = √169 = 13',
				'Angle opposite the 5 m leg: arctan(5 ÷ 12) = 22.6199°',
				'Area: ½ × 5 × 12 = 30'
			],
			result: 'The ladder is 13 m long, and its acute angles are about 22.62° and 67.38°.'
		},
		faq: [
			{
				q: 'Which side is the hypotenuse?',
				a: 'The hypotenuse is the side opposite the right angle. It is always the longest side of a right triangle.'
			},
			{
				q: 'Why does a missing leg need a longer hypotenuse?',
				a: 'A leg is always shorter than the hypotenuse, so c² − b² must be positive. If the hypotenuse is not longer than the known leg, no triangle can exist.'
			},
			{
				q: 'Do the two acute angles add up to 90 degrees?',
				a: 'Yes. In any right triangle the two acute angles always add up to 90°, so the calculator shows them to four decimal places and they sum to 90.'
			}
		]
	}
});
