import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './surface-area-calculator.meta';

const PI = Math.PI;
const SQRT3 = Math.sqrt(3);
const is = (...shapes: string[]) => (v: InputValues) => shapes.includes(String(v.shape));
const positive = (...xs: number[]) => xs.every((x) => Number.isFinite(x) && x > 0);

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'shape',
			label: 'Shape',
			type: 'select',
			display: 'menu',
			default: 'cylinder',
			options: [
				{ label: 'Cube', value: 'cube' },
				{ label: 'Rectangular box', value: 'box' },
				{ label: 'Sphere', value: 'sphere' },
				{ label: 'Cylinder', value: 'cylinder' },
				{ label: 'Cone', value: 'cone' },
				{ label: 'Square pyramid', value: 'pyramid' },
				{ label: 'Triangular prism (equilateral base)', value: 'prism' },
				{ label: 'Capsule', value: 'capsule' }
			]
		},
		{ id: 'edge', label: 'Edge length', type: 'number', default: 4, min: 0, visibleWhen: is('cube') },
		{ id: 'length', label: 'Length', type: 'number', default: 6, min: 0, visibleWhen: is('box') },
		{ id: 'width', label: 'Width', type: 'number', default: 4, min: 0, visibleWhen: is('box') },
		{
			id: 'height',
			label: 'Height',
			type: 'number',
			default: 10,
			min: 0,
			visibleWhen: is('box', 'cylinder', 'cone', 'pyramid')
		},
		{
			id: 'radius',
			label: 'Radius',
			type: 'number',
			default: 3,
			min: 0,
			visibleWhen: is('sphere', 'cylinder', 'cone', 'capsule')
		},
		{
			id: 'baseEdge',
			label: 'Base edge',
			type: 'number',
			default: 4,
			min: 0,
			help: 'Side of the square base, or of the triangular base.',
			visibleWhen: is('pyramid', 'prism')
		},
		{
			id: 'prismLength',
			label: 'Prism length',
			type: 'number',
			default: 10,
			min: 0,
			help: 'How far the triangle is extruded, end to end.',
			visibleWhen: is('prism')
		},
		{
			id: 'straight',
			label: 'Straight length',
			type: 'number',
			default: 5,
			min: 0,
			help: 'Length of the middle tube, not counting the two rounded ends.',
			visibleWhen: is('capsule')
		}
	],
	calculate(v): CalculationResult {
		const shape = String(v.shape);
		const n = (k: string) => Number(v[k]);
		const fail = (summary: string): CalculationResult => ({
			primaryResult: DASH,
			primaryLabel: 'Total surface area',
			summary
		});
		const sq = (x: number) => num(x, 4);

		let total: number;
		let working: string;
		let parts: [string, number][];

		switch (shape) {
			case 'cube': {
				const a = n('edge');
				if (!positive(a)) return fail('Enter an edge length greater than zero.');
				total = 6 * a * a;
				working = `6 × ${sq(a)}² = ${sq(total)}`;
				parts = [
					['One face', a * a],
					['Four side faces', 4 * a * a],
					['Top and bottom', 2 * a * a]
				];
				break;
			}
			case 'box': {
				const l = n('length');
				const w = n('width');
				const h = n('height');
				if (!positive(l, w, h)) return fail('Enter a length, width and height greater than zero.');
				total = 2 * (l * w + l * h + w * h);
				working = `2 × (${sq(l)} × ${sq(w)} + ${sq(l)} × ${sq(h)} + ${sq(w)} × ${sq(h)}) = ${sq(total)}`;
				parts = [
					['Top and bottom', 2 * l * w],
					['Front and back', 2 * l * h],
					['Left and right', 2 * w * h]
				];
				break;
			}
			case 'sphere': {
				const r = n('radius');
				if (!positive(r)) return fail('Enter a radius greater than zero.');
				total = 4 * PI * r * r;
				working = `4 × π × ${sq(r)}² = ${sq(total)}`;
				parts = [
					['Great circle area', PI * r * r],
					['Diameter', 2 * r]
				];
				break;
			}
			case 'cylinder': {
				const r = n('radius');
				const h = n('height');
				if (!positive(r, h)) return fail('Enter a radius and height greater than zero.');
				const curved = 2 * PI * r * h;
				const ends = 2 * PI * r * r;
				total = curved + ends;
				working = `2π × ${sq(r)} × ${sq(h)} + 2π × ${sq(r)}² = ${sq(total)}`;
				parts = [
					['Curved side', curved],
					['Top and bottom', ends]
				];
				break;
			}
			case 'cone': {
				const r = n('radius');
				const h = n('height');
				if (!positive(r, h)) return fail('Enter a radius and height greater than zero.');
				const slant = Math.sqrt(r * r + h * h);
				const curved = PI * r * slant;
				const base = PI * r * r;
				total = curved + base;
				working = `π × ${sq(r)} × ${sq(slant)} + π × ${sq(r)}² = ${sq(total)}`;
				parts = [
					['Slant height', slant],
					['Curved side', curved],
					['Base', base]
				];
				break;
			}
			case 'pyramid': {
				const s = n('baseEdge');
				const h = n('height');
				if (!positive(s, h)) return fail('Enter a base edge and height greater than zero.');
				const slant = Math.sqrt(h * h + (s / 2) ** 2);
				const sides = 2 * s * slant;
				const base = s * s;
				total = sides + base;
				working = `2 × ${sq(s)} × ${sq(slant)} + ${sq(s)}² = ${sq(total)}`;
				parts = [
					['Slant height of a side', slant],
					['Four triangular sides', sides],
					['Square base', base]
				];
				break;
			}
			case 'prism': {
				const s = n('baseEdge');
				const L = n('prismLength');
				if (!positive(s, L)) return fail('Enter a base edge and prism length greater than zero.');
				const triangle = (SQRT3 / 4) * s * s;
				const sides = 3 * s * L;
				total = 2 * triangle + sides;
				working = `2 × √3/4 × ${sq(s)}² + 3 × ${sq(s)} × ${sq(L)} = ${sq(total)}`;
				parts = [
					['One triangular end', triangle],
					['Two triangular ends', 2 * triangle],
					['Three rectangular sides', sides]
				];
				break;
			}
			case 'capsule': {
				const r = n('radius');
				const h = n('straight');
				if (!positive(r, h)) return fail('Enter a radius and straight length greater than zero.');
				const tube = 2 * PI * r * h;
				const ends = 4 * PI * r * r;
				total = tube + ends;
				working = `2π × ${sq(r)} × ${sq(h)} + 4π × ${sq(r)}² = ${sq(total)}`;
				parts = [
					['Curved tube', tube],
					['Two rounded ends', ends],
					['Overall length', h + 2 * r]
				];
				break;
			}
			default:
				return fail('Pick a shape.');
		}

		return {
			primaryResult: num(total, 4),
			primaryLabel: 'Total surface area',
			summary: working,
			secondaryMetrics: parts.map(([label, value]) => ({ label, value: num(value, 4) }))
		};
	},
	content: {
		intro:
			'Find the total surface area of a solid, the combined area of all its outside faces or curved surfaces. Pick a shape, enter its measurements, and see each part next to the total.',
		howTo: [
			'Choose the shape.',
			'Enter its measurements, all in the same unit.',
			'Read the total surface area in square units, along with the area of each part.'
		],
		formulas: [
			{ title: 'Cube', expression: 'Surface area = 6 × a²', variables: [{ symbol: 'a', meaning: 'edge length' }] },
			{
				title: 'Rectangular box',
				expression: 'Surface area = 2 × (lw + lh + wh)',
				variables: [{ symbol: 'l, w, h', meaning: 'length, width and height' }]
			},
			{ title: 'Sphere', expression: 'Surface area = 4 × π × r²', variables: [{ symbol: 'r', meaning: 'radius' }] },
			{
				title: 'Cylinder',
				expression: 'Surface area = 2 × π × r × h + 2 × π × r²',
				variables: [
					{ symbol: 'r', meaning: 'radius of the round top and bottom' },
					{ symbol: 'h', meaning: 'height' }
				]
			},
			{
				title: 'Cone',
				expression: 'Slant height s = √(r² + h²)   Surface area = π × r × s + π × r²',
				variables: [{ symbol: 's', meaning: 'slant height, from the tip down the side to the edge of the base' }]
			},
			{
				title: 'Square pyramid',
				expression: 'Slant height s = √(h² + (b ÷ 2)²)   Surface area = b² + 2 × b × s',
				variables: [{ symbol: 'b', meaning: 'side of the square base' }]
			},
			{
				title: 'Triangular prism (equilateral base)',
				expression: 'Surface area = 2 × (√3 ÷ 4) × b² + 3 × b × L',
				variables: [
					{ symbol: 'b', meaning: 'side of the equilateral triangle base' },
					{ symbol: 'L', meaning: 'length of the prism, end to end' }
				]
			},
			{
				title: 'Capsule',
				expression: 'Surface area = 2 × π × r × h + 4 × π × r²',
				variables: [{ symbol: 'h', meaning: 'length of the straight middle section, not the total length' }]
			}
		],
		example: {
			title: 'A shipping box, 12 in long, 8 in wide and 6 in tall',
			steps: [
				'Top and bottom: 2 × 12 × 8 = 192',
				'Front and back: 2 × 12 × 6 = 144',
				'Left and right: 2 × 8 × 6 = 96',
				'Total: 192 + 144 + 96 = 432'
			],
			result: 'The box has a total surface area of 432 square inches, which is the amount of cardboard it would take to cover it.'
		},
		faq: [
			{
				q: 'What is the difference between surface area and volume?',
				a: 'Surface area measures the outside of a solid, in square units. Volume measures the space inside, in cubic units.'
			},
			{
				q: 'What is the slant height of a cone?',
				a: 'It is the distance from the tip of the cone down its side to the edge of the base. It is longer than the vertical height, and the calculator works it out from the radius and height.'
			},
			{
				q: 'Why is the capsule height not its total length?',
				a: 'A capsule has two hemispherical ends. The straight length is the middle tube only, so the overall length is the straight length plus two radii.'
			},
			{
				q: 'Why does a sphere have no edges or flat faces?',
				a: 'A sphere is one smooth curved surface, so its surface area is found from the radius alone with 4 × π × r².'
			}
		]
	}
});
