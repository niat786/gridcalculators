import { defineCalculator, type CalculationResult } from '../types';
import { DASH, num } from '../format';
import meta from './slope-calculator.meta';

/** Keeps float noise such as -1e-17 from showing as "-0". */
const tidy = (x: number) => (Math.abs(x) < 1e-12 ? 0 : x);

/** Number with a true minus sign (−) for negatives, for display. */
const sgn = (x: number) => (x < 0 ? '−' : '') + num(Math.abs(tidy(x)), 6);

/** Angle in degrees to four decimal places, with a true minus sign. */
const degrees = (x: number) => (x < 0 ? '−' : '') + num(Math.abs(tidy(x)), 4) + '°';

function lineEquation(m: number, b: number): string {
	if (m === 0) return `y = ${sgn(b)}`;
	const coefficient = Math.abs(m) === 1 ? '' : num(Math.abs(m), 6);
	const term = `${m < 0 ? '−' : ''}${coefficient}x`;
	if (b === 0) return `y = ${term}`;
	return `y = ${term} ${b > 0 ? '+' : '−'} ${num(Math.abs(b), 6)}`;
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'x1', label: 'x of point 1', type: 'number', default: 2, width: 'half' },
		{ id: 'y1', label: 'y of point 1', type: 'number', default: 3, width: 'half' },
		{ id: 'x2', label: 'x of point 2', type: 'number', default: 6, width: 'half' },
		{ id: 'y2', label: 'y of point 2', type: 'number', default: 11, width: 'half' }
	],
	calculate(v): CalculationResult {
		const x1 = Number(v.x1);
		const y1 = Number(v.y1);
		const x2 = Number(v.x2);
		const y2 = Number(v.y2);
		if (![x1, y1, x2, y2].every(Number.isFinite)) {
			return { primaryResult: DASH, primaryLabel: 'Slope', summary: 'Enter x and y for both points.' };
		}
		if (x1 === x2 && y1 === y2) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Slope',
				summary: 'The two points are the same, so they do not define a line.'
			};
		}

		const dx = x2 - x1;
		const dy = y2 - y1;
		const distance = Math.hypot(dx, dy);

		if (dx === 0) {
			return {
				primaryResult: 'Undefined',
				primaryLabel: 'Slope',
				summary: `Both x values are ${num(x1, 6)}, so the line is vertical: Δx = 0 and the slope is Δy ÷ 0.`,
				secondaryMetrics: [
					{ label: 'Angle', value: '90°' },
					{ label: 'Distance', value: num(distance, 6) },
					{ label: 'Y-intercept', value: 'None' },
					{ label: 'Equation', value: `x = ${sgn(x1)}` }
				]
			};
		}

		const m = tidy(dy / dx);
		const b = tidy(y1 - m * x1);
		const angle = tidy((Math.atan(m) * 180) / Math.PI);
		return {
			primaryResult: sgn(m),
			primaryLabel: 'Slope',
			summary: `(${sgn(y2)} − ${sgn(y1)}) ÷ (${sgn(x2)} − ${sgn(x1)}) = ${sgn(m)}`,
			secondaryMetrics: [
				{ label: 'Angle', value: degrees(angle) },
				{ label: 'Distance', value: num(distance, 6) },
				{ label: 'Y-intercept', value: sgn(b) },
				{ label: 'Equation', value: lineEquation(m, b) }
			]
		};
	},
	content: {
		intro:
			'Find the slope of the straight line through two points, along with its angle, the distance between the points and the equation of the line.',
		howTo: [
			'Enter the x and y values of the first point.',
			'Enter the x and y values of the second point.',
			'Read the slope, angle, distance and the equation y = mx + b.'
		],
		formulas: [
			{
				title: 'Slope',
				expression: 'm = (y₂ − y₁) ÷ (x₂ − x₁)',
				variables: [{ symbol: 'm', meaning: 'slope, the rise for each unit of run' }]
			},
			{
				title: 'Angle',
				expression: 'θ = arctan(m)',
				variables: [{ symbol: 'θ', meaning: 'angle the line makes with the x-axis, in degrees' }]
			},
			{
				title: 'Distance',
				expression: 'd = √((x₂ − x₁)² + (y₂ − y₁)²)',
				variables: [{ symbol: 'd', meaning: 'straight-line distance between the two points' }]
			},
			{
				title: 'Equation of the line',
				expression: 'y = mx + b,   where b = y₁ − m × x₁',
				variables: [{ symbol: 'b', meaning: 'y-intercept, where the line crosses the y-axis' }]
			}
		],
		example: {
			title: 'A line through (2, 3) and (6, 11)',
			steps: [
				'Slope: (11 − 3) ÷ (6 − 2) = 8 ÷ 4 = 2',
				'Intercept: b = 3 − 2 × 2 = −1',
				'Equation: y = 2x − 1'
			],
			result: 'The line rises 2 units for every 1 unit across, and crosses the y-axis at −1.'
		},
		faq: [
			{
				q: 'What does an undefined slope mean?',
				a: 'The two points have the same x value, so the line is vertical. Dividing by a zero change in x is not possible, so the slope is undefined. Its equation is x = a constant.'
			},
			{
				q: 'What is a slope of zero?',
				a: 'A slope of zero means the line is horizontal. The two points have the same y value, and the equation is y = b.'
			},
			{
				q: 'Does it matter which point is first?',
				a: 'No. Swapping the two points changes the signs of both the rise and the run, so the slope and the equation stay the same.'
			}
		]
	}
});
