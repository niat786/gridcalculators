import { defineCalculator, type CalculationResult, type InputValues, type Metric } from '../types';
import { DASH } from '../format';
import meta from './hex-calculator.meta';

/** Longest number accepted, in digits. BigInt keeps every value exact, so this only guards against huge pastes. */
const MAX_DIGITS = 400;
const MINUS = '−';
const SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹';
const OPS: Record<string, string> = { add: '+', sub: '−', mul: '×', div: '÷' };

const sup = (n: number) =>
	String(n)
		.split('')
		.map((d) => SUP[Number(d)])
		.join('');
const abs = (n: bigint) => (n < BigInt(0) ? -n : n);
const toBase = (n: bigint, base: number) => (n < BigInt(0) ? MINUS : '') + abs(n).toString(base);
const hex = (n: bigint) => toBase(n, 16).toUpperCase();
const dec = (n: bigint) => (n < BigInt(0) ? MINUS : '') + abs(n).toLocaleString('en-US');
const inMode = (m: string) => (v: InputValues) => String(v.mode) === m;

/** Hexadecimal text, case-insensitive. Spaces are ignored. */
function parseHex(text: string): bigint | null {
	const s = text.replace(/\s/g, '');
	if (!/^[0-9a-fA-F]+$/.test(s) || s.length > MAX_DIGITS) return null;
	return BigInt(`0x${s}`);
}

/** Decimal text with an optional minus sign. */
function parseDecimal(text: string): bigint | null {
	const s = text.replace(/\s/g, '');
	if (!/^-?\d+$/.test(s) || s.length > MAX_DIGITS) return null;
	return BigInt(s);
}

function metricsFor(n: bigint): Metric[] {
	return [
		{ label: 'Hexadecimal', value: hex(n) },
		{ label: 'Decimal', value: dec(n) },
		{ label: 'Binary', value: toBase(n, 2) }
	];
}

/** "15×16¹ + 15×16⁰ = 255". Empty when the number is too long to spell out. */
function positionalSum(digits: string): string {
	if (digits.length > 8) return '';
	const n = digits.length;
	const terms = digits.split('').map((d, i) => `${parseInt(d, 16)}×16${sup(n - 1 - i)}`);
	return `${terms.join(' + ')} = ${BigInt(`0x${digits}`).toString()}`;
}

function fail(summary: string, primaryLabel = 'Hexadecimal result'): CalculationResult {
	return { primaryResult: DASH, primaryLabel, summary };
}

function convert(v: InputValues): CalculationResult {
	const text = String(v.value);
	if (String(v.from) === 'hex') {
		const n = parseHex(text);
		if (n === null) return fail('Enter a hexadecimal number, using 0–9 and A–F.', 'Decimal');
		const digits = text.replace(/\s/g, '').toUpperCase();
		const sum = positionalSum(digits);
		const why = sum
			? `Each digit is worth a power of 16, counting from the right: ${sum}.`
			: 'Each digit is worth a power of 16, counting from the right.';
		return {
			primaryResult: dec(n),
			primaryLabel: 'Decimal',
			summary: `${digits} in hexadecimal is ${dec(n)} in decimal. ${why}`,
			secondaryMetrics: metricsFor(n)
		};
	}

	const n = parseDecimal(text);
	if (n === null) return fail('Enter a whole number, such as 255. Use a minus sign for negative numbers.', 'Hexadecimal');
	const h = hex(n);
	const sign = n < BigInt(0) ? ' The minus sign stays in front.' : '';
	return {
		primaryResult: h,
		primaryLabel: 'Hexadecimal',
		long: true,
		summary: `${dec(n)} in decimal is ${h} in hexadecimal. Divide by 16, keep each remainder, and read the remainders from the bottom up. Remainders of 10 to 15 are written A to F.${sign}`,
		secondaryMetrics: metricsFor(n)
	};
}

function arithmetic(v: InputValues): CalculationResult {
	const op = String(v.op);
	const a = parseHex(String(v.a));
	const b = parseHex(String(v.b));
	if (a === null || b === null) return fail('Enter two hexadecimal numbers, using 0–9 and A–F.');
	if (!(op in OPS)) return fail('Pick an operation.');

	const sym = OPS[op];
	if (op === 'div') {
		if (b === BigInt(0)) {
			return fail('You can’t divide by zero. Change the second number to something other than 0.', 'Quotient (hexadecimal)');
		}
		const q = a / b;
		const r = a % b;
		return {
			primaryResult: hex(q),
			primaryLabel: 'Quotient (hexadecimal)',
			long: true,
			summary: `${hex(a)} ÷ ${hex(b)} = ${hex(q)} remainder ${hex(r)} in hexadecimal. In decimal, ${dec(a)} ÷ ${dec(b)} = ${dec(q)} remainder ${dec(r)}.`,
			secondaryMetrics: [...metricsFor(q), { label: 'Remainder', value: `${hex(r)} (decimal ${dec(r)})` }]
		};
	}

	let result: bigint;
	if (op === 'add') result = a + b;
	else if (op === 'sub') result = a - b;
	else result = a * b;

	return {
		primaryResult: hex(result),
		primaryLabel: 'Result (hexadecimal)',
		long: true,
		summary: `${hex(a)} ${sym} ${hex(b)} = ${hex(result)} in hexadecimal, which is ${dec(result)} in decimal (${dec(a)} ${sym} ${dec(b)} = ${dec(result)}).`,
		secondaryMetrics: metricsFor(result)
	};
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Mode',
			type: 'select',
			display: 'segmented',
			default: 'convert',
			options: [
				{ label: 'Convert', value: 'convert' },
				{ label: 'Arithmetic', value: 'arithmetic' }
			]
		},
		{
			id: 'from',
			label: 'Convert from',
			type: 'select',
			display: 'segmented',
			default: 'decimal',
			options: [
				{ label: 'Decimal', value: 'decimal' },
				{ label: 'Hexadecimal', value: 'hex' }
			],
			visibleWhen: inMode('convert')
		},
		{
			id: 'value',
			label: 'Number',
			type: 'text',
			default: '255',
			monospace: true,
			maxLength: 400,
			placeholder: 'e.g. 255 or FF',
			pattern: /^[\s0-9a-fA-F-]*$/,
			patternMessage: 'Use 0–9 and A–F only.',
			help: 'Hex uses 0–9 and A–F, and is not case-sensitive. Decimal numbers may start with a minus sign.',
			visibleWhen: inMode('convert')
		},
		{
			id: 'a',
			label: 'First hex number',
			type: 'text',
			default: 'FF',
			monospace: true,
			maxLength: 400,
			pattern: /^[0-9a-fA-F\s]*$/,
			patternMessage: 'Use 0–9 and A–F only.',
			visibleWhen: inMode('arithmetic')
		},
		{
			id: 'op',
			label: 'Operation',
			type: 'select',
			display: 'segmented',
			default: 'add',
			options: [
				{ label: '+', value: 'add' },
				{ label: '−', value: 'sub' },
				{ label: '×', value: 'mul' },
				{ label: '÷', value: 'div' }
			],
			visibleWhen: inMode('arithmetic')
		},
		{
			id: 'b',
			label: 'Second hex number',
			type: 'text',
			default: '1A',
			monospace: true,
			maxLength: 400,
			pattern: /^[0-9a-fA-F\s]*$/,
			patternMessage: 'Use 0–9 and A–F only.',
			help: 'For ÷, this is the divisor and cannot be 0.',
			visibleWhen: inMode('arithmetic')
		}
	],
	calculate(v: InputValues): CalculationResult {
		return String(v.mode) === 'arithmetic' ? arithmetic(v) : convert(v);
	},
	content: {
		intro:
			'Convert whole numbers between hexadecimal (base 16) and decimal, or add, subtract, multiply and divide hex numbers. Results also show the binary form, and division gives the remainder.',
		howTo: [
			'Pick Convert to change one number between decimal and hexadecimal, and choose which base you are starting from.',
			'Pick Arithmetic to work with two hex numbers. Use 0–9 and A–F; upper or lower case both work.',
			'Choose an operation. For division, the whole-number quotient is the result and the remainder is shown below it.'
		],
		formulas: [
			{
				title: 'Hexadecimal to decimal',
				expression: 'value = dₙ×16ⁿ + … + d₁×16¹ + d₀×16⁰',
				variables: [
					{ symbol: 'dₖ', meaning: 'The digit in position k, counting from the right starting at 0. A to F stand for 10 to 15' },
					{ symbol: '16ᵏ', meaning: 'The place value of that position: 1, 16, 256, 4096 and so on' }
				]
			},
			{
				title: 'Decimal to hexadecimal',
				expression: 'Divide by 16 and keep the remainder. Repeat on the quotient until it is 0, then read the remainders from last to first.',
				variables: [{ symbol: 'r', meaning: 'Each remainder is 0 to 15, written as one hex digit (0–9, then A–F)' }]
			},
			{
				title: 'Division with remainder',
				expression: 'a = q × b + r, where 0 ≤ r < b',
				variables: [
					{ symbol: 'q', meaning: 'The quotient: the whole number of times b fits into a' },
					{ symbol: 'r', meaning: 'The remainder left over' }
				]
			}
		],
		example: {
			title: 'Add FF and 1A in hexadecimal',
			steps: [
				'FF in decimal is 15×16 + 15 = 255.',
				'1A in decimal is 1×16 + 10 = 26.',
				'255 + 26 = 281.',
				'281 in hexadecimal is 119, because 1×256 + 1×16 + 9 = 281.'
			],
			result: 'FF + 1A = 119 in hexadecimal, which is 281 in decimal.'
		},
		faq: [
			{
				q: 'What does hexadecimal use for digits above 9?',
				a: 'It uses the letters A to F for the values 10 to 15. A is 10, B is 11, C is 12, D is 13, E is 14 and F is 15. Case does not matter, so ff and FF are the same number.'
			},
			{
				q: 'Why is hexadecimal used in computing?',
				a: 'One hex digit stands for exactly four binary digits, so a byte (eight bits) fits in two hex digits. That makes long binary values, such as memory addresses and colour codes, shorter and easier to read.'
			},
			{
				q: 'How do I convert decimal to hexadecimal by hand?',
				a: 'Divide the number by 16 and write down the remainder, using A to F for 10 to 15. Repeat on the quotient until it reaches 0, then read the remainders from the last to the first.'
			}
		]
	}
});
