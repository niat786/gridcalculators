import { defineCalculator } from '../types';
import meta from './random-number-generator.meta';

export default defineCalculator({
	meta,
	widget: { name: 'random' },
	inputs: [],
	calculate: () => ({ primaryResult: '', primaryLabel: '' }),
	content: {
		intro:
			'Generate random whole numbers in any range, as many as you need, with or without repeats, or randomly pick names or items from a list.',
		howTo: [
			'Choose random numbers or pick from a list.',
			'Set the minimum, maximum and how many you want (or paste your list).',
			'Tick “No repeats” for draws like lotteries or raffles.',
			'Press Generate, and copy the results if you need them.'
		],
		formulas: [
			{
				title: 'Each number',
				expression: 'n = min + uniform random integer in [0, max − min]',
				variables: []
			},
			{
				title: 'Probability of any one value',
				expression: 'P = 1 ÷ (max − min + 1)',
				variables: []
			}
		],
		example: {
			title: 'Pick 1 number from 1 to 100',
			steps: ['There are 100 possible numbers', 'Each has the same chance: 1 ÷ 100 = 1%'],
			result: 'Every number from 1 to 100 is equally likely to come up.'
		},
		faq: [
			{
				q: 'Are the numbers truly random?',
				a: 'They come from your browser’s cryptographic random generator (the Web Crypto API), which is unpredictable and suitable for security uses, and we remove the small bias that simple methods can introduce.'
			},
			{
				q: 'Can I use this for a raffle or giveaway?',
				a: 'Yes. Use “Pick from a list” with each entry on its own line, or number your entries and generate without repeats.'
			},
			{
				q: 'What does “No repeats” do?',
				a: 'It makes every number in the result different, like drawing balls from a bag without putting them back.'
			}
		]
	}
});
