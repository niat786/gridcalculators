import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './mass-calculator.meta';

const isCustom = (v: InputValues) => v.material === 'custom';
const customKg = (v: InputValues) => isCustom(v) && v.densityUnit !== 'lbft3';
const customLb = (v: InputValues) => isCustom(v) && v.densityUnit === 'lbft3';

/** Typical densities in kg per cubic metre. */
const PRESETS: Record<string, number> = {
	water: 1000,
	steel: 7850,
	aluminium: 2700,
	concrete: 2400,
	pine: 500,
	gold: 19300
};

/** Cubic metres in one unit of volume. */
const M3_PER: Record<string, number> = {
	m3: 1,
	L: 0.001,
	mL: 0.000001,
	ft3: 0.0283168466,
	in3: 0.000016387064,
	gal: 0.003785411784
};

const KG_PER_LB = 0.45359237;
const LB_PER_KG = 2.20462262;
const LB_FT3_PER_KG_M3 = 0.0624279606;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'material',
			label: 'Material',
			type: 'select',
			default: 'water',
			options: [
				{ label: 'Water (1,000 kg/m³)', value: 'water' },
				{ label: 'Steel (7,850 kg/m³)', value: 'steel' },
				{ label: 'Aluminium (2,700 kg/m³)', value: 'aluminium' },
				{ label: 'Concrete (2,400 kg/m³)', value: 'concrete' },
				{ label: 'Wood, pine (500 kg/m³)', value: 'pine' },
				{ label: 'Gold (19,300 kg/m³)', value: 'gold' },
				{ label: 'Custom density', value: 'custom' }
			]
		},
		{
			id: 'densityUnit',
			label: 'Density unit',
			type: 'select',
			display: 'segmented',
			default: 'kgm3',
			visibleWhen: isCustom,
			options: [
				{ label: 'kg/m³', value: 'kgm3' },
				{ label: 'lb/ft³', value: 'lbft3' }
			]
		},
		{ id: 'customKg', label: 'Density', type: 'number', default: 2000, min: 1, max: 30000, step: 1, suffix: 'kg/m³', visibleWhen: customKg },
		{ id: 'customLb', label: 'Density', type: 'number', default: 125, min: 0.1, max: 1900, step: 0.1, suffix: 'lb/ft³', visibleWhen: customLb },
		{ id: 'volume', label: 'Volume', type: 'number', default: 20, min: 0, max: 1000000000, step: 0.01 },
		{
			id: 'volumeUnit',
			label: 'Volume unit',
			type: 'select',
			default: 'L',
			options: [
				{ label: 'Litres (L)', value: 'L' },
				{ label: 'Cubic metres (m³)', value: 'm3' },
				{ label: 'Millilitres (cm³)', value: 'mL' },
				{ label: 'Cubic feet (ft³)', value: 'ft3' },
				{ label: 'Cubic inches (in³)', value: 'in3' },
				{ label: 'US gallons (gal)', value: 'gal' }
			]
		}
	],
	calculate(v): CalculationResult {
		let densityKg: number;
		if (v.material === 'custom') {
			densityKg = v.densityUnit === 'lbft3' ? Number(v.customLb) / LB_FT3_PER_KG_M3 : Number(v.customKg);
		} else {
			densityKg = PRESETS[String(v.material)];
		}
		const perM3 = M3_PER[String(v.volumeUnit)];
		const volume = Number(v.volume);
		if (!(densityKg > 0) || !(perM3 > 0) || !(volume > 0)) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Mass',
				summary: 'Pick a material and enter a volume above zero.'
			};
		}
		const volumeM3 = volume * perM3;
		const kg = densityKg * volumeM3;

		return {
			primaryResult: `${num(kg, 2)} kg`,
			primaryLabel: 'Mass',
			summary: `Mass = density × volume = ${num(densityKg, 0)} kg/m³ × ${num(volumeM3, 6)} m³.`,
			secondaryMetrics: [
				{ label: 'Mass in pounds', value: `${num(kg * LB_PER_KG, 2, 2)} lb` },
				{ label: 'Mass in grams', value: `${num(kg * 1000, 0)} g` },
				{ label: 'Density used', value: `${num(densityKg, 1)} kg/m³` },
				{ label: 'Volume in cubic metres', value: `${num(volumeM3, 6)} m³` }
			]
		};
	},
	content: {
		intro:
			'Work out the mass of a material from its density and the volume you have. Choose a common material or enter your own density, then enter a volume in the unit you measure in.',
		howTo: [
			'Choose a material, or Custom density and enter its value in kg/m³ or lb/ft³.',
			'Enter the volume and choose its unit.',
			'Read the mass in kilograms, pounds and grams.'
		],
		formulas: [
			{
				title: 'Mass from density and volume',
				expression: 'm = ρ × V',
				variables: [
					{ symbol: 'm', meaning: 'mass, in kg' },
					{ symbol: 'ρ', meaning: 'density, in kg/m³' },
					{ symbol: 'V', meaning: 'volume, in m³' }
				]
			},
			{
				title: 'Unit conversions',
				expression: '1 lb = 0.45359237 kg · 1 ft³ = 0.0283168 m³ · 1 US gal = 0.00378541 m³ · 1 lb/ft³ = 16.0185 kg/m³',
				variables: []
			}
		],
		example: {
			title: '20 litres of water',
			steps: [
				'Convert the volume: 20 L × 0.001 = 0.020 m³',
				'Multiply by the density: 1,000 kg/m³ × 0.020 m³ = 20 kg',
				'Convert: 20 kg × 2.20462 = 44.09 lb, and 20 kg = 20,000 g'
			],
			result: '20 kg (44.09 lb, 20,000 g).'
		},
		faq: [
			{
				q: 'What is the difference between mass and weight?',
				a: 'Mass is how much matter an object contains, and it is the same everywhere. Weight is the force gravity exerts on that mass. For weight on other planets, use the weight calculator.'
			},
			{
				q: 'Why do my material results differ from the preset?',
				a: 'Density varies with alloy, moisture, temperature and porosity. Concrete and wood vary a lot. For a specific product, use the density from its data sheet with Custom density.'
			},
			{
				q: 'Does the result include the container?',
				a: 'No. It is the mass of the material alone. Add the mass of any container or packaging separately.'
			},
			{
				q: 'How do I get the volume of a box or a tank?',
				a: 'Multiply length, width and height in the same unit to get the volume. For a cylinder, multiply π × radius² by the height.'
			}
		]
	}
});
