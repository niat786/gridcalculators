import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './hours-calculator.meta';

const MINUTES_PER_DAY = 1_440;

/** "HH:MM" (24-hour) to minutes after midnight. Null when the text is not a valid time. */
export function minutesOf(s: string): number | null {
	const m = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(s);
	return m ? +m[1] * 60 + +m[2] : null;
}

/** Minutes after midnight to "h:mm AM" / "h:mm PM". */
export function clock12(total: number): string {
	const mins = ((total % MINUTES_PER_DAY) + MINUTES_PER_DAY) % MINUTES_PER_DAY;
	const h24 = Math.floor(mins / 60);
	const h = h24 % 12 || 12;
	return `${h}:${String(mins % 60).padStart(2, '0')} ${h24 < 12 ? 'AM' : 'PM'}`;
}

/** Minutes to "h:mm" with minutes padded to two digits. */
export function hoursAndMinutes(total: number): string {
	return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
}

const invalid = (summary: string): CalculationResult => ({ primaryResult: DASH, primaryLabel: 'Hours worked', summary });

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'start', label: 'Start time', type: 'time', default: '09:00' },
		{ id: 'end', label: 'End time', type: 'time', default: '17:30', help: 'An earlier end time means the shift runs past midnight.' },
		{
			id: 'breakMins',
			label: 'Unpaid break',
			type: 'number',
			default: 30,
			min: 0,
			max: MINUTES_PER_DAY,
			decimal: false,
			suffix: 'minutes',
			help: 'Enter 0 if there was no unpaid break.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const start = minutesOf(String(v.start));
		const end = minutesOf(String(v.end));
		if (start === null || end === null) return invalid('Enter a start time and an end time.');

		const brk = Number(v.breakMins);
		if (!Number.isInteger(brk) || brk < 0) return invalid('Enter a whole number of break minutes, zero or more.');

		const crosses = end < start;
		const span = (crosses ? end + MINUTES_PER_DAY : end) - start;
		const worked = span - brk;
		if (worked < 0) return invalid('The break is longer than the shift.');

		const timeRange = `${clock12(start)} to ${clock12(end)}`;
		const summary =
			span === 0
				? 'The start and end times are the same, so no time is counted.'
				: `${timeRange}${crosses ? ', past midnight' : ''}, minus a ${num(brk, 0)}-minute unpaid break.`;

		return {
			primaryResult: hoursAndMinutes(worked),
			primaryLabel: 'Hours worked',
			summary,
			secondaryMetrics: [
				{ label: 'Decimal hours', value: num(worked / 60, 2, 2) },
				{ label: 'Total minutes', value: num(worked, 0) },
				{ label: 'Time before break', value: hoursAndMinutes(span) }
			]
		};
	},
	content: {
		intro:
			'Work out paid hours from a start time, an end time and any unpaid break. Shifts that run past midnight are handled automatically.',
		howTo: [
			'Enter the start time and the end time.',
			'Enter the unpaid break in minutes, or 0 if you had none.',
			'If the end time is earlier than the start time, the shift is treated as running past midnight.',
			'Read hours worked as hours and minutes, then as decimal hours.'
		],
		formulas: [
			{
				title: 'Shift length',
				expression: 'Shift = end time − start time, plus 24 hours when the end is earlier than the start',
				variables: []
			},
			{
				title: 'Hours worked',
				expression: 'Worked minutes = shift minutes − unpaid break minutes',
				variables: []
			},
			{
				title: 'Decimal hours',
				expression: 'Decimal hours = worked minutes ÷ 60',
				variables: [{ symbol: '60', meaning: 'minutes in an hour' }]
			}
		],
		example: {
			title: '10:00 PM to 6:30 AM with a 45-minute break',
			steps: [
				'6:30 AM is earlier than 10:00 PM, so the shift crosses midnight. Shift = 6:30 + 24:00 − 22:00 = 8 h 30 min = 510 minutes.',
				'Worked minutes = 510 − 45 = 465 minutes.',
				'Decimal hours = 465 ÷ 60 = 7.75.'
			],
			result: '7:45 (7.75 decimal hours).'
		},
		faq: [
			{
				q: 'How do overnight shifts work?',
				a: 'If the end time is earlier than the start time, the calculator assumes the shift ends the next morning. A 10:00 PM start and a 6:30 AM end is an 8 h 30 min shift.'
			},
			{
				q: 'How do I turn minutes into decimal hours?',
				a: 'Divide the minutes by 60. 15 minutes is 0.25 hours and 45 minutes is 0.75 hours. Many payroll systems use decimal hours.'
			},
			{
				q: 'What if the start and end times are the same?',
				a: 'The calculator counts zero hours, because it cannot tell whether you meant no time or a full 24-hour shift.'
			}
		]
	}
});
