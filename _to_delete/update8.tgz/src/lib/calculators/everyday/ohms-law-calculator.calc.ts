import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './ohms-law-calculator.meta';

type Quantity = 'V' | 'I' | 'R' | 'P';
type Pair = 'VI' | 'VR' | 'VP' | 'IR' | 'IP' | 'RP';

const FIELD_ID: Record<Quantity, string> = { V: 'voltage', I: 'current', R: 'resistance', P: 'power' };
const LABEL: Record<Quantity, string> = { V: 'Voltage', I: 'Current', R: 'Resistance', P: 'Power' };
const UNIT: Record<Quantity, string> = { V: 'V', I: 'A', R: 'Ω', P: 'W' };
const PAIR_QUANTITIES: Record<Pair, [Quantity, Quantity]> = {
	VI: ['V', 'I'],
	VR: ['V', 'R'],
	VP: ['V', 'P'],
	IR: ['I', 'R'],
	IP: ['I', 'P'],
	RP: ['R', 'P']
};
const PAIR_FORMULAS: Record<Pair, string> = {
	VI: 'Resistance = V ÷ I and power = V × I.',
	VR: 'Current = V ÷ R and power = V² ÷ R.',
	VP: 'Current = P ÷ V and resistance = V² ÷ P.',
	IR: 'Voltage = I × R and power = I² × R.',
	IP: 'Voltage = P ÷ I and resistance = P ÷ I².',
	RP: 'Voltage = √(P × R) and current = √(P ÷ R).'
};

const PREFIXES: [number, string][] = [
	[1e9, 'G'],
	[1e6, 'M'],
	[1e3, 'k'],
	[1, ''],
	[1e-3, 'm'],
	[1e-6, 'µ']
];

/** Formats a value with the SI prefix that keeps the number between 1 and 1,000, e.g. "25.532 mA". */
export function withPrefix(x: number, unit: string): string {
	if (!Number.isFinite(x)) return DASH;
	if (x === 0) return `0 ${unit}`;
	const a = Math.abs(x);
	const [scale, prefix] = PREFIXES.find(([s]) => a >= s) ?? PREFIXES[PREFIXES.length - 1];
	return `${num(x / scale, 3)} ${prefix}${unit}`;
}

/** Work out all four quantities from two known values of the given pair. */
export function solve(pair: Pair, a: number, b: number): Record<Quantity, number> {
	switch (pair) {
		case 'VI':
			return { V: a, I: b, R: a / b, P: a * b };
		case 'VR':
			return { V: a, I: a / b, R: b, P: (a * a) / b };
		case 'VP':
			return { V: a, I: b / a, R: (a * a) / b, P: b };
		case 'IR':
			return { V: a * b, I: a, R: b, P: a * a * b };
		case 'IP':
			return { V: b / a, I: a, R: b / (a * a), P: b };
		case 'RP':
			return { V: Math.sqrt(a * b), I: Math.sqrt(b / a), R: a, P: b };
	}
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'pair',
			label: 'Known values',
			type: 'select',
			default: 'VR',
			display: 'menu',
			options: [
				{ label: 'Voltage and current', value: 'VI' },
				{ label: 'Voltage and resistance', value: 'VR' },
				{ label: 'Voltage and power', value: 'VP' },
				{ label: 'Current and resistance', value: 'IR' },
				{ label: 'Current and power', value: 'IP' },
				{ label: 'Resistance and power', value: 'RP' }
			]
		},
		{
			id: 'target',
			label: 'Solve for',
			type: 'select',
			default: 'P',
			display: 'segmented',
			options: [
				{ label: 'Voltage', value: 'V' },
				{ label: 'Current', value: 'I' },
				{ label: 'Resistance', value: 'R' },
				{ label: 'Power', value: 'P' }
			],
			help: 'The answer shown in large type. All four values are listed below it.'
		},
		{
			id: 'voltage',
			label: 'Voltage',
			type: 'number',
			default: 12,
			min: 0,
			max: 1000000000,
			suffix: 'V',
			visibleWhen: (v) => String(v.pair).includes('V')
		},
		{
			id: 'current',
			label: 'Current',
			type: 'number',
			default: 2,
			min: 0,
			max: 1000000000,
			suffix: 'A',
			visibleWhen: (v) => String(v.pair).includes('I')
		},
		{
			id: 'resistance',
			label: 'Resistance',
			type: 'number',
			default: 470,
			min: 0,
			max: 1000000000000,
			suffix: 'Ω',
			visibleWhen: (v) => String(v.pair).includes('R')
		},
		{
			id: 'power',
			label: 'Power',
			type: 'number',
			default: 24,
			min: 0,
			max: 1000000000000,
			suffix: 'W',
			visibleWhen: (v) => String(v.pair).includes('P')
		}
	],
	calculate(v: InputValues): CalculationResult {
		const pair = String(v.pair) as Pair;
		const target = String(v.target) as Quantity;
		const quantities = PAIR_QUANTITIES[pair];
		if (!quantities || !LABEL[target]) {
			return { primaryResult: DASH, primaryLabel: 'Result', summary: 'Pick two known values and a quantity to solve for.' };
		}

		const a = Number(v[FIELD_ID[quantities[0]]]);
		const b = Number(v[FIELD_ID[quantities[1]]]);
		if (!(a > 0) || !(b > 0) || !Number.isFinite(a) || !Number.isFinite(b)) {
			return {
				primaryResult: DASH,
				primaryLabel: LABEL[target],
				summary: `Enter two values above zero: ${LABEL[quantities[0]].toLowerCase()} and ${LABEL[quantities[1]].toLowerCase()}.`
			};
		}

		const s = solve(pair, a, b);
		const fmt = (q: Quantity) => withPrefix(s[q], UNIT[q]);

		return {
			primaryResult: fmt(target),
			primaryLabel: LABEL[target],
			summary: PAIR_FORMULAS[pair],
			secondaryMetrics: [
				{ label: 'Voltage', value: fmt('V') },
				{ label: 'Current', value: fmt('I') },
				{ label: 'Resistance', value: fmt('R') },
				{ label: 'Power', value: fmt('P') }
			]
		};
	},
	content: {
		intro:
			"Work out voltage, current, resistance and power in a circuit from any two known values. Ohm's law and the power formulas give the other two in one step.",
		howTo: [
			'Pick the pair of values you already know, such as voltage and resistance.',
			'Enter the two values in the units shown. Use decimals for fractions, such as 0.5 A.',
			'Choose the quantity you want as the main answer. All four values appear below it.',
			'Read small and large results with SI prefixes, such as mA for milliamps or kΩ for kilohms.'
		],
		formulas: [
			{
				title: "Ohm's law",
				expression: 'V = I × R',
				variables: [
					{ symbol: 'V', meaning: 'Voltage in volts (V)' },
					{ symbol: 'I', meaning: 'Current in amps (A)' },
					{ symbol: 'R', meaning: 'Resistance in ohms (Ω)' }
				]
			},
			{
				title: 'Power',
				expression: 'P = V × I = I² × R = V² ÷ R',
				variables: [{ symbol: 'P', meaning: 'Power in watts (W)' }]
			}
		],
		example: {
			title: 'A 12 V supply across a 470 Ω resistor',
			steps: [
				'Current = V ÷ R = 12 ÷ 470 = 0.02553 A, which is 25.532 mA.',
				'Power = V² ÷ R = 12² ÷ 470 = 144 ÷ 470 = 0.30638 W, which is 306.383 mW.'
			],
			result: 'The current is 25.532 mA and the power is 306.383 mW.'
		},
		faq: [
			{
				q: "What is Ohm's law?",
				a: 'Ohm’s law says voltage equals current multiplied by resistance, V = I × R. Doubling the voltage across the same resistor doubles the current.'
			},
			{
				q: 'Why does the calculator show mA or kΩ?',
				a: 'Circuit values are often very small or very large. SI prefixes keep the number easy to read: m means one thousandth, k means one thousand, and M means one million.'
			},
			{
				q: 'Which two values do I need?',
				a: 'Any two of voltage, current, resistance and power that describe the same component or circuit. The other two follow from the formulas.'
			},
			{
				q: 'Does Ohm’s law work for AC circuits?',
				a: 'It works for purely resistive loads, such as heaters and simple resistors. Circuits with capacitors or inductors need impedance instead of resistance.'
			}
		]
	}
});
