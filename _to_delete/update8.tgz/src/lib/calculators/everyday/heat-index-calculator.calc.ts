import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './heat-index-calculator.meta';

const isF = (v: InputValues) => v.units === 'f';
const isC = (v: InputValues) => v.units === 'c';

/** The simple NWS formula, used when the result is below 80 °F. t in °F, rh in %. */
export function simpleHeatIndexF(t: number, rh: number): number {
	return 0.5 * (t + 61 + (t - 68) * 1.2 + rh * 0.094);
}

/**
 * NWS heat index in °F (Rothfusz regression with the dry-air and humid-air adjustments).
 * t in °F, rh in %. Returns the value and the method used.
 */
export function heatIndexF(t: number, rh: number): { value: number; method: string } {
	const simple = simpleHeatIndexF(t, rh);
	if ((simple + t) / 2 < 80) return { value: simple, method: 'Simple formula (below 80 °F)' };

	let hi =
		-42.379 +
		2.04901523 * t +
		10.14333127 * rh -
		0.22475541 * t * rh -
		6.83783e-3 * t * t -
		5.481717e-2 * rh * rh +
		1.22874e-3 * t * t * rh +
		8.5282e-4 * t * rh * rh -
		1.99e-6 * t * t * rh * rh;

	if (rh < 13 && t >= 80 && t <= 112) hi -= ((13 - rh) / 4) * Math.sqrt((17 - Math.abs(t - 95)) / 17);
	if (rh > 85 && t >= 80 && t <= 87) hi += ((rh - 85) / 10) * ((87 - t) / 5);

	return { value: hi, method: 'Rothfusz regression with NWS adjustments' };
}

/** NWS caution level from a heat index in °F. */
export function cautionLevel(hiF: number): string {
	if (hiF >= 125) return 'Extreme danger';
	if (hiF >= 103) return 'Danger';
	if (hiF >= 90) return 'Extreme caution';
	if (hiF >= 80) return 'Caution';
	return 'Below NWS caution levels';
}

const ADVICE: Record<string, string> = {
	'Below NWS caution levels': 'The heat index is below 80 °F, so heat is unlikely to add a risk on its own.',
	Caution: 'Fatigue is possible with prolonged exposure or activity.',
	'Extreme caution': 'Heat cramps and heat exhaustion are possible with prolonged exposure or activity.',
	Danger: 'Heat cramps and heat exhaustion are likely. Heat stroke is possible with prolonged exposure or activity.',
	'Extreme danger': 'Heat stroke is highly likely with continued exposure.'
};

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'units',
			label: 'Temperature unit',
			type: 'select',
			display: 'segmented',
			default: 'f',
			options: [
				{ label: 'Fahrenheit (°F)', value: 'f' },
				{ label: 'Celsius (°C)', value: 'c' }
			]
		},
		{ id: 'tempF', label: 'Air temperature', type: 'number', default: 90, min: 40, max: 150, step: 0.1, suffix: '°F', visibleWhen: isF },
		{ id: 'tempC', label: 'Air temperature', type: 'number', default: 32, min: 4, max: 66, step: 0.1, suffix: '°C', visibleWhen: isC },
		{ id: 'rh', label: 'Relative humidity', type: 'number', default: 70, min: 0, max: 100, step: 1, suffix: '%' }
	],
	calculate(v): CalculationResult {
		const fahrenheit = v.units !== 'c';
		const t = Number(fahrenheit ? v.tempF : v.tempC);
		const rh = Number(v.rh);
		if (!Number.isFinite(t) || !(rh >= 0 && rh <= 100)) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Heat index',
				summary: 'Enter a temperature and a relative humidity from 0% to 100%.'
			};
		}
		const tF = fahrenheit ? t : (t * 9) / 5 + 32;
		const tC = fahrenheit ? ((t - 32) * 5) / 9 : t;
		const { value: hiF, method } = heatIndexF(tF, rh);
		const hiC = ((hiF - 32) * 5) / 9;
		const level = cautionLevel(hiF);

		return {
			primaryResult: fahrenheit ? `${num(hiF, 0)} °F` : `${num(hiC, 0)} °C`,
			primaryLabel: 'Heat index (feels like)',
			summary: `${level}. ${ADVICE[level]}`,
			secondaryMetrics: [
				{ label: 'Heat index in °F', value: `${num(hiF, 1, 1)} °F` },
				{ label: 'Heat index in °C', value: `${num(hiC, 1, 1)} °C` },
				{ label: 'Caution level', value: level },
				{ label: 'Air temperature', value: `${num(tF, 1, 1)} °F (${num(tC, 1, 1)} °C)` },
				{ label: 'Method', value: method }
			]
		};
	},
	content: {
		intro:
			'Find the heat index, the temperature people feel when air heat and humidity combine. High humidity slows the evaporation of sweat, so the body cools less well, and the NWS caution level tells you how much risk to expect.',
		howTo: [
			'Choose Fahrenheit or Celsius.',
			'Enter the air temperature.',
			'Enter the relative humidity.',
			'Read the heat index and its caution level. Values are shown in both units.'
		],
		formulas: [
			{
				title: 'Simple formula (used first, and alone below 80 °F)',
				expression: 'HI = ½ × (T + 61 + (T − 68) × 1.2 + RH × 0.094)',
				variables: [
					{ symbol: 'T', meaning: 'air temperature in °F' },
					{ symbol: 'RH', meaning: 'relative humidity in %' }
				]
			},
			{
				title: 'Rothfusz regression (used when the average of T and the simple result is 80 °F or more)',
				expression:
					'HI = −42.379 + 2.04901523T + 10.14333127RH − 0.22475541T·RH − 0.00683783T² − 0.05481717RH² + 0.00122874T²·RH + 0.00085282T·RH² − 0.00000199T²·RH²',
				variables: []
			},
			{
				title: 'Adjustments to the regression',
				expression:
					'Dry air (RH below 13%, 80 to 112 °F): subtract [(13 − RH) ÷ 4] × √[(17 − |T − 95|) ÷ 17]. Humid air (RH above 85%, 80 to 87 °F): add [(RH − 85) ÷ 10] × [(87 − T) ÷ 5].',
				variables: []
			}
		],
		example: {
			title: '90 °F air at 70% relative humidity',
			steps: [
				'Simple formula: ½ × (90 + 61 + 22 × 1.2 + 70 × 0.094) = 91.99 °F',
				'Average with the air temperature: (91.99 + 90) ÷ 2 = 90.99, which is 80 °F or more, so use the regression',
				'Regression: 105.9 °F, no adjustment applies',
				'Caution level: 103 to 124 °F is danger'
			],
			result: 'Heat index about 106 °F (41 °C), in the danger level.'
		},
		faq: [
			{
				q: 'What are the NWS heat index caution levels?',
				a: 'Caution is 80 to 90 °F, extreme caution 90 to 103 °F, danger 103 to 124 °F and extreme danger 125 °F or higher. Each step calls for more care with outdoor work and exercise.'
			},
			{
				q: 'Does the heat index apply in the sun?',
				a: 'The NWS values are for shade and light wind. Direct sun can raise the heat index by up to about 15 °F (8 °C).'
			},
			{
				q: 'Why is the heat index close to the air temperature below 80 °F?',
				a: 'Below 80 °F the NWS uses its simple formula, and humidity has a small effect at cooler temperatures. The result is near the air temperature.'
			},
			{
				q: 'Is the heat index the same as the body temperature?',
				a: 'No. It describes how hot the conditions feel to a person in the shade. It does not measure body temperature, and people vary in how well they cope with heat.'
			}
		],
		sources: [{ title: 'National Weather Service — Heat Index', url: 'https://www.weather.gov/safety/heat-index' }]
	}
});
