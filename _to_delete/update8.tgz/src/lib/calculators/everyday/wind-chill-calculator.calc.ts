import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './wind-chill-calculator.meta';

const metric = (v: InputValues) => v.units === 'met';
const imperial = (v: InputValues) => v.units !== 'met';

/** NWS / Environment Canada wind chill (2001), in °F with wind in mph. */
export function windChillF(tF: number, mph: number): number {
	const w = Math.pow(mph, 0.16);
	return 35.74 + 0.6215 * tF - 35.75 * w + 0.4275 * tF * w;
}

/** NWS / Environment Canada wind chill (2001), in °C with wind in km/h. */
export function windChillC(tC: number, kmh: number): number {
	const w = Math.pow(kmh, 0.16);
	return 13.12 + 0.6215 * tC - 11.37 * w + 0.3965 * tC * w;
}

/**
 * Approximate frostbite time from the NWS wind chill chart bands, with wind chill in °F.
 * Bands: 30 minutes from −18 °F down to −34 °F, 10 minutes from −35 °F to −49 °F, 5 minutes at −50 °F and below.
 */
export function frostbiteTime(wcF: number): string | null {
	if (wcF > -18) return null;
	if (wcF > -35) return 'About 30 minutes';
	if (wcF > -50) return 'About 10 minutes';
	return 'About 5 minutes';
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'imp',
			options: [
				{ label: 'Imperial (°F, mph)', value: 'imp' },
				{ label: 'Metric (°C, km/h)', value: 'met' }
			]
		},
		{ id: 'tempF', label: 'Air temperature', type: 'number', default: 0, min: -100, max: 100, step: 0.1, suffix: '°F', visibleWhen: imperial },
		{ id: 'windMph', label: 'Wind speed', type: 'number', default: 15, min: 0, max: 200, step: 0.1, suffix: 'mph', visibleWhen: imperial },
		{ id: 'tempC', label: 'Air temperature', type: 'number', default: -18, min: -73, max: 40, step: 0.1, suffix: '°C', visibleWhen: metric },
		{ id: 'windKmh', label: 'Wind speed', type: 'number', default: 24, min: 0, max: 320, step: 0.1, suffix: 'km/h', visibleWhen: metric }
	],
	calculate(v): CalculationResult {
		const isMetric = metric(v);
		const t = Number(isMetric ? v.tempC : v.tempF);
		const w = Number(isMetric ? v.windKmh : v.windMph);
		if (!Number.isFinite(t) || !Number.isFinite(w) || w < 0) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Wind chill',
				summary: 'Enter an air temperature and a wind speed of zero or more.'
			};
		}
		const unit = isMetric ? '°C' : '°F';
		const speedUnit = isMetric ? 'km/h' : 'mph';
		const tF = isMetric ? t * 1.8 + 32 : t;
		const tC = isMetric ? t : ((t - 32) * 5) / 9;

		const applies = isMetric ? t <= 10 && w >= 4.8 : t <= 50 && w >= 3;
		if (!applies) {
			return {
				primaryResult: `${num(t, 0)} ${unit}`,
				primaryLabel: 'Air temperature (no wind chill)',
				summary:
					'The wind chill formula does not apply here. It is used only at 50 °F (10 °C) or colder, with wind above 3 mph (4.8 km/h), so the air temperature is shown.',
				secondaryMetrics: [
					{ label: 'Wind chill', value: 'Not applicable' },
					{ label: 'Wind speed', value: `${num(w, 1, 1)} ${speedUnit}` },
					{ label: 'Frostbite time', value: 'Not applicable' }
				]
			};
		}

		const wc = isMetric ? windChillC(t, w) : windChillF(t, w);
		const wcF = isMetric ? wc * 1.8 + 32 : wc;
		const wcC = isMetric ? wc : ((wc - 32) * 5) / 9;
		const frost = frostbiteTime(wcF);

		return {
			primaryResult: `${num(isMetric ? wcC : wcF, 0)} ${unit}`,
			primaryLabel: 'Wind chill (feels like)',
			summary: frost
				? `Exposed skin can freeze in ${frost.toLowerCase()}.`
				: 'Above −18 °F, the NWS chart lists no frostbite time, but cold still matters for long exposure.',
			secondaryMetrics: [
				{ label: isMetric ? 'Wind chill in °F' : 'Wind chill in °C', value: isMetric ? `${num(wcF, 1, 1)} °F` : `${num(wcC, 1, 1)} °C` },
				{ label: 'Air temperature', value: `${num(t, 1, 1)} ${unit}` },
				{ label: 'Wind speed', value: `${num(w, 1, 1)} ${speedUnit}` },
				{ label: 'Frostbite time (approx.)', value: frost ?? 'Not listed above −18 °F' }
			]
		};
	},
	content: {
		intro:
			'Find the wind chill, the temperature that cold, windy air feels like on exposed skin. Wind speeds up heat loss from the body, so it feels colder than the thermometer reading, though the air itself is no colder.',
		howTo: [
			'Choose Imperial (°F and mph) or Metric (°C and km/h).',
			'Enter the air temperature.',
			'Enter the wind speed.',
			'Read the wind chill and the approximate frostbite time. If the formula does not apply, the air temperature is shown.'
		],
		formulas: [
			{
				title: 'Imperial (°F, mph)',
				expression: 'WC = 35.74 + 0.6215T − 35.75V^0.16 + 0.4275TV^0.16',
				variables: [
					{ symbol: 'T', meaning: 'air temperature in °F' },
					{ symbol: 'V', meaning: 'wind speed in mph' },
					{ symbol: 'WC', meaning: 'wind chill in °F' }
				]
			},
			{
				title: 'Metric (°C, km/h)',
				expression: 'WC = 13.12 + 0.6215T − 11.37V^0.16 + 0.3965TV^0.16',
				variables: [
					{ symbol: 'T', meaning: 'air temperature in °C' },
					{ symbol: 'V', meaning: 'wind speed in km/h' },
					{ symbol: 'WC', meaning: 'wind chill in °C' }
				]
			},
			{
				title: 'Valid range',
				expression: 'Imperial: 50 °F or colder and wind above 3 mph. Metric: 10 °C or colder and wind above 4.8 km/h.',
				variables: []
			}
		],
		example: {
			title: '0 °F air with a 15 mph wind',
			steps: [
				'Wind term: 15^0.16 = 1.542',
				'Wind part: 35.74 + 0.6215 × 0 − 35.75 × 1.542 = −19.40',
				'Round: −19 °F, which is in the band where exposed skin can freeze in about 30 minutes'
			],
			result: 'Wind chill about −19 °F, so exposed skin can freeze in about 30 minutes.'
		},
		faq: [
			{
				q: 'Does wind chill change the air temperature?',
				a: 'No. It describes how cold the conditions feel on exposed skin. A thermometer reads the same value whatever the wind.'
			},
			{
				q: 'When does the wind chill formula apply?',
				a: 'Only at 50 °F (10 °C) or colder, with wind above 3 mph (4.8 km/h). Above those limits the NWS does not use wind chill, so this calculator shows the air temperature.'
			},
			{
				q: 'Does wind chill apply to pets or objects?',
				a: 'It is designed for people. Objects such as cars, pipes and water cool to the air temperature, not to the wind chill temperature.'
			},
			{
				q: 'How reliable are the frostbite times?',
				a: 'They are approximate guidance from the NWS wind chill chart. Frostbite can happen sooner in wet or poorly protected skin, so cover up and go indoors if skin turns pale, numb or waxy.'
			}
		],
		sources: [{ title: 'National Weather Service — Cold and wind chill chart', url: 'https://www.weather.gov/safety/cold-wind-chill-chart' }]
	}
});
