import { defineCalculator, type CalculationResult, type InputValues, type RowValue } from '../types';
import { DASH, num, pct, plural } from '../format';
import meta from './grade-calculator.meta';

const weighted = (v: InputValues) => v.mode === 'weighted';
const final = (v: InputValues) => v.mode === 'final';

/** Common letter bands. Schools vary, so check your own grading policy. */
export function letterFor(score: number): string {
	if (score >= 90) return 'A';
	if (score >= 80) return 'B';
	if (score >= 70) return 'C';
	if (score >= 60) return 'D';
	return 'F';
}

/** Score needed on the final: (desired − current × (1 − w)) ÷ w, with w as a fraction. */
export function finalNeeded(current: number, desired: number, weightPct: number): number {
	const w = weightPct / 100;
	return (desired - current * (1 - w)) / w;
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'What do you want to find?',
			type: 'select',
			display: 'segmented',
			default: 'weighted',
			options: [
				{ label: 'Weighted average', value: 'weighted' },
				{ label: 'Final exam needed', value: 'final' }
			]
		},
		{
			id: 'grades',
			label: 'Assignments',
			type: 'rows',
			columns: [
				{ id: 'name', label: 'Assignment', type: 'text', default: '', placeholder: 'Assignment name' },
				{ id: 'grade', label: 'Grade', type: 'number', default: 85, min: 0, max: 200, suffix: '%' },
				{ id: 'weight', label: 'Weight', type: 'number', default: 20, min: 0, max: 100, suffix: '%' }
			],
			default: [
				{ name: 'Homework', grade: 85, weight: 20 },
				{ name: 'Quizzes', grade: 92, weight: 15 },
				{ name: 'Midterm', grade: 78, weight: 25 },
				{ name: 'Project', grade: 90, weight: 20 }
			],
			minRows: 1,
			maxRows: 30,
			addLabel: 'Add assignment',
			visibleWhen: weighted
		},
		{
			id: 'current',
			label: 'Current grade',
			type: 'number',
			default: 88,
			min: 0,
			max: 200,
			step: 0.1,
			suffix: '%',
			visibleWhen: final
		},
		{
			id: 'desired',
			label: 'Desired grade',
			type: 'number',
			default: 90,
			min: 0,
			max: 200,
			step: 0.1,
			suffix: '%',
			visibleWhen: final
		},
		{
			id: 'finalWeight',
			label: 'Final exam weight',
			type: 'number',
			default: 20,
			min: 0.1,
			max: 100,
			step: 0.1,
			suffix: '%',
			visibleWhen: final
		}
	],
	calculate(v): CalculationResult {
		if (v.mode === 'final') {
			const current = Number(v.current);
			const desired = Number(v.desired);
			const weight = Number(v.finalWeight);
			if (
				!Number.isFinite(current) || current < 0 ||
				!Number.isFinite(desired) || desired < 0 ||
				!Number.isFinite(weight) || weight <= 0 || weight > 100
			) {
				return {
					primaryResult: DASH,
					primaryLabel: 'Score needed on the final',
					summary: 'Enter your current grade, the grade you want and a final exam weight above 0%.'
				};
			}

			const needed = finalNeeded(current, desired, weight);
			const shown = Math.max(needed, 0);
			const w = weight / 100;
			let summary: string;
			if (needed <= 0) summary = 'You already have enough for your target. Any final score keeps you there.';
			else if (needed > 100) summary = 'That is above 100%, so the target is out of reach on this exam.';
			else summary = `You need ${pct(needed, 2)} on the final to finish with ${pct(desired, 2)}.`;

			return {
				primaryResult: pct(shown, 2),
				primaryLabel: 'Score needed on the final',
				summary,
				secondaryMetrics: [
					{ label: 'From current grade', value: pct(current * (1 - w), 2) },
					{ label: 'From final exam', value: pct(shown * w, 2) },
					{ label: 'Target grade', value: pct(desired, 2) }
				]
			};
		}

		const rows = (v.grades as RowValue[]) ?? [];
		let weightedSum = 0;
		let totalWeight = 0;
		for (const row of rows) {
			const g = Number(row.grade);
			const w = Number(row.weight);
			if (!Number.isFinite(g) || g < 0 || !Number.isFinite(w) || w < 0) {
				return {
					primaryResult: DASH,
					primaryLabel: 'Current grade',
					summary: 'Enter a grade and a weight for every assignment.'
				};
			}
			weightedSum += g * w;
			totalWeight += w;
		}
		if (!(totalWeight > 0)) {
			return { primaryResult: DASH, primaryLabel: 'Current grade', summary: 'Enter at least one weight above 0%.' };
		}

		const grade = weightedSum / totalWeight;
		const letter = letterFor(grade);
		return {
			primaryResult: pct(grade, 2),
			primaryLabel: 'Current grade',
			summary:
				totalWeight === 100
					? `Letter grade ${letter}. The weights add up to 100%.`
					: `Letter grade ${letter}. The weights add up to ${num(totalWeight, 1, 0)}%, so the average is scaled to that total.`,
			secondaryMetrics: [
				{ label: 'Letter grade', value: letter },
				{ label: 'Weights counted', value: `${num(totalWeight, 1, 0)}%` },
				{ label: 'Assignments', value: plural(rows.length, 'assignment') }
			]
		};
	},
	content: {
		intro:
			'Find your current grade in a course from the scores and weights of your assignments, or work out the score you need on a final exam to reach the grade you want.',
		howTo: [
			'Choose “Weighted average” to grade your work so far, or “Final exam needed” to plan for the exam.',
			'For a weighted average, enter each assignment with its score and its share of the course.',
			'For the final exam, enter your current grade, your target grade and the exam’s weight.',
			'Read the grade or the score you need.'
		],
		formulas: [
			{
				title: 'Weighted average',
				expression: 'Grade = Σ (score × weight) ÷ Σ weight',
				variables: [
					{ symbol: 'score', meaning: 'Your percentage on one assignment' },
					{ symbol: 'weight', meaning: 'That assignment’s share of the course' }
				]
			},
			{
				title: 'Final exam needed',
				expression: 'Score needed = (desired − current × (1 − w)) ÷ w',
				variables: [
					{ symbol: 'desired', meaning: 'The overall course grade you want, as a percentage' },
					{ symbol: 'current', meaning: 'Your grade before the final, as a percentage' },
					{ symbol: 'w', meaning: 'The final exam’s weight as a fraction, for example 0.2 for 20%' }
				]
			}
		],
		example: {
			title: 'Final exam needed: current grade 88%, target 90%, final worth 20%',
			steps: [
				'Share from current grade: 88 × (1 − 0.2) = 70.4',
				'Remaining share needed: 90 − 70.4 = 19.6',
				'Score on the final: 19.6 ÷ 0.2 = 98'
			],
			result: 'You need 98% on the final exam to finish with 90%.'
		},
		faq: [
			{
				q: 'What letter grade is 85%?',
				a: 'On a common scale, 90 and above is an A, 80 to 89 is a B, 70 to 79 is a C, 60 to 69 is a D and below 60 is an F. Your school may use different cut-offs.'
			},
			{
				q: 'What if my weights do not add up to 100%?',
				a: 'The calculator divides by the total weight you entered, so your grade is still a fair average of the work you have so far.'
			},
			{
				q: 'Can the score needed be over 100%?',
				a: 'Yes. If the answer is above 100%, the target cannot be reached on that exam alone, and the calculator says so.'
			}
		]
	}
});
