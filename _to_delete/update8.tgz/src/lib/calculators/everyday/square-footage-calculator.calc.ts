import { defineCalculator, type CalculationResult, type InputValues, type NumberInput } from '../types';
import { DASH, money, num } from '../format';
import meta from './square-footage-calculator.meta';

const SQ_M_PER_SQ_FT = 0.09290304;

type Shape = 'rectangle' | 'circle' | 'triangle';

/** One dimension in both unit systems, shown only for its shape and the chosen units. */
const dim = (id: string, label: string, shape: Shape, def: { ft: number; m: number }): NumberInput[] => [
	{
		id: `${id}Ft`,
		label,
		type: 'number',
		default: def.ft,
		min: 0,
		max: 1000000,
		step: 0.1,
		suffix: 'ft',
		visibleWhen: (v: InputValues) => v.shape === shape && v.units === 'ft'
	},
	{
		id: `${id}M`,
		label,
		type: 'number',
		default: def.m,
		min: 0,
		max: 1000000,
		step: 0.1,
		suffix: 'm',
		visibleWhen: (v: InputValues) => v.shape === shape && v.units === 'm'
	}
];

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'shape',
			label: 'Shape',
			type: 'select',
			display: 'segmented',
			default: 'rectangle',
			options: [
				{ label: 'Rectangle', value: 'rectangle' },
				{ label: 'Circle', value: 'circle' },
				{ label: 'Triangle', value: 'triangle' }
			]
		},
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'ft',
			options: [
				{ label: 'Feet (sq ft)', value: 'ft' },
				{ label: 'Metres (sq m)', value: 'm' }
			]
		},
		...dim('rectLen', 'Length', 'rectangle', { ft: 12, m: 4 }),
		...dim('rectWid', 'Width', 'rectangle', { ft: 10, m: 3 }),
		...dim('circDia', 'Diameter', 'circle', { ft: 10, m: 2 }),
		...dim('triBase', 'Base', 'triangle', { ft: 10, m: 4 }),
		...dim('triHt', 'Height', 'triangle', { ft: 6, m: 3 }),
		{
			id: 'priceFt',
			label: 'Price per square foot (optional)',
			type: 'number',
			default: 5,
			min: 0,
			max: 100000,
			step: 0.01,
			prefix: '$',
			suffix: '/sq ft',
			help: 'Set to 0 to leave out the cost.',
			visibleWhen: (v) => v.units === 'ft'
		},
		{
			id: 'priceM',
			label: 'Price per square metre (optional)',
			type: 'number',
			default: 54,
			min: 0,
			max: 1000000,
			step: 0.01,
			prefix: '$',
			suffix: '/sq m',
			help: 'Set to 0 to leave out the cost.',
			visibleWhen: (v) => v.units === 'm'
		}
	],
	calculate(v): CalculationResult {
		const imperial = v.units === 'ft';
		const pick = (base: string) => Number(imperial ? v[`${base}Ft`] : v[`${base}M`]);
		const price = Number(imperial ? v.priceFt : v.priceM);
		const invalid = (): CalculationResult => ({
			primaryResult: DASH,
			primaryLabel: 'Area',
			summary: 'Enter a size greater than zero for every measurement.'
		});

		let area: number;
		if (v.shape === 'circle') {
			const d = pick('circDia');
			if (!(d > 0) || !Number.isFinite(d)) return invalid();
			area = Math.PI * (d / 2) ** 2;
		} else if (v.shape === 'triangle') {
			const b = pick('triBase');
			const h = pick('triHt');
			if (!(b > 0) || !Number.isFinite(b) || !(h > 0) || !Number.isFinite(h)) return invalid();
			area = (b * h) / 2;
		} else {
			const l = pick('rectLen');
			const w = pick('rectWid');
			if (!(l > 0) || !Number.isFinite(l) || !(w > 0) || !Number.isFinite(w)) return invalid();
			area = l * w;
		}
		if (!Number.isFinite(price) || price < 0) {
			return { primaryResult: DASH, primaryLabel: 'Area', summary: 'The price cannot be negative.' };
		}

		const sqFt = imperial ? area : area / SQ_M_PER_SQ_FT;
		const sqM = imperial ? area * SQ_M_PER_SQ_FT : area;
		const cost = area * price;
		const unit = imperial ? 'sq ft' : 'sq m';

		return {
			primaryResult: `${num(area, 2, 2)} ${unit}`,
			primaryLabel: 'Area',
			summary: `${v.shape === 'circle' ? 'Circle' : v.shape === 'triangle' ? 'Triangle' : 'Rectangle'} area, in ${unit}.`,
			secondaryMetrics: [
				{ label: 'Area in square feet', value: `${num(sqFt, 2, 2)} sq ft` },
				{ label: 'Area in square metres', value: `${num(sqM, 2, 2)} sq m` },
				{ label: 'Total cost', value: price > 0 ? money(cost) : DASH }
			]
		};
	},
	content: {
		intro:
			'Work out the area of a rectangle, circle or triangle in square feet or square metres, and the total cost of covering it at your price per unit.',
		howTo: [
			'Choose the shape of the space or surface.',
			'Pick feet or metres, then enter the measurements in that unit.',
			'Optionally enter a price per square foot or metre to see the total cost.',
			'Read the area in both systems and the cost.'
		],
		formulas: [
			{
				title: 'Rectangle',
				expression: 'Area = length × width',
				variables: []
			},
			{
				title: 'Circle',
				expression: 'Area = π × (diameter ÷ 2)²',
				variables: [{ symbol: 'π', meaning: 'About 3.14159' }]
			},
			{
				title: 'Triangle',
				expression: 'Area = base × height ÷ 2',
				variables: [{ symbol: 'height', meaning: 'Perpendicular height from the base to the opposite corner' }]
			},
			{
				title: 'Cost',
				expression: 'Cost = area × price per unit area',
				variables: [{ symbol: 'area', meaning: 'Area in the same unit as the price' }]
			}
		],
		example: {
			title: 'A 12 ft by 10 ft room at $5 per square foot',
			steps: [
				'Area: 12 × 10 = 120 sq ft',
				'In metres: 120 × 0.09290304 = 11.15 sq m',
				'Cost: 120 × $5 = $600.00'
			],
			result: 'The room is 120.00 sq ft (11.15 sq m) and covering it costs $600.00.'
		},
		faq: [
			{
				q: 'How do I convert square feet to square metres?',
				a: 'Multiply square feet by 0.09290304 to get square metres. To go the other way, divide square metres by the same number.'
			},
			{
				q: 'Should I add extra for waste when buying flooring?',
				a: 'Usually, yes. Many installers suggest adding around 5% to 10% for cuts and offcuts, more for diagonal layouts. This calculator gives the exact area, so add your own allowance.'
			},
			{
				q: 'How do I measure an irregular room?',
				a: 'Split it into rectangles and triangles, work out each area, then add them together. Use the same unit for every measurement.'
			}
		]
	}
});
