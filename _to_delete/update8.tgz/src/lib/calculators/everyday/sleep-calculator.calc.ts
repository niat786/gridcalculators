import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './sleep-calculator.meta';

const CYCLE_MINUTES = 90;
const FALL_ASLEEP_MINUTES = 15;
const MINUTES_PER_DAY = 1_440;
const CYCLE_OPTIONS = [6, 5, 4];
/** The option shown as the headline result: five full cycles (7.5 hours). */
const HEADLINE_CYCLES = 5;

/** "HH:MM" (24-hour) to minutes after midnight. Null when the text is not a valid time. */
export function minutesOf(s: string): number | null {
	const m = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(s);
	return m ? +m[1] * 60 + +m[2] : null;
}

/** Minutes after midnight to "h:mm AM" / "h:mm PM". */
export function clock12(total: number): string {
	const mins = ((total % MINUTES_PER_DAY) + MINUTES_PER_DAY) % MINUTES_PER_DAY;
	const h24 = Math.floor(mins / 60);
	const h = h24 % 12 || 12;
	return `${h}:${String(mins % 60).padStart(2, '0')} ${h24 < 12 ? 'AM' : 'PM'}`;
}

const mode = (m: string) => (v: InputValues) => v.mode === m;

const invalid = (summary: string): CalculationResult => ({ primaryResult: DASH, primaryLabel: 'Bedtime', summary });

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'What do you want to set?',
			type: 'select',
			display: 'segmented',
			default: 'wake',
			options: [
				{ label: 'I want to wake up at', value: 'wake' },
				{ label: 'I’m going to bed at', value: 'bed' }
			]
		},
		{
			id: 'wake',
			label: 'Wake-up time',
			type: 'time',
			default: '07:00',
			help: 'Bedtimes are worked out backwards from this time.',
			visibleWhen: mode('wake')
		},
		{
			id: 'bed',
			label: 'Bedtime',
			type: 'time',
			default: '23:00',
			help: 'Wake-up times are worked out forwards from this time.',
			visibleWhen: mode('bed')
		}
	],
	calculate(v): CalculationResult {
		const wakeMode = v.mode !== 'bed';
		const anchor = minutesOf(String(wakeMode ? v.wake : v.bed));
		if (anchor === null) return invalid('Enter a valid time.');

		const rows = CYCLE_OPTIONS.map((cycles) => {
			const asleep = cycles * CYCLE_MINUTES;
			const offset = asleep + FALL_ASLEEP_MINUTES;
			return {
				cycles: `${cycles} cycles`,
				hours: `${num(asleep / 60, 1)} hours`,
				time: clock12(wakeMode ? anchor - offset : anchor + offset)
			};
		});
		const headline = rows[CYCLE_OPTIONS.indexOf(HEADLINE_CYCLES)];

		return {
			primaryResult: headline.time,
			primaryLabel: wakeMode ? 'Bedtime for 5 cycles' : 'Wake-up time for 5 cycles',
			summary: 'Five full cycles is 7.5 hours of sleep, with 15 minutes allowed to fall asleep.',
			secondaryMetrics: [
				{ label: 'Time to fall asleep', value: '15 minutes' },
				{ label: 'Length of one cycle', value: '90 minutes' },
				{ label: 'Adult guideline', value: '7 or more hours' }
			],
			table: {
				title: wakeMode ? `Bedtimes to wake at ${clock12(anchor)}` : `Wake-up times after going to bed at ${clock12(anchor)}`,
				columns: [
					{ key: 'cycles', label: 'Sleep cycles' },
					{ key: 'hours', label: 'Time asleep' },
					{ key: 'time', label: wakeMode ? 'Go to bed at' : 'Wake up at', align: 'end' }
				],
				rows
			}
		};
	},
	content: {
		intro:
			'Plan your night around sleep cycles. Pick a wake-up time to see when to go to bed, or pick a bedtime to see when to wake up.',
		howTo: [
			'Choose whether you want to set a wake-up time or a bedtime.',
			'Enter that time with the time picker.',
			'Pick a row from the table. Each row is a number of full 90-minute sleep cycles.',
			'Treat the times as a guide, because everyone’s sleep is different.'
		],
		formulas: [
			{
				title: 'Time asleep',
				expression: 'Time asleep = cycles × 90 minutes',
				variables: [{ symbol: '90', meaning: 'minutes in one sleep cycle' }]
			},
			{
				title: 'Bedtime for a wake-up time',
				expression: 'Bedtime = wake-up time − (cycles × 90 + 15) minutes',
				variables: [{ symbol: '15', meaning: 'minutes allowed to fall asleep' }]
			},
			{
				title: 'Wake-up time for a bedtime',
				expression: 'Wake-up time = bedtime + (cycles × 90 + 15) minutes',
				variables: []
			}
		],
		example: {
			title: 'Wake at 7:00 AM with five cycles',
			steps: [
				'Time asleep: 5 × 90 = 450 minutes, which is 7.5 hours.',
				'Add 15 minutes to fall asleep: 450 + 15 = 465 minutes.',
				'7:00 AM is 420 minutes after midnight. 420 − 465 = −45, which is 45 minutes before midnight, or 11:15 PM.'
			],
			result: 'Go to bed at 11:15 PM for 7.5 hours of sleep.'
		},
		faq: [
			{
				q: 'How many hours of sleep do adults need?',
				a: 'The CDC advises that adults get 7 or more hours of sleep per night on a regular basis. The NHS says most adults need between 7 and 9 hours.'
			},
			{
				q: 'Why are sleep cycles 90 minutes?',
				a: 'A typical sleep cycle moves through light, deep and REM stages and lasts about 90 minutes. Many people find waking at the end of a cycle easier, but sleep needs vary.'
			},
			{
				q: 'What if I take longer than 15 minutes to fall asleep?',
				a: 'The calculator allows 15 minutes. If you usually take longer, move the bedtime earlier by the extra time.'
			}
		],
		sources: [
			{ title: 'CDC: Sleep', url: 'https://www.cdc.gov/sleep/' },
			{ title: 'NHS: Sleep and tiredness', url: 'https://www.nhs.uk/live-well/sleep-and-tiredness/' }
		],
		disclaimer: 'Sleep needs differ from person to person, so these times are estimates, not medical advice.'
	}
});
