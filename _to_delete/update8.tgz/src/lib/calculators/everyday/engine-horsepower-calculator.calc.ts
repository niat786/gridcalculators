import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './engine-horsepower-calculator.meta';

const isEt = (v: InputValues) => v.method !== 'trap';
const isTrap = (v: InputValues) => v.method === 'trap';
const imperial = (v: InputValues) => v.units !== 'met';
const metric = (v: InputValues) => v.units === 'met';

const KG_TO_LB = 2.20462262;
const KMH_TO_MPH = 0.621371;
const HP_TO_KW = 0.7456998716;

/** Hale's elapsed-time estimate: hp = weight ÷ (ET ÷ 5.825)³, weight in lb, ET in seconds. */
export function haleHpFromEt(weightLb: number, etSeconds: number): number {
	return weightLb / Math.pow(etSeconds / 5.825, 3);
}

/** Hale's trap-speed estimate: hp = weight × (MPH ÷ 234)³, weight in lb, speed in mph. */
export function haleHpFromTrap(weightLb: number, mph: number): number {
	return weightLb * Math.pow(mph / 234, 3);
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'method',
			label: 'Estimate from',
			type: 'select',
			display: 'segmented',
			default: 'et',
			options: [
				{ label: 'Elapsed time', value: 'et' },
				{ label: 'Trap speed', value: 'trap' }
			]
		},
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'imp',
			options: [
				{ label: 'Pounds and mph', value: 'imp' },
				{ label: 'Kilograms and km/h', value: 'met' }
			]
		},
		{ id: 'weightLb', label: 'Vehicle weight', type: 'number', default: 3000, min: 500, max: 10000, step: 1, suffix: 'lb', decimal: false, visibleWhen: imperial },
		{ id: 'weightKg', label: 'Vehicle weight', type: 'number', default: 1361, min: 200, max: 4500, step: 1, suffix: 'kg', decimal: false, visibleWhen: metric },
		{ id: 'et', label: 'Quarter-mile time', type: 'number', default: 13, min: 5, max: 30, step: 0.01, suffix: 's', visibleWhen: isEt },
		{ id: 'trapMph', label: 'Trap speed', type: 'number', default: 105, min: 30, max: 250, step: 0.1, suffix: 'mph', visibleWhen: (v) => isTrap(v) && imperial(v) },
		{ id: 'trapKmh', label: 'Trap speed', type: 'number', default: 169, min: 50, max: 400, step: 0.1, suffix: 'km/h', visibleWhen: (v) => isTrap(v) && metric(v) }
	],
	calculate(v): CalculationResult {
		const weightLb = metric(v) ? Number(v.weightKg) * KG_TO_LB : Number(v.weightLb);
		if (!(weightLb > 0)) {
			return { primaryResult: DASH, primaryLabel: 'Estimated engine power', summary: 'Enter the vehicle weight.' };
		}

		let hp: number;
		let basis: string;
		let method: string;
		if (v.method === 'trap') {
			const mph = metric(v) ? Number(v.trapKmh) * KMH_TO_MPH : Number(v.trapMph);
			if (!(mph > 0)) {
				return { primaryResult: DASH, primaryLabel: 'Estimated engine power', summary: 'Enter a trap speed above zero.' };
			}
			hp = haleHpFromTrap(weightLb, mph);
			basis = `${num(mph, 1, 1)} mph trap speed`;
			method = 'Hale trap speed';
		} else {
			const et = Number(v.et);
			if (!(et > 0)) {
				return { primaryResult: DASH, primaryLabel: 'Estimated engine power', summary: 'Enter a quarter-mile time above zero.' };
			}
			hp = haleHpFromEt(weightLb, et);
			basis = `${num(et, 2, 2)} s quarter mile`;
			method = 'Hale elapsed time';
		}

		return {
			primaryResult: `${num(hp, 0)} hp`,
			primaryLabel: 'Estimated engine power',
			summary: `Estimate for a car weighing ${num(weightLb, 0)} lb, from a ${basis}.`,
			secondaryMetrics: [
				{ label: 'Kilowatts (kW)', value: `${num(hp * HP_TO_KW, 0)} kW` },
				{ label: 'Weight used', value: `${num(weightLb, 0)} lb` },
				{ label: 'Pounds per hp', value: `${num(weightLb / hp, 1, 1)} lb/hp` },
				{ label: 'Method', value: method }
			]
		};
	},
	content: {
		intro:
			'Estimate an engine’s power from a quarter-mile run. Enter the car’s weight and either the elapsed time or the trap speed, and the calculator applies Hale’s formulas. The result is a rough estimate, not a dyno reading.',
		howTo: [
			'Choose pounds and mph, or kilograms and km/h.',
			'Enter the vehicle weight, including the driver if you want a realistic figure.',
			'Choose elapsed time or trap speed, then enter the matching figure from the run.',
			'Read the estimated horsepower, with kilowatts and pounds per hp.'
		],
		formulas: [
			{
				title: 'Elapsed time method',
				expression: 'hp = W ÷ (ET ÷ 5.825)³',
				variables: [
					{ symbol: 'W', meaning: 'vehicle weight in lb' },
					{ symbol: 'ET', meaning: 'quarter-mile elapsed time in seconds' }
				]
			},
			{
				title: 'Trap speed method',
				expression: 'hp = W × (MPH ÷ 234)³',
				variables: [
					{ symbol: 'W', meaning: 'vehicle weight in lb' },
					{ symbol: 'MPH', meaning: 'speed at the quarter-mile timing line, in mph' }
				]
			}
		],
		example: {
			title: 'A 3,000 lb car that runs the quarter mile in 13.00 seconds',
			steps: [
				'Divide the time by 5.825: 13.00 ÷ 5.825 = 2.2318',
				'Cube the result: 2.2318³ = 11.1158',
				'Divide the weight by that: 3,000 ÷ 11.1158 = 269.9 hp'
			],
			result: 'About 270 hp, roughly 201 kW.'
		},
		faq: [
			{
				q: 'How accurate are these estimates?',
				a: 'They are rough. Launch technique, traction, drivetrain losses, air density and track conditions all change the result. Use them to compare cars or check a ballpark, not as a measured power figure.'
			},
			{
				q: 'Which method should I use?',
				a: 'Use the method that matches the figure you have. If you have both, the two results usually land within a few percent of each other, and comparing them is a useful sense check.'
			},
			{
				q: 'Why does a small change in time matter so much?',
				a: 'Because power is proportional to the inverse cube of the time. On a 13-second pass, 0.1 seconds faster raises the estimate by about 2 percent.'
			},
			{
				q: 'Is the answer the same as the rated engine power?',
				a: 'Not usually. The estimate is the power that would produce that run. Manufacturers rate power under standard test conditions, which may differ from a real run.'
			}
		]
	}
});
