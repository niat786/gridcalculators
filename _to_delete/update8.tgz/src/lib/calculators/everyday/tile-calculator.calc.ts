import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num, plural } from '../format';
import meta from './tile-calculator.meta';

const imperial = (v: InputValues) => v.units === 'imperial';
const metric = (v: InputValues) => v.units === 'metric';

const pos = (n: number) => Number.isFinite(n) && n > 0;

function invalid(summary: string): CalculationResult {
	return { primaryResult: DASH, primaryLabel: 'Tiles to buy', summary };
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'imperial',
			options: [
				{ label: 'Feet and inches', value: 'imperial' },
				{ label: 'Metres and centimetres', value: 'metric' }
			]
		},
		// Feet and inches
		{ id: 'roomLenFt', label: 'Room length', type: 'number', default: 12, min: 0.5, max: 1000, step: 0.5, suffix: 'ft', width: 'half', visibleWhen: imperial },
		{ id: 'roomWidFt', label: 'Room width', type: 'number', default: 10, min: 0.5, max: 1000, step: 0.5, suffix: 'ft', width: 'half', visibleWhen: imperial },
		{ id: 'tileWIn', label: 'Tile width', type: 'number', default: 12, min: 0.5, max: 120, step: 0.5, suffix: 'in', width: 'half', visibleWhen: imperial },
		{ id: 'tileHIn', label: 'Tile height', type: 'number', default: 12, min: 0.5, max: 120, step: 0.5, suffix: 'in', width: 'half', visibleWhen: imperial },
		{
			id: 'groutIn',
			label: 'Grout gap',
			type: 'number',
			default: 0.125,
			min: 0,
			max: 1,
			step: 0.0625,
			suffix: 'in',
			help: 'A typical joint is 1/8 in.',
			visibleWhen: imperial
		},
		// Metres and centimetres
		{ id: 'roomLenM', label: 'Room length', type: 'number', default: 3.6, min: 0.1, max: 1000, step: 0.1, suffix: 'm', width: 'half', visibleWhen: metric },
		{ id: 'roomWidM', label: 'Room width', type: 'number', default: 3, min: 0.1, max: 1000, step: 0.1, suffix: 'm', width: 'half', visibleWhen: metric },
		{ id: 'tileWCm', label: 'Tile width', type: 'number', default: 30, min: 0.5, max: 300, step: 0.5, suffix: 'cm', width: 'half', visibleWhen: metric },
		{ id: 'tileHCm', label: 'Tile height', type: 'number', default: 30, min: 0.5, max: 300, step: 0.5, suffix: 'cm', width: 'half', visibleWhen: metric },
		{
			id: 'groutMm',
			label: 'Grout gap',
			type: 'number',
			default: 3,
			min: 0,
			max: 25,
			step: 0.5,
			suffix: 'mm',
			help: 'A typical joint is 2 to 3 mm.',
			visibleWhen: metric
		},
		{
			id: 'waste',
			label: 'Waste allowance',
			type: 'number',
			default: 10,
			min: 0,
			max: 50,
			step: 1,
			suffix: '%',
			help: 'Extra for cuts, breakage and edge pieces.'
		},
		{
			id: 'perBox',
			label: 'Tiles per box (optional)',
			type: 'number',
			default: 10,
			min: 0,
			max: 10000,
			step: 1,
			decimal: false,
			help: 'Set to 0 to leave out the box count.'
		}
	],
	calculate(v): CalculationResult {
		const isMetric = v.units === 'metric';
		// Work in inches (feet and inches) or centimetres (metric), so grout and tiles share one unit.
		const roomL = Number(isMetric ? v.roomLenM : v.roomLenFt) * (isMetric ? 100 : 12);
		const roomW = Number(isMetric ? v.roomWidM : v.roomWidFt) * (isMetric ? 100 : 12);
		const tileW = Number(isMetric ? v.tileWCm : v.tileWIn);
		const tileH = Number(isMetric ? v.tileHCm : v.tileHIn);
		const grout = isMetric ? Number(v.groutMm) / 10 : Number(v.groutIn);
		const waste = Number(v.waste);
		const perBox = Number(v.perBox);

		if (!pos(roomL) || !pos(roomW) || !pos(tileW) || !pos(tileH)) {
			return invalid('Enter a room size and tile size greater than zero.');
		}
		if (!Number.isFinite(grout) || grout < 0) return invalid('Enter a grout gap of 0 or more.');
		if (!Number.isFinite(waste) || waste < 0) return invalid('Enter a waste allowance of 0% or more.');
		if (!Number.isInteger(perBox) || perBox < 0) return invalid('Enter tiles per box as a whole number, 0 or more.');

		// Tiles across and down, counting each grout joint once per tile.
		// A small epsilon stops exact fits from adding an extra row or column.
		const across = Math.ceil((roomL + grout) / (tileW + grout) - 1e-9);
		const down = Math.ceil((roomW + grout) / (tileH + grout) - 1e-9);
		const tiles = across * down;
		const tilesWithWaste = Math.ceil(tiles * (1 + waste / 100) - 1e-9);
		const boxes = perBox > 0 ? Math.ceil(tilesWithWaste / perBox - 1e-9) : null;

		const perSquare = isMetric ? 10000 : 144;
		const unit = isMetric ? 'sq m' : 'sq ft';
		const roomArea = (roomL * roomW) / perSquare;
		const covered = (tilesWithWaste * tileW * tileH) / perSquare;

		return {
			primaryResult: plural(tilesWithWaste, 'tile'),
			primaryLabel: 'Tiles to buy',
			summary: `Includes ${num(waste, 0)}% extra for cuts and breakage.`,
			secondaryMetrics: [
				{ label: 'Room area', value: `${num(roomArea, 2)} ${unit}` },
				{ label: 'Tiles before waste', value: plural(tiles, 'tile') },
				{ label: 'Boxes', value: boxes === null ? DASH : plural(boxes, 'box', 'boxes') },
				{ label: 'Area covered by tiles', value: `${num(covered, 2)} ${unit}` }
			]
		};
	},
	content: {
		intro:
			'Work out how many floor or wall tiles a room needs, including the grout joints and a waste allowance, then how many boxes to buy and the area the tiles will cover.',
		howTo: [
			'Pick feet and inches or metres and centimetres, then enter the room length and width.',
			'Enter the size of one tile, and the width of the grout joint between tiles.',
			'Set a waste allowance. The default of 10% covers cuts and breakage.',
			'Optionally enter the tiles per box to see how many boxes to buy.'
		],
		formulas: [
			{
				title: 'Tiles across and down',
				expression:
					'Across = ⌈(room length + grout) ÷ (tile width + grout)⌉\nDown = ⌈(room width + grout) ÷ (tile height + grout)⌉\nTiles = across × down',
				variables: [
					{ symbol: 'grout', meaning: 'Width of the joint between tiles, in the same unit as the room and tile' },
					{ symbol: '⌈ ⌉', meaning: 'Round up to the next whole tile' }
				]
			},
			{
				title: 'Waste and boxes',
				expression: 'Tiles with waste = tiles × (1 + waste % ÷ 100), rounded up\nBoxes = tiles with waste ÷ tiles per box, rounded up',
				variables: []
			},
			{
				title: 'Area covered',
				expression: 'Area covered = tiles with waste × tile width × tile height',
				variables: []
			}
		],
		example: {
			title: 'A 12 ft by 10 ft room with 12 in tiles, 1/8 in grout, 10% waste and 10 tiles per box',
			steps: [
				'Across: (144 + 0.125) ÷ (12 + 0.125) = 11.89, rounded up to 12',
				'Down: (120 + 0.125) ÷ (12 + 0.125) = 9.91, rounded up to 10',
				'Tiles: 12 × 10 = 120',
				'With waste: 120 × 1.1 = 132 tiles',
				'Boxes: 132 ÷ 10 = 13.2, rounded up to 14 boxes'
			],
			result: 'Buy 132 tiles, which is 14 boxes of 10. The tiles cover 132 sq ft.'
		},
		faq: [
			{
				q: 'How many extra tiles should I buy?',
				a: 'Most rooms need 10%. Diagonal layouts, patterns and small rooms with many cuts may need 15% or more. Keep a few spare tiles from the same batch for future repairs.'
			},
			{
				q: 'Does the grout gap change the count?',
				a: 'Yes, a little. Each tile takes up its size plus the joint, so a wider joint means slightly fewer tiles across a room. The calculator includes the joint for each row and column.'
			},
			{
				q: 'Why is the area covered more than the room area?',
				a: 'The extra comes from the waste allowance. You buy more tiles than the room needs, so the area they cover is larger than the floor itself.'
			}
		]
	}
});
