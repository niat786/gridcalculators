import { defineMeta } from '../types';

export default defineMeta({
	slug: 'ohms-law-calculator',
	name: "Ohm's Law Calculator",
	category: 'everyday',
	shortDescription: 'Solve voltage, current, resistance and power from two known values.',
	metaTitle: "Ohm's Law Calculator — Volts, Amps, Ohms and Watts",
	metaDescription:
		"Free Ohm's law calculator. Enter any two of voltage, current, resistance or power to get the other two, with SI prefixes such as mA, kΩ and mW.",
	icon: 'zap',
	keywords: [
		'ohms law calculator',
		'ohm law calculator',
		'voltage current resistance',
		'power calculator watts',
		'v = ir calculator'
	],
	updated: '2026-10-28'
});
