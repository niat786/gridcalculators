import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './btu-calculator.meta';

/** 1 metre = 3.2808399 feet. */
const FT_PER_M = 3.2808399;
/** 1 BTU/h = 0.29307107 watts. */
const WATTS_PER_BTU_H = 0.29307107;
/** One ton of cooling is 12,000 BTU/h. */
const BTU_H_PER_TON = 12000;
/** Base load: 20 BTU/h for each square foot of a room with an 8 ft ceiling. */
const BTU_PER_SQ_FT = 20;
const REFERENCE_CEILING_FT = 8;
/** Only people beyond this number add load. */
const PEOPLE_INCLUDED = 2;
const BTU_PER_EXTRA_PERSON = 600;

/** Sun exposure as a change to the base load. */
const SUN: Record<string, number> = { shaded: -0.1, normal: 0, sunny: 0.1 };
/** Extra heat from the room type, in BTU/h. */
const ROOM_TYPE_BTU: Record<string, number> = { bedroom: 0, living: 0, kitchen: 4000 };

const isImperial = (v: InputValues) => v.units === 'ft';
const isMetric = (v: InputValues) => v.units === 'm';

const pos = (n: number) => Number.isFinite(n) && n > 0;

function invalid(summary: string): CalculationResult {
	return { primaryResult: DASH, primaryLabel: 'Cooling needed', summary };
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'ft',
			options: [
				{ label: 'Feet', value: 'ft' },
				{ label: 'Metres', value: 'm' }
			]
		},
		{ id: 'lenFt', label: 'Room length', type: 'number', default: 18, min: 1, max: 500, step: 0.5, suffix: 'ft', width: 'half', visibleWhen: isImperial },
		{ id: 'widFt', label: 'Room width', type: 'number', default: 14, min: 1, max: 500, step: 0.5, suffix: 'ft', width: 'half', visibleWhen: isImperial },
		{ id: 'lenM', label: 'Room length', type: 'number', default: 5.5, min: 0.5, max: 150, step: 0.1, suffix: 'm', width: 'half', visibleWhen: isMetric },
		{ id: 'widM', label: 'Room width', type: 'number', default: 4.3, min: 0.5, max: 150, step: 0.1, suffix: 'm', width: 'half', visibleWhen: isMetric },
		{ id: 'ceilFt', label: 'Ceiling height', type: 'number', default: 8, min: 4, max: 40, step: 0.5, suffix: 'ft', visibleWhen: isImperial },
		{ id: 'ceilM', label: 'Ceiling height', type: 'number', default: 2.5, min: 1.2, max: 12, step: 0.05, suffix: 'm', visibleWhen: isMetric },
		{
			id: 'sun',
			label: 'Sun exposure',
			type: 'select',
			display: 'menu',
			default: 'normal',
			options: [
				{ label: 'Shaded (−10%)', value: 'shaded' },
				{ label: 'Normal (no change)', value: 'normal' },
				{ label: 'Very sunny (+10%)', value: 'sunny' }
			],
			help: 'Pick shaded if the windows face away from the sun most of the day.'
		},
		{
			id: 'people',
			label: 'People in the room',
			type: 'number',
			default: 3,
			min: 0,
			max: 50,
			step: 1,
			decimal: false,
			help: 'Adds 600 BTU/h for each person beyond two.'
		},
		{
			id: 'use',
			label: 'Room type',
			type: 'select',
			display: 'menu',
			default: 'living',
			options: [
				{ label: 'Bedroom', value: 'bedroom' },
				{ label: 'Living room', value: 'living' },
				{ label: 'Kitchen', value: 'kitchen' }
			],
			help: 'A kitchen adds 4,000 BTU/h for heat from cooking appliances.'
		}
	],
	calculate(v): CalculationResult {
		const metric = isMetric(v);
		const len = Number(metric ? v.lenM : v.lenFt);
		const wid = Number(metric ? v.widM : v.widFt);
		const ceiling = Number(metric ? v.ceilM : v.ceilFt);
		const people = Number(v.people);
		const sunKey = String(v.sun);
		const roomKey = String(v.use);

		if (!pos(len) || !pos(wid) || !pos(ceiling)) {
			return invalid('Enter a room length, width and ceiling height greater than zero.');
		}
		if (!Number.isInteger(people) || people < 0) {
			return invalid('Enter the number of people as a whole number, 0 or more.');
		}
		if (!(sunKey in SUN) || !(roomKey in ROOM_TYPE_BTU)) {
			return invalid('Pick a sun exposure and a room type.');
		}

		const lenFt = metric ? len * FT_PER_M : len;
		const widFt = metric ? wid * FT_PER_M : wid;
		const ceilFt = metric ? ceiling * FT_PER_M : ceiling;
		const areaFt2 = lenFt * widFt;

		const base = areaFt2 * BTU_PER_SQ_FT * (ceilFt / REFERENCE_CEILING_FT);
		const sunAdj = base * SUN[sunKey];
		const roomAdd = Math.max(0, people - PEOPLE_INCLUDED) * BTU_PER_EXTRA_PERSON + ROOM_TYPE_BTU[roomKey];
		const total = Math.round(base + sunAdj + roomAdd);

		return {
			primaryResult: `${num(total, 0)} BTU/h`,
			primaryLabel: 'Cooling needed',
			summary: `An estimate for a room of ${num(areaFt2, 0)} sq ft. Treat it as a starting point and check the unit's rating.`,
			secondaryMetrics: [
				{ label: 'Room area', value: `${num(areaFt2, 1)} sq ft` },
				{ label: 'Base load', value: `${num(base, 0)} BTU/h` },
				{ label: 'Sun adjustment', value: `${sunAdj > 0 ? '+' : ''}${num(sunAdj, 0)} BTU/h` },
				{ label: 'People and room type', value: `${num(roomAdd, 0)} BTU/h` },
				{ label: 'Watts', value: `${num(total * WATTS_PER_BTU_H, 0)} W` },
				{ label: 'Tons of cooling', value: `${num(total / BTU_H_PER_TON, 2, 2)} tons` }
			]
		};
	},
	content: {
		intro:
			'Estimate how much cooling a room needs, in BTU per hour, watts and tons. It is a sizing estimate for a room air conditioner, not a full heat-load survey.',
		howTo: [
			'Pick feet or metres, then enter the room length, width and ceiling height.',
			'Choose how much sun the room gets, and how many people use it most of the time.',
			'Pick the room type. A kitchen adds heat from cooking appliances.',
			'Read the BTU/h figure to shop by, along with the watts and tons.'
		],
		formulas: [
			{
				title: 'Base load',
				expression: 'Base BTU/h = area × 20 × (ceiling height ÷ 8)',
				variables: [
					{ symbol: 'area', meaning: 'Room length × width, in square feet' },
					{ symbol: '20', meaning: 'BTU/h per square foot for a room with an 8 ft ceiling' },
					{ symbol: 'ceiling height', meaning: 'Height in feet. 8 ft is the reference height' }
				]
			},
			{
				title: 'Sun, people and room type',
				expression:
					'Sun = base × sun % ÷ 100, where the sun % is −10, 0 or +10\nPeople = 600 × (people − 2), only when there are more than two\nKitchen = +4,000 BTU/h',
				variables: [{ symbol: 'people', meaning: 'Everyone who regularly uses the room. The first two are already in the base' }]
			},
			{
				title: 'Total and conversions',
				expression: 'Total BTU/h = base + sun + people + room type\nWatts = BTU/h × 0.29307107\nTons = BTU/h ÷ 12,000',
				variables: [{ symbol: 'ton', meaning: 'One ton of cooling is 12,000 BTU/h' }]
			}
		],
		example: {
			title: 'An 18 ft by 14 ft living room, 8 ft ceiling, normal sun, 3 people',
			steps: [
				'Area: 18 × 14 = 252 sq ft',
				'Base: 252 × 20 × (8 ÷ 8) = 5,040 BTU/h',
				'People: (3 − 2) × 600 = 600 BTU/h',
				'Total: 5,040 + 600 = 5,640 BTU/h',
				'Watts: 5,640 × 0.29307107 = 1,652.9 W',
				'Tons: 5,640 ÷ 12,000 = 0.47 tons'
			],
			result: 'About 5,640 BTU/h (1,653 W), or 0.47 tons of cooling.'
		},
		faq: [
			{
				q: 'How many BTU do I need for a room?',
				a: 'A common starting point is 20 BTU/h for each square foot of a room with an 8 ft ceiling. This calculator adjusts that for ceiling height, sun, people and room type, following the room air conditioner sizing guidance from ENERGY STAR.'
			},
			{
				q: 'Is a bigger air conditioner always better?',
				a: 'No. An oversized unit cools the room too fast, switches on and off often, and leaves the air damp. Choose the size closest to your estimate.'
			},
			{
				q: 'Why does a kitchen need more BTU/h?',
				a: 'Cooking appliances give off a lot of heat, so a kitchen carries more load than its size suggests. The calculator adds 4,000 BTU/h for a kitchen.'
			}
		],
		sources: [{ title: 'ENERGY STAR', url: 'https://www.energystar.gov/' }]
	}
});
