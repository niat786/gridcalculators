import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './electricity-calculator.meta';

const DAYS_PER_YEAR = 365;

function invalid(summary: string): CalculationResult {
	return { primaryResult: DASH, primaryLabel: 'Monthly cost', summary };
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'power',
			label: 'Device power',
			type: 'number',
			default: 100,
			min: 0,
			max: 100000,
			step: 1,
			suffix: 'W',
			help: 'Find this on the label or power adapter. Watts = volts × amps.'
		},
		{
			id: 'hours',
			label: 'Hours used per day',
			type: 'number',
			default: 8,
			min: 0,
			max: 24,
			step: 0.5,
			suffix: 'hours'
		},
		{
			id: 'days',
			label: 'Days used per month',
			type: 'number',
			default: 30,
			min: 1,
			max: 31,
			step: 1,
			decimal: false,
			suffix: 'days'
		},
		{
			id: 'price',
			label: 'Price per kWh',
			type: 'number',
			default: 0.17,
			min: 0,
			max: 10,
			step: 0.01,
			prefix: '$',
			suffix: '/kWh',
			help: 'Check your electricity bill. Rates vary by region and plan.'
		},
		{
			id: 'quantity',
			label: 'Number of devices',
			type: 'number',
			default: 1,
			min: 1,
			max: 1000,
			step: 1,
			decimal: false,
			help: 'Use this for several identical devices.'
		}
	],
	calculate(v): CalculationResult {
		const watts = Number(v.power);
		const hours = Number(v.hours);
		const days = Number(v.days);
		const price = Number(v.price);
		const quantity = Number(v.quantity);

		if (!(watts >= 0) || !Number.isFinite(watts)) return invalid('Enter the device power in watts, 0 or more.');
		if (!(hours >= 0 && hours <= 24)) return invalid('Enter the hours used per day, from 0 to 24.');
		if (!Number.isInteger(days) || days < 1 || days > 31) return invalid('Enter the days used per month, from 1 to 31.');
		if (!(price >= 0) || !Number.isFinite(price)) return invalid('Enter a price per kWh of 0 or more.');
		if (!Number.isInteger(quantity) || quantity < 1) return invalid('Enter a whole number of devices, 1 or more.');

		// kWh = watts × hours ÷ 1,000, for every device.
		const kwhDay = (watts * hours * quantity) / 1000;
		const kwhMonth = kwhDay * days;
		const kwhYear = kwhDay * DAYS_PER_YEAR;
		const costDay = kwhDay * price;
		const costMonth = kwhMonth * price;
		const costYear = kwhYear * price;

		return {
			primaryResult: money(costMonth),
			primaryLabel: 'Monthly cost',
			summary: `Covers ${plural(quantity, 'device')}, ${num(hours, 1)} hours a day, for ${plural(days, 'day')} at ${money(price)} per kWh.`,
			secondaryMetrics: [
				{ label: 'Energy per day', value: `${num(kwhDay, 2)} kWh` },
				{ label: 'Energy per month', value: `${num(kwhMonth, 1)} kWh` },
				{ label: 'Energy per year', value: `${num(kwhYear, 0)} kWh` },
				{ label: 'Cost per day', value: money(costDay) },
				{ label: 'Cost per year', value: money(costYear) }
			]
		};
	},
	content: {
		intro:
			'Work out what a device costs to run each day, month and year, in kilowatt-hours (kWh) and in money, from its power rating and how long you use it.',
		howTo: [
			'Enter the device power in watts. Check the label or the power adapter.',
			'Enter the hours it runs per day, and the number of days per month.',
			'Enter your price per kWh from your electricity bill, and the number of identical devices.',
			'Read the monthly cost, then the yearly energy and cost.'
		],
		formulas: [
			{
				title: 'Energy per day',
				expression: 'kWh per day = watts × hours per day ÷ 1,000 × devices',
				variables: [
					{ symbol: 'kWh', meaning: 'Kilowatt-hour, the unit your electricity supplier bills' },
					{ symbol: 'watts', meaning: 'Power rating of the device' }
				]
			},
			{
				title: 'Energy per month and year',
				expression: 'kWh per month = kWh per day × days per month\nkWh per year = kWh per day × 365',
				variables: []
			},
			{
				title: 'Cost',
				expression: 'Cost = kWh × price per kWh',
				variables: [{ symbol: 'price', meaning: 'Your electricity rate, from the bill' }]
			}
		],
		example: {
			title: 'A 100 W device used for 8 hours a day at $0.17 per kWh',
			steps: [
				'Energy per day: 100 × 8 ÷ 1,000 = 0.8 kWh',
				'Energy per month: 0.8 × 30 = 24 kWh',
				'Monthly cost: 24 × $0.17 = $4.08',
				'Energy per year: 0.8 × 365 = 292 kWh',
				'Yearly cost: 292 × $0.17 = $49.64'
			],
			result: 'The device costs about $4.08 a month, or $49.64 a year.'
		},
		faq: [
			{
				q: 'Where do I find my price per kWh?',
				a: 'Look at the rate on your electricity bill. Some plans charge different rates at different times of day, so use an average if your rate changes.'
			},
			{
				q: 'How do I find a device’s wattage?',
				a: 'Check the label or the power adapter. Some labels show only volts and amps. Multiply them together to get watts.'
			},
			{
				q: 'Does standby use count?',
				a: 'Yes, if you include it. Enter the standby watts and the hours it stays in standby. Standby power is small, but it adds up over a year.'
			}
		]
	}
});
