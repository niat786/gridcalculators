import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './horsepower-calculator.meta';

const isLbFt = (v: InputValues) => v.torqueUnit !== 'nm';
const isNm = (v: InputValues) => v.torqueUnit === 'nm';

/** 1 lb·ft expressed in N·m. */
const NM_PER_LBFT = 1.3558179483;
/** 1 metric horsepower (PS) is 735.49875 W. */
const WATTS_PER_PS = 735.49875;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'torqueUnit',
			label: 'Torque unit',
			type: 'select',
			display: 'segmented',
			default: 'lbft',
			options: [
				{ label: 'Pound-feet (lb·ft)', value: 'lbft' },
				{ label: 'Newton-metres (N·m)', value: 'nm' }
			]
		},
		{ id: 'torqueLbft', label: 'Torque', type: 'number', default: 300, min: 0, max: 5000, step: 1, suffix: 'lb·ft', visibleWhen: isLbFt },
		{ id: 'torqueNm', label: 'Torque', type: 'number', default: 407, min: 0, max: 6800, step: 1, suffix: 'N·m', visibleWhen: isNm },
		{ id: 'rpm', label: 'Engine speed', type: 'number', default: 5000, min: 1, max: 30000, step: 10, suffix: 'rpm', decimal: false },
		{
			id: 'outUnit',
			label: 'Show power in',
			type: 'select',
			display: 'segmented',
			default: 'hp',
			options: [
				{ label: 'hp', value: 'hp' },
				{ label: 'PS', value: 'ps' },
				{ label: 'kW', value: 'kw' }
			]
		}
	],
	calculate(v): CalculationResult {
		const fromNm = isNm(v);
		const torque = Number(fromNm ? v.torqueNm : v.torqueLbft);
		const rpm = Number(v.rpm);
		if (!(torque > 0) || !(rpm > 0)) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Power',
				summary: 'Enter a torque and an engine speed, both above zero.'
			};
		}
		const torqueLbFt = fromNm ? torque / NM_PER_LBFT : torque;
		const torqueNm = fromNm ? torque : torque * NM_PER_LBFT;

		const hp = (torqueLbFt * rpm) / 5252;
		const kw = (torqueNm * rpm) / 9549;
		const ps = (kw * 1000) / WATTS_PER_PS;

		const shown =
			v.outUnit === 'ps' ? `${num(ps, 1, 1)} PS` : v.outUnit === 'kw' ? `${num(kw, 1, 1)} kW` : `${num(hp, 1, 1)} hp`;

		return {
			primaryResult: shown,
			primaryLabel: 'Engine power',
			summary: `${num(torqueLbFt, 1, 1)} lb·ft at ${num(rpm, 0)} rpm.`,
			secondaryMetrics: [
				{ label: 'Horsepower (hp)', value: `${num(hp, 1, 1)} hp` },
				{ label: 'Metric horsepower (PS)', value: `${num(ps, 1, 1)} PS` },
				{ label: 'Kilowatts (kW)', value: `${num(kw, 1, 1)} kW` },
				{
					label: fromNm ? 'Torque in lb·ft' : 'Torque in N·m',
					value: fromNm ? `${num(torqueLbFt, 1, 1)} lb·ft` : `${num(torqueNm, 1, 1)} N·m`
				}
			]
		};
	},
	content: {
		intro:
			'Work out engine power from torque and engine speed, and convert it between horsepower (hp), metric horsepower (PS) and kilowatts (kW). Use it when a spec sheet gives torque and rpm but not power.',
		howTo: [
			'Choose the torque unit, lb·ft or N·m.',
			'Enter the torque and the engine speed in rpm.',
			'Choose the unit to show the power in: hp, PS or kW.',
			'Read the power in all three units, and the torque in the other unit.'
		],
		formulas: [
			{
				title: 'Horsepower from torque (lb·ft)',
				expression: 'hp = torque (lb·ft) × rpm ÷ 5252',
				variables: [
					{ symbol: 'hp', meaning: 'mechanical horsepower' },
					{ symbol: '5252', meaning: '33,000 ÷ 2π, which converts lb·ft and rpm to hp' }
				]
			},
			{
				title: 'Kilowatts from torque (N·m)',
				expression: 'kW = torque (N·m) × rpm ÷ 9549',
				variables: [{ symbol: '9549', meaning: '60,000 ÷ 2π, which converts N·m and rpm to kW' }]
			},
			{
				title: 'Metric horsepower',
				expression: 'PS = kW × 1000 ÷ 735.49875',
				variables: [{ symbol: 'PS', meaning: 'metric horsepower (Pferdestärke), where 1 PS = 735.5 W' }]
			}
		],
		example: {
			title: '300 lb·ft of torque at 5,000 rpm',
			steps: [
				'Multiply torque by speed: 300 × 5,000 = 1,500,000',
				'Divide by 5,252: 1,500,000 ÷ 5,252 = 285.6 hp',
				'Convert to kilowatts: 285.6 × 0.7457 = 213.0 kW'
			],
			result: '285.6 hp, which is 213.0 kW.'
		},
		faq: [
			{
				q: 'What is the difference between hp and PS?',
				a: 'Mechanical horsepower (hp) is 745.7 watts. Metric horsepower (PS, from the German Pferdestärke) is 735.5 watts, so 1 PS is about 0.986 hp. Europe and Japan often quote power in PS.'
			},
			{
				q: 'Why is the constant 5252?',
				a: 'It is 33,000 divided by 2π. Horsepower is defined as 33,000 foot-pounds per minute, and an engine turns once per 2π radians, so torque in lb·ft times rpm, divided by 5252, gives hp.'
			},
			{
				q: 'Is torque or horsepower more important?',
				a: 'Torque is the twisting force, and horsepower is torque multiplied by speed. Torque gets a vehicle moving from a stop, while horsepower mainly sets the top speed.'
			},
			{
				q: 'Does this give the power at the wheels?',
				a: 'No. It gives the power the torque figure implies at the engine speed you enter. Drivetrain losses mean the power at the wheels is lower.'
			}
		]
	}
});
