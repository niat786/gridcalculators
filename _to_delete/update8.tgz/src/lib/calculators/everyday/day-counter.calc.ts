import { defineCalculator, type CalculationResult } from '../types';
import { DASH, num, plural } from '../format';
import meta from './day-counter.meta';

const DAY = 86_400_000;

/** A UTC calendar date. setUTCFullYear keeps years 0–99 literal (Date.UTC would map them to 1900+). */
function utcDate(y: number, m0: number, d: number): Date {
	const x = new Date(0);
	x.setUTCFullYear(y, m0, d);
	return x;
}

/** Parse YYYY-MM-DD as a UTC date. Null when the text is not a real calendar date. */
export function parseISODate(s: string): Date | null {
	const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
	if (!m) return null;
	const y = +m[1];
	const d = utcDate(y, +m[2] - 1, +m[3]);
	if (y < 1 || d.getUTCMonth() !== +m[2] - 1 || d.getUTCDate() !== +m[3]) return null;
	return d;
}

function addMonths(date: Date, n: number): Date {
	const total = date.getUTCFullYear() * 12 + date.getUTCMonth() + n;
	const y = Math.floor(total / 12);
	const m0 = total - y * 12;
	const d = Math.min(date.getUTCDate(), utcDate(y, m0 + 1, 0).getUTCDate());
	return utcDate(y, m0, d);
}

/** Whole calendar months from `from` to `to`, then the leftover days. Requires from <= to. */
export function monthsAndDays(from: Date, to: Date): { months: number; days: number } {
	let months = (to.getUTCFullYear() - from.getUTCFullYear()) * 12 + (to.getUTCMonth() - from.getUTCMonth());
	while (months > 0 && addMonths(from, months) > to) months -= 1;
	const days = Math.round((to.getTime() - addMonths(from, months).getTime()) / DAY);
	return { months, days };
}

/** Weekdays (Mon–Fri) among the `days` dates that start at `from`. The date after the last one is not counted. */
export function weekdaysIn(from: Date, days: number): number {
	const full = Math.floor(days / 7) * 5; // any seven consecutive days hold five weekdays
	const startDow = from.getUTCDay();
	let extra = 0;
	for (let i = 0; i < days % 7; i++) {
		const dow = (startDow + i) % 7;
		if (dow >= 1 && dow <= 5) extra++;
	}
	return full + extra;
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'start', label: 'Start date', type: 'date', default: '2026-01-01' },
		{ id: 'end', label: 'End date', type: 'date', default: 'today' },
		{
			id: 'includeEnd',
			label: 'Include the end day',
			type: 'toggle',
			default: false,
			help: 'Count the end date as a full day.'
		}
	],
	calculate(v): CalculationResult {
		const a = parseISODate(String(v.start));
		const b = parseISODate(String(v.end));
		if (!a || !b) {
			return { primaryResult: DASH, primaryLabel: 'Days between', summary: 'Enter two valid dates.' };
		}

		const include = v.includeEnd === true;
		const reversed = b < a;
		const from = reversed ? b : a;
		let to = reversed ? a : b;
		if (include) to = new Date(to.getTime() + DAY);

		const days = Math.round((to.getTime() - from.getTime()) / DAY);
		const weeks = Math.floor(days / 7);
		const { months, days: leftover } = monthsAndDays(from, to);
		const business = weekdaysIn(from, days);

		const direction = reversed ? 'The end date is before the start date, so the count runs backwards. ' : '';
		const edge = include ? 'Both the start and end days are counted.' : 'The end day is not counted.';

		return {
			primaryResult: plural(days, 'day'),
			primaryLabel: 'Days between',
			summary: `${direction}${edge}`,
			secondaryMetrics: [
				{ label: 'Weeks and days', value: `${plural(weeks, 'week')} and ${plural(days % 7, 'day')}` },
				{ label: 'Months and days (calendar)', value: `${plural(months, 'month')} and ${plural(leftover, 'day')}` },
				{ label: 'Business days (Mon–Fri)', value: num(business, 0) },
				{ label: 'Hours', value: num(days * 24, 0) }
			]
		};
	},
	content: {
		intro:
			'Count the days between two dates, then see the same span as weeks, calendar months, business days and hours.',
		howTo: [
			'Enter the start date.',
			'Enter the end date. It defaults to today.',
			'Turn on “Include the end day” to count both dates as full days.',
			'Read the days between first, then the other breakdowns.'
		],
		formulas: [
			{
				title: 'Days between',
				expression: 'Days = end date − start date, in whole days (+1 when the end day is included)',
				variables: []
			},
			{
				title: 'Weeks and days',
				expression: 'Weeks = ⌊days ÷ 7⌋, and the remaining days = days mod 7',
				variables: []
			},
			{
				title: 'Months and days',
				expression:
					'Months = the most whole calendar months that fit between the dates. Days = what is left over after those months.',
				variables: []
			},
			{
				title: 'Business days',
				expression: 'Count the Monday-to-Friday days in the span. The end date is left out unless it is included.',
				variables: []
			},
			{
				title: 'Hours',
				expression: 'Hours = days × 24',
				variables: []
			}
		],
		example: {
			title: 'From 1 January 2026 to 15 March 2026',
			steps: [
				'Days: 31 (rest of January) + 28 (February) + 14 (March) = 73 days.',
				'Weeks: ⌊73 ÷ 7⌋ = 10 weeks, and 73 mod 7 = 3 days.',
				'Months: 1 January + 2 months = 1 March, and 1 March + 14 days = 15 March, so 2 months and 14 days.',
				'Business days: 52 Monday-to-Friday days fall before 15 March.',
				'Hours: 73 × 24 = 1,752.'
			],
			result: '73 days (10 weeks and 3 days). Including the end day gives 74 days.'
		},
		faq: [
			{
				q: 'Is the end date included?',
				a: 'Not by default. From 1 March to 2 March is 1 day. Turn on “Include the end day” to count both dates, which makes that range 2 days.'
			},
			{
				q: 'How are calendar months counted?',
				a: 'Whole months are counted forward from the start date, the way a calendar counts them. From 1 January to 1 March is 2 months, and any days left over are shown separately.'
			},
			{
				q: 'Do business days skip public holidays?',
				a: 'No. Only Saturdays and Sundays are skipped. If you need a working-day count that excludes holidays, subtract those dates yourself.'
			}
		]
	}
});
