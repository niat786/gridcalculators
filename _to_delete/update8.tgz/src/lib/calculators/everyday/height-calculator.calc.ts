import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './height-calculator.meta';

const metric = (v: InputValues) => v.units === 'metric';
const imperial = (v: InputValues) => v.units === 'imperial';

/** Mid-parental method: add 13 cm for a boy, subtract 13 cm for a girl, then average the parents. */
export const SEX_OFFSET_CM = 13;
/** Target range: the prediction plus or minus this many cm. */
export const RANGE_CM = 8.5;

/** Feet and inches text, e.g. "5 ft 10.5 in", from centimetres. */
export function feetInches(cm: number): string {
	const tenths = Math.round((cm / 2.54) * 10);
	const ft = Math.floor(tenths / 120);
	const rem = tenths - ft * 120;
	return `${ft} ft ${num(rem / 10, 1, 0)} in`;
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'metric',
			options: [
				{ label: 'Metric (cm)', value: 'metric' },
				{ label: 'Imperial (ft, in)', value: 'imperial' }
			]
		},
		{
			id: 'sex',
			label: "Child's sex",
			type: 'select',
			display: 'segmented',
			default: 'boy',
			options: [
				{ label: 'Boy', value: 'boy' },
				{ label: 'Girl', value: 'girl' }
			]
		},
		{ id: 'fatherCm', label: "Father's height", type: 'number', default: 180, min: 120, max: 230, step: 0.1, suffix: 'cm', visibleWhen: metric },
		{ id: 'motherCm', label: "Mother's height", type: 'number', default: 165, min: 120, max: 230, step: 0.1, suffix: 'cm', visibleWhen: metric },
		{ id: 'fatherFt', label: "Father's height (feet)", type: 'number', default: 5, min: 4, max: 7, step: 1, suffix: 'ft', decimal: false, width: 'half', visibleWhen: imperial },
		{ id: 'fatherIn', label: "Father's height (inches)", type: 'number', default: 11, min: 0, max: 11.9, step: 0.1, suffix: 'in', width: 'half', visibleWhen: imperial },
		{ id: 'motherFt', label: "Mother's height (feet)", type: 'number', default: 5, min: 4, max: 7, step: 1, suffix: 'ft', decimal: false, width: 'half', visibleWhen: imperial },
		{ id: 'motherIn', label: "Mother's height (inches)", type: 'number', default: 5, min: 0, max: 11.9, step: 0.1, suffix: 'in', width: 'half', visibleWhen: imperial }
	],
	calculate(v): CalculationResult {
		const parentCm = (p: 'father' | 'mother') =>
			v.units === 'metric'
				? Number(v[`${p}Cm`])
				: (Number(v[`${p}Ft`]) * 12 + Number(v[`${p}In`])) * 2.54;
		const father = parentCm('father');
		const mother = parentCm('mother');
		const invalid: CalculationResult = {
			primaryResult: DASH,
			primaryLabel: 'Predicted adult height',
			summary: "Enter both parents' heights."
		};
		if (!(father > 0) || !(mother > 0)) return invalid;

		const isBoy = v.sex === 'boy';
		const offset = isBoy ? SEX_OFFSET_CM : -SEX_OFFSET_CM;
		const mid = (father + mother + offset) / 2;
		const low = mid - RANGE_CM;
		const high = mid + RANGE_CM;
		const shown = v.units === 'imperial' ? feetInches(mid) : `${num(mid, 0)} cm`;

		return {
			primaryResult: shown,
			primaryLabel: 'Predicted adult height',
			summary:
				'This is a population average, and genetics explain only part of final height. Read it as a target range.',
			secondaryMetrics: [
				{ label: 'Target range', value: `${num(low, 1, 1)} to ${num(high, 1, 1)} cm` },
				{ label: 'Target range (ft, in)', value: `${feetInches(low)} to ${feetInches(high)}` },
				{ label: 'Average of the two parents', value: `${num((father + mother) / 2, 1, 1)} cm` },
				{ label: 'Sex adjustment applied', value: `${isBoy ? '+' : '−'}${num(SEX_OFFSET_CM / 2, 1, 1)} cm` }
			]
		};
	},
	content: {
		intro:
			"Estimate a child's likely adult height from the heights of both parents, using the mid-parental height method. The answer is a target range, not a forecast.",
		howTo: [
			'Choose metric or imperial units, then choose whether the child is a boy or a girl.',
			"Enter the father's height and the mother's height.",
			'Read the predicted adult height and the target range around it.'
		],
		formulas: [
			{
				title: 'Boys',
				expression: '(father’s height + mother’s height + 13 cm) ÷ 2',
				variables: [
					{ symbol: 'father’s height', meaning: "The father's height in cm" },
					{ symbol: 'mother’s height', meaning: "The mother's height in cm" }
				]
			},
			{
				title: 'Girls',
				expression: '(father’s height + mother’s height − 13 cm) ÷ 2',
				variables: [{ symbol: '13 cm', meaning: 'The average difference in adult height between men and women, split across both parents' }]
			},
			{
				title: 'Target range',
				expression: 'predicted height ± 8.5 cm',
				variables: [{ symbol: '8.5 cm', meaning: 'The published half-width of the target range for the method' }]
			}
		],
		example: {
			title: 'A boy whose father is 180 cm and mother is 165 cm tall',
			steps: [
				'Add the parents and the adjustment: 180 + 165 + 13 = 358',
				'Divide by 2: 358 ÷ 2 = 179 cm',
				'Range: 179 − 8.5 = 170.5 cm to 179 + 8.5 = 187.5 cm'
			],
			result: 'Predicted adult height is 179 cm (about 5 ft 10.5 in), with a target range of 170.5 to 187.5 cm.'
		},
		faq: [
			{
				q: 'How accurate is this height predictor?',
				a: 'The target range is about 8.5 cm either side of the prediction. Many children finish within it, but some finish outside it, so treat the result as a rough guide.'
			},
			{
				q: 'Do genes decide a child’s height?',
				a: 'Genes explain only part of height. Nutrition, illness, sleep, hormones and the timing of puberty also play a part, which is why a prediction from parents can miss.'
			},
			{
				q: 'Should I use this instead of a growth chart?',
				a: 'No. A pediatrician plots a child’s height over time on the CDC growth charts, which compare the child with others of the same age and sex. The growth pattern shows more than any single prediction.'
			},
			{
				q: 'Why add or subtract 13 cm?',
				a: 'On average, adult men are taller than adult women. The method adds 13 cm for a boy and subtracts 13 cm for a girl, then averages the two parents, so each parent contributes half of the difference.'
			}
		],
		sources: [
			{ title: 'CDC — Growth Charts', url: 'https://www.cdc.gov/growthcharts/' },
			{ title: 'American Academy of Pediatrics — HealthyChildren.org', url: 'https://www.healthychildren.org/' }
		],
		disclaimer:
			'This is an estimate for planning and curiosity only. Ask a pediatrician if you are worried about a child’s growth.'
	}
});
