import { defineCalculator, type CalculationResult } from '../types';
import { DASH, num, plural } from '../format';
import meta from './age-calculator.meta';

const DAY = 86_400_000;

/** Parse YYYY-MM-DD as a UTC date (no time-zone drift). */
export function parseISODate(s: string): Date | null {
	const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
	if (!m) return null;
	const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
	return d.getUTCMonth() === +m[2] - 1 ? d : null;
}

function daysInMonth(y: number, m: number): number {
	return new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
}

/** Calendar difference: whole years, then months, then days (borrowing from the prior month). */
export function ageParts(from: Date, to: Date) {
	let y = to.getUTCFullYear() - from.getUTCFullYear();
	let m = to.getUTCMonth() - from.getUTCMonth();
	let d = to.getUTCDate() - from.getUTCDate();
	if (d < 0) {
		m -= 1;
		const pm = (to.getUTCMonth() + 11) % 12;
		const py = pm === 11 ? to.getUTCFullYear() - 1 : to.getUTCFullYear();
		d += daysInMonth(py, pm);
	}
	if (m < 0) {
		y -= 1;
		m += 12;
	}
	return { y, m, d };
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'dob', label: 'Date of birth', type: 'date', default: '1990-05-15' },
		{ id: 'on', label: 'Age on', type: 'date', default: 'today', help: 'Defaults to today' }
	],
	calculate(v): CalculationResult {
		const from = parseISODate(String(v.dob));
		const to = parseISODate(String(v.on));
		if (!from || !to) return { primaryResult: DASH, primaryLabel: 'Age', summary: 'Enter two valid dates.' };
		if (to < from) return { primaryResult: DASH, primaryLabel: 'Age', summary: 'The second date is before the date of birth.' };

		const { y, m, d } = ageParts(from, to);
		const days = Math.round((to.getTime() - from.getTime()) / DAY);

		// Next birthday (Feb 29 birthdays fall on Mar 1 in non-leap years)
		let next = new Date(Date.UTC(to.getUTCFullYear(), from.getUTCMonth(), from.getUTCDate()));
		if (next <= to) next = new Date(Date.UTC(to.getUTCFullYear() + 1, from.getUTCMonth(), from.getUTCDate()));
		const untilNext = Math.round((next.getTime() - to.getTime()) / DAY);

		return {
			primaryResult: plural(y, 'year'),
			primaryLabel: 'Age',
			summary: `${plural(y, 'year')}, ${plural(m, 'month')} and ${plural(d, 'day')}.`,
			secondaryMetrics: [
				{ label: 'In months', value: num(y * 12 + m, 0) },
				{ label: 'In weeks', value: num(Math.floor(days / 7), 0) },
				{ label: 'In days', value: num(days, 0) },
				{ label: 'Next birthday', value: untilNext === 0 ? 'Today' : `In ${plural(untilNext, 'day')}` }
			]
		};
	},
	content: {
		intro: 'Find your exact age, or the time between any two dates, in years, months and days.',
		howTo: ['Enter a date of birth.', 'Leave the second date as today, or pick another date.', 'Read the age and the totals.'],
		formulas: [
			{
				expression: 'Age = (end year − birth year), minus 1 if the birthday hasn’t happened yet that year',
				variables: []
			},
			{
				expression: 'Remaining months and days are counted on the calendar, borrowing the length of the previous month when needed.',
				variables: []
			}
		],
		example: {
			title: 'Born 15 May 1990, age on 28 October 2026',
			steps: [
				'Years: 2026 − 1990 = 36 (the birthday in May has passed)',
				'Months: October − May = 5',
				'Days: 28 − 15 = 13'
			],
			result: 'Age: 36 years, 5 months and 13 days.'
		},
		faq: [
			{
				q: 'How is age calculated?',
				a: 'Age is the number of full years since the date of birth. A year only counts once the birthday has passed in the current year.'
			},
			{
				q: 'How are leap-year birthdays handled?',
				a: 'If you were born on 29 February, the next birthday in a non-leap year is counted as 1 March.'
			},
			{
				q: 'Is my date of birth sent anywhere?',
				a: 'No. The calculation runs entirely in your browser and nothing is sent to our servers. The dates are kept in the page address so you can bookmark or share the result.'
			}
		]
	}
});
