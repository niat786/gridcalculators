import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './speed-calculator.meta';

type DistUnit = 'km' | 'mi' | 'm';
type SpeedUnit = 'km/h' | 'mph' | 'm/s' | 'knots';

/** Metres in one distance unit. */
const METRES: Record<DistUnit, number> = { km: 1000, mi: 1609.344, m: 1 };
/** Metres per second in one speed unit. A knot is 1,852 m per hour. */
const MPS: Record<SpeedUnit, number> = { 'km/h': 1000 / 3600, mph: 0.44704, 'm/s': 1, knots: 1852 / 3600 };

/** Whole seconds to h:mm:ss. */
export function hms(seconds: number): string {
	const total = Math.round(seconds);
	const h = Math.floor(total / 3600);
	const m = Math.floor((total % 3600) / 60);
	const s = total % 60;
	return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

const fail = (summary: string): CalculationResult => ({
	primaryResult: DASH,
	primaryLabel: 'Result',
	summary
});

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'solve',
			label: 'Solve for',
			type: 'select',
			default: 'speed',
			display: 'menu',
			options: [
				{ label: 'Speed', value: 'speed' },
				{ label: 'Distance', value: 'distance' },
				{ label: 'Time', value: 'time' }
			]
		},
		{
			id: 'distance',
			label: 'Distance',
			type: 'number',
			default: 150,
			min: 0,
			max: 1000000000,
			visibleWhen: (v) => v.solve !== 'distance'
		},
		{
			id: 'distUnit',
			label: 'Distance unit',
			type: 'select',
			default: 'km',
			display: 'segmented',
			options: [
				{ label: 'km', value: 'km' },
				{ label: 'mi', value: 'mi' },
				{ label: 'm', value: 'm' }
			]
		},
		{
			id: 'time',
			label: 'Time',
			type: 'duration',
			units: ['h', 'm', 's'],
			default: '2:30:0',
			visibleWhen: (v) => v.solve !== 'time',
			help: 'Hours, minutes and seconds.'
		},
		{
			id: 'speed',
			label: 'Speed',
			type: 'number',
			default: 60,
			min: 0,
			max: 1000000000,
			visibleWhen: (v) => v.solve !== 'speed'
		},
		{
			id: 'speedUnit',
			label: 'Speed unit',
			type: 'select',
			default: 'km/h',
			display: 'segmented',
			options: [
				{ label: 'km/h', value: 'km/h' },
				{ label: 'mph', value: 'mph' },
				{ label: 'm/s', value: 'm/s' },
				{ label: 'knots', value: 'knots' }
			]
		}
	],
	calculate(v: InputValues): CalculationResult {
		const solve = String(v.solve);
		const distUnit = String(v.distUnit) as DistUnit;
		const speedUnit = String(v.speedUnit) as SpeedUnit;
		if (!(distUnit in METRES) || !(speedUnit in MPS)) return fail('Pick a distance unit and a speed unit.');

		// Work in metres, metres per second and seconds, then convert for display.
		let metres: number;
		let mps: number;
		let seconds: number;
		if (solve === 'speed') {
			metres = Number(v.distance) * METRES[distUnit];
			seconds = Number(v.time);
			if (!(metres >= 0) || !(seconds > 0) || !Number.isFinite(metres) || !Number.isFinite(seconds)) {
				return fail('Enter a distance of zero or more, and a time above zero.');
			}
			mps = metres / seconds;
		} else if (solve === 'distance') {
			mps = Number(v.speed) * MPS[speedUnit];
			seconds = Number(v.time);
			if (!(mps >= 0) || !(seconds >= 0) || !Number.isFinite(mps) || !Number.isFinite(seconds)) {
				return fail('Enter a speed of zero or more, and a time.');
			}
			metres = mps * seconds;
		} else if (solve === 'time') {
			metres = Number(v.distance) * METRES[distUnit];
			mps = Number(v.speed) * MPS[speedUnit];
			if (!(metres >= 0) || !(mps > 0) || !Number.isFinite(metres) || !Number.isFinite(mps)) {
				return fail('Enter a distance of zero or more, and a speed above zero.');
			}
			seconds = metres / mps;
		} else {
			return fail('Pick speed, distance or time to solve for.');
		}

		const speedIn = (u: SpeedUnit) => num(mps / MPS[u], 2);
		const distance = metres / METRES[distUnit];
		const distanceText = `${num(distance, 2)} ${distUnit}`;
		const time = hms(seconds);

		const summary =
			solve === 'speed'
				? `Speed = distance ÷ time, using ${distanceText} in ${time}.`
				: solve === 'distance'
					? `Distance = speed × time, using ${speedIn(speedUnit)} ${speedUnit} for ${time}.`
					: `Time = distance ÷ speed, using ${distanceText} at ${speedIn(speedUnit)} ${speedUnit}.`;

		const primary =
			solve === 'speed'
				? { primaryResult: `${speedIn(speedUnit)} ${speedUnit}`, primaryLabel: 'Speed' }
				: solve === 'distance'
					? { primaryResult: distanceText, primaryLabel: 'Distance' }
					: { primaryResult: time, primaryLabel: 'Time (h:mm:ss)' };

		return {
			...primary,
			summary,
			secondaryMetrics: [
				{ label: 'Speed in km/h', value: speedIn('km/h') },
				{ label: 'Speed in mph', value: speedIn('mph') },
				{ label: 'Speed in m/s', value: speedIn('m/s') },
				{ label: 'Speed in knots', value: speedIn('knots') },
				{ label: 'Distance', value: distanceText },
				{ label: 'Time', value: time }
			]
		};
	},
	content: {
		intro:
			'Solve for speed, distance or time when you know the other two. Speed is shown in km/h, mph, m/s and knots, so you can compare figures from maps, cars, boats and planes.',
		howTo: [
			'Choose what you want to solve for: speed, distance or time.',
			'Enter the two values you know, and pick the distance unit and the speed unit.',
			'Enter time as hours, minutes and seconds. Leave a box empty to count it as zero.',
			'Read the main answer, then the speed in each unit below it.'
		],
		formulas: [
			{
				title: 'Speed',
				expression: 'Speed = distance ÷ time',
				variables: [{ symbol: 'speed', meaning: 'Distance covered per unit of time' }]
			},
			{
				title: 'Distance and time',
				expression: 'Distance = speed × time, and time = distance ÷ speed',
				variables: []
			},
			{
				title: 'Unit conversions',
				expression: '1 mi = 1.609344 km, 1 knot = 1.852 km/h, 1 m/s = 3.6 km/h, 1 mph = 1.609344 km/h',
				variables: []
			}
		],
		example: {
			title: '150 km in 2 hours 30 minutes',
			steps: [
				'Time = 2 h 30 min = 2.5 hours.',
				'Speed = 150 km ÷ 2.5 h = 60 km/h.',
				'In mph: 60 ÷ 1.609344 = 37.28 mph.',
				'In m/s: 150 000 m ÷ 9 000 s = 16.67 m/s.'
			],
			result: 'The speed is 60 km/h, or 37.28 mph, 16.67 m/s and 32.4 knots.'
		},
		faq: [
			{
				q: 'What is the formula for speed?',
				a: 'Speed equals distance divided by time. Travelling 150 km in 2.5 hours is an average speed of 60 km/h.'
			},
			{
				q: 'Is this average speed or instant speed?',
				a: 'It gives average speed over the whole trip. It does not show how fast you were going at any single moment.'
			},
			{
				q: 'How many km/h is a knot?',
				a: 'One knot is one nautical mile per hour, which is 1.852 km/h. Ships and aircraft use knots.'
			},
			{
				q: 'Can I enter the time in minutes only?',
				a: 'Yes. Leave hours and seconds empty, or enter 0 for them, and put the minutes in the middle box.'
			}
		]
	}
});
