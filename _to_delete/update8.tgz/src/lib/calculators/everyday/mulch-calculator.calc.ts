import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './mulch-calculator.meta';

const FT3_PER_YD3 = 27;
const SMALL_BAG_FT3 = 2;
const LARGE_BAG_FT3 = 3;

const isRect = (v: InputValues) => v.shape === 'rectangle';
const isCircle = (v: InputValues) => v.shape === 'circle';

const pos = (n: number) => Number.isFinite(n) && n > 0;

function invalid(summary: string): CalculationResult {
	return { primaryResult: DASH, primaryLabel: 'Mulch needed', summary };
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'shape',
			label: 'Shape',
			type: 'select',
			display: 'segmented',
			default: 'rectangle',
			options: [
				{ label: 'Rectangle', value: 'rectangle' },
				{ label: 'Circle', value: 'circle' }
			]
		},
		{ id: 'lenFt', label: 'Length', type: 'number', default: 20, min: 0.5, max: 1000, step: 0.5, suffix: 'ft', width: 'half', visibleWhen: isRect },
		{ id: 'widFt', label: 'Width', type: 'number', default: 15, min: 0.5, max: 1000, step: 0.5, suffix: 'ft', width: 'half', visibleWhen: isRect },
		{ id: 'diaFt', label: 'Diameter', type: 'number', default: 12, min: 0.5, max: 1000, step: 0.5, suffix: 'ft', visibleWhen: isCircle },
		{
			id: 'depthIn',
			label: 'Depth',
			type: 'number',
			default: 3,
			min: 0.5,
			max: 24,
			step: 0.5,
			suffix: 'in',
			help: 'Most beds use 2 to 3 inches of mulch.'
		},
		{
			id: 'price2',
			label: 'Price per 2 cu ft bag (optional)',
			type: 'number',
			default: 4.5,
			min: 0,
			max: 10000,
			step: 0.01,
			prefix: '$',
			suffix: '/bag',
			help: 'Set to 0 to leave out the cost.'
		},
		{
			id: 'price3',
			label: 'Price per 3 cu ft bag (optional)',
			type: 'number',
			default: 6.75,
			min: 0,
			max: 10000,
			step: 0.01,
			prefix: '$',
			suffix: '/bag',
			help: 'Set to 0 to leave out the cost.'
		}
	],
	calculate(v): CalculationResult {
		const rect = v.shape === 'rectangle';
		const len = Number(v.lenFt);
		const wid = Number(v.widFt);
		const dia = Number(v.diaFt);
		const depthIn = Number(v.depthIn);
		const price2 = Number(v.price2);
		const price3 = Number(v.price3);

		if (rect ? !pos(len) || !pos(wid) : !pos(dia)) {
			return invalid('Enter a length and width, or a diameter, greater than zero.');
		}
		if (!pos(depthIn)) return invalid('Enter a depth greater than zero.');
		if (!(price2 >= 0) || !(price3 >= 0)) return invalid('The price cannot be negative.');

		const area = rect ? len * wid : Math.PI * (dia / 2) ** 2;
		// Volume = area × depth. Depth is in inches, so divide by 12 to get feet.
		const volFt3 = area * (depthIn / 12);
		const volYd3 = volFt3 / FT3_PER_YD3;
		// A small epsilon stops exact multiples from adding an extra bag.
		const bags2 = Math.ceil(volFt3 / SMALL_BAG_FT3 - 1e-9);
		const bags3 = Math.ceil(volFt3 / LARGE_BAG_FT3 - 1e-9);

		return {
			primaryResult: `${num(volYd3, 2, 2)} cu yd`,
			primaryLabel: 'Mulch needed',
			summary: `Covers ${num(area, 1)} sq ft at ${num(depthIn, 1)} inches deep.`,
			secondaryMetrics: [
				{ label: 'Volume in cubic feet', value: `${num(volFt3, 2)} cu ft` },
				{ label: '2 cu ft bags', value: plural(bags2, 'bag') },
				{ label: '3 cu ft bags', value: plural(bags3, 'bag') },
				{ label: 'Cost with 2 cu ft bags', value: price2 > 0 ? money(bags2 * price2) : DASH },
				{ label: 'Cost with 3 cu ft bags', value: price3 > 0 ? money(bags3 * price3) : DASH }
			]
		};
	},
	content: {
		intro:
			'Work out how much mulch a bed, border or round planting ring needs, in cubic yards and cubic feet, with the number of 2 cu ft and 3 cu ft bags and an optional cost.',
		howTo: [
			'Choose a rectangle or a circle, then enter its length and width, or its diameter, in feet.',
			'Enter the depth you want in inches. Most beds use 2 to 3 inches.',
			'Optionally enter the price of each bag size to see the cost.',
			'Read the cubic yards to order in bulk, or the bag counts to buy by the bag.'
		],
		formulas: [
			{
				title: 'Area',
				expression: 'Rectangle: area = length × width\nCircle: area = π × (diameter ÷ 2)²',
				variables: [{ symbol: 'π', meaning: 'About 3.14159' }]
			},
			{
				title: 'Volume',
				expression: 'Volume in cu ft = area × depth in inches ÷ 12\nVolume in cu yd = cu ft ÷ 27',
				variables: [{ symbol: '27', meaning: 'Cubic feet in one cubic yard' }]
			},
			{
				title: 'Bags and cost',
				expression: 'Bags = volume in cu ft ÷ bag size, rounded up\nCost = bags × price per bag',
				variables: [{ symbol: 'bag size', meaning: 'Either 2 cu ft or 3 cu ft, as printed on the bag' }]
			}
		],
		example: {
			title: 'A 20 ft by 15 ft bed, 3 inches deep, with $4.50 and $6.75 bags',
			steps: [
				'Area: 20 × 15 = 300 sq ft',
				'Volume: 300 × (3 ÷ 12) = 75 cu ft, or 75 ÷ 27 = 2.78 cu yd',
				'2 cu ft bags: 75 ÷ 2 = 37.5, rounded up to 38 bags',
				'3 cu ft bags: 75 ÷ 3 = 25 bags',
				'Cost: 38 × $4.50 = $171.00, or 25 × $6.75 = $168.75'
			],
			result: 'Order about 2.78 cubic yards: 38 bags of 2 cu ft or 25 bags of 3 cu ft.'
		},
		faq: [
			{
				q: 'How deep should mulch be?',
				a: 'Most garden beds use 2 to 3 inches. Pull mulch back from plant stems and tree trunks so the wood does not stay wet.'
			},
			{
				q: 'Is it cheaper to buy mulch in bulk?',
				a: 'Often, for larger areas. Bulk mulch is sold by the cubic yard and usually costs less per unit of volume than bags. Bags are easier for small beds and for carrying.'
			},
			{
				q: 'Why does the calculator round the bag count up?',
				a: 'You cannot buy part of a bag, so any fraction of a bag needs a whole one. The count is rounded up to the next whole bag.'
			}
		]
	}
});
