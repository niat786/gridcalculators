import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, money, num } from '../format';
import meta from './gravel-calculator.meta';

/** 1 cubic yard = 0.764554858 cubic metres. */
const M3_PER_YD3 = 0.764554858;
const FT3_PER_YD3 = 27;

const pos = (n: number) => Number.isFinite(n) && n > 0;

const imperialRect = (v: InputValues) => v.units === 'imperial' && v.shape === 'rectangle';
const imperialCircle = (v: InputValues) => v.units === 'imperial' && v.shape === 'circle';
const metricRect = (v: InputValues) => v.units === 'metric' && v.shape === 'rectangle';
const metricCircle = (v: InputValues) => v.units === 'metric' && v.shape === 'circle';
const imperial = (v: InputValues) => v.units === 'imperial';
const metric = (v: InputValues) => v.units === 'metric';

function invalid(summary: string): CalculationResult {
	return { primaryResult: DASH, primaryLabel: 'Gravel needed', summary };
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'shape',
			label: 'Shape',
			type: 'select',
			display: 'segmented',
			default: 'rectangle',
			options: [
				{ label: 'Rectangle', value: 'rectangle' },
				{ label: 'Circle', value: 'circle' }
			]
		},
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'imperial',
			options: [
				{ label: 'Feet and inches', value: 'imperial' },
				{ label: 'Metric (m, cm)', value: 'metric' }
			]
		},
		// Feet and inches: rectangle
		{ id: 'lenFt', label: 'Length (feet)', type: 'number', default: 20, min: 0, max: 1000, step: 1, suffix: 'ft', decimal: false, width: 'half', visibleWhen: imperialRect },
		{ id: 'lenIn', label: 'Length (inches)', type: 'number', default: 0, min: 0, max: 11.5, step: 0.5, suffix: 'in', width: 'half', visibleWhen: imperialRect },
		{ id: 'widFt', label: 'Width (feet)', type: 'number', default: 10, min: 0, max: 1000, step: 1, suffix: 'ft', decimal: false, width: 'half', visibleWhen: imperialRect },
		{ id: 'widIn', label: 'Width (inches)', type: 'number', default: 0, min: 0, max: 11.5, step: 0.5, suffix: 'in', width: 'half', visibleWhen: imperialRect },
		// Feet and inches: circle
		{ id: 'diaFt', label: 'Diameter (feet)', type: 'number', default: 10, min: 0, max: 1000, step: 1, suffix: 'ft', decimal: false, width: 'half', visibleWhen: imperialCircle },
		{ id: 'diaIn', label: 'Diameter (inches)', type: 'number', default: 0, min: 0, max: 11.5, step: 0.5, suffix: 'in', width: 'half', visibleWhen: imperialCircle },
		// Metric: rectangle and circle
		{ id: 'lenM', label: 'Length', type: 'number', default: 6, min: 0, max: 1000, step: 0.1, suffix: 'm', width: 'half', visibleWhen: metricRect },
		{ id: 'widM', label: 'Width', type: 'number', default: 4, min: 0, max: 1000, step: 0.1, suffix: 'm', width: 'half', visibleWhen: metricRect },
		{ id: 'diaM', label: 'Diameter', type: 'number', default: 3, min: 0, max: 1000, step: 0.1, suffix: 'm', visibleWhen: metricCircle },
		// Depth
		{ id: 'depthIn', label: 'Depth', type: 'number', default: 3, min: 0.5, max: 36, step: 0.5, suffix: 'in', help: 'Two to four inches is common for paths and driveways.', visibleWhen: imperial },
		{ id: 'depthCm', label: 'Depth', type: 'number', default: 5, min: 0.5, max: 100, step: 0.5, suffix: 'cm', visibleWhen: metric },
		// Material and cost
		{
			id: 'densityTon',
			label: 'Density',
			type: 'number',
			default: 1.4,
			min: 0.1,
			max: 10,
			step: 0.01,
			suffix: 'tons/yd³',
			help: 'US tons of 2,000 lb. Check your supplier for their figure.',
			visibleWhen: imperial
		},
		{
			id: 'densityT',
			label: 'Density',
			type: 'number',
			default: 1.6,
			min: 0.1,
			max: 10,
			step: 0.01,
			suffix: 't/m³',
			help: 'Metric tonnes of 1,000 kg. Check your supplier for their figure.',
			visibleWhen: metric
		},
		{
			id: 'waste',
			label: 'Waste allowance',
			type: 'number',
			default: 10,
			min: 0,
			max: 50,
			step: 1,
			suffix: '%',
			help: 'Extra for spreading, settling and uneven ground.'
		},
		{
			id: 'priceTon',
			label: 'Price per ton (optional)',
			type: 'number',
			default: 40,
			min: 0,
			max: 100000,
			step: 0.01,
			prefix: '$',
			suffix: '/ton',
			help: 'Set to 0 to leave out the cost.',
			visibleWhen: imperial
		},
		{
			id: 'priceT',
			label: 'Price per tonne (optional)',
			type: 'number',
			default: 44,
			min: 0,
			max: 100000,
			step: 0.01,
			prefix: '$',
			suffix: '/tonne',
			help: 'Set to 0 to leave out the cost.',
			visibleWhen: metric
		}
	],
	calculate(v): CalculationResult {
		const isMetric = v.units === 'metric';
		const isRect = v.shape === 'rectangle';
		const waste = Number(v.waste);
		const density = Number(isMetric ? v.densityT : v.densityTon);
		const price = Number(isMetric ? v.priceT : v.priceTon);

		if (!Number.isFinite(waste) || waste < 0) return invalid('Enter a waste allowance of 0% or more.');
		if (!pos(density)) return invalid('Enter a density greater than zero.');
		if (!Number.isFinite(price) || price < 0) return invalid('The price cannot be negative.');

		// Volume before waste, in cubic metres and cubic yards.
		let volM3: number;
		let volYd3: number;
		if (isMetric) {
			const area = isRect ? Number(v.lenM) * Number(v.widM) : Math.PI * (Number(v.diaM) / 2) ** 2;
			const depth = Number(v.depthCm) / 100;
			const sizesOk = isRect ? pos(Number(v.lenM)) && pos(Number(v.widM)) : pos(Number(v.diaM));
			if (!sizesOk || !pos(depth)) return invalid('Enter sizes greater than zero for every dimension.');
			volM3 = area * depth;
			volYd3 = volM3 / M3_PER_YD3;
		} else {
			const len = Number(v.lenFt) + Number(v.lenIn) / 12;
			const wid = Number(v.widFt) + Number(v.widIn) / 12;
			const dia = Number(v.diaFt) + Number(v.diaIn) / 12;
			const area = isRect ? len * wid : Math.PI * (dia / 2) ** 2;
			const depthFt = Number(v.depthIn) / 12;
			const sizesOk = isRect ? pos(len) && pos(wid) : pos(dia);
			if (!sizesOk || !pos(depthFt)) return invalid('Enter sizes greater than zero for every dimension.');
			const volFt3 = area * depthFt;
			volYd3 = volFt3 / FT3_PER_YD3;
			volM3 = volYd3 * M3_PER_YD3;
		}

		const factor = 1 + waste / 100;
		const withWasteYd3 = volYd3 * factor;
		const withWasteM3 = volM3 * factor;
		// Weight is volume × density, in the matching unit: tons, or tonnes for metric.
		const weight = isMetric ? withWasteM3 * density : withWasteYd3 * density;
		const cost = weight * price;

		return {
			primaryResult: isMetric ? `${num(withWasteM3, 2, 2)} m³` : `${num(withWasteYd3, 2, 2)} cu yd`,
			primaryLabel: 'Gravel needed',
			summary: `Includes ${num(waste, 0)}% waste. Weight uses a density of ${num(density, 2, 2)} ${isMetric ? 't/m³' : 'tons/yd³'}.`,
			secondaryMetrics: [
				{ label: 'Volume before waste', value: `${num(volYd3, 2, 2)} cu yd (${num(volM3, 2, 2)} m³)` },
				{ label: 'Volume with waste', value: `${num(withWasteYd3, 2, 2)} cu yd (${num(withWasteM3, 2, 2)} m³)` },
				{ label: isMetric ? 'Weight in tonnes' : 'Weight in tons', value: `${num(weight, 2, 2)} ${isMetric ? 'tonnes' : 'tons'}` },
				{ label: 'Cost', value: price > 0 ? money(cost) : DASH }
			]
		};
	},
	content: {
		intro:
			'Estimate how much gravel or crushed stone a rectangular or round area needs, in cubic yards or cubic metres, with the weight in tons or tonnes and the cost.',
		howTo: [
			'Choose a rectangle or a circle, then pick feet and inches or metric.',
			'Enter the length and width, or the diameter, and the depth of the layer.',
			'Enter the density from your supplier, and a waste allowance. The default of 10% is a sensible margin.',
			'Optionally enter the price per ton or tonne to see the cost.'
		],
		formulas: [
			{
				title: 'Volume',
				expression: 'Rectangle: volume = length × width × depth\nCircle: volume = π × (diameter ÷ 2)² × depth',
				variables: [
					{ symbol: 'π', meaning: 'About 3.14159' },
					{ symbol: 'depth', meaning: 'Depth of the layer, in the same unit as the other dimensions' }
				]
			},
			{
				title: 'Waste, weight and cost',
				expression: 'Volume with waste = volume × (1 + waste % ÷ 100)\nWeight = volume with waste × density\nCost = weight × price per ton',
				variables: [{ symbol: 'density', meaning: 'Weight of one cubic yard (or cubic metre) of the gravel, from your supplier' }]
			},
			{
				title: 'Unit conversions',
				expression: '1 cubic yard = 27 cubic feet = 0.764555 m³',
				variables: []
			}
		],
		example: {
			title: 'A 20 ft by 10 ft area, 3 inches deep, at 1.4 tons per cubic yard, with 10% waste and $40 per ton',
			steps: [
				'Area: 20 × 10 = 200 sq ft. Depth: 3 ÷ 12 = 0.25 ft',
				'Volume: 200 × 0.25 = 50 cu ft, or 50 ÷ 27 = 1.852 cu yd',
				'With waste: 1.852 × 1.1 = 2.037 cu yd',
				'Weight: 2.037037 × 1.4 = 2.851852 tons',
				'Cost: 2.851852 × $40 = $114.07'
			],
			result: 'Order about 2.04 cubic yards, or 2.85 tons, for an estimated $114.07.'
		},
		faq: [
			{
				q: 'How much gravel do I need for a driveway?',
				a: 'Multiply the length, the width and the depth, converting the depth to the same unit. Two to four inches is a common depth for a gravel driveway, depending on the base and the traffic.'
			},
			{
				q: 'Are tons and tonnes the same?',
				a: 'No. A US ton is 2,000 lb, about 907 kg. A metric tonne is 1,000 kg. Check which one your supplier uses before you order.'
			},
			{
				q: 'Why should I add extra gravel?',
				a: 'Gravel settles into the base, spreads unevenly and gets lost at the edges. A 10% allowance covers most jobs, but add more for soft ground.'
			}
		]
	}
});
