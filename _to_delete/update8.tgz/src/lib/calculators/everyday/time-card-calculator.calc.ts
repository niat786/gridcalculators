import { defineCalculator, type CalculationResult, type InputValues, type RowValue } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './time-card-calculator.meta';

const MINUTES_PER_DAY = 1_440;
/** Hours after which each hour is paid at the overtime rate, in minutes. */
const OVERTIME_AFTER = 40 * 60;
const OVERTIME_MULTIPLIER = 1.5;

/** "HH:MM" (24-hour) to minutes after midnight. Null when the text is not a valid time. */
function minutesOf(s: string): number | null {
	const m = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(s.trim());
	return m ? +m[1] * 60 + +m[2] : null;
}

/** Minutes after midnight to "h:mm AM" / "h:mm PM". */
function clock12(total: number): string {
	const h24 = Math.floor(total / 60);
	const h = h24 % 12 || 12;
	return `${h}:${String(total % 60).padStart(2, '0')} ${h24 < 12 ? 'AM' : 'PM'}`;
}

/** Minutes to "h:mm". */
function hoursAndMinutes(total: number): string {
	return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
}

const fail = (summary: string): CalculationResult => ({
	primaryResult: DASH,
	primaryLabel: 'Total hours',
	summary
});

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'shifts',
			label: 'Shifts',
			type: 'rows',
			columns: [
				{ id: 'day', label: 'Day', type: 'text', default: 'Mon', placeholder: 'Day' },
				{ id: 'start', label: 'Start', type: 'text', default: '09:00', placeholder: 'HH:MM' },
				{ id: 'end', label: 'End', type: 'text', default: '17:00', placeholder: 'HH:MM' },
				{ id: 'breakMins', label: 'Break', type: 'number', default: 30, min: 0, max: MINUTES_PER_DAY, suffix: 'min' }
			],
			default: [
				{ day: 'Mon', start: '09:00', end: '17:00', breakMins: 30 },
				{ day: 'Tue', start: '09:00', end: '17:00', breakMins: 30 },
				{ day: 'Wed', start: '09:00', end: '17:00', breakMins: 30 },
				{ day: 'Thu', start: '09:00', end: '17:00', breakMins: 30 },
				{ day: 'Fri', start: '09:00', end: '17:00', breakMins: 30 }
			],
			minRows: 1,
			maxRows: 14,
			addLabel: 'Add shift',
			help: 'Times use 24-hour HH:MM. An end time earlier than the start is treated as an overnight shift.'
		},
		{
			id: 'rate',
			label: 'Hourly rate (optional)',
			type: 'number',
			default: 20,
			min: 0,
			max: 10000,
			prefix: '$',
			suffix: '/hour',
			help: 'Leave at 0 to skip pay. Hours over 40 a week are paid at 1.5 times this rate.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const shifts = (v.shifts as RowValue[]) ?? [];
		if (shifts.length === 0) return fail('Add at least one shift.');

		const rate = Number(v.rate);
		if (!Number.isFinite(rate) || rate < 0) return fail('Enter an hourly rate of zero or more.');

		let total = 0;
		const daily: Record<string, string>[] = [];
		for (let i = 0; i < shifts.length; i++) {
			const row = shifts[i];
			const day = String(row.day ?? '').trim();
			const label = `Row ${i + 1}${day ? ` (${day})` : ''}`;

			const start = minutesOf(String(row.start ?? ''));
			const end = minutesOf(String(row.end ?? ''));
			if (start === null || end === null) return fail(`Check ${label}: enter the start and end as HH:MM, such as 09:00.`);

			const brk = Number(row.breakMins);
			if (!Number.isInteger(brk) || brk < 0) return fail(`Check ${label}: enter the break as zero or more minutes.`);

			const span = (end < start ? end + MINUTES_PER_DAY : end) - start;
			const worked = span - brk;
			if (worked < 0) return fail(`Check ${label}: the break is longer than the shift.`);

			total += worked;
			daily.push({
				day: day || `Row ${i + 1}`,
				shift: `${clock12(start)} to ${clock12(end)}`,
				hours: hoursAndMinutes(worked)
			});
		}

		const regular = Math.min(total, OVERTIME_AFTER);
		const overtime = Math.max(0, total - OVERTIME_AFTER);
		const pay = rate * (regular / 60 + (overtime / 60) * OVERTIME_MULTIPLIER);

		const summary =
			overtime > 0
				? `${plural(shifts.length, 'shift')} totalling ${hoursAndMinutes(total)}, with ${hoursAndMinutes(overtime)} paid as overtime.`
				: `${plural(shifts.length, 'shift')} totalling ${hoursAndMinutes(total)}, all at the regular rate.`;

		return {
			primaryResult: hoursAndMinutes(total),
			primaryLabel: 'Total hours',
			summary,
			secondaryMetrics: [
				{ label: 'Decimal hours', value: num(total / 60, 2, 2) },
				{ label: 'Regular hours', value: hoursAndMinutes(regular) },
				{ label: 'Overtime hours', value: hoursAndMinutes(overtime) },
				{ label: 'Gross pay', value: rate > 0 ? money(pay) : 'Add an hourly rate' }
			],
			table: {
				title: 'Daily hours',
				columns: [
					{ key: 'day', label: 'Day' },
					{ key: 'shift', label: 'Shift' },
					{ key: 'hours', label: 'Hours', align: 'end' }
				],
				rows: daily,
				collapsed: false
			}
		};
	},
	content: {
		intro:
			'Add up the hours on a time card for one week. Enter each shift’s start time, end time and unpaid break, and the calculator totals the hours, splits out overtime and estimates gross pay.',
		howTo: [
			'Enter each shift’s day, start time and end time in 24-hour HH:MM format, such as 08:30 or 17:00.',
			'Enter the unpaid break for that shift in minutes, or 0 if there was none.',
			'Add a row for each shift you worked, or remove rows you did not work.',
			'Enter your hourly rate to see gross pay, or leave it at 0 to see hours only.'
		],
		formulas: [
			{
				title: 'Hours for one shift',
				expression: 'Worked minutes = (end − start) − break, with 24 hours added when the end is earlier than the start',
				variables: []
			},
			{
				title: 'Overtime split',
				expression: 'Regular hours = the first 40 hours. Overtime hours = total hours − 40, when the total is above 40.',
				variables: []
			},
			{
				title: 'Gross pay',
				expression: 'Pay = regular hours × rate + overtime hours × rate × 1.5',
				variables: [{ symbol: '1.5', meaning: 'Overtime multiplier' }]
			}
		],
		example: {
			title: 'Five 9 to 5 days with a 30-minute break, paid at $20 an hour',
			steps: [
				'Each day: 17:00 − 09:00 = 8 h, minus 30 min = 7 h 30 min.',
				'Total: 5 × 7 h 30 min = 37 h 30 min, which is 37.50 decimal hours.',
				'Under 40 hours, so no overtime. Pay = 37.5 × $20 = $750.00.'
			],
			result: 'Total 37:30 (37.50 hours), gross pay $750.00.'
		},
		faq: [
			{
				q: 'How is overtime calculated here?',
				a: 'Hours beyond 40 in the week are paid at 1.5 times your hourly rate. This matches the US federal rule for non-exempt workers. Some states and employers use daily overtime or other rules.'
			},
			{
				q: 'How do I enter a shift that runs past midnight?',
				a: 'Enter the real end time, such as 06:00. If the end time is earlier than the start time, the shift is counted as running into the next morning.'
			},
			{
				q: 'What is the difference between h:mm and decimal hours?',
				a: 'h:mm shows hours and minutes, so 7:30 is seven and a half hours. Decimal hours write the same time as a number, so 7:30 is 7.50. Payroll systems often use decimals.'
			},
			{
				q: 'Does this include taxes or deductions?',
				a: 'No. Gross pay is before tax, insurance and other deductions, so your take-home pay will be lower.'
			}
		],
		disclaimer:
			'Results are estimates for planning. Check your pay stub or your employer’s records for the amount you are actually paid.'
	}
});
