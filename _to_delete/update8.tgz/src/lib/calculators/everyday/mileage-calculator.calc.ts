import { defineCalculator, type CalculationResult, type InputValues, type RowValue } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './mileage-calculator.meta';

const fail = (summary: string): CalculationResult => ({
	primaryResult: DASH,
	primaryLabel: 'Reimbursement',
	summary
});

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Enter miles as',
			type: 'select',
			default: 'total',
			display: 'segmented',
			options: [
				{ label: 'Total miles', value: 'total' },
				{ label: 'Trip log', value: 'trips' }
			]
		},
		{
			id: 'miles',
			label: 'Business miles',
			type: 'number',
			default: 1250,
			min: 0,
			max: 100000000,
			suffix: 'miles',
			visibleWhen: (v) => v.mode !== 'trips'
		},
		{
			id: 'trips',
			label: 'Trips',
			type: 'rows',
			columns: [
				{ id: 'date', label: 'Date', type: 'text', default: '2026-02-03', placeholder: 'YYYY-MM-DD' },
				{ id: 'purpose', label: 'Purpose', type: 'text', default: 'Client visit', placeholder: 'Purpose' },
				{ id: 'miles', label: 'Miles', type: 'number', default: 12.5, min: 0, max: 100000, suffix: 'mi' }
			],
			default: [
				{ date: '2026-02-03', purpose: 'Client visit', miles: 12.5 },
				{ date: '2026-02-10', purpose: 'Supplier meeting', miles: 40 },
				{ date: '2026-02-17', purpose: 'Bank and post office', miles: 7.3 }
			],
			minRows: 1,
			maxRows: 200,
			addLabel: 'Add trip',
			visibleWhen: (v) => v.mode === 'trips'
		},
		{
			id: 'rate',
			label: 'Rate per mile',
			type: 'number',
			default: 0.725,
			min: 0,
			max: 5,
			decimal: true,
			prefix: '$',
			suffix: '/mile',
			help: 'Default is the US IRS 2026 business rate (72.5¢). Elsewhere, enter your tax authority’s rate (e.g. HMRC, CRA).'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const rate = Number(v.rate);
		if (!Number.isFinite(rate) || rate < 0) return fail('Enter a rate per mile of zero or more.');

		let total = 0;
		let trips: Record<string, string>[] | undefined;
		let tripCount: number | undefined;

		if (v.mode === 'trips') {
			const list = (v.trips as RowValue[]) ?? [];
			if (list.length === 0) return fail('Add at least one trip.');
			trips = [];
			for (let i = 0; i < list.length; i++) {
				const miles = Number(list[i].miles);
				if (!Number.isFinite(miles) || miles < 0) return fail(`Check trip ${i + 1}: enter miles as zero or more.`);
				total += miles;
				trips.push({
					date: String(list[i].date ?? '') || `Trip ${i + 1}`,
					purpose: String(list[i].purpose ?? ''),
					miles: num(miles, 2),
					amount: money(miles * rate)
				});
			}
			tripCount = list.length;
		} else {
			total = Number(v.miles);
			if (!Number.isFinite(total) || total < 0) return fail('Enter business miles of zero or more.');
		}

		const reimbursement = total * rate;
		const rateText = `$${num(rate, 3, 2)}`;

		return {
			primaryResult: money(reimbursement),
			primaryLabel: 'Reimbursement',
			summary: `${num(total, 2)} miles at ${rateText} per mile. Check the current IRS rate before you claim.`,
			secondaryMetrics: [
				{ label: 'Total miles', value: num(total, 2) },
				{ label: 'Rate per mile', value: rateText },
				{ label: 'Trips logged', value: tripCount === undefined ? 'Not used' : plural(tripCount, 'trip') }
			],
			...(trips
				? {
						table: {
							title: 'Trip log',
							columns: [
								{ key: 'date', label: 'Date' },
								{ key: 'purpose', label: 'Purpose' },
								{ key: 'miles', label: 'Miles', align: 'end' as const },
								{ key: 'amount', label: 'Amount', align: 'end' as const }
							],
							rows: trips,
							collapsed: false
						}
					}
				: {})
		};
	},
	content: {
		intro:
			'Work out how much your employer or tax return can reimburse for business driving. Enter total business miles, or log each trip, and the calculator multiplies the total by your rate per mile.',
		howTo: [
			'Choose Total miles to enter one figure, or Trip log to enter each trip’s date, purpose and miles.',
			'Enter the rate per mile. The default is the 2026 IRS standard business rate.',
			'Read the total miles and the reimbursement.',
			'Check irs.gov for the current rate if you are claiming for a different year.'
		],
		formulas: [
			{
				title: 'Total miles',
				expression: 'Total miles = sum of every trip’s miles',
				variables: [{ symbol: 'Σ', meaning: 'Add up every trip' }]
			},
			{
				title: 'Reimbursement',
				expression: 'Reimbursement = total miles × rate per mile',
				variables: [{ symbol: 'rate', meaning: 'The IRS standard mileage rate, or your agreed rate' }]
			}
		],
		example: {
			title: '1,250 business miles at the 2026 IRS rate',
			steps: ['Total miles: 1,250 business miles, entered as one figure.', 'Reimbursement = 1,250 × $0.725 = $906.25.'],
			result: '$906.25 for 1,250 miles.'
		},
		faq: [
			{
				q: 'What is the IRS standard mileage rate?',
				a: 'The IRS sets a standard rate per mile each year for business use of a car. It covers fuel, wear and running costs. The 2026 business rate is 72.5 cents per mile, as published on irs.gov.'
			},
			{
				q: 'What should a mileage log include?',
				a: 'Keep a record for each trip with the date, where you went, the business purpose and the miles driven. A log kept as you go is easier to support than one written later.'
			},
			{
				q: 'Does driving to my regular workplace count?',
				a: 'Usually not. Commuting between home and a regular workplace is generally personal, so it is not business mileage. Travel between work sites or to meet clients generally is.'
			},
			{
				q: 'Is the reimbursement taxable?',
				a: 'That depends on how your employer pays it and the rules that apply to you. Ask your employer or a tax adviser before you file.'
			}
		],
		sources: [{ title: 'IRS: 2026 business standard mileage rate is 72.5 cents per mile', url: 'https://www.irs.gov/newsroom/irs-sets-2026-business-standard-mileage-rate-at-725-cents-per-mile-up-25-cents' }],
		disclaimer: 'Mileage rates change each year. This is an estimate for planning, not tax advice.'
	}
});
