import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num, plural } from '../format';
import meta from './stair-calculator.meta';

const CM_PER_IN = 2.54;
/** IRC R311.7.5: a riser may be at most 7¾ in and a tread at least 10 in. */
const MAX_RISER_IN = 7.75;
const MIN_TREAD_IN = 10;
const EPS = 1e-9;

const fail = (summary: string): CalculationResult => ({
	primaryResult: DASH,
	primaryLabel: 'Number of risers',
	summary
});

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'unit',
			label: 'Units',
			type: 'select',
			default: 'in',
			display: 'segmented',
			options: [
				{ label: 'Inches', value: 'in' },
				{ label: 'Centimetres', value: 'cm' }
			]
		},
		{
			id: 'totalIn',
			label: 'Total rise',
			type: 'number',
			default: 108,
			min: 1,
			max: 2000,
			suffix: 'in',
			help: 'Height from the lower floor to the upper floor.',
			visibleWhen: (v) => v.unit !== 'cm'
		},
		{
			id: 'totalCm',
			label: 'Total rise',
			type: 'number',
			default: 274,
			min: 1,
			max: 5000,
			suffix: 'cm',
			help: 'Height from the lower floor to the upper floor.',
			visibleWhen: (v) => v.unit === 'cm'
		},
		{
			id: 'riserIn',
			label: 'Maximum riser height',
			type: 'number',
			default: 7.75,
			min: 1,
			max: 12,
			decimal: true,
			suffix: 'in',
			help: 'The tallest step you want. Sets the number of risers.',
			visibleWhen: (v) => v.unit !== 'cm'
		},
		{
			id: 'riserCm',
			label: 'Maximum riser height',
			type: 'number',
			default: 19.5,
			min: 1,
			max: 30,
			decimal: true,
			suffix: 'cm',
			help: 'The tallest step you want. Sets the number of risers.',
			visibleWhen: (v) => v.unit === 'cm'
		},
		{
			id: 'treadIn',
			label: 'Tread depth',
			type: 'number',
			default: 10,
			min: 1,
			max: 30,
			decimal: true,
			suffix: 'in',
			help: 'The depth of each step you walk on.',
			visibleWhen: (v) => v.unit !== 'cm'
		},
		{
			id: 'treadCm',
			label: 'Tread depth',
			type: 'number',
			default: 25.4,
			min: 1,
			max: 75,
			decimal: true,
			suffix: 'cm',
			help: 'The depth of each step you walk on.',
			visibleWhen: (v) => v.unit === 'cm'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const isCm = v.unit === 'cm';
		const scale = isCm ? CM_PER_IN : 1;
		const toIn = (x: InputValues[string]) => Number(x) / scale;
		const out = (inches: number) => inches * scale;
		const unit = isCm ? 'cm' : 'in';

		const rise = isCm ? toIn(v.totalCm) : toIn(v.totalIn);
		const maxRiser = isCm ? toIn(v.riserCm) : toIn(v.riserIn);
		const tread = isCm ? toIn(v.treadCm) : toIn(v.treadIn);
		if (![rise, maxRiser, tread].every((x) => Number.isFinite(x) && x > 0)) {
			return fail('Enter a total rise, a maximum riser height and a tread depth, all above zero.');
		}

		const risers = Math.ceil(rise / maxRiser - EPS);
		if (risers < 2) {
			return fail('The total rise fits in one riser, so there are no treads. Check the rise and the maximum riser.');
		}

		const treads = risers - 1;
		const riser = rise / risers;
		const run = treads * tread;
		const stringer = Math.hypot(rise, run);
		const angle = (Math.atan2(rise, run) * 180) / Math.PI;

		const riserOk = riser <= MAX_RISER_IN + EPS;
		const treadOk = tread >= MIN_TREAD_IN - EPS;
		const problems = [
			...(riserOk ? [] : [`the riser is over 7¾ in`]),
			...(treadOk ? [] : [`the tread is under 10 in`])
		];
		const summary =
			problems.length === 0
				? 'Each riser is 7¾ in or less and each tread is 10 in or more, which matches IRC R311.7.5. Local codes can differ.'
				: `This layout may not meet IRC R311.7.5: ${problems.join(' and ')}. Local codes can differ.`;

		return {
			primaryResult: plural(risers, 'riser'),
			primaryLabel: 'Number of risers',
			summary,
			secondaryMetrics: [
				{ label: 'Actual riser height', value: `${num(out(riser), 2)} ${unit}` },
				{ label: 'Number of treads', value: num(treads, 0) },
				{ label: 'Total run', value: `${num(out(run), 2)} ${unit}` },
				{ label: 'Stringer length', value: `${num(out(stringer), 2)} ${unit}` },
				{ label: 'Stair angle', value: `${num(angle, 1)}°` },
				{ label: 'Code check', value: riserOk && treadOk ? 'Within IRC R311.7.5' : 'Outside IRC R311.7.5' }
			]
		};
	},
	content: {
		intro:
			'Plan a straight staircase from the total rise between floors. The calculator works out how many risers and treads you need, the total run, the stringer length and the stair angle.',
		howTo: [
			'Choose inches or centimetres, then enter the total rise from one floor to the next.',
			'Enter the tallest riser you want. The calculator divides the rise into whole steps that stay at or below it.',
			'Enter the tread depth, the horizontal depth you walk on.',
			'Read the riser count, run and stringer length, then check the code note.'
		],
		formulas: [
			{
				title: 'Number of risers',
				expression: 'Risers = ⌈total rise ÷ maximum riser⌉',
				variables: [{ symbol: '⌈ ⌉', meaning: 'Round up to the next whole number' }]
			},
			{
				title: 'Actual riser and treads',
				expression: 'Actual riser = total rise ÷ risers, and treads = risers − 1',
				variables: []
			},
			{
				title: 'Run, stringer and angle',
				expression: 'Run = treads × tread depth, stringer = √(rise² + run²), angle = arctan(rise ÷ run)',
				variables: [
					{ symbol: '√', meaning: 'Square root' },
					{ symbol: 'arctan', meaning: 'Inverse tangent, in degrees' }
				]
			}
		],
		example: {
			title: 'A 9 ft rise with 10 in treads',
			steps: [
				'Risers = ⌈108 ÷ 7.75⌉ = ⌈13.94⌉ = 14.',
				'Actual riser = 108 ÷ 14 = 7.71 in. Treads = 14 − 1 = 13.',
				'Run = 13 × 10 = 130 in. Stringer = √(108² + 130²) = 169.01 in.',
				'Angle = arctan(108 ÷ 130) = 39.7°.'
			],
			result: '14 risers of 7.71 in, 13 treads, a 130 in run and a 169.01 in stringer at 39.7°.'
		},
		disclaimer:
			'Building codes vary by place. The code check uses the common IRC R311.7.5 limits only, so confirm your local rules before you build.',
		faq: [
			{
				q: 'What is the maximum riser height in the code?',
				a: 'The International Residential Code (IRC) R311.7.5 sets the maximum riser at 7¾ inches and the minimum tread depth at 10 inches. Many local codes match these, but some differ.'
			},
			{
				q: 'Why are there one fewer treads than risers?',
				a: 'The top of the staircase is the upper floor, so it has no tread of its own. A flight with 14 risers has 13 treads between them.'
			},
			{
				q: 'What is a stringer?',
				a: 'The stringer is the sloped board that supports the treads and risers. Its length is the diagonal across the rise and the run, which is why it is longer than either.'
			},
			{
				q: 'Does this cover winders or spiral stairs?',
				a: 'No. It is for straight flights with equal risers and treads. Curved, winding and spiral stairs need their own layout.'
			}
		],
		sources: [{ title: 'International Code Council (ICC)', url: 'https://www.iccsafe.org/' }]
	}
});
