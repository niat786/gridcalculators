import { defineMeta } from '../types';

export default defineMeta({
	slug: 'age-calculator',
	name: 'Age Calculator',
	category: 'everyday',
	shortDescription: 'Exact age in years, months and days from any date.',
	metaTitle: 'Age Calculator — Exact Age in Years, Months & Days',
	metaDescription:
		'Free age calculator. Find your exact age in years, months and days, plus total weeks and days lived and the countdown to your next birthday.',
	icon: 'calendar',
	keywords: ['age', 'how old am i', 'birthday', 'date of birth', 'age in days'],
	popularRank: 1,
	updated: '2026-10-28'
});
