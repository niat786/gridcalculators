import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './weight-calculator.meta';

const isKg = (v: InputValues) => v.massUnit !== 'lb';
const isLb = (v: InputValues) => v.massUnit === 'lb';

/** Standard gravity on Earth, in m/s² (defined value). */
const EARTH_G = 9.80665;
const KG_PER_LB = 0.45359237;
const LB_PER_KG = 2.20462262;
const LBF_PER_N = 0.2248089431;

/** Surface gravity in m/s², from NASA's planetary fact sheet. */
const GRAVITY: Record<string, number> = {
	earth: EARTH_G,
	moon: 1.62,
	mercury: 3.7,
	venus: 8.87,
	mars: 3.71,
	jupiter: 24.79,
	saturn: 10.44,
	uranus: 8.87,
	neptune: 11.15,
	pluto: 0.62
};

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'massUnit',
			label: 'Mass unit',
			type: 'select',
			display: 'segmented',
			default: 'kg',
			options: [
				{ label: 'Kilograms (kg)', value: 'kg' },
				{ label: 'Pounds (lb)', value: 'lb' }
			]
		},
		{ id: 'massKg', label: 'Mass', type: 'number', default: 70, min: 0.01, max: 100000, step: 0.1, suffix: 'kg', visibleWhen: isKg },
		{ id: 'massLb', label: 'Mass', type: 'number', default: 154, min: 0.01, max: 220000, step: 0.1, suffix: 'lb', visibleWhen: isLb },
		{
			id: 'body',
			label: 'Where',
			type: 'select',
			default: 'earth',
			options: [
				{ label: 'Earth (9.81 m/s²)', value: 'earth' },
				{ label: 'Moon (1.62 m/s²)', value: 'moon' },
				{ label: 'Mercury (3.70 m/s²)', value: 'mercury' },
				{ label: 'Venus (8.87 m/s²)', value: 'venus' },
				{ label: 'Mars (3.71 m/s²)', value: 'mars' },
				{ label: 'Jupiter (24.79 m/s²)', value: 'jupiter' },
				{ label: 'Saturn (10.44 m/s²)', value: 'saturn' },
				{ label: 'Uranus (8.87 m/s²)', value: 'uranus' },
				{ label: 'Neptune (11.15 m/s²)', value: 'neptune' },
				{ label: 'Pluto (0.62 m/s²)', value: 'pluto' }
			]
		}
	],
	calculate(v): CalculationResult {
		const kg = isLb(v) ? Number(v.massLb) * KG_PER_LB : Number(v.massKg);
		const g = GRAVITY[String(v.body)];
		if (!(kg > 0) || g === undefined) {
			return { primaryResult: DASH, primaryLabel: 'Weight', summary: 'Enter a mass above zero and pick a body.' };
		}
		const weightN = kg * g;
		const scaleKg = weightN / EARTH_G;
		const scaleLb = scaleKg * LB_PER_KG;
		const lbf = weightN * LBF_PER_N;
		const share = (g / EARTH_G) * 100;

		return {
			primaryResult: `${num(weightN, 2, 2)} N`,
			primaryLabel: 'Weight',
			summary: `That is ${num(share, 1, 1)}% of your weight on Earth.`,
			secondaryMetrics: [
				{ label: 'Scale reading (kg)', value: `${num(scaleKg, 2, 2)} kg` },
				{ label: 'Scale reading (lb)', value: `${num(scaleLb, 2, 2)} lb` },
				{ label: 'Weight in pounds-force', value: `${num(lbf, 2, 2)} lbf` },
				{ label: 'Gravity used', value: `${num(g, 2, 2)} m/s²` },
				{ label: 'Mass', value: `${num(kg, 2, 2)} kg` }
			]
		};
	},
	content: {
		intro:
			'Work out how much a mass weighs on Earth, the Moon or a planet. Weight is the force of gravity on a mass, so it changes with the gravity of the place you stand on, even though the mass stays the same.',
		howTo: [
			'Choose kilograms or pounds, and enter the mass.',
			'Pick the body, such as the Moon or Mars.',
			'Read the weight in newtons, and the scale reading in kilograms and pounds.'
		],
		formulas: [
			{
				title: 'Weight',
				expression: 'W = m × g',
				variables: [
					{ symbol: 'W', meaning: 'weight, in newtons (N)' },
					{ symbol: 'm', meaning: 'mass, in kilograms' },
					{ symbol: 'g', meaning: 'surface gravity of the body, in m/s²' }
				]
			},
			{
				title: 'Scale reading',
				expression: 'Scale reading (kg) = W ÷ 9.80665',
				variables: [{ symbol: '9.80665', meaning: 'standard gravity on Earth, in m/s²' }]
			}
		],
		example: {
			title: 'A 70 kg person on the Moon',
			steps: [
				'Weight: 70 × 1.62 = 113.40 N',
				'Scale reading: 113.40 ÷ 9.80665 = 11.56 kg',
				'In pounds: 11.56 × 2.20462 = 25.49 lb'
			],
			result: '113.40 N. A scale calibrated for Earth would read 11.56 kg (25.49 lb).'
		},
		faq: [
			{
				q: 'Why is weight different from mass?',
				a: 'Mass is the amount of matter in an object and is the same everywhere. Weight is the force gravity puts on that mass, so it depends on the body you are standing on.'
			},
			{
				q: 'What does the scale reading mean on another body?',
				a: 'A bathroom scale is calibrated for Earth. It shows the mass that would produce the same force on Earth, so on the Moon it reads about one-sixth of your Earth value.'
			},
			{
				q: 'Why use 9.80665 m/s² for Earth?',
				a: '9.80665 m/s² is standard gravity, a fixed value agreed in 1901 by the General Conference on Weights and Measures. It is the conventional figure for converting kilograms to newtons.'
			},
			{
				q: 'How accurate are the planet values?',
				a: 'They are surface gravity values from NASA’s planetary fact sheet. Gravity varies slightly from place to place on a planet, and for gas giants the value refers to a reference level in the atmosphere.'
			}
		],
		sources: [{ title: 'NASA — Planetary Fact Sheet', url: 'https://nssdc.gsfc.nasa.gov/planetary/factsheet/' }]
	}
});
