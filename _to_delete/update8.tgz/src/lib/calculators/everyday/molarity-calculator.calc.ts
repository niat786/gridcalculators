import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './molarity-calculator.meta';

type VolumeUnit = 'mL' | 'L';
type Solve = 'molarity' | 'mass' | 'volume';

const fail = (summary: string): CalculationResult => ({
	primaryResult: DASH,
	primaryLabel: 'Result',
	summary
});

const isPositive = (x: number) => Number.isFinite(x) && x > 0;
const isZeroOrMore = (x: number) => Number.isFinite(x) && x >= 0;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'solve',
			label: 'Solve for',
			type: 'select',
			default: 'molarity',
			display: 'menu',
			options: [
				{ label: 'Molarity, from mass and volume', value: 'molarity' },
				{ label: 'Mass for a target molarity', value: 'mass' },
				{ label: 'Volume for a target molarity', value: 'volume' }
			]
		},
		{
			id: 'mass',
			label: 'Mass of solute',
			type: 'number',
			default: 5.844,
			min: 0,
			max: 10000000,
			suffix: 'g',
			visibleWhen: (v) => v.solve !== 'mass'
		},
		{
			id: 'molarMass',
			label: 'Molar mass',
			type: 'number',
			default: 58.44,
			min: 0,
			max: 100000,
			suffix: 'g/mol',
			help: 'Add up the atomic masses in the formula. Table salt (NaCl) is 58.44 g/mol.'
		},
		{
			id: 'targetM',
			label: 'Target molarity',
			type: 'number',
			default: 0.5,
			min: 0,
			max: 100,
			suffix: 'M',
			help: 'Moles of solute per litre of solution.',
			visibleWhen: (v) => v.solve !== 'molarity'
		},
		{
			id: 'volume',
			label: 'Volume of solution',
			type: 'number',
			default: 100,
			min: 0,
			max: 10000000,
			visibleWhen: (v) => v.solve !== 'volume'
		},
		{
			id: 'volumeUnit',
			label: 'Volume unit',
			type: 'select',
			default: 'mL',
			display: 'segmented',
			options: [
				{ label: 'mL', value: 'mL' },
				{ label: 'L', value: 'L' }
			]
		}
	],
	calculate(v: InputValues): CalculationResult {
		const solve = String(v.solve) as Solve;
		const unit = String(v.volumeUnit) as VolumeUnit;
		const litres = (x: number) => (unit === 'mL' ? x / 1000 : x);
		const fromLitres = (x: number) => (unit === 'mL' ? x * 1000 : x);

		const molarMass = Number(v.molarMass);
		if (!isPositive(molarMass)) return fail('Enter a molar mass above zero.');

		let molarity: number;
		let moles: number;
		let mass: number;
		let volumeL: number;

		if (solve === 'molarity') {
			mass = Number(v.mass);
			volumeL = litres(Number(v.volume));
			if (!isZeroOrMore(mass) || !isPositive(volumeL)) return fail('Enter a mass of zero or more, and a volume above zero.');
			moles = mass / molarMass;
			molarity = moles / volumeL;
		} else if (solve === 'mass') {
			molarity = Number(v.targetM);
			volumeL = litres(Number(v.volume));
			if (!isZeroOrMore(molarity) || !isPositive(volumeL)) return fail('Enter a target molarity and a volume above zero.');
			moles = molarity * volumeL;
			mass = moles * molarMass;
		} else {
			mass = Number(v.mass);
			molarity = Number(v.targetM);
			if (!isZeroOrMore(mass) || !isPositive(molarity)) return fail('Enter a mass of zero or more and a target molarity above zero.');
			moles = mass / molarMass;
			volumeL = moles / molarity;
		}

		if (![molarity, moles, mass, volumeL].every(Number.isFinite)) return fail('Check the values; the result is not a finite number.');

		const volumeOut = `${num(fromLitres(volumeL), 2)} ${unit}`;
		const summary =
			solve === 'molarity'
				? `Molarity = moles ÷ litres: ${num(mass, 4)} g ÷ ${num(molarMass, 4)} g/mol = ${num(moles, 5)} mol in ${num(volumeL, 4)} L.`
				: solve === 'mass'
					? `Mass = molarity × litres × molar mass: ${num(molarity, 4)} M × ${num(volumeL, 4)} L × ${num(molarMass, 4)} g/mol.`
					: `Volume = moles ÷ molarity: ${num(moles, 4)} mol ÷ ${num(molarity, 4)} M.`;

		const primary =
			solve === 'molarity'
				? { primaryResult: `${num(molarity, 4)} M`, primaryLabel: 'Molarity' }
				: solve === 'mass'
					? { primaryResult: `${num(mass, 3)} g`, primaryLabel: 'Mass needed' }
					: { primaryResult: volumeOut, primaryLabel: 'Volume needed' };

		return {
			...primary,
			summary,
			secondaryMetrics: [
				{ label: 'Molarity', value: `${num(molarity, 4)} M` },
				{ label: 'Moles of solute', value: `${num(moles, 5)} mol` },
				{ label: 'Mass of solute', value: `${num(mass, 3)} g` },
				{ label: 'Volume of solution', value: volumeOut }
			]
		};
	},
	content: {
		intro:
			'Work out the molarity of a solution, or the mass or volume you need for a target molarity. Molarity is moles of solute per litre of solution.',
		howTo: [
			'Choose what to solve for: molarity from a known mass, or the mass or volume needed for a target molarity.',
			'Enter the molar mass of the solute. Add up the atomic masses in its formula, or look it up.',
			'Enter the mass, target molarity or volume that you know, and pick mL or L for the volume.',
			'Read the answer, with the moles of solute shown below it.'
		],
		formulas: [
			{
				title: 'Molarity',
				expression: 'M = n ÷ V',
				variables: [
					{ symbol: 'M', meaning: 'Molarity in mol/L, also written as M' },
					{ symbol: 'n', meaning: 'Moles of solute' },
					{ symbol: 'V', meaning: 'Volume of the solution in litres' }
				]
			},
			{
				title: 'Moles from mass',
				expression: 'n = mass ÷ molar mass',
				variables: [{ symbol: 'molar mass', meaning: 'Grams per mole, from the formula of the solute' }]
			},
			{
				title: 'Mass needed for a target',
				expression: 'mass = M × V × molar mass',
				variables: []
			}
		],
		example: {
			title: 'Table salt in 100 mL of water',
			steps: [
				'Moles: 5.844 g ÷ 58.44 g/mol = 0.1 mol.',
				'Volume: 100 mL = 0.1 L.',
				'Molarity: 0.1 mol ÷ 0.1 L = 1 M.'
			],
			result: '1 M, which is 1 mole of NaCl per litre of solution.'
		},
		faq: [
			{
				q: 'Why is molarity measured per litre and not per litre of water?',
				a: 'Molarity uses the total volume of the finished solution. Adding a solute can change the volume, so the solution volume is what counts.'
			},
			{
				q: 'Where do I find the molar mass?',
				a: 'Add up the atomic masses of every atom in the formula, using the periodic table. For example, NaCl is 22.99 + 35.45 = 58.44 g/mol.'
			},
			{
				q: 'Can I enter the volume in mL?',
				a: 'Yes. Choose mL for the volume unit and the calculator converts it to litres before it works out molarity.'
			},
			{
				q: 'What if my solute is a hydrate or has more than one ionic form?',
				a: 'Use the molar mass of the exact compound you weigh, including any water of crystallisation. Molarity counts the formula units you dissolve, so a salt that splits into ions still counts as one mole per formula unit.'
			}
		]
	}
});
