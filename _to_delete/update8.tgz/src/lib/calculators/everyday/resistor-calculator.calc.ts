import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './resistor-calculator.meta';

const isFive = (v: InputValues) => String(v.bands) === '5';

/** Digit value of each color (IEC 60062). */
const DIGIT: Record<string, number> = {
	black: 0,
	brown: 1,
	red: 2,
	orange: 3,
	yellow: 4,
	green: 5,
	blue: 6,
	violet: 7,
	grey: 8,
	white: 9
};

/** Multiplier of each color (IEC 60062). Gold and silver are decimal multipliers. */
const MULTIPLIER: Record<string, number> = {
	black: 1,
	brown: 10,
	red: 100,
	orange: 1e3,
	yellow: 1e4,
	green: 1e5,
	blue: 1e6,
	violet: 1e7,
	grey: 1e8,
	white: 1e9,
	gold: 0.1,
	silver: 0.01
};

/** Tolerance of each color, in percent (IEC 60062). */
const TOLERANCE: Record<string, number> = {
	brown: 1,
	red: 2,
	green: 0.5,
	blue: 0.25,
	violet: 0.1,
	grey: 0.05,
	gold: 5,
	silver: 10
};

const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

/** Format ohms with an SI prefix: Ω, kΩ, MΩ or GΩ. */
export function formatOhms(x: number): string {
	if (x >= 1e9) return `${num(x / 1e9, 3)} GΩ`;
	if (x >= 1e6) return `${num(x / 1e6, 3)} MΩ`;
	if (x >= 1e3) return `${num(x / 1e3, 3)} kΩ`;
	return `${num(x, 3)} Ω`;
}

const digitOptions = Object.keys(DIGIT).map((c) => ({ label: `${cap(c)} (${DIGIT[c]})`, value: c }));

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'bands',
			label: 'Number of bands',
			type: 'select',
			display: 'segmented',
			default: '4',
			options: [
				{ label: '4 bands', value: '4' },
				{ label: '5 bands', value: '5' }
			]
		},
		{ id: 'b1', label: 'Band 1', help: 'First digit', type: 'select', default: 'brown', options: digitOptions },
		{ id: 'b2', label: 'Band 2', help: 'Second digit', type: 'select', default: 'black', options: digitOptions },
		{ id: 'b3', label: 'Band 3', help: 'Third digit (5-band codes only)', type: 'select', default: 'black', options: digitOptions, visibleWhen: isFive },
		{
			id: 'mult',
			label: 'Multiplier',
			help: 'Band 3 on a 4-band resistor, band 4 on a 5-band resistor.',
			type: 'select',
			default: 'red',
			options: [
				{ label: 'Black (×1)', value: 'black' },
				{ label: 'Brown (×10)', value: 'brown' },
				{ label: 'Red (×100)', value: 'red' },
				{ label: 'Orange (×1,000)', value: 'orange' },
				{ label: 'Yellow (×10,000)', value: 'yellow' },
				{ label: 'Green (×100,000)', value: 'green' },
				{ label: 'Blue (×1,000,000)', value: 'blue' },
				{ label: 'Violet (×10,000,000)', value: 'violet' },
				{ label: 'Grey (×100,000,000)', value: 'grey' },
				{ label: 'White (×1,000,000,000)', value: 'white' },
				{ label: 'Gold (×0.1)', value: 'gold' },
				{ label: 'Silver (×0.01)', value: 'silver' }
			]
		},
		{
			id: 'tol',
			label: 'Tolerance',
			help: 'Band 4 on a 4-band resistor, band 5 on a 5-band resistor.',
			type: 'select',
			default: 'gold',
			options: [
				{ label: 'Brown (±1%)', value: 'brown' },
				{ label: 'Red (±2%)', value: 'red' },
				{ label: 'Green (±0.5%)', value: 'green' },
				{ label: 'Blue (±0.25%)', value: 'blue' },
				{ label: 'Violet (±0.1%)', value: 'violet' },
				{ label: 'Grey (±0.05%)', value: 'grey' },
				{ label: 'Gold (±5%)', value: 'gold' },
				{ label: 'Silver (±10%)', value: 'silver' }
			]
		}
	],
	calculate(v): CalculationResult {
		const five = isFive(v);
		const digitKeys = five ? [v.b1, v.b2, v.b3] : [v.b1, v.b2];
		const digits = digitKeys.map((k) => DIGIT[String(k)]);
		const mult = MULTIPLIER[String(v.mult)];
		const tol = TOLERANCE[String(v.tol)];
		if (digits.some((d) => d === undefined) || mult === undefined || tol === undefined) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Resistance',
				summary: 'Pick a color for every band.'
			};
		}
		const significant = five ? digits[0] * 100 + digits[1] * 10 + digits[2] : digits[0] * 10 + digits[1];
		const ohms = significant * mult;
		if (!(ohms > 0)) {
			return {
				primaryResult: '0 Ω',
				primaryLabel: 'Resistance',
				summary: 'Zero ohms: this is a jumper (zero-ohm link), usually marked with a single black band. Check the colors if you expected a resistor.'
			};
		}
		const min = ohms * (1 - tol / 100);
		const max = ohms * (1 + tol / 100);
		const colors = [...digitKeys, v.mult, v.tol].map((c) => cap(String(c))).join(' · ');

		return {
			primaryResult: formatOhms(ohms),
			primaryLabel: 'Resistance',
			summary: `${formatOhms(ohms)} ±${num(tol, 2)}%: the real value can be anywhere from ${formatOhms(min)} to ${formatOhms(max)}.`,
			secondaryMetrics: [
				{ label: 'Tolerance', value: `±${num(tol, 2)}%` },
				{ label: 'Minimum', value: formatOhms(min) },
				{ label: 'Maximum', value: formatOhms(max) },
				{ label: 'Color code', value: colors }
			]
		};
	},
	content: {
		intro:
			'Read the resistance of a resistor from its colored bands. Choose 4 or 5 bands, pick the color of each band, and the calculator gives the resistance, the tolerance and the lowest and highest value it may have.',
		howTo: [
			'Choose 4 bands or 5 bands, to match the resistor.',
			'Pick the color of band 1 and band 2, and band 3 if there are five bands.',
			'Pick the multiplier color and the tolerance color, which is usually gold or silver.',
			'Read the resistance, the tolerance and the minimum and maximum values.'
		],
		formulas: [
			{
				title: '4-band resistor',
				expression: 'R = (10 × band 1 + band 2) × multiplier',
				variables: [{ symbol: 'R', meaning: 'resistance, in ohms (Ω)' }]
			},
			{
				title: '5-band resistor',
				expression: 'R = (100 × band 1 + 10 × band 2 + band 3) × multiplier',
				variables: []
			},
			{
				title: 'Tolerance range',
				expression: 'R_min = R × (1 − t) · R_max = R × (1 + t), where t is the tolerance as a fraction',
				variables: [{ symbol: 't', meaning: 'tolerance, for example 0.05 for ±5%' }]
			},
			{
				title: 'Color values (IEC 60062)',
				expression:
					'Digits: black 0, brown 1, red 2, orange 3, yellow 4, green 5, blue 6, violet 7, grey 8, white 9. Multipliers: black ×1 to white ×10⁹, gold ×0.1, silver ×0.01. Tolerance: brown ±1%, red ±2%, green ±0.5%, blue ±0.25%, violet ±0.1%, grey ±0.05%, gold ±5%, silver ±10%.',
				variables: []
			}
		],
		example: {
			title: 'A 4-band resistor with yellow, violet, orange and gold bands',
			steps: [
				'First two digits: yellow 4, violet 7, so 47',
				'Multiplier: orange is ×1,000, so 47 × 1,000 = 47,000 Ω',
				'Tolerance: gold is ±5%, so the range is 44.65 kΩ to 49.35 kΩ'
			],
			result: '47 kΩ ±5%, between 44.65 kΩ and 49.35 kΩ.'
		},
		faq: [
			{
				q: 'How do I know which end to read first?',
				a: 'Read from the end that has the tolerance band. Gold or silver is almost always the tolerance band, so start from the other end, which holds band 1.'
			},
			{
				q: 'What is the difference between 4-band and 5-band resistors?',
				a: 'A 5-band resistor adds a third significant digit, which lets it give more precise values. They are usually precision parts, often with 1% or tighter tolerance.'
			},
			{
				q: 'What does tolerance mean?',
				a: 'It is the allowed spread around the marked value. A 5% resistor marked 1 kΩ can measure anywhere from 950 Ω to 1.05 kΩ when new.'
			},
			{
				q: 'What if the colors look different from the chart?',
				a: 'Lighting, dirt and age can change how bands look, and brown and red are often hard to tell apart. If you are unsure, measure the resistor with a multimeter.'
			}
		],
		sources: [{ title: 'IEC — International Electrotechnical Commission (IEC 60062 resistor color code)', url: 'https://www.iec.ch' }]
	}
});
