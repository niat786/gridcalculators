import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './voltage-drop-calculator.meta';

const imperial = (v: InputValues) => v.units === 'imperial';
const metric = (v: InputValues) => v.units === 'metric';
const awgSystem = (v: InputValues) => v.system === 'awg';
const mm2System = (v: InputValues) => v.system === 'mm2';

/**
 * DC resistance at 75 °C, ohms per 1000 ft, uncoated conductors (NEC Chapter 9, Table 8).
 * `cu` = copper, `al` = aluminum.
 */
export const AWG_OHMS_PER_1000FT: Record<string, { cu: number; al: number }> = {
	'14': { cu: 3.07, al: 5.06 },
	'12': { cu: 1.93, al: 3.18 },
	'10': { cu: 1.21, al: 2.0 },
	'8': { cu: 0.764, al: 1.26 },
	'6': { cu: 0.491, al: 0.808 },
	'4': { cu: 0.308, al: 0.508 },
	'3': { cu: 0.245, al: 0.403 },
	'2': { cu: 0.194, al: 0.319 },
	'1': { cu: 0.154, al: 0.253 },
	'1/0': { cu: 0.122, al: 0.201 },
	'2/0': { cu: 0.0967, al: 0.159 },
	'3/0': { cu: 0.0766, al: 0.126 },
	'4/0': { cu: 0.0608, al: 0.1 }
};

/** Resistivity at 75 °C, ohm·mm² per metre, for metric sizes. */
export const RESISTIVITY_OHM_MM2_PER_M = { copper: 0.02156, aluminum: 0.03547 };

const FT_PER_M = 1 / 0.3048;
const GUIDE_PERCENT = 3;

const AWG_OPTIONS = Object.keys(AWG_OHMS_PER_1000FT).map((k) => ({ value: k, label: `${k} AWG` }));
const MM2_OPTIONS = ['1.5', '2.5', '4', '6', '10', '16', '25', '35', '50', '70', '95'].map((k) => ({
	value: k,
	label: `${k} mm²`
}));

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'phase',
			label: 'Supply',
			type: 'select',
			display: 'segmented',
			default: 'single',
			options: [
				{ label: 'Single-phase', value: 'single' },
				{ label: 'Three-phase', value: 'three' }
			]
		},
		{
			id: 'material',
			label: 'Conductor',
			type: 'select',
			display: 'segmented',
			default: 'copper',
			options: [
				{ label: 'Copper', value: 'copper' },
				{ label: 'Aluminum', value: 'aluminum' }
			]
		},
		{
			id: 'system',
			label: 'Wire size system',
			type: 'select',
			display: 'segmented',
			default: 'awg',
			options: [
				{ label: 'AWG', value: 'awg' },
				{ label: 'Metric (mm²)', value: 'mm2' }
			]
		},
		{ id: 'awg', label: 'Wire size', type: 'select', default: '10', options: AWG_OPTIONS, visibleWhen: awgSystem },
		{ id: 'mm2', label: 'Wire size', type: 'select', default: '4', options: MM2_OPTIONS, visibleWhen: mm2System },
		{
			id: 'units',
			label: 'Length units',
			type: 'select',
			display: 'segmented',
			default: 'imperial',
			options: [
				{ label: 'Imperial (ft)', value: 'imperial' },
				{ label: 'Metric (m)', value: 'metric' }
			]
		},
		{ id: 'lengthFt', label: 'One-way length', type: 'number', default: 50, min: 1, max: 3000, step: 1, suffix: 'ft', visibleWhen: imperial },
		{ id: 'lengthM', label: 'One-way length', type: 'number', default: 15, min: 0.5, max: 900, step: 0.1, suffix: 'm', visibleWhen: metric },
		{ id: 'current', label: 'Current', type: 'number', default: 20, min: 0.1, max: 2000, step: 0.1, suffix: 'A' },
		{ id: 'volts', label: 'Supply voltage', type: 'number', default: 120, min: 1, max: 1000, step: 1, suffix: 'V', help: 'Line-to-line for three-phase.' }
	],
	calculate(v): CalculationResult {
		const fail = (summary: string): CalculationResult => ({
			primaryResult: DASH,
			primaryLabel: 'Voltage drop',
			summary
		});

		const copper = v.material === 'copper';
		const three = v.phase === 'three';
		const current = Number(v.current);
		const volts = Number(v.volts);
		const lengthM = imperial(v) ? Number(v.lengthFt) / FT_PER_M : Number(v.lengthM);

		let ohmsPerM: number;
		if (v.system === 'mm2') {
			const area = Number(v.mm2);
			ohmsPerM = (copper ? RESISTIVITY_OHM_MM2_PER_M.copper : RESISTIVITY_OHM_MM2_PER_M.aluminum) / area;
		} else {
			const row = AWG_OHMS_PER_1000FT[String(v.awg)];
			if (!row) return fail('Pick a wire size.');
			// Ohms per 1000 ft → ohms per metre.
			ohmsPerM = (copper ? row.cu : row.al) / 1000 / 0.3048;
		}

		if (!(current > 0) || !(volts > 0) || !(lengthM > 0) || !(ohmsPerM > 0)) {
			return fail('Enter the length, current and voltage.');
		}

		// One-way resistance of the run, then the drop for the whole circuit.
		const resistance = ohmsPerM * lengthM;
		const factor = three ? Math.sqrt(3) : 2;
		const drop = factor * current * resistance;
		const atLoad = volts - drop;
		if (!(atLoad > 0)) {
			return fail('The drop is larger than the supply voltage. Check the wire size and length.');
		}

		const pct = (drop / volts) * 100;
		const within = pct <= GUIDE_PERCENT;

		return {
			primaryResult: `${num(pct, 2, 2)}%`,
			primaryLabel: 'Voltage drop',
			summary: `${num(drop, 2, 2)} V is lost along the run, leaving ${num(atLoad, 1, 1)} V at the load. ${
				within
					? 'That is within the 3% guide for a branch circuit.'
					: 'That is above the 3% guide for a branch circuit, so a larger wire or a shorter run would help.'
			}`,
			secondaryMetrics: [
				{ label: 'Volts dropped', value: `${num(drop, 2, 2)} V` },
				{ label: 'Voltage at the load', value: `${num(atLoad, 1, 1)} V` },
				{ label: 'Resistance, one way', value: `${num(resistance, 4, 4)} Ω` },
				{ label: 'Against the 3% guide', value: within ? 'Within 3%' : 'Above 3%' }
			]
		};
	},
	content: {
		intro:
			'Estimate how much voltage a wire run loses between the supply and the load. Pick the wire size, metal, length, current and supply voltage to see the percentage drop and whether it is within the usual 3% guide.',
		howTo: [
			'Choose single-phase or three-phase, and copper or aluminum.',
			'Pick the wire size in AWG or mm², then enter the one-way length.',
			'Enter the current in amps and the supply voltage.',
			'Read the percentage drop, the voltage at the load and whether it is within 3%.'
		],
		formulas: [
			{
				title: 'Conductor resistance',
				expression: 'R = resistance per length × one-way length',
				variables: [
					{ symbol: 'R', meaning: 'Resistance of one conductor for the one-way run, in ohms' },
					{ symbol: 'AWG', meaning: 'Ohms per 1000 ft are taken from NEC Chapter 9, Table 8, at 75 °C' },
					{ symbol: 'mm²', meaning: 'Resistance = 0.02156 (copper) or 0.03547 (aluminum) Ω·mm²/m, divided by the wire area' }
				]
			},
			{
				title: 'Single-phase voltage drop',
				expression: 'Voltage drop = 2 × L × R × I',
				variables: [
					{ symbol: 'L', meaning: 'One-way length' },
					{ symbol: 'I', meaning: 'Current in amps' },
					{ symbol: '2', meaning: 'Current flows out and back along two conductors' }
				]
			},
			{
				title: 'Three-phase voltage drop',
				expression: 'Voltage drop = √3 × L × R × I',
				variables: [{ symbol: '√3', meaning: 'About 1.732, for three balanced phases' }]
			},
			{
				title: 'Percentage drop',
				expression: '% drop = voltage drop ÷ supply voltage × 100',
				variables: [{ symbol: 'V', meaning: 'Supply voltage' }]
			}
		],
		example: {
			title: '10 AWG copper, 50 ft, 20 A, 120 V single-phase',
			steps: [
				'Resistance: 1.21 Ω per 1000 ft × 50 ft ÷ 1000 = 0.0605 Ω one way',
				'Voltage drop: 2 × 20 A × 0.0605 Ω = 2.42 V',
				'Percentage: 2.42 ÷ 120 × 100 = 2.02%',
				'Voltage at the load: 120 − 2.42 = 117.6 V'
			],
			result: 'Voltage drop is 2.02%, leaving 117.6 V at the load. That is within the 3% guide.'
		},
		faq: [
			{
				q: 'What voltage drop is allowed outside the US?',
				a: 'IEC 60364 and the UK wiring regulations (BS 7671) generally allow 3% for lighting circuits and 5% for other circuits from the supply to the load. Always follow your local wiring rules.'
			},
			{
				q: 'What is the 3% guide?',
				a: 'The NEC informational note suggests keeping the drop to 3% or less on a branch circuit, and 5% or less from the service to the farthest outlet. These are guidance values, not hard limits, so check local rules.'
			},
			{
				q: 'Why does this ignore reactance?',
				a: 'At the wire sizes most homes and small projects use, resistance is the main cause of voltage drop, so reactance has little effect. For long runs of large conductors, or for motor starting, a fuller calculation is needed.'
			},
			{
				q: 'How do I fix a large voltage drop?',
				a: 'Use a larger wire, shorten the run, or split the load. Each step up in AWG size lowers the resistance by about a fifth, so two steps can bring a borderline drop within the guide.'
			},
			{
				q: 'Why is aluminum drop higher?',
				a: 'Aluminum has about 1.65 times the resistance of copper for the same size, so an aluminum wire of the same gauge drops more voltage. It needs a larger size for the same result.'
			}
		],
		sources: [
			{ title: 'NFPA — National Electrical Code', url: 'https://www.nfpa.org/' }
		],
		disclaimer:
			'This is an estimate. Check local wiring rules and have a licensed electrician confirm any installation.'
	}
});
