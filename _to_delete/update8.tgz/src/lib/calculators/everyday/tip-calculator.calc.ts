import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, money, num } from '../format';
import meta from './tip-calculator.meta';

const ok = (x: number) => Number.isFinite(x);

/** Round to whole cents, so 0.1 + 0.2 style float noise never changes a result. */
const cents = (x: number) => Math.round(x * 100) / 100;

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'bill', label: 'Bill amount', type: 'number', default: 50, min: 0, max: 1000000, step: 0.01, prefix: '$' },
		{ id: 'tipPct', label: 'Tip', type: 'number', default: 18, min: 0, max: 100, step: 1, suffix: '%' },
		{ id: 'people', label: 'Number of people', type: 'number', default: 1, min: 1, max: 1000, step: 1, decimal: false },
		{
			id: 'roundUp',
			label: 'Round each share up to the next dollar',
			type: 'toggle',
			default: false,
			help: 'Each person pays a whole dollar amount.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const bill = Number(v.bill);
		const pct = Number(v.tipPct);
		const people = Number(v.people);
		if (!ok(bill) || bill < 0 || !ok(pct) || pct < 0 || !ok(people) || people < 1 || !Number.isInteger(people)) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Per person',
				summary: 'Enter a bill, a tip percentage and at least one person.'
			};
		}

		const tip = cents((bill * pct) / 100);
		const total = cents(bill + tip);
		const exactShare = total / people;
		const share = v.roundUp ? Math.ceil(cents(exactShare)) : cents(exactShare);

		return {
			primaryResult: money(share, Boolean(v.roundUp)),
			primaryLabel: people === 1 ? 'Total for you' : 'Each person pays',
			summary: `${num(pct, 2)}% tip on ${money(bill)} for ${num(people, 0)} ${people === 1 ? 'person' : 'people'}.`,
			secondaryMetrics: [
				{ label: 'Tip amount', value: money(tip) },
				{ label: 'Total with tip', value: money(total) },
				{ label: 'Tip per person', value: money(cents(tip / people)) },
				{ label: 'Total per person', value: money(cents(exactShare)) }
			]
		};
	},
	content: {
		intro:
			'Find the tip on a restaurant or service bill, the total you will pay, and how much each person owes when you split it.',
		howTo: [
			'Enter the bill amount before tax, or the full bill if you prefer.',
			'Set the tip percentage. The default is 18%.',
			'Enter how many people are sharing the bill.',
			'Turn on rounding if you want each share to be a whole dollar amount.'
		],
		formulas: [
			{
				title: 'Tip and total',
				expression: 'Tip = bill × tip % ÷ 100\nTotal = bill + tip',
				variables: [
					{ symbol: 'bill', meaning: 'The bill amount before the tip' },
					{ symbol: 'tip %', meaning: 'The tip as a percentage, for example 18' }
				]
			},
			{
				title: 'Each share',
				expression: 'Share = total ÷ people\nWith rounding on, the share is rounded up to the next whole dollar.',
				variables: [{ symbol: 'people', meaning: 'The number of people paying' }]
			}
		],
		example: {
			title: 'A $84.50 bill, a 20% tip, shared by 3 people',
			steps: [
				'Tip: $84.50 × 20 ÷ 100 = $16.90',
				'Total: $84.50 + $16.90 = $101.40',
				'Each share: $101.40 ÷ 3 = $33.80',
				'With rounding on: $33.80 rounds up to $34 per person'
			],
			result: 'Each person pays $33.80, or $34 with rounding on.'
		},
		faq: [
			{
				q: 'Should I tip on the bill before or after tax?',
				a: 'Tipping customs vary. In the US, many people tip on the pre-tax amount, but either choice is common. Use whichever you prefer and adjust the bill amount to match.'
			},
			{
				q: 'What tip percentage is normal?',
				a: 'In the US, 15% to 20% is a common range for sit-down restaurant service, and 18% is a frequent default. Tipping norms differ by country and by type of service.'
			},
			{
				q: 'Why round up each share?',
				a: 'Rounding up gives everyone a whole-dollar amount, which makes cash and simple payments easier. The total paid is then a little more than the exact bill.'
			}
		]
	}
});
