import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, money, num } from '../format';
import meta from './fuel-cost-calculator.meta';

const L_PER_GAL = 3.785411784;
const KM_PER_MI = 1.609344;

const us = (v: InputValues) => v.units === 'us';
const metric = (v: InputValues) => v.units === 'metric';

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'us',
			options: [
				{ label: 'US (miles, mpg, $/gal)', value: 'us' },
				{ label: 'Metric (km, L/100 km, price/L)', value: 'metric' }
			]
		},
		{ id: 'distUs', label: 'Trip distance', type: 'number', default: 250, min: 0.1, max: 1000000, step: 1, suffix: 'mi', visibleWhen: us },
		{ id: 'distKm', label: 'Trip distance', type: 'number', default: 400, min: 0.1, max: 1000000, step: 1, suffix: 'km', visibleWhen: metric },
		{ id: 'mpg', label: 'Fuel efficiency', type: 'number', default: 28, min: 1, max: 200, step: 0.1, suffix: 'mpg', visibleWhen: us },
		{ id: 'l100', label: 'Fuel efficiency', type: 'number', default: 6.5, min: 0.5, max: 100, step: 0.1, suffix: 'L/100 km', visibleWhen: metric },
		{ id: 'priceGal', label: 'Fuel price', type: 'number', default: 3.45, min: 0, max: 1000, step: 0.01, prefix: '$', suffix: '/gal', visibleWhen: us },
		{ id: 'priceL', label: 'Fuel price', type: 'number', default: 1.8, min: 0, max: 1000, step: 0.01, prefix: '$', suffix: '/L', visibleWhen: metric },
		{
			id: 'roundTrip',
			label: 'Round trip',
			type: 'toggle',
			default: false,
			help: 'Doubles the distance for the return journey.'
		}
	],
	calculate(v): CalculationResult {
		const isUs = v.units === 'us';
		const dist = Number(isUs ? v.distUs : v.distKm);
		const eff = Number(isUs ? v.mpg : v.l100);
		const price = Number(isUs ? v.priceGal : v.priceL);
		if (!Number.isFinite(dist) || dist <= 0 || !Number.isFinite(eff) || eff <= 0 || !Number.isFinite(price) || price < 0) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Trip fuel cost',
				summary: 'Enter a trip distance, fuel efficiency and fuel price.'
			};
		}

		const total = dist * (v.roundTrip ? 2 : 1);
		// Work out fuel in both systems so both are always shown.
		const gallons = isUs ? total / eff : total * eff / 100 / L_PER_GAL;
		const litres = isUs ? gallons * L_PER_GAL : total * eff / 100;
		const cost = (isUs ? gallons : litres) * price;

		const distanceText = isUs
			? `${num(total, 1, 0)} mi (${num(total * KM_PER_MI, 1, 0)} km)`
			: `${num(total, 1, 0)} km (${num(total / KM_PER_MI, 1, 0)} mi)`;
		const fuelText = isUs
			? `${num(gallons, 2, 2)} gal (${num(litres, 2, 2)} L)`
			: `${num(litres, 2, 2)} L (${num(gallons, 2, 2)} gal)`;

		return {
			primaryResult: money(cost),
			primaryLabel: 'Trip fuel cost',
			summary: isUs
				? `About ${num(gallons, 2, 2)} gallons of fuel for ${num(total, 1, 0)} miles.`
				: `About ${num(litres, 2, 2)} litres of fuel for ${num(total, 1, 0)} kilometres.`,
			secondaryMetrics: [
				{ label: 'Fuel needed', value: fuelText },
				{ label: 'Total distance', value: distanceText },
				{ label: isUs ? 'Cost per 100 miles' : 'Cost per 100 km', value: money((cost / total) * 100) }
			]
		};
	},
	content: {
		intro:
			'Estimate how much fuel a trip will use and what it will cost, using your distance, your vehicle’s fuel efficiency and the local price of fuel.',
		howTo: [
			'Choose US or metric units to match your car and your fuel price.',
			'Enter the trip distance and turn on round trip if you will return.',
			'Enter your fuel efficiency. Use your car’s average figure for the best estimate.',
			'Enter the fuel price per gallon or per litre and read the trip cost.'
		],
		formulas: [
			{
				title: 'US units',
				expression: 'Fuel needed (gal) = distance (mi) ÷ fuel efficiency (mpg)\nCost = fuel needed × price per gallon',
				variables: [
					{ symbol: 'mpg', meaning: 'Miles per US gallon' },
					{ symbol: 'distance', meaning: 'Total distance, doubled for a round trip' }
				]
			},
			{
				title: 'Metric units',
				expression: 'Fuel needed (L) = distance (km) × L/100 km ÷ 100\nCost = fuel needed × price per litre',
				variables: [{ symbol: 'L/100 km', meaning: 'Litres of fuel used per 100 kilometres' }]
			}
		],
		example: {
			title: 'A 250 mile round trip at 28 mpg with fuel at $3.45 per gallon',
			steps: [
				'Total distance: 250 × 2 = 500 miles',
				'Fuel needed: 500 ÷ 28 = 17.86 gallons',
				'Cost: 17.857 × $3.45 = $61.61'
			],
			result: 'The trip uses about 17.86 gallons and costs about $61.61 in fuel.'
		},
		faq: [
			{
				q: 'Where do I find my fuel efficiency?',
				a: 'Most cars show an average figure on the trip computer or in the fuel economy label. A figure from a recent tank of fuel, worked out as miles driven divided by gallons added, is often more accurate.'
			},
			{
				q: 'Does this include tolls, wear or parking?',
				a: 'No. It covers fuel only. Add tolls, parking and other running costs yourself if you want a full trip budget.'
			},
			{
				q: 'Why does the fuel use change with speed?',
				a: 'Fuel efficiency falls at high speed, in heavy traffic, with a full load and in cold weather. Use a figure that matches your usual driving for a closer estimate.'
			}
		]
	}
});
