import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num, plural } from '../format';
import meta from './concrete-calculator.meta';

/** 1 m³ = 35.3146667 ft³. */
const FT3_PER_M3 = 35.3146667;
/** Yield of a single bag, in cubic feet. */
const BAG_60_FT3 = 0.45;
const BAG_80_FT3 = 0.6;

const pos = (x: number) => Number.isFinite(x) && x > 0;

/** Show a field only for one unit system and one kind of shape (slab, or round column/hole). */
const show = (units: 'imperial' | 'metric', kind: 'slab' | 'round') => (v: InputValues) =>
	v.units === units && (kind === 'slab' ? v.shape === 'slab' : v.shape !== 'slab');

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'shape',
			label: 'Shape',
			type: 'select',
			display: 'menu',
			default: 'slab',
			options: [
				{ label: 'Slab or footing', value: 'slab' },
				{ label: 'Round column', value: 'column' },
				{ label: 'Round hole or post', value: 'hole' }
			]
		},
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'imperial',
			options: [
				{ label: 'Feet and inches', value: 'imperial' },
				{ label: 'Metric (m, cm)', value: 'metric' }
			]
		},
		// Feet and inches: slab
		{ id: 'lenFt', label: 'Length (feet)', type: 'number', default: 10, min: 0, max: 1000, step: 1, suffix: 'ft', decimal: false, width: 'half', visibleWhen: show('imperial', 'slab') },
		{ id: 'lenIn', label: 'Length (inches)', type: 'number', default: 0, min: 0, max: 11.9, step: 0.5, suffix: 'in', width: 'half', visibleWhen: show('imperial', 'slab') },
		{ id: 'widFt', label: 'Width (feet)', type: 'number', default: 12, min: 0, max: 1000, step: 1, suffix: 'ft', decimal: false, width: 'half', visibleWhen: show('imperial', 'slab') },
		{ id: 'widIn', label: 'Width (inches)', type: 'number', default: 0, min: 0, max: 11.9, step: 0.5, suffix: 'in', width: 'half', visibleWhen: show('imperial', 'slab') },
		{ id: 'thIn', label: 'Thickness', type: 'number', default: 4, min: 0.5, max: 60, step: 0.5, suffix: 'in', visibleWhen: show('imperial', 'slab') },
		// Feet and inches: round column, hole or post
		{ id: 'diaIn', label: 'Diameter', type: 'number', default: 12, min: 0.5, max: 240, step: 0.5, suffix: 'in', visibleWhen: show('imperial', 'round') },
		{ id: 'hFt', label: 'Height or depth (feet)', type: 'number', default: 8, min: 0, max: 1000, step: 1, suffix: 'ft', decimal: false, width: 'half', visibleWhen: show('imperial', 'round') },
		{ id: 'hIn', label: 'Height or depth (inches)', type: 'number', default: 0, min: 0, max: 11.9, step: 0.5, suffix: 'in', width: 'half', visibleWhen: show('imperial', 'round') },
		// Metric: slab
		{ id: 'lenM', label: 'Length', type: 'number', default: 3, min: 0, max: 1000, step: 0.01, suffix: 'm', visibleWhen: show('metric', 'slab') },
		{ id: 'widM', label: 'Width', type: 'number', default: 4, min: 0, max: 1000, step: 0.01, suffix: 'm', visibleWhen: show('metric', 'slab') },
		{ id: 'thCm', label: 'Thickness', type: 'number', default: 10, min: 0.5, max: 2000, step: 0.5, suffix: 'cm', visibleWhen: show('metric', 'slab') },
		// Metric: round column, hole or post
		{ id: 'diaCm', label: 'Diameter', type: 'number', default: 30, min: 0.5, max: 5000, step: 0.5, suffix: 'cm', visibleWhen: show('metric', 'round') },
		{ id: 'hM', label: 'Height or depth', type: 'number', default: 2.4, min: 0, max: 1000, step: 0.01, suffix: 'm', visibleWhen: show('metric', 'round') },
		{
			id: 'waste',
			label: 'Waste allowance',
			type: 'number',
			default: 10,
			min: 0,
			max: 50,
			step: 1,
			suffix: '%',
			help: 'Extra for spills, uneven ground and over-digging.'
		}
	],
	calculate(v): CalculationResult {
		const imperial = v.units === 'imperial';
		const isSlab = v.shape === 'slab';
		const waste = Number(v.waste);
		if (!Number.isFinite(waste) || waste < 0) {
			return { primaryResult: DASH, primaryLabel: 'Concrete needed', summary: 'Enter a waste allowance of 0% or more.' };
		}

		// Volume in cubic feet (imperial) or cubic metres (metric), before waste.
		let volFt3: number;
		let volM3: number;
		if (imperial) {
			const length = Number(v.lenFt) + Number(v.lenIn) / 12;
			const width = Number(v.widFt) + Number(v.widIn) / 12;
			const thickness = Number(v.thIn) / 12;
			const height = Number(v.hFt) + Number(v.hIn) / 12;
			const diameter = Number(v.diaIn) / 12;
			if (isSlab) {
				if (!pos(length) || !pos(width) || !pos(thickness)) return invalid();
				volFt3 = length * width * thickness;
			} else {
				if (!pos(diameter) || !pos(height)) return invalid();
				volFt3 = Math.PI * (diameter / 2) ** 2 * height;
			}
			volM3 = volFt3 / FT3_PER_M3;
		} else {
			const length = Number(v.lenM);
			const width = Number(v.widM);
			const thickness = Number(v.thCm) / 100;
			const height = Number(v.hM);
			const diameter = Number(v.diaCm) / 100;
			if (isSlab) {
				if (!pos(length) || !pos(width) || !pos(thickness)) return invalid();
				volM3 = length * width * thickness;
			} else {
				if (!pos(diameter) || !pos(height)) return invalid();
				volM3 = Math.PI * (diameter / 2) ** 2 * height;
			}
			volFt3 = volM3 * FT3_PER_M3;
		}

		const factor = 1 + waste / 100;
		const withWasteFt3 = volFt3 * factor;
		const withWasteM3 = volM3 * factor;
		const cubicYards = withWasteFt3 / 27;
		// A tiny epsilon stops exact multiples from rounding up an extra bag.
		const bags60 = Math.ceil(withWasteFt3 / BAG_60_FT3 - 1e-9);
		const bags80 = Math.ceil(withWasteFt3 / BAG_80_FT3 - 1e-9);

		return {
			primaryResult: imperial ? `${num(cubicYards, 2, 2)} cu yd` : `${num(withWasteM3, 2, 2)} m³`,
			primaryLabel: 'Concrete needed',
			summary: `Includes ${num(waste, 0)}% waste. Bag counts are for mixing by hand.`,
			secondaryMetrics: [
				{ label: 'Volume before waste', value: `${num(volFt3 / 27, 2, 2)} cu yd (${num(volM3, 2, 2)} m³)` },
				{ label: 'Volume with waste', value: `${num(cubicYards, 2, 2)} cu yd (${num(withWasteM3, 2, 2)} m³)` },
				{ label: '60 lb bags (0.45 cu ft each)', value: plural(bags60, 'bag') },
				{ label: '80 lb bags (0.6 cu ft each)', value: plural(bags80, 'bag') }
			]
		};
	},
	content: {
		intro:
			'Estimate how much ready-mix or bagged concrete a slab, footing, column or post needs, in cubic yards or cubic metres, with the number of 60 lb and 80 lb bags.',
		howTo: [
			'Choose the shape: a slab or footing, a round column, or a round hole or post.',
			'Pick feet and inches or metric, then enter the size of the shape.',
			'Set a waste allowance. The default of 10% covers spills and uneven ground.',
			'Read the volume to order, and the bag counts if you are mixing by hand.'
		],
		formulas: [
			{
				title: 'Slab or footing',
				expression: 'Volume = length × width × thickness',
				variables: [{ symbol: 'thickness', meaning: 'Depth of the pour, converted to the same unit as length' }]
			},
			{
				title: 'Round column, hole or post',
				expression: 'Volume = π × (diameter ÷ 2)² × height',
				variables: [
					{ symbol: 'π', meaning: 'About 3.14159' },
					{ symbol: 'height', meaning: 'Height of the column, or depth of the hole' }
				]
			},
			{
				title: 'Bags and waste',
				expression: 'Volume with waste = volume × (1 + waste % ÷ 100)\nBags = volume in cu ft ÷ bag yield',
				variables: [
					{ symbol: 'bag yield', meaning: '0.45 cu ft for a 60 lb bag, 0.6 cu ft for an 80 lb bag' },
					{ symbol: '1 cu yd', meaning: '27 cubic feet' }
				]
			}
		],
		example: {
			title: 'A 10 ft by 12 ft slab, 4 inches thick, with 10% waste',
			steps: [
				'Volume: 10 × 12 × (4 ÷ 12) = 40 cu ft',
				'With waste: 40 × 1.10 = 44 cu ft, or 44 ÷ 27 = 1.63 cu yd',
				'60 lb bags: 44 ÷ 0.45 = 97.8, rounded up to 98 bags',
				'80 lb bags: 44 ÷ 0.6 = 73.3, rounded up to 74 bags'
			],
			result: 'Order about 1.63 cubic yards, or 98 bags of 60 lb concrete.'
		},
		faq: [
			{
				q: 'How much concrete should I order for a slab?',
				a: 'Work out the volume, add 5% to 10% for waste and uneven ground, then round up. Ready-mix suppliers usually sell in quarter-yard steps, so ask them for the nearest increment.'
			},
			{
				q: 'Is a 60 lb bag the same as a 80 lb bag?',
				a: 'No. A 60 lb bag yields about 0.45 cubic feet of mixed concrete and an 80 lb bag yields about 0.6 cubic feet. Check the yield printed on the bag, as brands vary.'
			},
			{
				q: 'Why does a round column use a different formula?',
				a: 'A round column is a cylinder, so its volume is the area of the circular base times its height. Use the diameter of the finished column, and the depth for a hole or post.'
			}
		]
	}
});

function invalid(): CalculationResult {
	return {
		primaryResult: DASH,
		primaryLabel: 'Concrete needed',
		summary: 'Enter sizes greater than zero for every dimension.'
	};
}
