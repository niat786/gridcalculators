import { defineCalculator, type CalculationResult, type InputValues, type NumberInput } from '../types';
import { DASH, num } from '../format';
import meta from './density-calculator.meta';

/** Each unit as a multiple of the SI base unit (kg, m³, kg/m³). */
const MASS_KG: Record<string, number> = { kg: 1, g: 0.001, lb: 0.45359237 };
const VOLUME_M3: Record<string, number> = { m3: 1, L: 0.001, cm3: 0.000001, ft3: 0.028316846592 };
const DENSITY_KG_M3: Record<string, number> = { kgm3: 1, gcm3: 1000, lbft3: 0.45359237 / 0.028316846592 };

const MASS_LABEL: Record<string, string> = { kg: 'kg', g: 'g', lb: 'lb' };
const VOLUME_LABEL: Record<string, string> = { m3: 'm³', L: 'L', cm3: 'cm³', ft3: 'ft³' };
const DENSITY_LABEL: Record<string, string> = { kgm3: 'kg/m³', gcm3: 'g/cm³', lbft3: 'lb/ft³' };

/** Show a quantity field only when it is an input (not the answer) and its unit is chosen. */
const shown = (solveFor: string, unitKey: string, unit: string) => (v: InputValues) =>
	v.solve !== solveFor && v[unitKey] === unit;

const field = (
	id: string,
	label: string,
	suffix: string,
	def: number,
	step: number,
	visibleWhen: (v: InputValues) => boolean
): NumberInput => ({ id, label, type: 'number', default: def, min: 0, max: 1000000000, step, suffix, visibleWhen });

/** Three significant figures for large numbers, more decimals for small ones. */
const fmt = (x: number) => num(x, Math.abs(x) >= 1 ? 3 : 6);

const pos = (n: number) => Number.isFinite(n) && n > 0;

function invalid(label: string): CalculationResult {
	return { primaryResult: DASH, primaryLabel: label, summary: 'Enter a mass, volume and density greater than zero.' };
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'solve',
			label: 'Solve for',
			type: 'select',
			display: 'segmented',
			default: 'density',
			options: [
				{ label: 'Density', value: 'density' },
				{ label: 'Mass', value: 'mass' },
				{ label: 'Volume', value: 'volume' }
			]
		},
		{
			id: 'massUnit',
			label: 'Mass unit',
			type: 'select',
			display: 'segmented',
			default: 'kg',
			options: [
				{ label: 'kg', value: 'kg' },
				{ label: 'g', value: 'g' },
				{ label: 'lb', value: 'lb' }
			]
		},
		field('mass_kg', 'Mass', 'kg', 2.7, 0.1, shown('mass', 'massUnit', 'kg')),
		field('mass_g', 'Mass', 'g', 2700, 1, shown('mass', 'massUnit', 'g')),
		field('mass_lb', 'Mass', 'lb', 5.95, 0.01, shown('mass', 'massUnit', 'lb')),
		{
			id: 'volumeUnit',
			label: 'Volume unit',
			type: 'select',
			display: 'menu',
			default: 'L',
			options: [
				{ label: 'Cubic metres (m³)', value: 'm3' },
				{ label: 'Litres (L)', value: 'L' },
				{ label: 'Cubic centimetres (cm³)', value: 'cm3' },
				{ label: 'Cubic feet (ft³)', value: 'ft3' }
			]
		},
		field('vol_m3', 'Volume', 'm³', 0.001, 0.0001, shown('volume', 'volumeUnit', 'm3')),
		field('vol_L', 'Volume', 'L', 1, 0.1, shown('volume', 'volumeUnit', 'L')),
		field('vol_cm3', 'Volume', 'cm³', 1000, 1, shown('volume', 'volumeUnit', 'cm3')),
		field('vol_ft3', 'Volume', 'ft³', 0.0353, 0.001, shown('volume', 'volumeUnit', 'ft3')),
		{
			id: 'densityUnit',
			label: 'Density unit',
			type: 'select',
			display: 'segmented',
			default: 'gcm3',
			help: 'Water is about 1 g/cm³, or 1,000 kg/m³.',
			options: [
				{ label: 'kg/m³', value: 'kgm3' },
				{ label: 'g/cm³', value: 'gcm3' },
				{ label: 'lb/ft³', value: 'lbft3' }
			]
		},
		field('den_kgm3', 'Density', 'kg/m³', 1000, 1, shown('density', 'densityUnit', 'kgm3')),
		field('den_gcm3', 'Density', 'g/cm³', 1, 0.001, shown('density', 'densityUnit', 'gcm3')),
		field('den_lbft3', 'Density', 'lb/ft³', 62.4, 0.1, shown('density', 'densityUnit', 'lbft3'))
	],
	calculate(v): CalculationResult {
		const solve = String(v.solve);
		const massUnit = String(v.massUnit);
		const volumeUnit = String(v.volumeUnit);
		const densityUnit = String(v.densityUnit);
		if (!(massUnit in MASS_KG) || !(volumeUnit in VOLUME_M3) || !(densityUnit in DENSITY_KG_M3)) {
			return invalid('Density');
		}

		// Every quantity in SI base units: kg, m³ and kg/m³.
		const massIn = Number(v[`mass_${massUnit}`]) * MASS_KG[massUnit];
		const volumeIn = Number(v[`vol_${volumeUnit}`]) * VOLUME_M3[volumeUnit];
		const densityIn = Number(v[`den_${densityUnit}`]) * DENSITY_KG_M3[densityUnit];

		if (solve === 'mass') {
			if (!pos(densityIn) || !pos(volumeIn)) return invalid('Mass');
			const kg = densityIn * volumeIn;
			return {
				primaryResult: `${fmt(kg / MASS_KG[massUnit])} ${MASS_LABEL[massUnit]}`,
				primaryLabel: 'Mass',
				summary: 'Density × volume.',
				secondaryMetrics: [
					{ label: 'In kilograms', value: `${fmt(kg)} kg` },
					{ label: 'In grams', value: `${fmt(kg / MASS_KG.g)} g` },
					{ label: 'In pounds', value: `${fmt(kg / MASS_KG.lb)} lb` }
				]
			};
		}

		if (solve === 'volume') {
			if (!pos(massIn) || !pos(densityIn)) return invalid('Volume');
			const m3 = massIn / densityIn;
			return {
				primaryResult: `${fmt(m3 / VOLUME_M3[volumeUnit])} ${VOLUME_LABEL[volumeUnit]}`,
				primaryLabel: 'Volume',
				summary: 'Mass ÷ density.',
				secondaryMetrics: [
					{ label: 'In cubic metres', value: `${fmt(m3)} m³` },
					{ label: 'In litres', value: `${fmt(m3 / VOLUME_M3.L)} L` },
					{ label: 'In cubic feet', value: `${fmt(m3 / VOLUME_M3.ft3)} ft³` }
				]
			};
		}

		// Solving for density: shown in the chosen unit and in all three common units.
		if (!pos(massIn) || !pos(volumeIn)) return invalid('Density');
		const rho = massIn / volumeIn;
		return {
			primaryResult: `${fmt(rho / DENSITY_KG_M3[densityUnit])} ${DENSITY_LABEL[densityUnit]}`,
			primaryLabel: 'Density',
			summary: 'Mass ÷ volume, shown in all three common density units.',
			secondaryMetrics: [
				{ label: 'In kg/m³', value: `${fmt(rho)} kg/m³` },
				{ label: 'In g/cm³', value: `${fmt(rho / DENSITY_KG_M3.gcm3)} g/cm³` },
				{ label: 'In lb/ft³', value: `${fmt(rho / DENSITY_KG_M3.lbft3)} lb/ft³` }
			]
		};
	},
	content: {
		intro:
			'Solve the density formula for any of its three parts: density, mass or volume. Pick the units for each value, and the answer is converted for you.',
		howTo: [
			'Choose what to solve for: density, mass or volume.',
			'Pick a unit for each value you know, then type its amount.',
			'Read the answer in your chosen unit. For density, the same value is also shown in all three common units.'
		],
		formulas: [
			{
				title: 'Density',
				expression: 'ρ = m ÷ V',
				variables: [
					{ symbol: 'ρ', meaning: 'Density, the mass in each unit of volume (the Greek letter rho)' },
					{ symbol: 'm', meaning: 'Mass' },
					{ symbol: 'V', meaning: 'Volume' }
				]
			},
			{
				title: 'Mass and volume',
				expression: 'm = ρ × V\nV = m ÷ ρ',
				variables: []
			},
			{
				title: 'Unit conversions',
				expression: '1 lb = 0.45359237 kg\n1 ft³ = 0.028316846592 m³\n1 g/cm³ = 1,000 kg/m³\n1 lb/ft³ = 16.018463 kg/m³',
				variables: []
			}
		],
		example: {
			title: 'A 2.7 kg block with a volume of 1 litre',
			steps: [
				'Convert the volume: 1 L = 0.001 m³',
				'Density in kg/m³: 2.7 ÷ 0.001 = 2,700 kg/m³',
				'Density in g/cm³: 2,700 ÷ 1,000 = 2.7 g/cm³',
				'Density in lb/ft³: 2,700 ÷ 16.018463 = 168.555 lb/ft³'
			],
			result: 'The density is 2.7 g/cm³, which is 2,700 kg/m³ or 168.555 lb/ft³.'
		},
		faq: [
			{
				q: 'What is the difference between density and specific gravity?',
				a: 'Density is mass per unit of volume, such as g/cm³. Specific gravity is the density divided by the density of water, so it has no units. A density of 2.7 g/cm³ has a specific gravity of 2.7.'
			},
			{
				q: 'How do I convert g/cm³ to kg/m³?',
				a: 'Multiply by 1,000. For example, 1 g/cm³ equals 1,000 kg/m³, which is the density of water.'
			},
			{
				q: 'Why does the volume of a solid matter for density?',
				a: 'Density depends on how much space the material fills, so the volume must be the true volume of the object. For an irregular object, measure the water it displaces.'
			}
		]
	}
});
