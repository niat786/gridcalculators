import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num, plural } from '../format';
import meta from './time-calculator.meta';

const mode = (m: string) => (v: InputValues) => v.mode === m;

/** Split seconds into d/h/m/s parts (sign kept separately). */
export function splitSeconds(total: number) {
	const sign = total < 0 ? -1 : 1;
	let t = Math.round(Math.abs(total));
	const d = Math.floor(t / 86400);
	t -= d * 86400;
	const h = Math.floor(t / 3600);
	t -= h * 3600;
	const m = Math.floor(t / 60);
	const s = t - m * 60;
	return { sign, d, h, m, s };
}

export function describe(total: number): string {
	const { sign, d, h, m, s } = splitSeconds(total);
	const parts = [d && plural(d, 'day'), h && plural(h, 'hour'), m && plural(m, 'minute'), s && plural(s, 'second')].filter(Boolean);
	return `${sign < 0 ? '−' : ''}${parts.length ? parts.join(', ') : '0 seconds'}`;
}

function clock(total: number): string {
	const { sign, d, h, m, s } = splitSeconds(total);
	const hh = d * 24 + h;
	return `${sign < 0 ? '−' : ''}${hh}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'What do you want to do?',
			type: 'select',
			display: 'segmented',
			default: 'add',
			options: [
				{ label: 'Add or subtract times', value: 'add' },
				{ label: 'Add time to a date', value: 'date' }
			]
		},
		{ id: 'a', label: 'First time', type: 'duration', units: ['d', 'h', 'm', 's'], default: '0:2:45:0', visibleWhen: mode('add') },
		{
			id: 'op',
			label: 'Operation',
			type: 'select',
			display: 'segmented',
			default: 'plus',
			options: [
				{ label: 'Add (+)', value: 'plus' },
				{ label: 'Subtract (−)', value: 'minus' }
			],
			visibleWhen: mode('add')
		},
		{ id: 'b', label: 'Second time', type: 'duration', units: ['d', 'h', 'm', 's'], default: '0:1:30:30', visibleWhen: mode('add') },
		{ id: 'start', label: 'Start date', type: 'date', default: 'today', visibleWhen: mode('date') },
		{ id: 'clock', label: 'Start time', type: 'time', default: '09:00', visibleWhen: mode('date') },
		{
			id: 'dur',
			label: 'Time to add (use − to go back)',
			type: 'duration',
			units: ['d', 'h', 'm'],
			default: '0:8:30',
			allowNegative: true,
			visibleWhen: mode('date')
		}
	],
	calculate(v): CalculationResult {
		if (v.mode === 'date') {
			const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(v.start));
			const t = /^(\d{2}):(\d{2})$/.exec(String(v.clock));
			const dur = Number(v.dur);
			if (!m || !t || !Number.isFinite(dur)) return { primaryResult: DASH, primaryLabel: 'Ends at', summary: 'Enter a date, a time and a duration.' };
			// Wall-clock arithmetic in UTC so daylight-saving changes don't shift the answer.
			const startMs = Date.UTC(+m[1], +m[2] - 1, +m[3], +t[1], +t[2]);
			const end = new Date(startMs + dur * 1000);
			const date = end.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC' });
			const time = end.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', timeZone: 'UTC' });
			return {
				primaryResult: time,
				primaryLabel: 'Ends at',
				summary: date,
				secondaryMetrics: [
					{ label: dur < 0 ? 'Time subtracted' : 'Time added', value: describe(Math.abs(dur)) },
					{ label: 'In hours', value: num(Math.abs(dur) / 3600, 2) }
				]
			};
		}

		const a = Number(v.a);
		const b = Number(v.b);
		if (!Number.isFinite(a) || !Number.isFinite(b)) return { primaryResult: DASH, primaryLabel: 'Result', summary: 'Enter two times.' };
		const total = v.op === 'minus' ? a - b : a + b;
		return {
			primaryResult: clock(total),
			primaryLabel: 'Result (hours:minutes:seconds)',
			summary: describe(total),
			secondaryMetrics: [
				{ label: 'Total hours', value: num(total / 3600, 4) },
				{ label: 'Total minutes', value: num(total / 60, 2) },
				{ label: 'Total seconds', value: num(total, 0) }
			]
		};
	},
	content: {
		intro:
			'Add or subtract amounts of time in days, hours, minutes and seconds, or add a duration to a date and time to find exactly when something ends.',
		howTo: [
			'Choose whether to combine two times or add time to a date.',
			'Enter each time in the day, hour, minute and second boxes. Empty boxes count as zero.',
			'Pick add or subtract. Results carry over automatically (90 minutes becomes 1 hour 30 minutes).',
			'Read the result as h:mm:ss, in words, and as total hours, minutes or seconds.'
		],
		formulas: [
			{
				title: 'Convert everything to seconds',
				expression: 'total = days × 86,400 + hours × 3,600 + minutes × 60 + seconds',
				variables: []
			},
			{
				title: 'Convert back',
				expression: 'hours = ⌊total ÷ 3,600⌋, minutes = ⌊remainder ÷ 60⌋, seconds = remainder mod 60',
				variables: []
			}
		],
		example: {
			title: 'Add 2 h 45 min to 1 h 30 min 30 s',
			steps: [
				'2 h 45 min = 2 × 3,600 + 45 × 60 = 9,900 s',
				'1 h 30 min 30 s = 3,600 + 1,800 + 30 = 5,430 s',
				'Total = 9,900 + 5,430 = 15,330 s',
				'15,330 s = 4 h (14,400 s) + 15 min (900 s) + 30 s'
			],
			result: '4 hours, 15 minutes and 30 seconds (4:15:30).'
		},
		faq: [
			{
				q: 'How do I add hours and minutes?',
				a: 'Add the minutes together and the hours together. Every 60 minutes carries over as 1 hour. For example 2:45 + 1:30 = 3:75, which is 4:15.'
			},
			{
				q: 'How do I convert minutes to decimal hours?',
				a: 'Divide the minutes by 60. 45 minutes is 0.75 hours, so 2 hours 45 minutes is 2.75 hours. The “Total hours” line shows this for you.'
			},
			{
				q: 'Does adding time to a date account for daylight saving?',
				a: 'No. It adds exact clock time, so 24 hours always lands on the same clock time the next day. On a daylight-saving change the real elapsed time differs by an hour.'
			}
		]
	}
});
