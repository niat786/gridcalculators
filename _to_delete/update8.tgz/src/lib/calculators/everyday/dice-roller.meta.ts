import { defineMeta } from '../types';

export default defineMeta({
	slug: 'dice-roller',
	name: 'Dice Roller',
	category: 'everyday',
	shortDescription: 'Roll d4, d6, d8, d10, d12, d20 or d100 dice online, with modifiers.',
	metaTitle: 'Dice Roller — Roll d6, d20 and More Online',
	metaDescription:
		'Free online dice roller. Roll up to 20 dice of any type — d4, d6, d8, d10, d12, d20, d100 or custom — add a modifier and see each die and the total.',
	icon: 'box',
	keywords: ['dice roller', 'roll a dice', 'd20 roller', 'virtual dice', 'dnd dice roller'],
	updated: '2026-10-28'
});
