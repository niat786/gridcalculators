import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './shoe-size-conversion.meta';

type Row = { us: number; uk: number; eu: string; cm: number };

/** Common retail chart (Brannock-based). Brands differ by up to half a size. */
export const CHART: Record<'men' | 'women', Row[]> = {
	men: [
		{ us: 6, uk: 5.5, eu: '39', cm: 24 },
		{ us: 6.5, uk: 6, eu: '39', cm: 24.5 },
		{ us: 7, uk: 6.5, eu: '40', cm: 25 },
		{ us: 7.5, uk: 7, eu: '40–41', cm: 25.5 },
		{ us: 8, uk: 7.5, eu: '41', cm: 26 },
		{ us: 8.5, uk: 8, eu: '41–42', cm: 26.5 },
		{ us: 9, uk: 8.5, eu: '42', cm: 27 },
		{ us: 9.5, uk: 9, eu: '42–43', cm: 27.5 },
		{ us: 10, uk: 9.5, eu: '43', cm: 28 },
		{ us: 10.5, uk: 10, eu: '43–44', cm: 28.5 },
		{ us: 11, uk: 10.5, eu: '44', cm: 29 },
		{ us: 11.5, uk: 11, eu: '44–45', cm: 29.5 },
		{ us: 12, uk: 11.5, eu: '45', cm: 30 },
		{ us: 13, uk: 12.5, eu: '46', cm: 31 },
		{ us: 14, uk: 13.5, eu: '47', cm: 32 },
		{ us: 15, uk: 14.5, eu: '48', cm: 33 }
	],
	women: [
		{ us: 4, uk: 2, eu: '35', cm: 21 },
		{ us: 4.5, uk: 2.5, eu: '35', cm: 21.5 },
		{ us: 5, uk: 3, eu: '35–36', cm: 22 },
		{ us: 5.5, uk: 3.5, eu: '36', cm: 22.5 },
		{ us: 6, uk: 4, eu: '36–37', cm: 23 },
		{ us: 6.5, uk: 4.5, eu: '37', cm: 23.5 },
		{ us: 7, uk: 5, eu: '37–38', cm: 24 },
		{ us: 7.5, uk: 5.5, eu: '38', cm: 24.5 },
		{ us: 8, uk: 6, eu: '38–39', cm: 25 },
		{ us: 8.5, uk: 6.5, eu: '39', cm: 25.5 },
		{ us: 9, uk: 7, eu: '39–40', cm: 26 },
		{ us: 9.5, uk: 7.5, eu: '40', cm: 26.5 },
		{ us: 10, uk: 8, eu: '40–41', cm: 27 },
		{ us: 10.5, uk: 8.5, eu: '41', cm: 27.5 },
		{ us: 11, uk: 9, eu: '41–42', cm: 28 },
		{ us: 12, uk: 10, eu: '42–43', cm: 29 }
	]
};

const euValue = (eu: string) => {
	const parts = eu.split('–').map(Number);
	return parts.reduce((a, b) => a + b, 0) / parts.length;
};

/** The chart row closest to the entered size in the chosen system. */
export function findRow(who: 'men' | 'women', system: string, size: number): Row | undefined {
	const rows = CHART[who];
	const key = (r: Row) => (system === 'us' ? r.us : system === 'uk' ? r.uk : system === 'eu' ? euValue(r.eu) : r.cm);
	let best: Row | undefined;
	let gap = Infinity;
	for (const r of rows) {
		const d = Math.abs(key(r) - size);
		if (d < gap - 1e-9) {
			gap = d;
			best = r;
		}
	}
	// Outside the chart by more than a size: don't guess.
	const tolerance = system === 'cm' ? 1 : 1;
	return gap <= tolerance ? best : undefined;
}

const fmt = (n: number) => num(n, 1);
const sys = (s: string) => (v: InputValues) => v.system === s;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'who',
			label: 'Shoes for',
			type: 'select',
			display: 'segmented',
			default: 'men',
			options: [
				{ label: 'Men', value: 'men' },
				{ label: 'Women', value: 'women' }
			]
		},
		{
			id: 'system',
			label: 'Size system you know',
			type: 'select',
			display: 'segmented',
			default: 'us',
			options: [
				{ label: 'US', value: 'us' },
				{ label: 'UK', value: 'uk' },
				{ label: 'EU', value: 'eu' },
				{ label: 'cm', value: 'cm' }
			]
		},
		{ id: 'us', label: 'US size', type: 'number', default: 9, min: 1, max: 20, step: 0.5, visibleWhen: sys('us') },
		{ id: 'uk', label: 'UK size', type: 'number', default: 8.5, min: 1, max: 20, step: 0.5, visibleWhen: sys('uk') },
		{ id: 'eu', label: 'EU size', type: 'number', default: 42, min: 30, max: 52, step: 0.5, visibleWhen: sys('eu') },
		{ id: 'cm', label: 'Foot length', type: 'number', default: 27, min: 18, max: 36, step: 0.1, suffix: 'cm', visibleWhen: sys('cm'), help: 'Heel to longest toe' }
	],
	calculate(v): CalculationResult {
		const who = v.who === 'women' ? 'women' : 'men';
		const system = String(v.system);
		const size = Number(v[system]);
		if (!Number.isFinite(size)) return { primaryResult: DASH, primaryLabel: 'Converted sizes', summary: 'Enter a size.' };
		const row = findRow(who, system, size);
		if (!row) return { primaryResult: DASH, primaryLabel: 'Converted sizes', summary: `That size is outside our ${who === 'men' ? 'men’s' : 'women’s'} chart. Try the other chart, or check the brand’s own sizes.` };
		const primary = system === 'eu' ? `US ${fmt(row.us)}` : `EU ${row.eu}`;
		return {
			primaryResult: primary,
			primaryLabel: `${who === 'men' ? 'Men’s' : 'Women’s'} size`,
			summary: `US ${fmt(row.us)} · UK ${fmt(row.uk)} · EU ${row.eu} · foot length about ${fmt(row.cm)} cm.`,
			secondaryMetrics: [
				{ label: 'US', value: fmt(row.us) },
				{ label: 'UK', value: fmt(row.uk) },
				{ label: 'EU', value: row.eu },
				{ label: 'Foot length', value: `${fmt(row.cm)} cm (${num(row.cm / 2.54, 2)} in)` }
			],
			table: {
				title: `Full ${who === 'men' ? 'men’s' : 'women’s'} size chart`,
				collapsed: true,
				columns: [
					{ key: 'us', label: 'US' },
					{ key: 'uk', label: 'UK' },
					{ key: 'eu', label: 'EU' },
					{ key: 'cm', label: 'Foot (cm)', align: 'end' }
				],
				rows: CHART[who].map((r) => ({ us: fmt(r.us), uk: fmt(r.uk), eu: r.eu, cm: fmt(r.cm) }))
			}
		};
	},
	content: {
		intro:
			'Convert shoe sizes between the US, UK and European systems, or find your size from your foot length. Separate charts for men’s and women’s shoes.',
		howTo: [
			'Choose men’s or women’s shoes.',
			'Pick the size system you already know and enter your size.',
			'Read the matching sizes, or open the full chart.'
		],
		formulas: [
			{
				title: 'Rules of thumb',
				expression: 'Men: UK ≈ US − 0.5\nWomen: UK ≈ US − 2\nEU ≈ (foot length in cm + 1.5) × 1.5',
				variables: []
			}
		],
		example: {
			title: 'A men’s US 9',
			steps: ['Men’s UK is about half a size smaller: UK 8.5', 'Look up EU in the chart: 42', 'Foot length for US 9 is about 27 cm'],
			result: 'US 9 men’s ≈ UK 8.5 ≈ EU 42.'
		},
		faq: [
			{
				q: 'Why does my size differ between brands?',
				a: 'There is no single worldwide standard: each brand uses its own lasts and sizing. Treat any chart as a starting point and check the brand’s own size guide.'
			},
			{
				q: 'How do I measure my foot length?',
				a: 'Stand on a sheet of paper with your heel against a wall, mark the tip of your longest toe, and measure from the wall to the mark. Measure both feet in the evening and use the longer one.'
			},
			{
				q: 'How do men’s and women’s US sizes compare?',
				a: 'A women’s US size is about 1.5 sizes larger than the men’s for the same foot: a men’s 8 is roughly a women’s 9.5.'
			}
		]
	}
});
