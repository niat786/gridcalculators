import { defineCalculator } from '../types';
import meta from './dice-roller.meta';

export default defineCalculator({
	meta,
	widget: { name: 'dice' },
	inputs: [],
	calculate: () => ({ primaryResult: '', primaryLabel: '' }),
	content: {
		intro:
			'Roll virtual dice for board games, tabletop RPGs and classroom probability. Choose the dice type and how many, add a modifier, and see every die plus the total.',
		howTo: [
			'Pick the type of dice: d6 is an ordinary six-sided die, d20 is the twenty-sided die used in many RPGs.',
			'Choose how many dice to roll (up to 20) and any modifier to add or subtract.',
			'Press Roll. Earlier rolls stay listed so you can check them.'
		],
		formulas: [
			{
				title: 'Each die',
				expression: 'Result = uniform random integer from 1 to s; Total = sum of the dice + modifier',
				variables: [{ symbol: 's', meaning: 'number of sides' }]
			},
			{
				title: 'Average total',
				expression: 'Average = n × (s + 1) ÷ 2 + modifier',
				variables: [{ symbol: 'n', meaning: 'number of dice' }]
			}
		],
		example: {
			title: 'Rolling 2d6',
			steps: ['Each die shows 1 to 6 with equal chance', 'Totals range from 2 to 12; 7 is the most likely (6 of 36 ways, 16.7%)', 'Average total: 2 × 3.5 = 7'],
			result: 'A 2d6 roll averages 7.'
		},
		faq: [
			{
				q: 'What does “2d6+3” mean?',
				a: 'Roll two six-sided dice, add them, then add 3. The number before the d is how many dice; the number after is how many sides each has.'
			},
			{
				q: 'Is this dice roller fair?',
				a: 'Yes. Every roll uses your browser’s cryptographic random generator with bias removed, so each face is exactly as likely as any other. Nothing is sent to a server.'
			},
			{
				q: 'How do I roll with advantage in D&D?',
				a: 'Roll 2d20 and keep the higher die (or the lower one for disadvantage). Both dice are shown after each roll.'
			}
		]
	}
});
