import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num, pct } from '../format';
import meta from './dew-point-calculator.meta';

const fahrenheit = (v: InputValues) => v.units === 'f';
const celsius = (v: InputValues) => v.units === 'c';

/** Magnus coefficients from Alduchov and Eskridge (1996). */
const A = 17.625;
const B = 243.04; // °C

/** Dew point in °C from air temperature in °C and relative humidity in percent. */
export function dewPointC(tC: number, rh: number): number {
	const gamma = Math.log(rh / 100) + (A * tC) / (B + tC);
	return (B * gamma) / (A - gamma);
}

/** Comfort band from a dew point in °F, following a general National Weather Service guideline. */
export function comfortBand(tdF: number): string {
	if (tdF < 55) return 'Dry';
	if (tdF < 65) return 'Comfortable';
	if (tdF <= 70) return 'Humid';
	return 'Oppressive';
}

const BAND_TEXT: Record<string, string> = {
	Dry: 'Dry air. Skin and airways may feel dry.',
	Comfortable: 'Comfortable for most people.',
	Humid: 'Humid. Stickiness is noticeable.',
	Oppressive: 'Oppressive. Muggy and uncomfortable for most people.'
};

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'units',
			label: 'Temperature unit',
			type: 'select',
			display: 'segmented',
			default: 'c',
			options: [
				{ label: 'Celsius (°C)', value: 'c' },
				{ label: 'Fahrenheit (°F)', value: 'f' }
			]
		},
		{ id: 'tempC', label: 'Air temperature', type: 'number', default: 25, min: -60, max: 60, step: 0.1, suffix: '°C', visibleWhen: celsius },
		{ id: 'tempF', label: 'Air temperature', type: 'number', default: 77, min: -76, max: 140, step: 0.1, suffix: '°F', visibleWhen: fahrenheit },
		{ id: 'rh', label: 'Relative humidity', type: 'number', default: 60, min: 0, max: 100, step: 1, suffix: '%' }
	],
	calculate(v): CalculationResult {
		const isF = fahrenheit(v);
		const t = Number(isF ? v.tempF : v.tempC);
		const rh = Number(v.rh);
		if (!Number.isFinite(t) || !(rh > 0 && rh <= 100)) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Dew point',
				summary: 'Enter a temperature and a relative humidity above 0% and up to 100%.'
			};
		}
		const tC = isF ? ((t - 32) * 5) / 9 : t;
		const tdC = dewPointC(tC, rh);
		const tdF = (tdC * 9) / 5 + 32;
		const band = comfortBand(tdF);
		const unit = isF ? '°F' : '°C';
		const primary = isF ? `${num(tdF, 1, 1)} °F` : `${num(tdC, 1, 1)} °C`;
		const otherDew = isF ? `${num(tdC, 1, 1)} °C` : `${num(tdF, 1, 1)} °F`;
		const gap = isF ? (tC - tdC) * 1.8 : tC - tdC;

		return {
			primaryResult: primary,
			primaryLabel: 'Dew point',
			summary: BAND_TEXT[band],
			secondaryMetrics: [
				{ label: isF ? 'Dew point in °C' : 'Dew point in °F', value: otherDew },
				{ label: 'Comfort level', value: band },
				{ label: 'Air temperature', value: `${num(t, 1, 1)} ${unit}` },
				{ label: 'Air minus dew point', value: `${num(gap, 1, 1)} ${unit}` },
				{ label: 'Relative humidity', value: pct(rh, 1) }
			]
		};
	},
	content: {
		intro:
			'Find the dew point from the air temperature and relative humidity. The dew point is the temperature the air must cool to before its water vapour begins to condense, and it is a clearer guide to how humid the air feels than humidity alone.',
		howTo: [
			'Choose Celsius or Fahrenheit.',
			'Enter the air temperature.',
			'Enter the relative humidity, from 1% to 100%.',
			'Read the dew point, its comfort level and the gap between the air and the dew point.'
		],
		formulas: [
			{
				title: 'Step 1: intermediate value (Magnus formula)',
				expression: 'γ = ln(RH ÷ 100) + a × T ÷ (b + T)',
				variables: [
					{ symbol: 'T', meaning: 'air temperature in °C' },
					{ symbol: 'RH', meaning: 'relative humidity in %' },
					{ symbol: 'a', meaning: '17.625, a dimensionless coefficient' },
					{ symbol: 'b', meaning: '243.04 °C' },
					{ symbol: 'ln', meaning: 'natural logarithm' }
				]
			},
			{
				title: 'Step 2: dew point',
				expression: 'Td = b × γ ÷ (a − γ)',
				variables: [{ symbol: 'Td', meaning: 'dew point in °C' }]
			},
			{
				title: 'Comfort bands (general NWS guideline, dew point in °F)',
				expression: 'Below 55 dry · 55 to 65 comfortable · 65 to 70 humid · above 70 oppressive',
				variables: []
			}
		],
		example: {
			title: '25 °C air at 60% relative humidity',
			steps: [
				'Find γ: ln(0.60) + (17.625 × 25) ÷ (243.04 + 25) = 1.133',
				'Dew point: (243.04 × 1.133) ÷ (17.625 − 1.133) = 16.7 °C',
				'Convert: 16.7 °C is 62.1 °F, which falls in the comfortable band (55 to 65 °F)'
			],
			result: 'Dew point 16.7 °C (62.1 °F), comfortable.'
		},
		faq: [
			{
				q: 'What is dew point?',
				a: 'It is the temperature at which air, held at the same pressure, becomes saturated with water vapour. If the air cools to the dew point, dew, fog or condensation can form.'
			},
			{
				q: 'Why use dew point instead of relative humidity?',
				a: 'Relative humidity depends on temperature. 60% at 20 °C and 60% at 35 °C hold very different amounts of moisture. Dew point tracks the actual moisture in the air, so it matches how humid the air feels better.'
			},
			{
				q: 'How accurate is the Magnus formula?',
				a: 'Alduchov and Eskridge (1996) reported errors of about 0.4 °C over the range of normal weather temperatures. That is more than accurate enough for everyday use.'
			},
			{
				q: 'What dew point feels comfortable?',
				a: 'Under a general National Weather Service guideline, dew points below 55 °F feel dry, 55 to 65 °F comfortable, 65 to 70 °F humid and above 70 °F oppressive. People differ, so treat these bands as a guide.'
			}
		],
		sources: [{ title: 'National Weather Service (weather.gov)', url: 'https://www.weather.gov' }]
	}
});
