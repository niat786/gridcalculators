import { defineCalculator, type CalculationResult } from '../types';
import { DASH, num, plural } from '../format';
import meta from './roofing-calculator.meta';

const SQ_FT_PER_SQUARE = 100;
const BUNDLES_PER_SQUARE = 3;

/** Roof pitches as rise per 12 inches of run. */
const PITCHES = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '14', '16', '18', '20'];

const pos = (n: number) => Number.isFinite(n) && n > 0;

function invalid(summary: string): CalculationResult {
	return { primaryResult: DASH, primaryLabel: 'Roof area', summary };
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'length',
			label: 'House length',
			type: 'number',
			default: 40,
			min: 1,
			max: 1000,
			step: 0.5,
			suffix: 'ft',
			width: 'half',
			help: 'Measure the outside of the walls, not the roof.'
		},
		{ id: 'width', label: 'House width', type: 'number', default: 30, min: 1, max: 1000, step: 0.5, suffix: 'ft', width: 'half' },
		{
			id: 'overhang',
			label: 'Roof overhang',
			type: 'number',
			default: 12,
			min: 0,
			max: 72,
			step: 1,
			suffix: 'in',
			help: 'How far the roof reaches past the walls on each side.'
		},
		{
			id: 'pitch',
			label: 'Roof pitch',
			type: 'select',
			display: 'menu',
			default: '6',
			help: 'Rise in inches for every 12 inches of run.',
			options: PITCHES.map((p) => ({ label: `${p}/12`, value: p }))
		},
		{
			id: 'waste',
			label: 'Waste allowance',
			type: 'number',
			default: 10,
			min: 0,
			max: 50,
			step: 1,
			suffix: '%',
			help: 'Extra for cuts, hips, valleys and ridges.'
		}
	],
	calculate(v): CalculationResult {
		const length = Number(v.length);
		const width = Number(v.width);
		const overhangIn = Number(v.overhang);
		const rise = Number(v.pitch);
		const waste = Number(v.waste);

		if (!pos(length) || !pos(width)) return invalid('Enter a house length and width greater than zero.');
		if (!Number.isFinite(overhangIn) || overhangIn < 0) return invalid('Enter an overhang of 0 inches or more.');
		if (!pos(rise)) return invalid('Pick a roof pitch.');
		if (!Number.isFinite(waste) || waste < 0) return invalid('Enter a waste allowance of 0% or more.');

		// The roof reaches past the walls on all four sides, so add the overhang twice to each length.
		const overhang = overhangIn / 12;
		const plan = (length + 2 * overhang) * (width + 2 * overhang);
		const multiplier = Math.sqrt(1 + (rise / 12) ** 2);
		const roof = plan * multiplier;
		const squares = roof / SQ_FT_PER_SQUARE;
		const squaresWithWaste = squares * (1 + waste / 100);
		// A small epsilon stops exact multiples from adding an extra bundle.
		const bundles = Math.ceil(squaresWithWaste * BUNDLES_PER_SQUARE - 1e-9);

		return {
			primaryResult: `${num(roof, 0)} sq ft`,
			primaryLabel: 'Roof area',
			summary: `Includes ${num(waste, 0)}% waste. One roofing square is 100 sq ft.`,
			secondaryMetrics: [
				{ label: 'Roof area on the plan', value: `${num(plan, 0)} sq ft` },
				{ label: 'Pitch multiplier', value: num(multiplier, 4, 4) },
				{ label: 'Squares before waste', value: num(squares, 2, 2) },
				{ label: 'Squares with waste', value: num(squaresWithWaste, 2, 2) },
				{ label: 'Shingle bundles', value: plural(bundles, 'bundle') }
			]
		};
	},
	content: {
		intro:
			'Estimate the roof area of a house from its footprint, overhang and roof pitch, then work out roofing squares and the number of shingle bundles to order.',
		howTo: [
			'Enter the length and width of the house, measured on the outside of the walls.',
			'Enter the roof overhang in inches, then pick the roof pitch.',
			'Set a waste allowance. The default of 10% covers cuts and waste at the edges.',
			'Read the roof area, then order the number of bundles shown.'
		],
		formulas: [
			{
				title: 'Plan area',
				expression: 'Plan area = (length + 2 × overhang) × (width + 2 × overhang)',
				variables: [{ symbol: 'overhang', meaning: 'Overhang in feet, which is the inches ÷ 12' }]
			},
			{
				title: 'Pitch multiplier',
				expression: 'Multiplier = √(1 + (rise ÷ 12)²)',
				variables: [{ symbol: 'rise', meaning: 'The first number of the pitch, such as 6 for 6/12' }]
			},
			{
				title: 'Roof area, squares and bundles',
				expression:
					'Roof area = plan area × multiplier\nSquares = roof area ÷ 100\nBundles = squares × (1 + waste % ÷ 100) × 3, rounded up',
				variables: [
					{ symbol: 'square', meaning: 'A roofing unit of 100 sq ft' },
					{ symbol: '3', meaning: 'Shingle bundles per square, for most common shingles' }
				]
			}
		],
		example: {
			title: 'A 40 ft by 30 ft house, 12 in overhang, 6/12 pitch, 10% waste',
			steps: [
				'Plan area: (40 + 2 × 1) × (30 + 2 × 1) = 42 × 32 = 1,344 sq ft',
				'Pitch multiplier: √(1 + (6 ÷ 12)²) = √1.25 = 1.1180',
				'Roof area: 1,344 × 1.1180 = 1,502.6 sq ft',
				'Squares with waste: 1,502.6 ÷ 100 × 1.1 = 16.53',
				'Bundles: 16.53 × 3 = 49.59, rounded up to 50'
			],
			result: 'About 1,503 sq ft of roof, which needs 50 bundles of shingles.'
		},
		faq: [
			{
				q: 'How do I find my roof pitch?',
				a: 'Pitch is the rise in inches for every 12 inches of horizontal run. A roof that climbs 6 inches over 12 inches is a 6/12 pitch. Your roofer or a level and tape can confirm it.'
			},
			{
				q: 'What is a roofing square?',
				a: 'A roofing square is 100 square feet of roof. Shingles are sold by the square, and each square usually needs three bundles of standard shingles.'
			},
			{
				q: 'Why is the overhang included?',
				a: 'The overhang extends past the walls, so the roof covers more area than the footprint of the house. Leaving it out would underestimate the shingles you need.'
			}
		]
	}
});
