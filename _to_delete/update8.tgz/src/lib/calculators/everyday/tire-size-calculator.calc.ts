import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './tire-size-calculator.meta';

const isText = (v: InputValues) => v.entry !== 'parts';
const isParts = (v: InputValues) => v.entry === 'parts';

/** A tire size such as 225/45R17, with an optional letter prefix (P, LT) and optional R. */
const SIZE = /^\s*(?:[A-Za-z]{1,2}\s*)?\d{3}\s*\/\s*\d{2,3}\s*R?\s*\d{2}\s*$/i;
const OPTIONAL_SIZE = /^\s*$|^\s*(?:[A-Za-z]{1,2}\s*)?\d{3}\s*\/\s*\d{2,3}\s*R?\s*\d{2}\s*$/i;

const MM_PER_IN = 25.4;
const MM_PER_MILE = 1609344;
const MM_PER_KM = 1000000;

export interface TireDims {
	width: number; // mm
	aspect: number; // %
	rim: number; // inches
}

/** Parse "225/45R17" into width (mm), aspect (%) and rim (in). Returns null when it does not match. */
export function parseTireSize(text: string): TireDims | null {
	const m = text.match(/(\d{3})\s*\/\s*(\d{2,3})\s*R?\s*(\d{2})/i);
	if (!m) return null;
	return { width: Number(m[1]), aspect: Number(m[2]), rim: Number(m[3]) };
}

/** Overall diameter in mm: rim diameter plus two sidewalls. */
export function overallDiameterMm(d: TireDims): number {
	const sidewall = (d.width * d.aspect) / 100;
	return d.rim * MM_PER_IN + 2 * sidewall;
}

const signed = (n: number, decimals: number) => (n > 0 ? '+' : '') + num(n, decimals, decimals);

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'entry',
			label: 'Enter the size as',
			type: 'select',
			display: 'segmented',
			default: 'text',
			options: [
				{ label: 'Tire size', value: 'text' },
				{ label: 'Width, aspect, rim', value: 'parts' }
			]
		},
		{
			id: 'sizeText',
			label: 'Tire size',
			type: 'text',
			default: '225/45R17',
			placeholder: '225/45R17',
			maxLength: 20,
			pattern: SIZE,
			patternMessage: 'Use the form 225/45R17.',
			visibleWhen: isText
		},
		{ id: 'width', label: 'Section width', type: 'number', default: 225, min: 100, max: 400, step: 1, suffix: 'mm', decimal: false, visibleWhen: isParts },
		{ id: 'aspect', label: 'Aspect ratio', type: 'number', default: 45, min: 20, max: 90, step: 1, suffix: '%', decimal: false, visibleWhen: isParts },
		{ id: 'rim', label: 'Rim diameter', type: 'number', default: 17, min: 10, max: 30, step: 1, suffix: 'in', decimal: false, visibleWhen: isParts },
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'imp',
			options: [
				{ label: 'Inches and mph', value: 'imp' },
				{ label: 'Millimetres and km/h', value: 'met' }
			]
		},
		{
			id: 'compare',
			label: 'Second size to compare (optional)',
			help: 'The speedometer is assumed to be calibrated for the first size.',
			type: 'text',
			default: '',
			placeholder: '235/40R18',
			maxLength: 20,
			pattern: OPTIONAL_SIZE,
			patternMessage: 'Use the form 235/40R18, or leave this blank.'
		}
	],
	calculate(v): CalculationResult {
		const imperial = v.units !== 'met';
		const dims: TireDims | null =
			v.entry === 'parts'
				? { width: Number(v.width), aspect: Number(v.aspect), rim: Number(v.rim) }
				: parseTireSize(String(v.sizeText));
		if (!dims || !(dims.width > 0) || !(dims.aspect > 0) || !(dims.rim > 0) || !Number.isFinite(dims.width + dims.aspect + dims.rim)) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Overall diameter',
				summary: 'Enter a tire size such as 225/45R17, or a width, aspect ratio and rim diameter.'
			};
		}

		const sidewall = (dims.width * dims.aspect) / 100;
		const diameter = overallDiameterMm(dims);
		const circumference = Math.PI * diameter;
		const revs = (imperial ? MM_PER_MILE : MM_PER_KM) / circumference;
		const perWord = imperial ? 'mile' : 'km';

		const compareText = String(v.compare).trim();
		let diffValue = 'Not compared';
		let speedValue = 'Add a second size to compare';
		const speedLabel = imperial ? 'Actual speed at 60 mph on the speedometer' : 'Actual speed at 100 km/h on the speedometer';
		if (compareText !== '') {
			const other = parseTireSize(compareText);
			if (!other) {
				diffValue = 'Check the second size';
				speedValue = 'Check the second size';
			} else {
				const otherDiameter = overallDiameterMm(other);
				const pct = ((otherDiameter - diameter) / diameter) * 100;
				const actual = (imperial ? 60 : 100) * (otherDiameter / diameter);
				diffValue = `${signed(pct, 2)}%`;
				speedValue = `${num(actual, 1, 1)} ${imperial ? 'mph' : 'km/h'}`;
			}
		}

		return {
			primaryResult: imperial ? `${num(diameter / MM_PER_IN, 2, 2)} in` : `${num(diameter, 1, 1)} mm`,
			primaryLabel: 'Overall diameter',
			summary: `About ${num(revs, 0)} wheel turns per ${perWord} at this size.`,
			secondaryMetrics: [
				{ label: 'Sidewall height', value: imperial ? `${num(sidewall / MM_PER_IN, 2, 2)} in` : `${num(sidewall, 1, 1)} mm` },
				{ label: 'Rim diameter', value: imperial ? `${num(dims.rim, 0, 0)} in` : `${num(dims.rim * MM_PER_IN, 1, 1)} mm` },
				{
					label: 'Circumference',
					value: imperial ? `${num(circumference / MM_PER_IN, 1, 1)} in` : `${num(circumference, 1, 1)} mm`
				},
				{ label: `Revolutions per ${perWord}`, value: num(revs, 0, 0) },
				{ label: 'Diameter change (second size)', value: diffValue },
				{ label: speedLabel, value: speedValue }
			]
		};
	},
	content: {
		intro:
			'Read a tire size and work out its real dimensions: the overall diameter, sidewall height, circumference and how many turns the wheel makes per mile or kilometre. Add a second size to see how a change of tire affects the speedometer.',
		howTo: [
			'Enter the tire size as printed on the sidewall, such as 225/45R17, or choose Width, aspect, rim and enter the three numbers.',
			'Choose inches and mph, or millimetres and km/h.',
			'Optionally enter a second size to compare it with the first.',
			'Read the overall diameter, the speedometer check and the other figures.'
		],
		formulas: [
			{
				title: 'Sidewall and overall diameter',
				expression: 'Sidewall = width × aspect ÷ 100 · Diameter = rim × 25.4 + 2 × sidewall',
				variables: [
					{ symbol: 'width', meaning: 'section width, in mm (the first number)' },
					{ symbol: 'aspect', meaning: 'aspect ratio, in % (the second number)' },
					{ symbol: 'rim', meaning: 'rim diameter, in inches (the number after R)' }
				]
			},
			{
				title: 'Circumference and revolutions',
				expression: 'Circumference = π × diameter · Revolutions per mile = 1,609,344 mm ÷ circumference',
				variables: []
			},
			{
				title: 'Speedometer check (new size compared with the current size)',
				expression: 'Actual speed = speedometer reading × new diameter ÷ current diameter',
				variables: []
			}
		],
		example: {
			title: 'A 225/45R17 tire',
			steps: [
				'Sidewall: 225 × 45 ÷ 100 = 101.25 mm',
				'Overall diameter: 17 × 25.4 + 2 × 101.25 = 634.3 mm, which is 24.97 in',
				'Circumference: π × 634.3 = 1,992.7 mm',
				'Revolutions per mile: 1,609,344 ÷ 1,992.7 = 808'
			],
			result: '24.97 in overall diameter, and about 808 wheel turns per mile.'
		},
		faq: [
			{
				q: 'What do the numbers in a tire size mean?',
				a: 'In 225/45R17, 225 is the section width in millimetres, 45 is the aspect ratio (sidewall height as a percentage of width), R means radial construction, and 17 is the rim diameter in inches.'
			},
			{
				q: 'Why does a bigger tire make the speedometer read low?',
				a: 'The speedometer counts wheel turns and multiplies by the tire it was calibrated for. A larger tire covers more ground per turn, so the car travels faster than the display shows.'
			},
			{
				q: 'Does a 3% change in diameter matter?',
				a: 'It can. A 3% change at 60 mph means the speedometer is about 2 mph out. Changes above about 3% can also affect the odometer, ABS and stability systems, so check with your vehicle manual or a tire fitter.'
			},
			{
				q: 'Can I compare sizes with a different rim diameter?',
				a: 'Yes. The calculator uses the overall diameter, so a smaller rim with a taller sidewall can give almost the same result as a larger rim with a shorter one.'
			}
		]
	}
});
