import { defineCalculator } from '../types';
import meta from './password-generator.meta';

export default defineCalculator({
	meta,
	widget: { name: 'password' },
	inputs: [],
	calculate: () => ({ primaryResult: '', primaryLabel: '' }),
	content: {
		intro:
			'Create a strong, random password in one click. It is generated on your device with your browser’s cryptographic random number generator and is never sent or stored anywhere.',
		howTo: [
			'Choose a length: 16 or more characters is a good default.',
			'Pick which kinds of characters to include.',
			'Copy the password, or press New for another.',
			'Store it in a password manager rather than reusing it.'
		],
		formulas: [
			{
				title: 'Password strength (entropy)',
				expression: 'bits = length × log₂(number of possible characters)',
				variables: []
			}
		],
		example: {
			title: 'A 16-character password using all four character types',
			steps: ['Possible characters: 26 + 26 + 10 + 25 symbols = 87', 'log₂(87) ≈ 6.44 bits per character', '16 × 6.44 ≈ 103 bits'],
			result: 'About 103 bits of entropy: far beyond what any computer can guess by brute force.'
		},
		faq: [
			{
				q: 'Is it safe to generate a password on a website?',
				a: 'Here, yes: the password is made entirely in your browser using the Web Crypto API and never leaves your device. It isn’t saved, logged or added to the page address.'
			},
			{
				q: 'How long should my password be?',
				a: 'At least 12 characters, and 16 or more for important accounts. Length adds more strength than complexity.'
			},
			{
				q: 'Should I use a different password for every account?',
				a: 'Yes. Reusing passwords lets one data breach unlock your other accounts. A password manager makes unique passwords easy.'
			}
		],
		sources: [{ title: 'NIST SP 800-63B: Digital Identity Guidelines (authentication)', url: 'https://pages.nist.gov/800-63-3/sp800-63b.html' }]
	}
});
