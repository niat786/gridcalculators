import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num, plural } from '../format';
import meta from './base64-encode-decode.meta';

const STANDARD = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
const URL_SAFE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';

/** Decoding accepts both alphabets. */
const VALUE = new Map<string, number>();
[...STANDARD].forEach((ch, i) => VALUE.set(ch, i));
VALUE.set('-', 62);
VALUE.set('_', 63);

/** Bytes → Base64. Every 3 bytes (24 bits) become 4 characters of 6 bits each. */
export function base64Encode(bytes: Uint8Array, urlSafe: boolean): string {
	const alphabet = urlSafe ? URL_SAFE : STANDARD;
	let out = '';
	let i = 0;
	for (; i + 2 < bytes.length; i += 3) {
		const n = (bytes[i] << 16) | (bytes[i + 1] << 8) | bytes[i + 2];
		out += alphabet[(n >> 18) & 63] + alphabet[(n >> 12) & 63] + alphabet[(n >> 6) & 63] + alphabet[n & 63];
	}
	const left = bytes.length - i;
	if (left === 1) {
		const n = bytes[i] << 16;
		out += alphabet[(n >> 18) & 63] + alphabet[(n >> 12) & 63] + (urlSafe ? '' : '==');
	} else if (left === 2) {
		const n = (bytes[i] << 16) | (bytes[i + 1] << 8);
		out += alphabet[(n >> 18) & 63] + alphabet[(n >> 12) & 63] + alphabet[(n >> 6) & 63] + (urlSafe ? '' : '=');
	}
	return out;
}

export type Decoded = { ok: true; bytes: Uint8Array } | { ok: false; reason: string };

/** Base64 → bytes. Whitespace (line breaks) is ignored. Returns a reason when the text is not valid Base64. */
export function base64Decode(text: string): Decoded {
	const s = text.replace(/\s+/g, '');
	if (!/^[A-Za-z0-9+\/\-_]*={0,2}$/.test(s)) {
		return { ok: false, reason: 'Base64 uses only A–Z, a–z, 0–9, + and /, with = padding at the end. Check for stray characters.' };
	}
	const padding = s.length - s.replace(/=+$/, '').length;
	const body = s.slice(0, s.length - padding);
	if ((padding > 0 && s.length % 4 !== 0) || body.length % 4 === 1) {
		return { ok: false, reason: 'The length is not valid for Base64. A character may be missing or extra.' };
	}
	const bytes = new Uint8Array(Math.floor((body.length * 3) / 4));
	let acc = 0;
	let bits = 0;
	let o = 0;
	for (const ch of body) {
		acc = ((acc << 6) | (VALUE.get(ch) ?? 0)) & 0xffffff;
		bits += 6;
		if (bits >= 8) {
			bits -= 8;
			bytes[o++] = (acc >> bits) & 0xff;
		}
	}
	return { ok: true, bytes };
}

const chars = (s: string) => Array.from(s).length;
const utf8Bytes = (s: string) => new TextEncoder().encode(s).length;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'What do you want to do?',
			type: 'select',
			display: 'segmented',
			default: 'encode',
			options: [
				{ label: 'Encode text', value: 'encode' },
				{ label: 'Decode Base64', value: 'decode' }
			]
		},
		{
			id: 'plain',
			label: 'Text to encode',
			type: 'text',
			default: 'Café',
			multiline: true,
			monospace: true,
			placeholder: 'Type or paste text',
			visibleWhen: (v: InputValues) => v.mode !== 'decode'
		},
		{
			id: 'urlSafe',
			label: 'URL-safe alphabet',
			type: 'toggle',
			default: false,
			help: 'Uses - and _ instead of + and /, and leaves out = padding.',
			visibleWhen: (v: InputValues) => v.mode !== 'decode'
		},
		{
			id: 'encoded',
			label: 'Base64 to decode',
			type: 'text',
			default: 'SGVsbG8sIFdvcmxkIQ==',
			multiline: true,
			monospace: true,
			placeholder: 'Paste Base64 text',
			help: 'Both alphabets and missing padding are accepted.',
			visibleWhen: (v: InputValues) => v.mode === 'decode'
		}
	],
	calculate(v): CalculationResult {
		if (v.mode === 'decode') {
			const input = String(v.encoded);
			const inputBytes = utf8Bytes(input);
			if (input.replace(/\s+/g, '') === '') {
				return { primaryResult: DASH, primaryLabel: 'Decoded text', summary: 'Paste some Base64 text to decode.' };
			}
			const decoded = base64Decode(input);
			const fail = (reason: string): CalculationResult => ({
				primaryResult: DASH,
				primaryLabel: 'Decoded text',
				summary: reason,
				secondaryMetrics: [
					{ label: 'Input characters', value: num(chars(input), 0) },
					{ label: 'Decoded bytes', value: DASH },
					{ label: 'Decoded characters', value: DASH },
					{ label: 'Size change', value: DASH }
				]
			});
			if (!decoded.ok) return fail(decoded.reason);
			if (decoded.bytes.length === 0) return fail('This Base64 decodes to no data. Check the input.');
			let text: string;
			try {
				text = new TextDecoder('utf-8', { fatal: true }).decode(decoded.bytes);
			} catch {
				return fail('The decoded bytes are not UTF-8 text, so they cannot be shown here. The data may be binary, such as an image or a file.');
			}
			const change = (decoded.bytes.length / inputBytes - 1) * 100;
			return {
				primaryResult: text,
				primaryLabel: 'Decoded text',
				long: true,
				summary: `Decoded ${plural(decoded.bytes.length, 'byte')} into ${plural(chars(text), 'character')} of UTF-8 text.`,
				secondaryMetrics: [
					{ label: 'Input characters', value: num(chars(input), 0) },
					{ label: 'Decoded bytes', value: num(decoded.bytes.length, 0) },
					{ label: 'Decoded characters', value: num(chars(text), 0) },
					{ label: 'Size change', value: `${change >= 0 ? '+' : '−'}${num(Math.abs(change), 1)}%` }
				]
			};
		}

		const text = String(v.plain);
		if (text === '') {
			return { primaryResult: DASH, primaryLabel: 'Base64 output', summary: 'Enter some text to encode.' };
		}
		const bytes = new TextEncoder().encode(text);
		const out = base64Encode(bytes, Boolean(v.urlSafe));
		const change = (out.length / bytes.length - 1) * 100;
		return {
			primaryResult: out,
			primaryLabel: v.urlSafe ? 'URL-safe Base64' : 'Base64',
			long: true,
			summary: `${plural(bytes.length, 'byte')} of UTF-8 became ${plural(out.length, 'character')} of Base64.`,
			secondaryMetrics: [
				{ label: 'Input characters', value: num(chars(text), 0) },
				{ label: 'Input bytes (UTF-8)', value: num(bytes.length, 0) },
				{ label: 'Output characters', value: num(out.length, 0) },
				{ label: 'Size change', value: `+${num(change, 1)}%` }
			]
		};
	},
	content: {
		intro:
			'Convert text to Base64, a way to write any bytes with 64 safe ASCII characters, or decode Base64 back into readable text. Base64 is encoding, not encryption, so anyone can reverse it.',
		howTo: [
			'Choose Encode text or Decode Base64.',
			'Paste your text (or Base64) into the box. Line breaks in Base64 are ignored.',
			'Turn on URL-safe alphabet if the Base64 will go in a URL or a filename.',
			'Copy the result. Byte and character counts below it show how much the size changed.'
		],
		formulas: [
			{
				title: 'Output length',
				expression: 'characters = 4 × ⌈bytes ÷ 3⌉   (with = padding)',
				variables: [
					{ symbol: 'bytes', meaning: 'Length of the input after UTF-8 encoding' },
					{ symbol: '⌈ ⌉', meaning: 'Round up to a whole number' }
				]
			},
			{
				title: 'Each 6-bit character',
				expression: 'index = ⌊group ÷ 2ⁿ⌋ mod 64, for n = 18, 12, 6 and 0',
				variables: [
					{ symbol: 'group', meaning: 'The 24 bits of three input bytes, read as one number' },
					{ symbol: 'n', meaning: 'Bit position of each 6-bit slice' },
					{ symbol: 'index', meaning: 'Position in the Base64 alphabet (A = 0, + = 62, / = 63)' }
				]
			}
		],
		example: {
			title: 'Encoding “Hello, World!”',
			steps: [
				'Text to bytes: “Hello, World!” is 13 ASCII bytes.',
				'Groups: 13 bytes = four groups of 3 bytes (16 characters) plus 1 leftover byte (2 characters and ==).',
				'Total: 16 + 4 = 20 characters.'
			],
			result: 'SGVsbG8sIFdvcmxkIQ==, which is 20 characters, about 54% longer than the 13-byte input.'
		},
		faq: [
			{
				q: 'Is Base64 encryption?',
				a: 'No. Base64 only changes how bytes are written so they travel safely through systems that expect plain text. Anyone can decode it with no key. Use real encryption, such as AES, to keep data secret.'
			},
			{
				q: 'Why is Base64 longer than the original?',
				a: 'Base64 uses 4 characters for every 3 bytes, so the output is about one third larger. Padding with = can add up to two more characters.'
			},
			{
				q: 'What is URL-safe Base64?',
				a: 'It swaps + for - and / for _, and usually drops = padding, so the text can sit in a URL or filename without escaping. Many JWT tokens and web-safe identifiers use this form.'
			},
			{
				q: 'Why does my Base64 fail to decode?',
				a: 'Common causes are a missing or extra character, a character outside the Base64 set, or data that is not text. If the bytes are an image or file, they will not decode to readable text.'
			}
		],
		sources: [
			{ title: 'RFC 4648 — The Base16, Base32, and Base64 Data Encodings', url: 'https://www.rfc-editor.org/rfc/rfc4648' },
			{ title: 'RFC 3629 — UTF-8, a transformation format of ISO 10646', url: 'https://www.rfc-editor.org/rfc/rfc3629' }
		]
	}
});
