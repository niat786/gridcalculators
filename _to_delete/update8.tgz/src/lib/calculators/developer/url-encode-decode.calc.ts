import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './url-encode-decode.meta';

const chars = (s: string) => Array.from(s).length;
const escapes = (s: string) => (s.match(/%/g) ?? []).length;
const utf8Bytes = (s: string) => new TextEncoder().encode(s).length;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'What do you want to do?',
			type: 'select',
			display: 'segmented',
			default: 'encode',
			options: [
				{ label: 'Encode', value: 'encode' },
				{ label: 'Decode', value: 'decode' }
			]
		},
		{
			id: 'method',
			label: 'Method',
			type: 'select',
			display: 'menu',
			default: 'component',
			options: [
				{ label: 'Query value (encodeURIComponent)', value: 'component' },
				{ label: 'Full URL (encodeURI)', value: 'url' }
			],
			help: 'Query value escapes everything except letters, digits and - _ . ! ~ * \' ( ). Full URL also keeps / ? & = # : @ + $ , ; and %.'
		},
		{
			id: 'plain',
			label: 'Text to encode',
			type: 'text',
			default: 'https://example.com/search?q=café menu & tea',
			multiline: true,
			monospace: true,
			placeholder: 'Type or paste text or a URL',
			visibleWhen: (v: InputValues) => v.mode !== 'decode'
		},
		{
			id: 'encoded',
			label: 'Text to decode',
			type: 'text',
			default: 'https://example.com/search?q=caf%C3%A9%20menu%20%26%20tea',
			multiline: true,
			monospace: true,
			placeholder: 'Paste percent-encoded text',
			help: 'Full URL decoding leaves reserved escapes such as %2F or %26 in place.',
			visibleWhen: (v: InputValues) => v.mode === 'decode'
		}
	],
	calculate(v): CalculationResult {
		const useUrl = v.method === 'url';
		if (v.mode === 'decode') {
			const input = String(v.encoded);
			if (input === '') return { primaryResult: DASH, primaryLabel: 'Decoded text', summary: 'Paste some encoded text to decode.' };
			const decodeFn = useUrl ? decodeURI : decodeURIComponent;
			let text: string;
			try {
				text = decodeFn(input);
			} catch {
				return {
					primaryResult: DASH,
					primaryLabel: 'Decoded text',
					summary: 'A % must be followed by two hex digits (0–9, A–F), and multi-byte characters such as %C3%A9 need all their bytes.',
					secondaryMetrics: [
						{ label: 'Input characters', value: num(chars(input), 0) },
						{ label: 'Escape sequences (%XX)', value: num(escapes(input), 0) },
						{ label: 'Output characters', value: DASH },
						{ label: 'Output bytes (UTF-8)', value: DASH }
					]
				};
			}
			return {
				primaryResult: text,
				primaryLabel: 'Decoded text',
				long: true,
				summary: useUrl
					? 'Decoded with decodeURI. Escapes for reserved characters such as %2F or %26 stay encoded.'
					: 'Decoded with decodeURIComponent, so every escape becomes its character.',
				secondaryMetrics: [
					{ label: 'Input characters', value: num(chars(input), 0) },
					{ label: 'Escape sequences (%XX)', value: num(escapes(input), 0) },
					{ label: 'Output characters', value: num(chars(text), 0) },
					{ label: 'Output bytes (UTF-8)', value: num(utf8Bytes(text), 0) }
				]
			};
		}

		const text = String(v.plain);
		if (text === '') return { primaryResult: DASH, primaryLabel: 'Encoded text', summary: 'Enter some text to encode.' };
		const encodeFn = useUrl ? encodeURI : encodeURIComponent;
		let out: string;
		try {
			out = encodeFn(text);
		} catch {
			return {
				primaryResult: DASH,
				primaryLabel: 'Encoded text',
				summary: 'The text contains a broken character (half of a surrogate pair) that cannot be encoded.'
			};
		}
		return {
			primaryResult: out,
			primaryLabel: 'Encoded text',
			long: true,
			summary: useUrl
				? 'Encoded with encodeURI. Reserved characters such as / ? & = are kept, so the URL structure stays intact.'
				: 'Encoded with encodeURIComponent. Reserved characters such as / ? & = are escaped, so the value stays in one piece.',
			secondaryMetrics: [
				{ label: 'Input characters', value: num(chars(text), 0) },
				{ label: 'Input bytes (UTF-8)', value: num(utf8Bytes(text), 0) },
				{ label: 'Output characters', value: num(chars(out), 0) },
				{ label: 'Escape sequences (%XX)', value: num(escapes(out), 0) }
			]
		};
	},
	content: {
		intro:
			'Percent-encode text so it can sit safely inside a URL, or decode %XX escapes back to readable text. Choose the query value method for a single parameter and the full URL method for a whole address.',
		howTo: [
			'Choose Encode or Decode.',
			'Pick Query value to encode one parameter, or Full URL to keep a whole address working.',
			'Paste your text and read the result. Non-English letters become several %XX bytes in UTF-8.',
			'Check the escape count in the metrics to see how many characters were changed.'
		],
		formulas: [
			{
				title: 'Percent encoding',
				expression: 'character → UTF-8 bytes → each byte as %HH',
				variables: [
					{ symbol: '%HH', meaning: 'A byte written as a percent sign and two hexadecimal digits' },
					{ symbol: 'é', meaning: 'Encodes to two bytes, C3 and A9, so it becomes %C3%A9' }
				]
			},
			{
				title: 'Output length',
				expression: 'escaped length = unreserved characters + 3 × escaped bytes',
				variables: [
					{ symbol: '3', meaning: 'Each escaped byte takes three characters: %, and two hex digits' }
				]
			}
		],
		example: {
			title: 'Encoding a search phrase as a query value',
			steps: [
				'Input: café menu & tea (é is two UTF-8 bytes).',
				'Space becomes %20, & becomes %26, and é becomes %C3%A9.',
				'Count the escapes: %C3, %A9, %20, %20, %26 and %20 make 6 sequences.'
			],
			result: 'caf%C3%A9%20menu%20%26%20tea'
		},
		faq: [
			{
				q: 'What is the difference between encodeURI and encodeURIComponent?',
				a: 'encodeURIComponent escapes everything except a few safe letters and symbols, so it suits one query value. encodeURI leaves structural characters such as / ? & = # alone, so it suits a complete URL.'
			},
			{
				q: 'Why does a space become %20 and sometimes +?',
				a: '%20 is the standard escape for a space. Some HTML form submissions use + for spaces instead. This tool keeps + as a literal plus sign when decoding, so check which convention your system uses.'
			},
			{
				q: 'Why did my decode fail?',
				a: 'A % must be followed by exactly two hex digits. Multi-byte characters also need all their bytes, so %C3 on its own is invalid. Fix the escape and try again.'
			},
			{
				q: 'Should I encode a whole URL?',
				a: 'Usually not. Encode each value on its own with the query value method, then join them into the URL. Encoding the whole URL would also escape the : and / that keep it working.'
			}
		],
		sources: [
			{ title: 'RFC 3986 — Uniform Resource Identifier (URI): Generic Syntax', url: 'https://www.rfc-editor.org/rfc/rfc3986' }
		]
	}
});
