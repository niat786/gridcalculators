import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num, plural } from '../format';
import meta from './bandwidth-calculator.meta';

/** Size units as powers of the base (1 = KB, 4 = TB). */
function sizeExponent(unit: string): number | undefined {
	switch (unit) {
		case 'KB':
			return 1;
		case 'MB':
			return 2;
		case 'GB':
			return 3;
		case 'TB':
			return 4;
		default:
			return undefined;
	}
}

/** Speeds are always decimal: 1 Mbps = 1,000,000 bits per second. */
function speedBits(unit: string): number | undefined {
	switch (unit) {
		case 'Kbps':
			return 1e3;
		case 'Mbps':
			return 1e6;
		case 'Gbps':
			return 1e9;
		default:
			return undefined;
	}
}

function hms(total: number): string {
	const h = Math.floor(total / 3600);
	const m = Math.floor((total % 3600) / 60);
	const s = total % 60;
	return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function words(total: number): string {
	const h = Math.floor(total / 3600);
	const m = Math.floor((total % 3600) / 60);
	const s = total % 60;
	const parts: string[] = [];
	if (h > 0) parts.push(plural(h, 'hour'));
	if (m > 0) parts.push(plural(m, 'minute'));
	if (s > 0 || parts.length === 0) parts.push(plural(s, 'second'));
	return parts.join(', ');
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'What do you want to calculate?',
			type: 'select',
			display: 'segmented',
			default: 'download',
			options: [
				{ label: 'Download time', value: 'download' },
				{ label: 'Monthly data', value: 'monthly' }
			]
		},
		{
			id: 'base',
			label: 'Size units',
			type: 'select',
			display: 'segmented',
			default: 'decimal',
			options: [
				{ label: 'Decimal (1,000)', value: 'decimal' },
				{ label: 'Binary (1,024)', value: 'binary' }
			],
			help: 'Storage and network sizes usually use 1,000. Many operating systems show file sizes in 1,024 steps.',
			visibleWhen: (v: InputValues) => v.mode !== 'monthly'
		},
		{
			id: 'size',
			label: 'File size',
			type: 'number',
			default: 4.7,
			min: 0.001,
			max: 1000000,
			step: 0.1,
			visibleWhen: (v: InputValues) => v.mode !== 'monthly'
		},
		{
			id: 'sizeUnit',
			label: 'Size unit',
			type: 'select',
			display: 'segmented',
			default: 'GB',
			options: [
				{ label: 'KB', value: 'KB' },
				{ label: 'MB', value: 'MB' },
				{ label: 'GB', value: 'GB' },
				{ label: 'TB', value: 'TB' }
			],
			visibleWhen: (v: InputValues) => v.mode !== 'monthly'
		},
		{
			id: 'speed',
			label: 'Connection speed',
			type: 'number',
			default: 100,
			min: 0.001,
			max: 100000,
			step: 1,
			visibleWhen: (v: InputValues) => v.mode !== 'monthly'
		},
		{
			id: 'avg',
			label: 'Average speed used',
			type: 'number',
			default: 20,
			min: 0,
			max: 100000,
			step: 1,
			help: 'Your typical speed while in use, not the plan maximum.',
			visibleWhen: (v: InputValues) => v.mode === 'monthly'
		},
		{
			id: 'speedUnit',
			label: 'Speed unit',
			type: 'select',
			display: 'segmented',
			default: 'Mbps',
			options: [
				{ label: 'Kbps', value: 'Kbps' },
				{ label: 'Mbps', value: 'Mbps' },
				{ label: 'Gbps', value: 'Gbps' }
			]
		},
		{
			id: 'hours',
			label: 'Hours in use per day',
			type: 'number',
			default: 6,
			min: 0,
			max: 24,
			step: 0.5,
			suffix: 'hours',
			visibleWhen: (v: InputValues) => v.mode === 'monthly'
		},
		{
			id: 'days',
			label: 'Days per month',
			type: 'number',
			default: 30,
			min: 1,
			max: 31,
			step: 1,
			suffix: 'days',
			decimal: false,
			visibleWhen: (v: InputValues) => v.mode === 'monthly'
		}
	],
	calculate(v): CalculationResult {
		const sp = speedBits(String(v.speedUnit));

		if (v.mode === 'monthly') {
			const avg = Number(v.avg);
			const hours = Number(v.hours);
			const days = Number(v.days);
			if (sp === undefined || !(avg >= 0) || !(hours >= 0) || !(days > 0)) {
				return { primaryResult: DASH, primaryLabel: 'Data used per month', summary: 'Enter an average speed, hours and days.' };
			}
			const bytesPerSecond = (avg * sp) / 8;
			const perDay = bytesPerSecond * 3600 * hours;
			const perMonth = perDay * days;
			return {
				primaryResult: `${num(perMonth / 1e9, 2)} GB`,
				primaryLabel: 'Data used per month',
				summary: `${num(hours, 1)} hours a day for ${plural(days, 'day')} at ${num(avg, 2)} ${String(v.speedUnit)} on average, in decimal GB.`,
				secondaryMetrics: [
					{ label: 'Per day', value: `${num(perDay / 1e9, 2)} GB` },
					{ label: 'Per hour in use', value: `${num((bytesPerSecond * 3600) / 1e9, 2)} GB` },
					{ label: 'Total in GiB (binary)', value: `${num(perMonth / 1024 ** 3, 2)} GiB` },
					{ label: 'Average transfer rate', value: `${num(bytesPerSecond / 1e6, 2)} MB/s` }
				]
			};
		}

		const size = Number(v.size);
		const speed = Number(v.speed);
		const exp = sizeExponent(String(v.sizeUnit));
		if (!(size > 0) || !(speed > 0) || exp === undefined || sp === undefined) {
			return { primaryResult: DASH, primaryLabel: 'Download time (h:mm:ss)', summary: 'Enter a file size and a speed above zero.' };
		}
		// Size in bytes, then bits: every byte is 8 bits. Speeds are already in bits per second.
		const base = v.base === 'binary' ? 1024 : 1000;
		const bits = size * base ** exp * 8;
		const bitsPerSecond = speed * sp;
		const seconds = bits / bitsPerSecond;
		const total = Math.round(seconds);

		return {
			primaryResult: hms(total),
			primaryLabel: 'Download time (h:mm:ss)',
			summary: `About ${words(total)} at ${num(speed, 2)} ${String(v.speedUnit)}, before protocol overhead and congestion.`,
			secondaryMetrics: [
				{ label: 'Size in bits', value: num(bits, 0) },
				{ label: 'Transfer rate (MB/s)', value: num(bitsPerSecond / 8 / 1e6, 2) },
				{ label: 'Time in seconds', value: num(seconds, 2) },
				{ label: 'Time in hours', value: num(seconds / 3600, 3) }
			]
		};
	},
	content: {
		intro:
			'Estimate how long a file takes to download at a given speed, or how much data a month of daily use will use. Speeds are in bits, file sizes in bytes, so the calculator multiplies by 8 when it converts.',
		howTo: [
			'Choose Download time, or Monthly data.',
			'For a download, enter the file size and unit, then the connection speed and its unit.',
			'For monthly data, enter your average speed, the hours you use it each day and the number of days.',
			'Read the result. Download times are rounded to the nearest second.'
		],
		formulas: [
			{
				title: 'Download time',
				expression: 'time (s) = file size (bytes) × 8 ÷ speed (bits per second)',
				variables: [
					{ symbol: '× 8', meaning: 'Converts bytes to bits. One byte is 8 bits.' },
					{ symbol: 'speed', meaning: 'Mbps × 1,000,000 or Kbps × 1,000 or Gbps × 1,000,000,000' }
				]
			},
			{
				title: 'Monthly data',
				expression: 'GB per month = average speed (bits/s) ÷ 8 × hours × 3,600 × days ÷ 10⁹',
				variables: [
					{ symbol: '÷ 8', meaning: 'Converts bits per second to bytes per second' },
					{ symbol: '10⁹', meaning: 'Bytes in one decimal gigabyte' }
				]
			},
			{
				title: 'Decimal or binary',
				expression: 'decimal: 1 GB = 1,000³ bytes;   binary: 1 GiB = 1,024³ bytes',
				variables: [{ symbol: 'KiB, MiB', meaning: 'Binary units, which some systems label KB and MB anyway' }]
			}
		],
		example: {
			title: 'A 4.7 GB file on a 100 Mbps connection',
			steps: [
				'Size in bits: 4.7 GB × 1,000,000,000 × 8 = 37,600,000,000 bits.',
				'Speed in bits per second: 100 Mbps = 100,000,000 bits per second.',
				'Time: 37,600,000,000 ÷ 100,000,000 = 376 seconds.',
				'Convert: 376 seconds = 6 minutes and 16 seconds.'
			],
			result: '0:06:16, or a transfer rate of 12.5 MB/s.'
		},
		faq: [
			{
				q: 'Why does my download run at one eighth of my plan speed?',
				a: 'Internet plans are sold in bits per second (Mbps), but file sizes are in bytes (MB). One byte is 8 bits, so 100 Mbps moves about 12.5 MB of data each second. Protocol overhead and shared networks lower it further.'
			},
			{
				q: 'Why does my file look bigger on my computer than on the label?',
				a: 'Some systems count in 1,024-byte steps and label them KB, MB and GB. Storage and network labels usually use 1,000. A 1 GB file is 1,000,000,000 bytes in decimal and 1,073,741,824 bytes in binary.'
			},
			{
				q: 'How much data does streaming use?',
				a: 'It depends on the quality and the device. Use your own average speed from a speed test or your router statistics, and the hours you actually stream. The monthly result is an estimate, so give it a margin.'
			},
			{
				q: 'Is the download time exact?',
				a: 'No. It is the best-case time at your speed. Real transfers are slower because of overhead, Wi-Fi limits, server speed and other devices on the network.'
			}
		],
		sources: [
			{ title: 'IEC 80000-13 — Quantities and units, binary prefixes (International Electrotechnical Commission)', url: 'https://www.iec.ch' }
		]
	}
});
