import { defineMeta } from '../types';

export default defineMeta({
	slug: 'password-generator',
	name: 'Password Generator',
	category: 'developer',
	shortDescription: 'Strong random passwords, made privately in your browser.',
	metaTitle: 'Password Generator — Strong, Random & Private',
	metaDescription:
		'Free password generator. Create strong random passwords with your choice of length and characters, made in your browser with cryptographic randomness.',
	icon: 'lock',
	keywords: ['password generator', 'random password', 'strong password', 'secure password', 'password maker'],
	updated: '2026-10-28'
});
