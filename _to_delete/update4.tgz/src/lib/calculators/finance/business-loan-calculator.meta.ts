import { defineMeta } from '../types';

export default defineMeta({
	slug: 'business-loan-calculator',
	name: 'Business Loan Calculator',
	category: 'finance',
	shortDescription: 'Loan payment, total interest, origination fee and effective APR.',
	metaTitle: 'Business Loan Calculator — Payment & Effective APR',
	metaDescription:
		'Free business loan calculator. Enter the amount, rate, term and origination fee to see your monthly or weekly payment, total cost and effective APR.',
	icon: 'wallet',
	keywords: ['business loan calculator', 'small business loan payment', 'origination fee calculator', 'business loan apr', 'weekly loan payment'],
	updated: '2026-10-28'
});
