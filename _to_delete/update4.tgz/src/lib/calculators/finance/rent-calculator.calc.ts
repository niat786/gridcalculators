import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, money, pct } from '../format';
import meta from './rent-calculator.meta';

/** Share of gross monthly income that rent should not pass. */
const RENT_SHARE = 0.3;
/** Share of gross monthly income for rent plus all other debt payments. */
const TOTAL_DEBT_SHARE = 0.36;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Find',
			type: 'select',
			display: 'segmented',
			default: 'afford',
			options: [
				{ label: 'Rent I can afford', value: 'afford' },
				{ label: 'Income needed', value: 'needed' }
			]
		},
		{
			id: 'income',
			label: 'Gross annual income',
			type: 'number',
			default: 75000,
			min: 0,
			max: 100_000_000,
			step: 1000,
			prefix: '$',
			suffix: '/yr',
			help: 'Before tax.',
			visibleWhen: (v) => v.mode === 'afford'
		},
		{
			id: 'debts',
			label: 'Monthly debt payments',
			type: 'number',
			default: 400,
			min: 0,
			max: 1_000_000,
			step: 50,
			prefix: '$',
			suffix: '/mo',
			help: 'Car loans, credit cards, student loans. Enter 0 if none.',
			visibleWhen: (v) => v.mode === 'afford'
		},
		{
			id: 'rent',
			label: 'Monthly rent',
			type: 'number',
			default: 1800,
			min: 0,
			max: 1_000_000,
			step: 50,
			prefix: '$',
			suffix: '/mo',
			visibleWhen: (v) => v.mode === 'needed'
		}
	],
	calculate(v: InputValues): CalculationResult {
		if (v.mode === 'needed') {
			const rent = Number(v.rent);
			if (!(rent > 0)) {
				return {
					primaryResult: DASH,
					primaryLabel: 'Annual income needed',
					summary: 'Enter the monthly rent you are looking at.'
				};
			}
			const grossMonthly = rent / RENT_SHARE;
			const income = grossMonthly * 12;
			return {
				primaryResult: money(income),
				primaryLabel: 'Annual income needed',
				summary: `Rent of ${money(rent)} a month needs about ${money(grossMonthly)} a month before tax, if rent is 30% of income.`,
				secondaryMetrics: [
					{ label: 'Gross monthly income needed', value: money(grossMonthly) },
					{ label: '40× monthly rent (landlord rule)', value: money(rent * 40) },
					{ label: 'Annual rent', value: money(rent * 12) },
					{ label: 'Monthly rent', value: money(rent) }
				]
			};
		}

		const income = Number(v.income);
		const debts = Number(v.debts);
		const invalid = (): CalculationResult => ({
			primaryResult: DASH,
			primaryLabel: 'Affordable monthly rent',
			summary: 'Enter your yearly income and your monthly debt payments, with 0 for no debts.'
		});
		if (!(income > 0) || !(debts >= 0)) return invalid();

		const grossMonthly = income / 12;
		const rentAt30 = grossMonthly * RENT_SHARE;
		const afterDebts = Math.max(0, grossMonthly * TOTAL_DEBT_SHARE - debts);
		const safest = Math.min(rentAt30, afterDebts);
		const debtShare = (debts / grossMonthly) * 100;

		const summary =
			afterDebts < rentAt30
				? `Your debts already take ${pct(debtShare, 1)} of income, so the debt limit is the one to watch. Keep rent under ${money(safest)} a month.`
				: `Keep rent under ${money(safest)} a month to stay within 30% of income and 36% including debts.`;

		return {
			primaryResult: money(rentAt30),
			primaryLabel: 'Affordable monthly rent (30%)',
			summary,
			secondaryMetrics: [
				{ label: 'Gross monthly income', value: money(grossMonthly) },
				{ label: 'Rent after debts (36% total)', value: money(afterDebts) },
				{ label: 'Safest rent (lower figure)', value: money(safest) },
				{ label: 'Debts as share of income', value: pct(debtShare, 1) }
			]
		};
	},
	content: {
		intro:
			'Work out how much rent fits your budget. Enter your income and debts to find a comfortable monthly rent, or enter a rent to see how much income you need.',
		howTo: [
			'Pick Rent I can afford, or Income needed.',
			'For affordable rent, enter your gross yearly income and the debt payments you make each month.',
			'For income needed, enter the monthly rent you are considering.',
			'Read the affordable rent, or the yearly income you need, and the safest figure after debts.'
		],
		formulas: [
			{
				title: 'Affordable rent',
				expression: 'Rent = 30% × (gross yearly income ÷ 12)',
				variables: [{ symbol: '30%', meaning: 'the share of gross monthly income that rent should take' }]
			},
			{
				title: 'Rent after debts',
				expression: 'Rent after debts = 36% × (gross yearly income ÷ 12) − monthly debt payments',
				variables: [{ symbol: '36%', meaning: 'the share of gross monthly income for rent plus all debts' }]
			},
			{
				title: 'Income needed',
				expression: 'Yearly income = monthly rent × 12 ÷ 30% = monthly rent × 40',
				variables: [{ symbol: '40×', meaning: 'the landlord rule: yearly income of about 40 times monthly rent' }]
			}
		],
		example: {
			title: 'A $75,000 salary with $400 a month in debts',
			steps: [
				'Gross monthly income: $75,000 ÷ 12 = $6,250.00',
				'Rent at 30%: $6,250.00 × 0.30 = $1,875.00',
				'Rent after debts: $6,250.00 × 0.36 − $400 = $2,250.00 − $400 = $1,850.00',
				'Safest rent is the lower figure: $1,850.00 a month'
			],
			result:
				'You can afford about $1,875.00 a month at 30% of income. Keep it under $1,850.00 to stay within 36% once your debts are included.'
		},
		faq: [
			{
				q: 'What is the 30% rule?',
				a: 'It is a common guide that rent should take no more than 30% of your gross (before tax) monthly income. It is a starting point, not a hard limit, and high-cost cities often stretch it.'
			},
			{
				q: 'What is the 40× rule?',
				a: 'Landlords often ask for a yearly income of about 40 times the monthly rent. That is the same as the 30% rule, because 12 ÷ 0.30 = 40. A rent of $1,800 needs $72,000 a year.'
			},
			{
				q: 'Should I use gross or take-home pay?',
				a: 'Use gross pay, since landlords and lenders usually check income before tax. If you want a stricter budget, work out the same share of your take-home pay.'
			},
			{
				q: 'Why does the debt figure matter?',
				a: 'Landlords often look at rent plus other debts. Keeping the total near 36% of gross income leaves room for bills, savings and surprises.'
			}
		],
		sources: [
			{
				title: 'U.S. Department of Housing and Urban Development',
				url: 'https://www.hud.gov/'
			},
			{
				title: 'Consumer Financial Protection Bureau',
				url: 'https://www.consumerfinance.gov/'
			}
		],
		disclaimer:
			'Estimates only, based on gross income. Landlords set their own rules, and your budget, local costs and savings matter as much as these ratios.'
	}
});
