import { defineMeta } from '../types';

export default defineMeta({
	slug: 'commission-calculator',
	name: 'Commission Calculator',
	category: 'finance',
	shortDescription: 'Commission and total earnings from flat or tiered sales rates.',
	metaTitle: 'Commission Calculator — Flat or Tiered Rates',
	metaDescription:
		'Free commission calculator. Work out your commission and total earnings from a sale, with optional base pay and a tiered rate above a sales threshold.',
	icon: 'percent',
	keywords: ['commission calculator', 'sales commission calculator', 'tiered commission calculator', 'commission rate', 'sales pay calculator'],
	updated: '2026-10-28'
});
