import { defineCalculator, type CalculationResult, type RowValue } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './debt-consolidation-calculator.meta';

/** Safety cap on each month-by-month loop (100 years). */
const MAX_MONTHS = 1200;

/** Level payment on a loan: P·r(1 + r)^n / ((1 + r)^n − 1); r = 0 → P / n. */
function levelPayment(principal: number, annualPct: number, n: number): number {
	const r = annualPct / 1200;
	if (r === 0) return principal / n;
	const f = Math.pow(1 + r, n);
	return (principal * r * f) / (f - 1);
}

/**
 * Pay one debt at a fixed monthly amount: add interest, then take the payment.
 * Returns null when the balance never clears within the cap.
 */
function payOff(balance: number, apr: number, payment: number): { months: number; interest: number } | null {
	const r = apr / 1200;
	let bal = balance;
	let months = 0;
	let interest = 0;
	while (bal > 0.005 && months < MAX_MONTHS) {
		const i = bal * r;
		interest += i;
		bal += i;
		bal -= Math.min(payment, bal);
		months++;
	}
	return bal > 0.005 ? null : { months, interest };
}

function termText(months: number): string {
	return plural(months, 'month');
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'debts',
			label: 'Current debts',
			type: 'rows',
			columns: [
				{ id: 'name', label: 'Debt', type: 'text', default: '', placeholder: 'Debt name' },
				{ id: 'balance', label: 'Balance', type: 'number', default: 0, min: 0, max: 100_000_000, prefix: '$' },
				{ id: 'apr', label: 'APR', type: 'number', default: 0, min: 0, max: 100, suffix: '%' },
				{ id: 'payment', label: 'Monthly payment', type: 'number', default: 0, min: 0, max: 100_000_000, prefix: '$' }
			],
			default: [
				{ name: 'Credit card', balance: 4200, apr: 24.99, payment: 120 },
				{ name: 'Store card', balance: 1800, apr: 29.9, payment: 60 },
				{ name: 'Personal loan', balance: 6000, apr: 12.5, payment: 180 }
			],
			minRows: 1,
			maxRows: 10,
			addLabel: 'Add debt'
		},
		{ id: 'newRate', label: 'New loan rate', type: 'number', default: 11, min: 0, max: 100, step: 0.01, suffix: '%', help: 'Annual rate on the consolidation loan' },
		{ id: 'newMonths', label: 'New loan term (months)', type: 'number', default: 60, min: 1, max: MAX_MONTHS / 2, step: 1, suffix: 'months', decimal: false },
		{
			id: 'feePct',
			label: 'Consolidation fee',
			type: 'number',
			default: 3,
			min: 0,
			max: 20,
			step: 0.1,
			suffix: '%',
			help: 'Charged on the total balance and added to the loan'
		}
	],
	calculate(v): CalculationResult {
		const rows = (v.debts as RowValue[]) ?? [];
		const newRate = Number(v.newRate);
		const newMonths = Number(v.newMonths);
		const feePct = Number(v.feePct);
		const primaryLabel = 'Total saved';

		const debtsValid = rows.length > 0 && rows.every((r) => {
			const balance = Number(r.balance);
			const apr = Number(r.apr);
			const payment = Number(r.payment);
			return balance > 0 && Number.isFinite(balance) && apr >= 0 && apr <= 100 && payment > 0 && Number.isFinite(payment);
		});
		if (
			!debtsValid ||
			!(newRate >= 0 && newRate <= 100) ||
			!Number.isInteger(newMonths) ||
			newMonths < 1 ||
			newMonths > MAX_MONTHS / 2 ||
			!(feePct >= 0 && feePct <= 20)
		) {
			return {
				primaryResult: DASH,
				primaryLabel,
				summary: 'Enter a balance, APR and monthly payment for every debt, plus the new loan rate, term and fee.'
			};
		}

		// Current plan: each debt paid at its own payment, one after another in time.
		let totalBalance = 0;
		let currentPayment = 0;
		let currentInterest = 0;
		let currentMonths = 0;
		const table: Record<string, string>[] = [];
		for (let i = 0; i < rows.length; i++) {
			const row = rows[i];
			const balance = Number(row.balance);
			const apr = Number(row.apr);
			const payment = Number(row.payment);
			const name = String(row.name).trim() || `Debt ${i + 1}`;
			const result = payOff(balance, apr, payment);
			if (!result) {
				return {
					primaryResult: DASH,
					primaryLabel,
					summary: `${name} would never be paid off at ${money(payment)} a month. Raise that payment above its monthly interest.`
				};
			}
			totalBalance += balance;
			currentPayment += payment;
			currentInterest += result.interest;
			currentMonths = Math.max(currentMonths, result.months);
			table.push({
				debt: name,
				balance: money(balance),
				apr: `${num(apr, 2)}%`,
				payment: money(payment),
				months: num(result.months, 0),
				interest: money(result.interest)
			});
		}

		// New loan: the fee is added to the balance, then the loan is repaid at its level payment.
		const fee = totalBalance * (feePct / 100);
		const newPayment = levelPayment(totalBalance + fee, newRate, newMonths);
		const newCost = newPayment * newMonths - totalBalance;
		const diff = currentInterest - newCost;

		return {
			primaryResult: money(Math.abs(diff)),
			primaryLabel: diff >= 0 ? 'Total saved' : 'Extra cost',
			summary: `The new loan costs ${money(newCost)} in interest and fees, against ${money(currentInterest)} of interest on your current debts.`,
			secondaryMetrics: [
				{ label: 'Current monthly payments', value: money(currentPayment) },
				{ label: 'New monthly payment', value: money(newPayment) },
				{ label: 'Current payoff time', value: termText(currentMonths) },
				{ label: 'New loan term', value: termText(newMonths) },
				{ label: 'Current total interest', value: money(currentInterest) },
				{ label: 'New loan total cost', value: money(newCost) },
				{ label: 'Consolidation fee', value: money(fee) }
			],
			table: {
				title: 'Current debts, paid separately',
				collapsed: true,
				columns: [
					{ key: 'debt', label: 'Debt' },
					{ key: 'balance', label: 'Balance', align: 'end' },
					{ key: 'apr', label: 'APR', align: 'end' },
					{ key: 'payment', label: 'Payment', align: 'end' },
					{ key: 'months', label: 'Months', align: 'end' },
					{ key: 'interest', label: 'Interest', align: 'end' }
				],
				rows: table
			}
		};
	},
	content: {
		intro:
			'Compare what you pay now on several debts with what you would pay on one consolidation loan. See the monthly payment, the payoff time and the total cost for both, and whether the new loan saves you money.',
		howTo: [
			'List each existing debt with its balance, APR and monthly payment.',
			'Enter the rate, term and fee for the consolidation loan.',
			'Read whether the new loan saves money or costs more over its life.',
			'Open the table to see how long each current debt takes to clear.'
		],
		formulas: [
			{
				title: 'Current plan, one debt at a time',
				expression: 'Each month: interest = balance × APR ÷ 12, then balance = balance + interest − payment',
				variables: [{ symbol: 'APR', meaning: 'annual rate on that debt, as a decimal ÷ 100' }]
			},
			{
				title: 'New loan payment',
				expression: 'M = (B + F) × r(1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'B', meaning: 'total of all current balances' },
					{ symbol: 'F', meaning: 'consolidation fee (B × fee %)' },
					{ symbol: 'r', meaning: 'new loan rate ÷ 12 ÷ 100' },
					{ symbol: 'n', meaning: 'new loan term in months' }
				]
			},
			{
				title: 'Total cost compared',
				expression: 'New loan cost = M × n − B        Saving = current interest − new loan cost',
				variables: []
			}
		],
		example: {
			title: 'Three debts with $12,000 in total balances',
			steps: [
				'Current interest, each debt paid at its own payment: $6,363.26 in total, over up to 64 months',
				'Consolidation fee: 3% of $12,000 = $360, so the new loan is $12,360',
				'New loan at 11% over 60 months: payment of $268.74 a month',
				'New loan cost: 268.736 × 60 − 12,000 = $4,124.18 (interest plus the fee)',
				'Saving: 6,363.26 − 4,124.18 = $2,239.08'
			],
			result: 'The consolidation loan saves $2,239.08 and lowers the monthly payment from $360.00 to $268.74.'
		},
		faq: [
			{
				q: 'Does a lower monthly payment always mean I save money?',
				a: 'No. A longer term can lower the monthly payment while raising the total interest. Compare the total cost and the payoff time, not only the payment.'
			},
			{
				q: 'Why is the consolidation fee added to the loan?',
				a: 'Many lenders roll their fee into the loan, so it is repaid with interest. This calculator adds the fee to the amount borrowed and counts it in the new loan cost.'
			},
			{
				q: 'What if one debt would never be paid off?',
				a: 'A payment that does not cover the monthly interest leaves the balance growing. The calculator shows a dash and names that debt, so you can raise its payment.'
			},
			{
				q: 'Does this include new spending on the cards?',
				a: 'No. It assumes you stop adding to these debts, that the rates stay the same and that you make every payment on time.'
			}
		],
		sources: [{ title: 'Consumer Financial Protection Bureau', url: 'https://www.consumerfinance.gov/' }],
		disclaimer:
			'Estimates only. Consolidation loans carry their own rates and fees, and some consolidation options can cost more over time. Check the lender’s terms before you borrow.'
	}
});
