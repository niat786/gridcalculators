import { defineMeta } from '../types';

export default defineMeta({
	slug: 'heloc-calculator',
	name: 'HELOC Calculator',
	category: 'finance',
	shortDescription: 'Interest-only payments during the draw period, then repayment costs.',
	metaTitle: 'HELOC Calculator — Draw & Repayment Payments',
	metaDescription:
		'Free HELOC calculator. Estimate interest-only payments during the draw period, the payment once repayment starts, and the total interest on your credit line.',
	icon: 'banknote',
	keywords: [
		'heloc calculator',
		'home equity line of credit',
		'heloc payment',
		'heloc draw period',
		'heloc repayment'
	],
	updated: '2026-10-28'
});
