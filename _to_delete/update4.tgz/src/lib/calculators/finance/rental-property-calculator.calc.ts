import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct, num } from '../format';
import meta from './rental-property-calculator.meta';

const ok = (x: number, lo: number, hi: number) => Number.isFinite(x) && x >= lo && x <= hi;

/** Monthly principal and interest: M = P × r × (1 + r)ⁿ ÷ ((1 + r)ⁿ − 1), with r = 0 → P ÷ n. */
function monthlyPayment(principal: number, annualPct: number, months: number): number {
	const r = annualPct / 1200;
	if (r === 0) return principal / months;
	const f = Math.pow(1 + r, months);
	return (principal * r * f) / (f - 1);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'price', label: 'Purchase price', type: 'number', default: 300000, min: 1, max: 100_000_000, step: 1000, prefix: '$' },
		{ id: 'down', label: 'Down payment', type: 'number', default: 25, min: 0, max: 100, step: 0.5, suffix: '%' },
		{ id: 'rate', label: 'Mortgage rate', type: 'number', default: 6.5, min: 0, max: 30, step: 0.01, suffix: '%' },
		{
			id: 'term',
			label: 'Loan term',
			type: 'select',
			display: 'segmented',
			default: '30',
			options: [
				{ label: '15 yr', value: '15' },
				{ label: '20 yr', value: '20' },
				{ label: '25 yr', value: '25' },
				{ label: '30 yr', value: '30' }
			]
		},
		{
			id: 'closing',
			label: 'Closing costs',
			type: 'number',
			default: 6000,
			min: 0,
			max: 1_000_000,
			step: 100,
			prefix: '$',
			help: 'Paid at purchase, on top of the down payment'
		},
		{ id: 'rent', label: 'Monthly rent', type: 'number', default: 2400, min: 0, max: 1_000_000, step: 50, prefix: '$', suffix: '/mo' },
		{
			id: 'vacancy',
			label: 'Vacancy',
			type: 'number',
			default: 5,
			min: 0,
			max: 100,
			step: 0.5,
			suffix: '%',
			help: 'Share of gross rent you expect to lose to empty months and unpaid rent'
		},
		{ id: 'tax', label: 'Property tax', type: 'number', default: 3600, min: 0, max: 1_000_000, step: 100, prefix: '$', suffix: '/yr' },
		{ id: 'insurance', label: 'Landlord insurance', type: 'number', default: 1200, min: 0, max: 1_000_000, step: 100, prefix: '$', suffix: '/yr' },
		{
			id: 'maint',
			label: 'Maintenance',
			type: 'number',
			default: 5,
			min: 0,
			max: 100,
			step: 0.5,
			suffix: '%',
			help: 'Percent of collected rent'
		},
		{
			id: 'mgmt',
			label: 'Property management',
			type: 'number',
			default: 8,
			min: 0,
			max: 100,
			step: 0.5,
			suffix: '%',
			help: 'Percent of collected rent. Enter 0 if you manage it yourself.'
		},
		{ id: 'hoa', label: 'HOA fees', type: 'number', default: 100, min: 0, max: 100_000, step: 10, prefix: '$', suffix: '/mo' }
	],
	calculate(v): CalculationResult {
		const price = Number(v.price);
		const down = Number(v.down);
		const rate = Number(v.rate);
		const term = Number(v.term);
		const closing = Number(v.closing);
		const rent = Number(v.rent);
		const vacancy = Number(v.vacancy);
		const tax = Number(v.tax);
		const insurance = Number(v.insurance);
		const maint = Number(v.maint);
		const mgmt = Number(v.mgmt);
		const hoa = Number(v.hoa);

		if (
			!ok(price, 1, 1e9) ||
			!ok(down, 0, 100) ||
			!ok(rate, 0, 30) ||
			![15, 20, 25, 30].includes(term) ||
			!ok(closing, 0, 1e9) ||
			!ok(rent, 0, 1e9) ||
			!ok(vacancy, 0, 100) ||
			!ok(tax, 0, 1e9) ||
			!ok(insurance, 0, 1e9) ||
			!ok(maint, 0, 100) ||
			!ok(mgmt, 0, 100) ||
			!ok(hoa, 0, 1e9)
		) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Monthly cash flow',
				summary: 'Enter a purchase price, a down payment below 100% or equal to it, and valid rent and expense amounts.'
			};
		}

		const downPayment = price * (down / 100);
		const loan = price - downPayment;
		const monthlyPI = monthlyPayment(loan, rate, term * 12);
		const annualDebt = monthlyPI * 12;

		const grossRent = rent * 12;
		const collectedRent = grossRent * (1 - vacancy / 100);
		const operating =
			tax + insurance + collectedRent * (maint / 100) + collectedRent * (mgmt / 100) + hoa * 12;
		const noi = collectedRent - operating;
		const capRate = (noi / price) * 100;

		const cashInvested = downPayment + closing;
		const annualCashFlow = noi - annualDebt;
		const monthlyCashFlow = annualCashFlow / 12;
		const cashOnCash = cashInvested > 0 ? pct((annualCashFlow / cashInvested) * 100, 2) : DASH;

		const summary =
			monthlyCashFlow >= 0
				? `After vacancy, expenses and the mortgage, the property leaves ${money(monthlyCashFlow)} a month.`
				: `After vacancy, expenses and the mortgage, you pay ${money(-monthlyCashFlow)} a month out of pocket.`;

		return {
			primaryResult: money(monthlyCashFlow),
			primaryLabel: 'Monthly cash flow',
			summary,
			secondaryMetrics: [
				{ label: 'Net operating income (yearly)', value: money(noi) },
				{ label: 'Cap rate', value: pct(capRate, 2) },
				{ label: 'Cash-on-cash return', value: cashOnCash },
				{ label: 'Cash invested', value: money(cashInvested) },
				{ label: 'Monthly mortgage payment', value: money(monthlyPI) },
				{ label: 'Loan amount', value: money(loan) }
			]
		};
	},
	content: {
		intro:
			'Estimate what a rental property earns after vacancy, running costs and the mortgage. The calculator also gives the cap rate and cash-on-cash return, two common ways to compare investment properties.',
		howTo: [
			'Enter the purchase price, down payment, closing costs, and the mortgage rate and term.',
			'Enter the monthly rent and the vacancy rate you expect.',
			'Add yearly property tax and insurance, the maintenance and management percentages, and any HOA fees.',
			'Read the monthly cash flow, then compare the cap rate and cash-on-cash return.'
		],
		formulas: [
			{
				title: 'Net operating income (NOI)',
				expression: 'NOI = rent × 12 × (1 − vacancy) − (tax + insurance + maintenance + management + HOA × 12)',
				variables: [
					{ symbol: 'maintenance', meaning: 'maintenance % × collected rent' },
					{ symbol: 'management', meaning: 'management % × collected rent' }
				]
			},
			{
				title: 'Cap rate',
				expression: 'Cap rate = NOI ÷ purchase price × 100',
				variables: [{ symbol: 'NOI', meaning: 'yearly income after operating costs, before the mortgage' }]
			},
			{
				title: 'Cash-on-cash return',
				expression: 'Cash-on-cash = (NOI − yearly mortgage payments) ÷ cash invested × 100',
				variables: [
					{ symbol: 'cash invested', meaning: 'down payment plus closing costs' }
				]
			},
			{
				title: 'Monthly cash flow',
				expression: 'Monthly cash flow = (NOI − 12 × M) ÷ 12',
				variables: [{ symbol: 'M', meaning: 'monthly principal and interest on the loan' }]
			}
		],
		example: {
			title: 'A $300,000 property, 25% down, $6,000 closing costs, $2,400 rent, and a 6.5% 30-year loan',
			steps: [
				'Loan = $300,000 × 0.75 = $225,000, and the monthly principal and interest is $1,422.15',
				'Collected rent = $2,400 × 12 × (1 − 0.05) = $27,360',
				'Operating costs = $3,600 tax + $1,200 insurance + $1,368 maintenance + $2,188.80 management + $1,200 HOA = $9,556.80',
				'NOI = $27,360 − $9,556.80 = $17,803.20, so the cap rate is $17,803.20 ÷ $300,000 ≈ 5.93%',
				'Cash flow = ($17,803.20 − 12 × $1,422.15) ÷ 12 = $61.45 a month. Cash invested is $81,000, so cash-on-cash ≈ 0.91%'
			],
			result: 'Monthly cash flow of $61.45, a 5.93% cap rate and a 0.91% cash-on-cash return.'
		},
		faq: [
			{
				q: 'What is a good cap rate?',
				a: 'There is no single answer. A higher cap rate means more income for each dollar of price, but it often comes with more risk or a weaker location. Compare cap rates for similar properties in the same area.'
			},
			{
				q: 'What does cash-on-cash return measure?',
				a: 'It shows the yearly cash you keep after the mortgage, as a share of the cash you put in. Because it uses your actual down payment and closing costs, it reflects the effect of borrowing.'
			},
			{
				q: 'Why is vacancy taken off the rent?',
				a: 'Few properties rent every month of the year. Setting aside a share of gross rent for empty months and unpaid rent gives a more realistic income figure.'
			},
			{
				q: 'What is not included?',
				a: 'Income tax, depreciation, major repairs such as a new roof, and capital improvements are not included. Keep a reserve for them, because they can change the result a lot.'
			}
		],
		sources: [
			{ title: 'Internal Revenue Service', url: 'https://www.irs.gov/' },
			{ title: 'Consumer Financial Protection Bureau', url: 'https://www.consumerfinance.gov/' }
		],
		disclaimer:
			'Estimates only. Rents, vacancy, expenses and taxes vary by property and market, and this is not tax or investment advice.'
	}
});
