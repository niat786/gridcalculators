import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './business-loan-calculator.meta';

const MAX_MONTHS = 600;

/** "5 years 3 months", "2 years", "9 months". */
function termText(months: number): string {
	const y = Math.floor(months / 12);
	const m = months % 12;
	return [y ? plural(y, 'year') : '', m ? plural(m, 'month') : ''].filter(Boolean).join(' ');
}

/** Present value of n equal payments at the periodic rate j. */
function presentValue(pay: number, j: number, n: number): number {
	return j === 0 ? pay * n : (pay * (1 - Math.pow(1 + j, -n))) / j;
}

/**
 * Nominal annual rate (decimal) at which the payments are worth `received` today.
 * `perYear` is the number of payments a year. Bisection on 0 to 1000% until the bracket
 * is narrower than 1e-10. Returns null when the answer would be above 1000%.
 */
function effectiveRate(pay: number, perYear: number, n: number, received: number): number | null {
	const pvAt = (a: number) => presentValue(pay, a / perYear, n);
	let lo = 0;
	let hi = 10;
	if (pvAt(hi) > received) return null;
	while (hi - lo > 1e-10) {
		const mid = (lo + hi) / 2;
		if (pvAt(mid) > received) lo = mid;
		else hi = mid;
	}
	return (lo + hi) / 2;
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'amount', label: 'Loan amount', type: 'number', default: 50000, min: 1, max: 100_000_000, step: 500, prefix: '$' },
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 9.5, min: 0, max: 100, step: 0.01, suffix: '%', help: 'Annual rate' },
		{ id: 'months', label: 'Term (months)', type: 'number', default: 60, min: 1, max: MAX_MONTHS, step: 1, suffix: 'months', decimal: false },
		{
			id: 'feePct',
			label: 'Origination fee',
			type: 'number',
			default: 2,
			min: 0,
			max: 20,
			step: 0.1,
			suffix: '%',
			help: 'Taken from the loan amount at closing'
		},
		{
			id: 'frequency',
			label: 'Payment frequency',
			type: 'select',
			display: 'segmented',
			default: 'monthly',
			options: [
				{ label: 'Monthly', value: 'monthly' },
				{ label: 'Weekly', value: 'weekly' }
			]
		}
	],
	calculate(v): CalculationResult {
		const amount = Number(v.amount);
		const rate = Number(v.rate);
		const months = Number(v.months);
		const feePct = Number(v.feePct);
		const weekly = String(v.frequency) === 'weekly';
		const perYear = weekly ? 52 : 12;
		const label = weekly ? 'Weekly payment' : 'Monthly payment';

		if (
			!(amount > 0) ||
			!Number.isFinite(amount) ||
			!(rate >= 0 && rate <= 100) ||
			!Number.isInteger(months) ||
			months < 1 ||
			months > MAX_MONTHS ||
			!(feePct >= 0 && feePct <= 20)
		) {
			return {
				primaryResult: DASH,
				primaryLabel: label,
				summary: 'Enter a loan amount, a rate from 0% to 100%, a term of 1 to 600 months, and a fee from 0% to 20%.'
			};
		}

		// Weekly loans run for the same length of time: months × 52 ÷ 12 payments, rounded.
		const n = weekly ? Math.round((months * 52) / 12) : months;
		const r = rate / 100 / perYear;
		const f = Math.pow(1 + r, n);
		const pay = r === 0 ? amount / n : (amount * r * f) / (f - 1);
		const totalPaid = pay * n;
		const fee = amount * (feePct / 100);
		const totalInterest = totalPaid - amount;
		const totalCost = totalInterest + fee;
		const apr = effectiveRate(pay, perYear, n, amount - fee);

		return {
			primaryResult: money(pay),
			primaryLabel: label,
			summary: `${money(amount, true)} at ${num(rate, 2)}% over ${termText(months)}, paid ${weekly ? 'weekly' : 'monthly'}.`,
			secondaryMetrics: [
				{ label: 'Effective APR', value: apr === null ? 'Over 1,000%' : `${num(apr * 100, 2, 2)}%` },
				{ label: 'Total interest', value: money(totalInterest) },
				{ label: 'Origination fee', value: money(fee) },
				{ label: 'Total cost', value: money(totalCost) },
				{ label: 'Total of payments', value: money(totalPaid) },
				{ label: 'Number of payments', value: plural(n, 'payment') }
			]
		};
	},
	content: {
		intro:
			'Work out the regular payment on a business loan, the total interest, the origination fee and the effective APR. Switch between monthly and weekly payments to compare how each one works.',
		howTo: [
			'Enter the amount you are borrowing and the interest rate.',
			'Set the term in months and the origination fee as a percentage of the loan.',
			'Choose monthly or weekly payments.',
			'Read the payment, the total cost and the effective APR, which includes the fee.'
		],
		formulas: [
			{
				title: 'Payment',
				expression: 'M = P × r(1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'M', meaning: 'payment per period' },
					{ symbol: 'P', meaning: 'loan amount' },
					{ symbol: 'r', meaning: 'annual rate ÷ payments per year ÷ 100' },
					{ symbol: 'n', meaning: 'number of payments (weekly: months × 52 ÷ 12, rounded)' }
				]
			},
			{
				title: 'Origination fee and total cost',
				expression: 'Fee = P × fee % ÷ 100        Total cost = (M × n − P) + Fee',
				variables: []
			},
			{
				title: 'Effective APR',
				expression: 'P − Fee = M × (1 − (1 + i)⁻ⁿ) ÷ i, solved for i by bisection.   APR = i × payments per year × 100%',
				variables: [{ symbol: 'i', meaning: 'rate per payment period that makes the payments worth the loan after the fee' }]
			}
		],
		example: {
			title: 'A $50,000 loan at 9.5% for 60 months with a 2% fee',
			steps: [
				'Monthly rate: r = 9.5 ÷ 12 ÷ 100 = 0.0079167',
				'Monthly payment: M = $1,050.093, shown as $1,050.09',
				'Origination fee: 50,000 × 2% = $1,000, so $49,000 is the net amount',
				'Total of payments: 1,050.093 × 60 = $63,005.58, so interest = $13,005.58',
				'Effective APR: solving the payments against $49,000 gives 10.37%'
			],
			result: 'Monthly payment of $1,050.09. Total cost of $14,005.58 with an effective APR of 10.37%.'
		},
		faq: [
			{
				q: 'Why is the effective APR higher than the interest rate?',
				a: 'The fee is paid out of the loan, so you repay the full amount on less cash. The effective APR spreads that fee over the term, which pushes the figure above the interest rate.'
			},
			{
				q: 'Is a weekly payment cheaper than a monthly one?',
				a: 'The total interest is usually a little lower with weekly payments, because you repay principal more often. The weekly payment is smaller, but you make more of them. Check that your lender uses the same annual rate for both.'
			},
			{
				q: 'What is an origination fee?',
				a: 'It is a one-off charge a lender takes for setting up the loan, usually a percentage of the amount borrowed. Some lenders take it from the loan proceeds, which is how this calculator treats it.'
			}
		],
		sources: [{ title: 'U.S. Small Business Administration', url: 'https://www.sba.gov/' }],
		disclaimer:
			'Estimates only. Your lender’s rate, fees, and payment schedule depend on your loan agreement. Speak to a qualified adviser before you borrow.'
	}
});
