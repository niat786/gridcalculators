import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './credit-card-calculator.meta';

/** Safety cap on the month-by-month loop (100 years). */
const MAX_MONTHS = 1200;
/** Months shown in the table. */
const TABLE_MONTHS = 12;

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'balance', label: 'Card balance', type: 'number', default: 4800, min: 0, max: 100_000_000, step: 0.01, prefix: '$' },
		{
			id: 'apr',
			label: 'APR',
			type: 'number',
			default: 22.9,
			min: 0,
			max: 100,
			step: 0.01,
			suffix: '%',
			help: 'Interest is charged monthly at APR ÷ 12'
		},
		{
			id: 'payType',
			label: 'Payment type',
			type: 'select',
			display: 'segmented',
			default: 'fixed',
			options: [
				{ label: 'Fixed amount', value: 'fixed' },
				{ label: 'Percent of balance', value: 'percent' }
			]
		},
		{
			id: 'payment',
			label: 'Monthly payment',
			type: 'number',
			default: 150,
			min: 0,
			max: 100_000_000,
			step: 1,
			prefix: '$',
			visibleWhen: (v) => v.payType !== 'percent'
		},
		{
			id: 'percent',
			label: 'Minimum percentage',
			type: 'number',
			default: 2,
			min: 0.1,
			max: 100,
			step: 0.1,
			suffix: '%',
			help: 'Share of the statement balance',
			visibleWhen: (v) => v.payType === 'percent'
		},
		{
			id: 'floor',
			label: 'Minimum floor',
			type: 'number',
			default: 25,
			min: 0,
			max: 1_000_000,
			step: 1,
			prefix: '$',
			help: 'The payment never drops below this',
			visibleWhen: (v) => v.payType === 'percent'
		}
	],
	calculate(v): CalculationResult {
		const balance = Number(v.balance);
		const apr = Number(v.apr);
		const percentMode = String(v.payType) === 'percent';
		const fixed = Number(v.payment);
		const pct = Number(v.percent);
		const floor = Number(v.floor);
		const monthlyRate = apr / 1200;

		const inputsOk =
			balance > 0 &&
			Number.isFinite(balance) &&
			apr >= 0 &&
			apr <= 100 &&
			(percentMode ? pct > 0 && pct <= 100 && floor >= 0 && Number.isFinite(floor) : fixed > 0 && Number.isFinite(fixed));
		if (!inputsOk) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Time to pay off',
				summary: percentMode
					? 'Enter a balance above zero, an APR from 0% to 100%, a percentage above zero and a floor of zero or more.'
					: 'Enter a balance above zero, an APR from 0% to 100%, and a monthly payment above zero.'
			};
		}

		// A fixed payment that does not cover this month's interest can never clear the card.
		const firstInterest = balance * monthlyRate;
		if (!percentMode && fixed <= firstInterest) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Time to pay off',
				summary: `Interest alone is ${money(firstInterest)} a month, so a payment of ${money(fixed)} never clears the balance. Increase the payment.`
			};
		}

		// Month by month: add interest to the statement balance, then take this month's payment.
		let bal = balance;
		let months = 0;
		let totalInterest = 0;
		let firstPayment = 0;
		let lastPayment = 0;
		const table: Record<string, string>[] = [];
		while (bal > 0.005 && months < MAX_MONTHS) {
			const interest = bal * monthlyRate;
			bal += interest;
			totalInterest += interest;
			const due = percentMode ? Math.max(bal * (pct / 100), floor) : fixed;
			const pay = Math.min(due, bal);
			bal -= pay;
			months++;
			if (months === 1) firstPayment = pay;
			lastPayment = pay;
			if (months <= TABLE_MONTHS) {
				table.push({
					month: num(months, 0),
					payment: money(pay),
					interest: money(interest),
					principal: money(pay - interest),
					balance: money(Math.max(bal, 0))
				});
			}
		}

		if (bal > 0.005) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Time to pay off',
				summary: percentMode
					? 'These minimums would take more than 100 years to clear the card. Raise the percentage or the floor.'
					: 'At this payment the balance would take more than 100 years to clear. Increase the payment.'
			};
		}

		const summary = percentMode
			? `Paying ${num(pct, 2)}% of the statement balance, never less than ${money(floor)}, clears ${money(balance)} in ${plural(months, 'month')}.`
			: `Paying ${money(fixed)} a month clears ${money(balance)} in ${plural(months, 'month')}.`;

		return {
			primaryResult: plural(months, 'month'),
			primaryLabel: 'Time to pay off',
			summary,
			secondaryMetrics: [
				{ label: 'Total interest', value: money(totalInterest) },
				{ label: 'Total paid', value: money(balance + totalInterest) },
				{ label: 'First payment', value: money(firstPayment) },
				{ label: 'Final payment', value: money(lastPayment) }
			],
			table: {
				title: 'First 12 months',
				collapsed: true,
				columns: [
					{ key: 'month', label: 'Month', align: 'start' },
					{ key: 'payment', label: 'Payment', align: 'end' },
					{ key: 'interest', label: 'Interest', align: 'end' },
					{ key: 'principal', label: 'Principal', align: 'end' },
					{ key: 'balance', label: 'Balance', align: 'end' }
				],
				rows: table
			}
		};
	},
	content: {
		intro:
			'Work out how long it takes to clear a credit card, and how much interest you pay on the way. Use a fixed monthly payment, or a minimum that is a percentage of the balance with a floor, as many card issuers set it.',
		howTo: [
			'Enter the balance and the APR from your latest statement.',
			'Pick Fixed amount to test a payment you can make, or Percent of balance to model a card minimum.',
			'For a percentage minimum, enter the percentage and the floor the payment never drops below.',
			'Read the time to pay off and the total interest, then open the first 12 months.'
		],
		formulas: [
			{
				title: 'Monthly interest',
				expression: 'Interest = balance × APR ÷ 12 ÷ 100',
				variables: [{ symbol: 'APR', meaning: 'annual percentage rate on the card' }]
			},
			{
				title: 'Percentage minimum',
				expression: 'Payment = the larger of (balance after interest × percentage ÷ 100) and the floor',
				variables: [{ symbol: 'floor', meaning: 'the smallest payment allowed' }]
			},
			{
				title: 'Never pays off',
				expression: 'A fixed payment at or below the monthly interest never reduces the balance',
				variables: []
			}
		],
		example: {
			title: 'A $4,800 balance at 22.9% APR with $150 a month',
			steps: [
				'Monthly rate: 22.9 ÷ 12 ÷ 100 = 1.9083% a month',
				'First month interest: $4,800 × 1.9083% = $91.60, which is less than the $150 payment',
				'Each month, interest is added to the balance, then $150 is taken off',
				'The card is cleared in 50 months. The final payment is $135.39',
				'Total interest: $2,685.39, so the total paid is $7,485.39'
			],
			result: 'Paid off in 50 months with $2,685.39 of interest.'
		},
		faq: [
			{
				q: 'Why does a minimum payment take so long?',
				a: 'Most of a small payment goes to interest at the start. The balance falls slowly, so the card can take years to clear.'
			},
			{
				q: 'What is a percentage minimum?',
				a: 'Many card issuers set the minimum as a share of the statement balance, with a floor so small balances still pay a set amount. This calculator follows that rule.'
			},
			{
				q: 'What if my payment is too small?',
				a: 'If a fixed payment does not cover the monthly interest, the balance grows and the card never clears. The calculator shows a dash and tells you the payment to increase.'
			},
			{
				q: 'Does this include new purchases?',
				a: 'No. It assumes the balance and APR stay the same and that you make no new charges. New spending extends the payoff time.'
			}
		],
		sources: [{ title: 'Consumer Financial Protection Bureau', url: 'https://www.consumerfinance.gov/' }],
		disclaimer:
			'Estimates only. Assumes a fixed APR, no new charges and no fees. Your card statement is the final word on your balance and minimum payment.'
	}
});
