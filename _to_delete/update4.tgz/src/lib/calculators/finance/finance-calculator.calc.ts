import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, money, num } from '../format';
import meta from './finance-calculator.meta';

const SOLVE_OPTIONS = [
	{ label: 'Future value (FV)', value: 'fv' },
	{ label: 'Present value (PV)', value: 'pv' },
	{ label: 'Payment (PMT)', value: 'pmt' },
	{ label: 'Number of periods (N)', value: 'n' },
	{ label: 'Interest rate (I/Y)', value: 'iy' }
];

const PER_YEAR = [
	{ label: 'Annually (1)', value: '1' },
	{ label: 'Semiannually (2)', value: '2' },
	{ label: 'Quarterly (4)', value: '4' },
	{ label: 'Monthly (12)', value: '12' },
	{ label: 'Biweekly (26)', value: '26' },
	{ label: 'Weekly (52)', value: '52' },
	{ label: 'Daily (365)', value: '365' }
];

const SOLVES = ['fv', 'pv', 'pmt', 'n', 'iy'];

const TIMING = [
	{ label: 'End', value: 'end' },
	{ label: 'Beginning', value: 'beginning' }
];

const LABEL: Record<string, string> = {
	fv: 'Future value (FV)',
	pv: 'Present value (PV)',
	pmt: 'Payment (PMT)',
	n: 'Periods (N)',
	iy: 'Interest rate (I/Y)'
};

/** (1 + i)ⁿ, computed in a way that stays accurate for very small rates. */
const growth = (i: number, n: number) => Math.exp(n * Math.log1p(i));

/** The annuity factor: ((1 + i)ⁿ − 1) ÷ i, times (1 + i) for payments at the beginning. */
function annuityFactor(i: number, n: number, beginning: boolean): number {
	if (i === 0) return n;
	const gm1 = Math.expm1(n * Math.log1p(i));
	return (gm1 / i) * (beginning ? 1 + i : 1);
}

/** Left side of the TVM equation. It equals zero when the five values agree. */
function residual(i: number, n: number, beginning: boolean, pv: number, pmt: number, fv: number): number {
	return pv * growth(i, n) + pmt * annuityFactor(i, n, beginning) + fv;
}

/** Solve for the per-period rate by bisection. Returns NaN when no sign change is found. */
function solveRate(n: number, beginning: boolean, pv: number, pmt: number, fv: number): number {
	let lo = -0.99;
	// Keep (1 + hi)ⁿ finite so large N never overflows.
	let hi = Math.min(1, Math.pow(10, 300 / n) - 1);
	let flo = residual(lo, n, beginning, pv, pmt, fv);
	const fhi = residual(hi, n, beginning, pv, pmt, fv);
	if (!Number.isFinite(flo) || !Number.isFinite(fhi) || Math.sign(flo) === Math.sign(fhi)) return NaN;
	for (let k = 0; k < 300; k++) {
		const mid = (lo + hi) / 2;
		const fm = residual(mid, n, beginning, pv, pmt, fv);
		if (fm === 0) return mid;
		if (Math.sign(fm) === Math.sign(flo)) {
			lo = mid;
			flo = fm;
		} else {
			hi = mid;
		}
	}
	return (lo + hi) / 2;
}

/**
 * Time-value-of-money solver. Cash-flow signs: money you receive is positive, money you pay
 * out is negative. Every solved value satisfies
 *   PV × (1 + i)ⁿ + PMT × A + FV = 0,   where A = ((1 + i)ⁿ − 1) ÷ i × (1 + i × t)
 * with i = I/Y ÷ P/Y, n = N, and t = 1 for beginning-of-period payments, otherwise 0.
 */
export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'solve',
			label: 'Solve for',
			type: 'select',
			display: 'menu',
			default: 'fv',
			options: SOLVE_OPTIONS,
			help: 'The one value to calculate. The others are the inputs.'
		},
		{
			id: 'n',
			label: 'Number of periods (N)',
			type: 'number',
			default: 120,
			min: 0.01,
			max: 10_000,
			step: 1,
			help: 'Total payment periods, not years.',
			visibleWhen: (v) => v.solve !== 'n'
		},
		{
			id: 'iy',
			label: 'Interest rate per year (I/Y)',
			type: 'number',
			default: 6,
			min: 0,
			max: 1000,
			step: 0.01,
			suffix: '%',
			visibleWhen: (v) => v.solve !== 'iy'
		},
		{
			id: 'pv',
			label: 'Present value (PV)',
			type: 'number',
			default: -1000,
			min: -1_000_000_000,
			max: 1_000_000_000,
			step: 100,
			prefix: '$',
			help: 'Money now. Use a minus sign if you pay it out.',
			visibleWhen: (v) => v.solve !== 'pv'
		},
		{
			id: 'pmt',
			label: 'Payment per period (PMT)',
			type: 'number',
			default: -100,
			min: -1_000_000_000,
			max: 1_000_000_000,
			step: 10,
			prefix: '$',
			help: 'Regular payment. Minus if you pay it, plus if you receive it.',
			visibleWhen: (v) => v.solve !== 'pmt'
		},
		{
			id: 'fv',
			label: 'Future value (FV)',
			type: 'number',
			default: 20000,
			min: -1_000_000_000,
			max: 1_000_000_000,
			step: 100,
			prefix: '$',
			help: 'Money at the end. Plus if you receive it, minus if you pay it.',
			visibleWhen: (v) => v.solve !== 'fv'
		},
		{ id: 'py', label: 'Payments per year (P/Y)', type: 'select', display: 'menu', default: '12', options: PER_YEAR, help: 'Compounding is set equal to payments per year (C/Y).' },
		{ id: 'timing', label: 'Payment timing', type: 'select', display: 'segmented', default: 'end', options: TIMING }
	],
	calculate(v: InputValues): CalculationResult {
		const solve = String(v.solve);
		const beginning = v.timing === 'beginning';
		const periodsPerYear = Number(v.py);
		const invalid = (summary: string): CalculationResult => ({
			primaryResult: DASH,
			primaryLabel: LABEL[solve] ?? 'Result',
			summary
		});

		if (!SOLVES.includes(solve) || !PER_YEAR.some((o) => o.value === String(v.py)) || (v.timing !== 'end' && !beginning)) {
			return invalid('Check the solve-for choice, payments per year and timing.');
		}

		const nIn = Number(v.n);
		const iyIn = Number(v.iy);
		const pvIn = Number(v.pv);
		const pmtIn = Number(v.pmt);
		const fvIn = Number(v.fv);

		if (
			(solve !== 'n' && !(nIn > 0 && nIn <= 10_000)) ||
			(solve !== 'iy' && !(iyIn >= 0 && iyIn <= 1000)) ||
			(solve !== 'pv' && !Number.isFinite(pvIn)) ||
			(solve !== 'pmt' && !Number.isFinite(pmtIn)) ||
			(solve !== 'fv' && !Number.isFinite(fvIn))
		) {
			return invalid('Fill in the other values. N must be above zero, and the rate must be from 0 to 1,000%.');
		}

		const i = iyIn / 100 / periodsPerYear;
		const n = nIn;
		let answer = NaN;
		let periods = n;
		let rate = i;

		switch (solve) {
			case 'fv':
				answer = -(pvIn * growth(i, n) + pmtIn * annuityFactor(i, n, beginning));
				break;
			case 'pv':
				answer = -(pmtIn * annuityFactor(i, n, beginning) + fvIn) / growth(i, n);
				break;
			case 'pmt':
				answer = -(pvIn * growth(i, n) + fvIn) / annuityFactor(i, n, beginning);
				break;
			case 'n': {
				const t = beginning ? 1 : 0;
				if (i === 0) {
					periods = pmtIn === 0 ? NaN : -(pvIn + fvIn) / pmtIn;
				} else {
					const c = (pmtIn * (1 + i * t)) / i;
					const denom = pvIn + c;
					const S = denom === 0 ? NaN : (c - fvIn) / denom;
					periods = S > 0 ? Math.log(S) / Math.log1p(i) : NaN;
				}
				answer = periods;
				break;
			}
			case 'iy': {
				rate = solveRate(n, beginning, pvIn, pmtIn, fvIn);
				answer = rate * periodsPerYear * 100;
				break;
			}
		}

		if (!Number.isFinite(answer) || (solve === 'n' && !(periods > 0))) {
			return invalid('No answer for these values. Check the signs: money in and money out must point in opposite directions.');
		}

		const finalN = solve === 'n' ? periods : n;
		const finalRate = solve === 'iy' ? rate : i;
		const shown =
			solve === 'n' ? `${num(periods, 2, 2)} periods` : solve === 'iy' ? `${num(answer, 4)}%` : money(answer);

		return {
			primaryResult: shown,
			primaryLabel: LABEL[solve],
			summary: `Solved with ${periodsPerYear} payments a year, ${beginning ? 'at the beginning' : 'at the end'} of each period.`,
			secondaryMetrics: [
				{ label: 'Rate per period', value: `${num(finalRate * 100, 4, 4)}%` },
				{ label: 'Periods (N)', value: num(finalN, 2, 2) },
				{ label: 'Years (N ÷ P/Y)', value: num(finalN / periodsPerYear, 2, 2) }
			]
		};
	},
	content: {
		intro:
			'Solve any one of the five time-value-of-money values from the other four. Use it for loans, savings goals and regular payments, and use the same signs for every cash flow so the answers agree.',
		howTo: [
			'Choose the value to solve for. Its box is hidden because the calculator works it out.',
			'Enter N (periods), I/Y (the yearly rate), PV, PMT and FV. Use a minus sign for money you pay out.',
			'Choose payments per year. Interest compounds at the same frequency, so I/Y is divided by P/Y.',
			'Choose end or beginning timing, then read the answer and the periodic rate below it.'
		],
		formulas: [
			{
				title: 'Cash-flow signs',
				expression: 'Money you receive is positive. Money you pay out is negative.',
				variables: [
					{ symbol: 'PV', meaning: 'a loan you receive is positive; an investment you make is negative' },
					{ symbol: 'PMT', meaning: 'a loan payment you make is negative; a regular income you receive is positive' },
					{ symbol: 'FV', meaning: 'a balance you receive later is positive' }
				]
			},
			{
				title: 'Time-value equation',
				expression: 'PV × (1 + i)ⁿ + PMT × A + FV = 0,   A = ((1 + i)ⁿ − 1) ÷ i × (1 + i × t)',
				variables: [
					{ symbol: 'i', meaning: 'rate per period: I/Y ÷ P/Y, as a decimal' },
					{ symbol: 'n', meaning: 'number of periods (N)' },
					{ symbol: 't', meaning: '1 for beginning-of-period payments, otherwise 0' }
				]
			},
			{
				title: 'Solving for N',
				expression: 'N = ln(S) ÷ ln(1 + i),   S = (PMT × (1 + i × t) ÷ i − FV) ÷ (PV + PMT × (1 + i × t) ÷ i)',
				variables: [{ symbol: 'ln', meaning: 'natural logarithm' }]
			},
			{
				title: 'Solving for I/Y',
				expression: 'Find i so that the time-value equation equals zero, then I/Y = i × P/Y × 100',
				variables: [{ symbol: 'i', meaning: 'found by bisection, since no simple formula exists' }]
			}
		],
		example: {
			title: 'A $200,000 loan at 6% a year, repaid monthly over 30 years',
			steps: [
				'Per-month rate: i = 6 ÷ 12 ÷ 100 = 0.005, with N = 30 × 12 = 360 payments',
				'Growth factor: 1.005³⁶⁰ ≈ 6.022575',
				'Annuity factor: (6.022575 − 1) ÷ 0.005 ≈ 1,004.515',
				'Payment: PMT = −(PV × 6.022575 + FV × 0) ÷ 1,004.515 = −($200,000 × 6.022575) ÷ 1,004.515 ≈ −$1,199.10'
			],
			result: 'The monthly payment is about $1,199.10. It is negative because you pay it out, and the loan is positive because you receive it.'
		},
		faq: [
			{
				q: 'Why are some answers negative?',
				a: 'The sign shows direction. A negative PMT or PV means money you pay out. Use the same sign rule for every value, and the equation will balance.'
			},
			{
				q: 'Do I enter the number of years or periods?',
				a: 'Enter periods for N. For a 10-year monthly plan, enter 120 with 12 payments a year. The years line below the result shows N divided by P/Y.'
			},
			{
				q: 'Why does the calculator say there is no answer?',
				a: 'Some sign and value combinations have no solution. For example, if every cash flow is paid out and none is received, a balance can never be reached. Check the signs and the other values.'
			},
			{
				q: 'Why is I/Y found differently from the other values?',
				a: 'The rate appears inside a power, so it cannot be isolated with a simple formula. The calculator searches for the rate that makes the equation balance.'
			}
		],
		sources: [{ title: 'U.S. Securities and Exchange Commission — Investor.gov', url: 'https://www.investor.gov' }],
		disclaimer:
			'Estimates only. Real loans and investments can include fees, rate changes and taxes that this calculator does not model.'
	}
});
