import { defineMeta } from '../types';

export default defineMeta({
	slug: 'debt-consolidation-calculator',
	name: 'Debt Consolidation Calculator',
	category: 'finance',
	shortDescription: 'Compare paying your debts separately with one consolidation loan.',
	metaTitle: 'Debt Consolidation Calculator — Savings Compared',
	metaDescription:
		'Free debt consolidation calculator. List your debts and the new loan terms to compare monthly payments, payoff time and total interest against one loan.',
	icon: 'layers',
	keywords: ['debt consolidation calculator', 'consolidation loan calculator', 'combine debts', 'debt consolidation savings', 'debt payoff comparison'],
	updated: '2026-10-28'
});
