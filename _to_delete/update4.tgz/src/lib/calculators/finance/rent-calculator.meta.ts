import { defineMeta } from '../types';

export default defineMeta({
	slug: 'rent-calculator',
	name: 'Rent Calculator',
	category: 'finance',
	shortDescription: 'How much rent you can afford, or the income you need for a rent.',
	metaTitle: 'Rent Calculator — Affordable Rent & Income Needed',
	metaDescription:
		'Free rent calculator. Find the rent you can afford from your income and debts, or the yearly income you need for a set rent, using the 30% and 40× rules.',
	icon: 'house',
	keywords: ['rent calculator', 'how much rent can I afford', 'rent to income', '30 percent rule', 'income needed for rent'],
	updated: '2026-10-28'
});
