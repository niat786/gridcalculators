import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, pct, plural } from '../format';
import meta from './rent-vs-buy-calculator.meta';

const ok = (x: number, lo: number, hi: number) => Number.isFinite(x) && x >= lo && x <= hi;

/** Monthly principal and interest: M = P × r × (1 + r)ⁿ ÷ ((1 + r)ⁿ − 1), with r = 0 → P ÷ n. */
function monthlyPayment(principal: number, annualPct: number, months: number): number {
	const r = annualPct / 1200;
	if (r === 0) return principal / months;
	const f = Math.pow(1 + r, months);
	return (principal * r * f) / (f - 1);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'years', label: 'Years to compare', type: 'number', default: 10, min: 1, max: 30, step: 1, suffix: 'years', decimal: false },
		{ id: 'price', label: 'Home price', type: 'number', default: 400000, min: 1, max: 100_000_000, step: 1000, prefix: '$' },
		{ id: 'down', label: 'Down payment', type: 'number', default: 20, min: 0, max: 100, step: 0.5, suffix: '%' },
		{ id: 'rate', label: 'Mortgage rate', type: 'number', default: 6.5, min: 0, max: 30, step: 0.01, suffix: '%' },
		{
			id: 'term',
			label: 'Mortgage term',
			type: 'select',
			display: 'segmented',
			default: '30',
			options: [
				{ label: '15 yr', value: '15' },
				{ label: '20 yr', value: '20' },
				{ label: '30 yr', value: '30' }
			]
		},
		{
			id: 'tax',
			label: 'Property tax',
			type: 'number',
			default: 1.1,
			min: 0,
			max: 20,
			step: 0.05,
			suffix: '% a year',
			help: 'Percent of the home value each year'
		},
		{
			id: 'maint',
			label: 'Maintenance',
			type: 'number',
			default: 1,
			min: 0,
			max: 20,
			step: 0.1,
			suffix: '% a year',
			help: 'Percent of the home value each year'
		},
		{ id: 'insurance', label: 'Home insurance', type: 'number', default: 1500, min: 0, max: 1_000_000, step: 100, prefix: '$', suffix: '/yr' },
		{
			id: 'appreciation',
			label: 'Home appreciation',
			type: 'number',
			default: 3,
			min: -20,
			max: 30,
			step: 0.1,
			suffix: '% a year'
		},
		{
			id: 'selling',
			label: 'Selling costs',
			type: 'number',
			default: 6,
			min: 0,
			max: 30,
			step: 0.5,
			suffix: '%',
			help: 'Agent and other fees, as a share of the sale price'
		},
		{ id: 'rent', label: 'Monthly rent', type: 'number', default: 2000, min: 0, max: 1_000_000, step: 50, prefix: '$', suffix: '/mo' },
		{
			id: 'rentIncrease',
			label: 'Rent increase',
			type: 'number',
			default: 3,
			min: -10,
			max: 20,
			step: 0.1,
			suffix: '% a year'
		},
		{
			id: 'invest',
			label: 'Return on savings',
			type: 'number',
			default: 5,
			min: -20,
			max: 50,
			step: 0.1,
			suffix: '% a year',
			help: 'Growth on the down payment if you rent and invest it instead'
		}
	],
	calculate(v): CalculationResult {
		const years = Number(v.years);
		const price = Number(v.price);
		const down = Number(v.down);
		const rate = Number(v.rate);
		const term = Number(v.term);
		const tax = Number(v.tax);
		const maint = Number(v.maint);
		const insurance = Number(v.insurance);
		const appreciation = Number(v.appreciation);
		const selling = Number(v.selling);
		const monthlyRent = Number(v.rent);
		const rentIncrease = Number(v.rentIncrease);
		const invest = Number(v.invest);

		if (
			!Number.isInteger(years) ||
			!ok(years, 1, 30) ||
			!ok(price, 1, 1e9) ||
			!ok(down, 0, 100) ||
			!ok(rate, 0, 30) ||
			![15, 20, 30].includes(term) ||
			!ok(tax, 0, 20) ||
			!ok(maint, 0, 20) ||
			!ok(insurance, 0, 1e6) ||
			!ok(appreciation, -20, 30) ||
			!ok(selling, 0, 30) ||
			!ok(monthlyRent, 0, 1e6) ||
			!ok(rentIncrease, -10, 20) ||
			!ok(invest, -20, 50)
		) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Cheaper option',
				summary: 'Enter a whole number of years from 1 to 30 and valid values for every field.'
			};
		}

		const downPayment = price * (down / 100);
		const loan = price - downPayment;
		const months = term * 12;
		const monthlyPI = monthlyPayment(loan, rate, months);
		const monthlyRate = rate / 1200;
		const g = appreciation / 100;
		const growthOnSavings = invest / 100;
		const rentGrowth = rentIncrease / 100;

		let balance = loan;
		let cumulativeOwning = 0;
		let cumulativeRent = 0;
		let breakEven: number | null = null;
		let buyCost = 0;
		let rentCost = 0;
		const rows: Record<string, string>[] = [];

		for (let y = 1; y <= years; y++) {
			const valueStart = price * Math.pow(1 + g, y - 1);
			const valueEnd = price * Math.pow(1 + g, y);

			// Principal and interest for this year, stopping at the end of the mortgage term.
			let yearPaid = 0;
			for (let m = 0; m < 12; m++) {
				if ((y - 1) * 12 + m >= months || balance <= 0) break;
				const interest = balance * monthlyRate;
				const principal = Math.min(monthlyPI - interest, balance);
				balance -= principal;
				yearPaid += interest + principal;
			}
			if (balance < 0.005) balance = 0;

			cumulativeOwning += yearPaid + (tax / 100) * valueStart + (maint / 100) * valueStart + insurance;
			const netSaleProceeds = valueEnd * (1 - selling / 100) - balance;
			buyCost = downPayment + cumulativeOwning - netSaleProceeds;

			cumulativeRent += monthlyRent * 12 * Math.pow(1 + rentGrowth, y - 1);
			rentCost = cumulativeRent - downPayment * (Math.pow(1 + growthOnSavings, y) - 1);

			const buyCheaper = buyCost <= rentCost;
			if (breakEven === null && buyCheaper) breakEven = y;

			rows.push({
				year: num(y),
				buy: money(buyCost, true),
				rent: money(rentCost, true),
				cheaper: buyCheaper ? 'Buying' : 'Renting'
			});
		}

		const diff = rentCost - buyCost;
		const even = Math.abs(diff) < 0.5;
		const winner = even ? 'Even' : diff > 0 ? 'Buying' : 'Renting';
		const summary = even
			? `Over ${plural(years, 'year')}, the two options cost about the same.`
			: `Over ${plural(years, 'year')}, ${winner === 'Buying' ? 'buying' : 'renting'} costs ${money(Math.abs(diff), true)} less than ${
					winner === 'Buying' ? 'renting' : 'buying'
				}.`;

		return {
			primaryResult: winner,
			primaryLabel: `Cheaper over ${plural(years, 'year')}`,
			summary,
			secondaryMetrics: [
				{ label: 'Buying net cost', value: money(buyCost, true) },
				{ label: 'Renting net cost', value: money(rentCost, true) },
				{ label: 'Difference', value: money(Math.abs(diff), true) },
				{
					label: 'Break-even year',
					value: breakEven !== null ? `Year ${breakEven}` : `Not within ${plural(years, 'year')}`
				},
				{ label: 'Monthly principal and interest', value: money(monthlyPI) }
			],
			table: {
				title: 'Year-by-year net cost',
				collapsed: true,
				columns: [
					{ key: 'year', label: 'Year' },
					{ key: 'buy', label: 'Buying', align: 'end' },
					{ key: 'rent', label: 'Renting', align: 'end' },
					{ key: 'cheaper', label: 'Cheaper', align: 'end' }
				],
				rows
			}
		};
	},
	content: {
		intro:
			'Compare the cost of buying a home with the cost of renting and investing your down payment. The calculator adds up each year on both sides and shows which option is cheaper over the period you choose.',
		howTo: [
			'Enter how many years you want to compare, plus the home price, down payment and mortgage details.',
			'Enter the yearly property tax, maintenance and insurance for the home.',
			'Enter your current monthly rent, how fast you expect it to rise, and what your savings could earn.',
			'Read which option is cheaper, the break-even year, and the year-by-year table.'
		],
		formulas: [
			{
				title: 'Net cost of buying (end of year y)',
				expression: 'Down payment + payments + tax + maintenance + insurance − net sale proceeds',
				variables: [
					{ symbol: 'payments', meaning: 'principal and interest paid to date, for up to the mortgage term' },
					{ symbol: 'net sale proceeds', meaning: 'home value × (1 − selling costs) − loan balance' }
				]
			},
			{
				title: 'Net cost of renting (end of year y)',
				expression: 'Rent paid − down payment × ((1 + return)ʸ − 1)',
				variables: [
					{ symbol: 'rent paid', meaning: 'monthly rent × 12, rising each year by the rent increase, added up to year y' },
					{ symbol: 'return', meaning: 'yearly return on the savings you would have invested' }
				]
			},
			{
				title: 'Monthly principal and interest',
				expression: 'M = L × r × (1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'L', meaning: 'loan: home price minus down payment' },
					{ symbol: 'r', meaning: 'monthly rate: annual rate ÷ 12 ÷ 100' },
					{ symbol: 'n', meaning: 'number of monthly payments: term in years × 12' }
				]
			}
		],
		example: {
			title: 'Comparing 10 years: a $400,000 home with 20% down at 6.5% over 30 years, against $2,000 rent',
			steps: [
				'Down payment = $80,000, loan = $320,000, and the monthly principal and interest is $2,022.62',
				'After 10 years, principal and interest total $242,714.12, tax $50,441.07, maintenance $45,855.52 and insurance $15,000',
				'Home value grows to $537,566.55. After 6% selling costs and the $271,283.60 loan balance, the sale leaves $234,028.95',
				'Buying cost = $80,000 + $242,714.12 + $50,441.07 + $45,855.52 + $15,000 − $234,028.95 ≈ $199,982',
				'Renting cost = $275,133.10 of rent − $50,311.57 of growth on the $80,000 down payment ≈ $224,822'
			],
			result: 'Buying is cheaper by about $24,840 over 10 years, and it becomes cheaper than renting in year 8.'
		},
		faq: [
			{
				q: 'What does net cost mean?',
				a: 'It is the cash you put in, minus what you get back. For buying, that is the down payment and yearly costs, minus the money you keep after selling. For renting, it is the rent you pay, minus the growth on the down payment you invested.'
			},
			{
				q: 'What is the break-even year?',
				a: 'It is the first year in which buying costs no more than renting. If buying never catches up within your period, the result says so.'
			},
			{
				q: 'What does this calculator leave out?',
				a: 'Purchase closing costs and moving costs are not included, which makes buying look slightly cheaper than it is. Rates, appreciation and rent growth stay the same every year. Any yearly savings from the cheaper option are not invested, and taxes on the sale and income tax effects are ignored.'
			},
			{
				q: 'Does buying always win over a long period?',
				a: 'No. The answer depends on home price growth, interest rates, rent increases and what your savings would earn. Change one input at a time to see how much each one matters.'
			}
		],
		sources: [
			{ title: 'Consumer Financial Protection Bureau', url: 'https://www.consumerfinance.gov/' },
			{ title: 'U.S. Department of Housing and Urban Development', url: 'https://www.hud.gov/' }
		],
		disclaimer:
			'Estimates only. Real costs, prices, rents and investment returns vary, and this comparison is not financial advice.'
	}
});
