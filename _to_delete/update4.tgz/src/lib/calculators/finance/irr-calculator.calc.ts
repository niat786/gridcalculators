import { defineCalculator, type CalculationResult, type InputValues, type RowValue } from '../types';
import { DASH, money, num, pct } from '../format';
import meta from './irr-calculator.meta';

/** Net present value with the first flow at time 0 and each later row one period further on. */
export function npv(flows: number[], rate: number): number {
	let total = 0;
	for (let t = 0; t < flows.length; t++) total += flows[t] / Math.pow(1 + rate, t);
	return Math.abs(total) < 1e-9 ? 0 : total;
}

/** Internal rate of return per period by bisection. Returns null when NPV does not change sign. */
export function irr(flows: number[]): number | null {
	let lo = -0.99;
	let hi = 10;
	let fLo = npv(flows, lo);
	const fHi = npv(flows, hi);
	if (!Number.isFinite(fLo) || !Number.isFinite(fHi) || (fLo > 0) === (fHi > 0)) return null;
	for (let i = 0; i < 300; i++) {
		const mid = (lo + hi) / 2;
		const fMid = npv(flows, mid);
		if (fMid === 0) return mid;
		if ((fMid > 0) === (fLo > 0)) {
			lo = mid;
			fLo = fMid;
		} else {
			hi = mid;
		}
	}
	return (lo + hi) / 2;
}

/** Periods (counted by row, first row = 0) until the running total turns positive, or null. */
export function paybackPeriods(flows: number[]): number | null {
	let cumulative = flows[0];
	if (cumulative >= 0) return 0;
	for (let t = 1; t < flows.length; t++) {
		const next = cumulative + flows[t];
		if (next >= 0) return t - 1 + -cumulative / flows[t];
		cumulative = next;
	}
	return null;
}

const DEFAULT_ROWS: RowValue[] = [
	{ label: 'Year 0', amount: -10000 },
	{ label: 'Year 1', amount: 3000 },
	{ label: 'Year 2', amount: 4000 },
	{ label: 'Year 3', amount: 4000 },
	{ label: 'Year 4', amount: 3000 },
	{ label: 'Year 5', amount: 2000 }
];

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'flows',
			label: 'Cash flows',
			type: 'rows',
			columns: [
				{ id: 'label', label: 'Period', type: 'text', default: '', placeholder: 'Label' },
				{ id: 'amount', label: 'Cash flow', type: 'number', default: 0, prefix: '$' }
			],
			default: DEFAULT_ROWS,
			minRows: 2,
			maxRows: 60,
			addLabel: 'Add period',
			help: 'Enter the first row as the investment, usually negative. Rows are equal time steps.'
		},
		{
			id: 'rate',
			label: 'Discount rate',
			type: 'number',
			default: 8,
			min: 0,
			max: 100,
			step: 0.1,
			suffix: '%',
			help: 'Per period. Used for NPV.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const rows = (v.flows as RowValue[]) ?? [];
		const rate = Number(v.rate);
		const labelOf = (row: RowValue, i: number) => String(row.label || `Row ${i + 1}`);
		const invalid = (summary: string): CalculationResult => ({
			primaryResult: DASH,
			primaryLabel: 'Internal rate of return',
			summary
		});

		if (rows.length < 2) return invalid('Enter at least two cash flows: the investment and one return.');
		const flows: number[] = [];
		for (const row of rows) {
			const amount = Number(row.amount);
			if (!Number.isFinite(amount)) return invalid('Enter an amount for every cash flow.');
			flows.push(amount);
		}
		if (!(rate >= 0 && rate <= 100)) return invalid('Enter a discount rate between 0% and 100%.');
		if (!flows.some((f) => f < 0) || !flows.some((f) => f > 0)) {
			return invalid(
				'IRR needs at least one negative and one positive cash flow. Enter the investment as a negative and the returns as positive.'
			);
		}

		const r = irr(flows);
		if (r === null) {
			return invalid('No IRR was found. The cash flows never cross zero between −99% and 1,000% per period.');
		}

		const npvAtRate = npv(flows, rate / 100);
		const payback = paybackPeriods(flows);
		const total = flows.reduce((s, f) => s + f, 0);

		let cumulative = 0;
		const table = {
			title: 'Cash flows, present value and running total',
			collapsed: true,
			columns: [
				{ key: 'period', label: 'Period' },
				{ key: 'flow', label: 'Cash flow', align: 'end' as const },
				{ key: 'pv', label: 'Present value', align: 'end' as const },
				{ key: 'running', label: 'Running total', align: 'end' as const }
			],
			rows: rows.map((row, t) => {
				const flow = flows[t];
				cumulative += flow;
				return {
					period: labelOf(row, t),
					flow: money(flow),
					pv: money(flow / Math.pow(1 + rate / 100, t)),
					running: money(cumulative)
				};
			})
		};

		const above = r * 100 > rate;
		return {
			primaryResult: pct(r * 100, 2),
			primaryLabel: 'Internal rate of return (per period)',
			summary: above
				? `The return is above your ${pct(rate, 2)} discount rate, so NPV is positive at that rate.`
				: `The return is at or below your ${pct(rate, 2)} discount rate, so NPV is zero or negative at that rate.`,
			secondaryMetrics: [
				{ label: `NPV at ${pct(rate, 2)}`, value: money(npvAtRate) },
				{ label: 'Payback period', value: payback === null ? 'Not reached' : `${num(payback, 2, 2)} periods` },
				{ label: 'Net total of cash flows', value: money(total) },
				{ label: 'Cash flows entered', value: num(flows.length, 0) }
			],
			table
		};
	},
	content: {
		intro:
			'Find the internal rate of return (IRR) of an investment from its cash flows. The calculator also shows the net present value (NPV) at your discount rate and how long the investment takes to pay back.',
		howTo: [
			'Enter the first cash flow as the investment, usually a negative number.',
			'Add each later cash flow in order, one row per equal time period.',
			'Enter the discount rate you would otherwise earn, per period.',
			'Read the IRR, then check the NPV and payback period.'
		],
		formulas: [
			{
				title: 'Net present value',
				expression: 'NPV = Σ CFₜ ÷ (1 + r)ᵗ',
				variables: [
					{ symbol: 'CFₜ', meaning: 'cash flow in period t (the first row is t = 0)' },
					{ symbol: 'r', meaning: 'discount rate per period, as a decimal' },
					{ symbol: 'Σ', meaning: 'sum over every row' }
				]
			},
			{
				title: 'Internal rate of return',
				expression: 'IRR is the rate r where NPV = 0',
				variables: [{ symbol: 'IRR', meaning: 'found here by bisection, to a very small tolerance' }]
			},
			{
				title: 'Payback period',
				expression: 'Payback = (last period before break-even) + (cost still unrecovered ÷ cash flow in the next period)',
				variables: []
			}
		],
		example: {
			title: 'A $10,000 investment that returns cash over five years',
			steps: [
				'Cash flows: −$10,000, $3,000, $4,000, $4,000, $3,000, $2,000',
				'Solve NPV = 0 for r: IRR ≈ 19.25% per year',
				'NPV at 8%: −$10,000 + $3,000 ÷ 1.08 + $4,000 ÷ 1.08² + … ≈ $2,948.72',
				'Running total turns positive in year 3: 2 + 3,000 ÷ 4,000 = 2.75 years'
			],
			result:
				'The IRR is 19.25% a year, the NPV at 8% is $2,948.72, and the payback period is 2.75 years.'
		},
		faq: [
			{
				q: 'What is a good IRR?',
				a: 'A good IRR is one above the return you could get elsewhere for similar risk. Compare it with your discount rate, the cost of borrowing, or the return on a safe investment.'
			},
			{
				q: 'Why does IRR need a negative and a positive cash flow?',
				a: 'IRR is the rate that makes the total present value zero. With only one sign, the total can never reach zero, so there is no rate to find.'
			},
			{
				q: 'What if I get two IRRs?',
				a: 'Cash flows that change sign more than once can have more than one rate that makes NPV zero. This calculator shows one of them. NPV at your discount rate is the more reliable guide in that case.'
			},
			{
				q: 'Are the rows monthly or yearly?',
				a: 'Either. The rate and payback use the same time step as your rows, so enter them as equal periods and set the discount rate per period.'
			}
		],
		sources: [
			{
				title: 'U.S. Securities and Exchange Commission, Investor.gov',
				url: 'https://www.investor.gov/'
			}
		],
		disclaimer:
			'Estimates from the cash flows you enter. Real returns depend on timing, taxes, fees and risk, and this is not investment advice.'
	}
});
