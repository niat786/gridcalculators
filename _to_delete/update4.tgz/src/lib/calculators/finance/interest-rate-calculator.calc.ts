import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, num, plural } from '../format';
import meta from './interest-rate-calculator.meta';

/** Present value of n equal payments at the monthly rate j. */
function presentValue(pay: number, j: number, n: number): number {
	return j === 0 ? pay * n : (pay * (1 - Math.pow(1 + j, -n))) / j;
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'amount', label: 'Loan amount', type: 'number', default: 20000, min: 1, max: 100_000_000, step: 100, prefix: '$' },
		{ id: 'months', label: 'Term (months)', type: 'number', default: 60, min: 1, max: 600, step: 1, suffix: 'months', decimal: false },
		{
			id: 'payment',
			label: 'Monthly payment',
			type: 'number',
			default: 396.02,
			min: 0.01,
			max: 100_000_000,
			step: 0.01,
			prefix: '$',
			help: 'The fixed payment on the loan'
		}
	],
	calculate(v): CalculationResult {
		const amount = Number(v.amount);
		const months = Number(v.months);
		const pay = Number(v.payment);
		const label = 'Annual interest rate';

		if (
			!(amount > 0) ||
			!Number.isFinite(amount) ||
			!Number.isInteger(months) ||
			months < 1 ||
			months > 600 ||
			!(pay > 0) ||
			!Number.isFinite(pay)
		) {
			return {
				primaryResult: DASH,
				primaryLabel: label,
				summary: 'Enter a loan amount above zero, a term of 1 to 600 months, and a monthly payment above zero.'
			};
		}

		const total = pay * months;
		if (total < amount) {
			return {
				primaryResult: DASH,
				primaryLabel: label,
				summary: `The payments add up to ${money(total)}, which is less than the ${money(amount)} loan, so no interest rate fits. Increase the payment or the term.`
			};
		}

		// The payments must be worth the loan today. Their present value falls as the rate rises,
		// so bisection on 0% to 100% finds the rate where the two match.
		if (presentValue(pay, 1 / 12, months) > amount) {
			return {
				primaryResult: DASH,
				primaryLabel: label,
				summary: 'These payments imply a rate above 100% a year. Check the payment and the term.'
			};
		}
		let lo = 0;
		let hi = 1;
		while (hi - lo > 1e-12) {
			const mid = (lo + hi) / 2;
			if (presentValue(pay, mid / 12, months) > amount) lo = mid;
			else hi = mid;
		}
		const annual = (lo + hi) / 2;

		return {
			primaryResult: `${num(annual * 100, 3, 2)}%`,
			primaryLabel: label,
			summary: `${money(pay)} a month for ${plural(months, 'month')} on ${money(amount)} implies this annual rate.`,
			secondaryMetrics: [
				{ label: 'Monthly rate', value: `${num((annual / 12) * 100, 4, 4)}%` },
				{ label: 'Total of payments', value: money(total) },
				{ label: 'Total interest', value: money(total - amount) },
				{ label: 'Number of payments', value: plural(months, 'payment') }
			]
		};
	},
	content: {
		intro:
			'Work out the annual interest rate hidden in a loan, from the amount borrowed, the term and the monthly payment. Useful when a lender quotes a payment but not the rate.',
		howTo: [
			'Enter the amount you borrowed.',
			'Enter the term in months.',
			'Enter the fixed monthly payment shown in your loan agreement.',
			'Read the annual rate and the total interest.'
		],
		formulas: [
			{
				title: 'Present value of the payments',
				expression: 'Loan = M × (1 − (1 + r)⁻ⁿ) ÷ r',
				variables: [
					{ symbol: 'M', meaning: 'monthly payment' },
					{ symbol: 'n', meaning: 'number of monthly payments' },
					{ symbol: 'r', meaning: 'monthly rate, solved for by bisection on 0% to 100% a year' }
				]
			},
			{
				title: 'Annual rate and total interest',
				expression: 'Annual rate = r × 12 × 100%        Total interest = M × n − Loan',
				variables: []
			}
		],
		example: {
			title: 'A $20,000 loan over 60 months with a $396.02 payment',
			steps: [
				'Total of payments: 396.02 × 60 = $23,761.20',
				'Total interest: 23,761.20 − 20,000 = $3,761.20',
				'Solve 396.02 × (1 − (1 + r)⁻⁶⁰) ÷ r = 20,000, which gives r ≈ 0.58330% a month',
				'Annual rate: 0.58330% × 12 = 7.00%'
			],
			result: 'The loan carries an annual interest rate of 7.00%, with $3,761.20 of total interest.'
		},
		faq: [
			{
				q: 'Why is it called an implied rate?',
				a: 'The loan agreement may show only the payment, the term and the amount. The rate is the figure that connects those three, so it is worked out rather than read off.'
			},
			{
				q: 'Why does the calculator show a dash?',
				a: 'A dash means the numbers cannot describe a loan. If the payments add up to less than the amount borrowed, no rate works. If the rate would exceed 100% a year, the inputs are probably wrong.'
			},
			{
				q: 'Does this include fees?',
				a: 'No. It finds the interest rate that matches the payments exactly. Upfront fees raise the real APR above this rate. Use the APR calculator to include them.'
			}
		],
		sources: [{ title: 'Consumer Financial Protection Bureau', url: 'https://www.consumerfinance.gov/' }],
		disclaimer:
			'Estimates only. The rate is worked out from the figures you enter and assumes fixed, equal monthly payments. Your loan agreement is the final word.'
	}
});
