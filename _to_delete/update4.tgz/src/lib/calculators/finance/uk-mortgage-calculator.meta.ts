import { defineMeta } from '../types';

export default defineMeta({
	slug: 'uk-mortgage-calculator',
	name: 'UK Mortgage Calculator',
	category: 'finance',
	shortDescription: 'Monthly payments in pounds for repayment or interest-only mortgages.',
	metaTitle: 'UK Mortgage Calculator — Repayment & Interest-Only',
	metaDescription:
		'Free UK mortgage calculator. Estimate monthly repayment or interest-only payments in pounds, plus total interest and the total you will repay.',
	icon: 'house',
	keywords: [
		'uk mortgage calculator',
		'repayment mortgage',
		'interest only mortgage',
		'mortgage payment uk',
		'monthly mortgage pounds'
	],
	updated: '2026-10-28'
});
