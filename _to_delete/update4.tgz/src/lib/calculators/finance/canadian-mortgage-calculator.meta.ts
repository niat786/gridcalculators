import { defineMeta } from '../types';

export default defineMeta({
	slug: 'canadian-mortgage-calculator',
	name: 'Canadian Mortgage Calculator',
	category: 'finance',
	shortDescription: 'CAD mortgage payments for every frequency, with interest and CMHC notes.',
	metaTitle: 'Canadian Mortgage Calculator — CAD Payments',
	metaDescription:
		'Free Canadian mortgage calculator. Compare monthly, semi-monthly, bi-weekly and weekly payments, including accelerated options, with semi-annual compounding.',
	icon: 'house',
	keywords: [
		'canadian mortgage calculator',
		'mortgage calculator canada',
		'cad mortgage payment',
		'bi-weekly mortgage canada',
		'accelerated bi-weekly',
		'cmhc insurance'
	],
	updated: '2026-10-28'
});
