import { defineCalculator, type CalculationResult, type RowValue } from '../types';
import { DASH, money, num } from '../format';
import meta from './debt-to-income-ratio-calculator.meta';

/** Plain reading of the back-end ratio. Lenders set their own limits, so these are guides. */
function band(ratio: number): { label: string; reading: string } {
	if (ratio <= 36) {
		return { label: 'Good', reading: 'At or under 36%. Most lenders see this as a comfortable level of debt.' };
	}
	if (ratio <= 43) {
		return {
			label: 'Manageable',
			reading: 'Between 36% and 43%. Many lenders still approve loans at this level, but they may look more closely at your application.'
		};
	}
	return {
		label: 'High',
		reading: 'Above 43%. Lenders often see this as a high level of debt, and loan options may be limited.'
	};
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'income',
			label: 'Gross monthly income',
			type: 'number',
			default: 6000,
			min: 0,
			max: 1_000_000_000,
			step: 100,
			prefix: '$',
			help: 'Income before tax and deductions.'
		},
		{
			id: 'housing',
			label: 'Monthly housing payment',
			type: 'number',
			default: 1800,
			min: 0,
			max: 1_000_000_000,
			step: 50,
			prefix: '$',
			suffix: '/mo',
			help: 'Rent, or your mortgage with taxes and insurance if you pay them.'
		},
		{
			id: 'debts',
			label: 'Other monthly debts',
			type: 'rows',
			columns: [
				{ id: 'name', label: 'Debt', type: 'text', default: '', placeholder: 'Debt name' },
				{ id: 'amount', label: 'Monthly payment', type: 'number', default: 0, min: 0, max: 1_000_000_000, prefix: '$' }
			],
			default: [
				{ name: 'Car loan', amount: 350 },
				{ name: 'Student loan', amount: 200 },
				{ name: 'Credit card minimum', amount: 120 }
			],
			maxRows: 20,
			addLabel: 'Add debt'
		}
	],
	calculate(v): CalculationResult {
		const income = Number(v.income);
		const housing = Number(v.housing);
		const rows = (v.debts as RowValue[]) ?? [];

		const invalid = (): CalculationResult => ({
			primaryResult: DASH,
			primaryLabel: 'Back-end ratio',
			summary: 'Enter your gross monthly income, housing payment and each debt payment.'
		});

		if (!(income > 0) || !(housing >= 0)) return invalid();

		let otherDebts = 0;
		for (const row of rows) {
			const amount = Number(row.amount);
			if (!Number.isFinite(amount) || amount < 0) return invalid();
			otherDebts += amount;
		}

		const totalDebt = housing + otherDebts;
		const back = (totalDebt / income) * 100;
		const front = (housing / income) * 100;
		// Round to the one decimal shown, so the band always matches the number on screen.
		const reading = band(Math.round(back * 10) / 10);

		return {
			primaryResult: `${num(back, 1, 1)}%`,
			primaryLabel: 'Back-end ratio',
			summary: `${reading.label}. ${reading.reading}`,
			secondaryMetrics: [
				{ label: 'Front-end ratio (housing)', value: `${num(front, 1, 1)}%` },
				{ label: 'Total monthly debt payments', value: money(totalDebt) },
				{ label: 'Other monthly debts', value: money(otherDebts) },
				{ label: 'Reading', value: reading.label }
			]
		};
	},
	content: {
		intro:
			'Your debt-to-income ratio compares your monthly debt payments with your gross monthly income. Lenders use it to judge how much room is left in your budget before they lend. This calculator gives your back-end ratio and your front-end (housing) ratio.',
		howTo: [
			'Enter your gross monthly income, which is your pay before tax and deductions.',
			'Enter your monthly housing payment: rent, or your mortgage with taxes and insurance.',
			'Add each other monthly debt payment, such as a car loan, student loan or card minimum.',
			'Read the back-end ratio, the front-end ratio and the plain reading below the result.'
		],
		formulas: [
			{
				title: 'Back-end ratio (debt-to-income)',
				expression: 'Back-end ratio = (housing payment + other debt payments) ÷ gross income × 100',
				variables: [{ symbol: '%', meaning: 'shown as a percentage of gross monthly income' }]
			},
			{
				title: 'Front-end ratio (housing)',
				expression: 'Front-end ratio = housing payment ÷ gross income × 100',
				variables: [{ symbol: 'gross income', meaning: 'monthly income before tax and deductions' }]
			}
		],
		example: {
			title: '$6,000 gross income, $1,800 housing and $670 in other debts',
			steps: [
				'Other debts: $350 + $200 + $120 = $670',
				'Total debt payments: $1,800 + $670 = $2,470',
				'Back-end ratio: $2,470 ÷ $6,000 × 100 ≈ 41.2%',
				'Front-end ratio: $1,800 ÷ $6,000 × 100 = 30.0%'
			],
			result: 'Back-end ratio 41.2%, which is in the manageable band, and front-end ratio 30.0%.'
		},
		faq: [
			{
				q: 'What is a good debt-to-income ratio?',
				a: 'A back-end ratio of 36% or less is generally seen as comfortable. Between 36% and 43% is manageable for many lenders, and above 43% is often considered high.'
			},
			{
				q: 'What is the difference between front-end and back-end ratios?',
				a: 'The front-end ratio counts only housing costs. The back-end ratio adds every other monthly debt payment, so it is always the larger of the two when you have other debts.'
			},
			{
				q: 'Should I use gross or take-home income?',
				a: 'Lenders usually use gross income, the amount before tax. Your take-home pay will be lower, so the same debts feel heavier in your budget than the ratio suggests.'
			},
			{
				q: 'Which debts count?',
				a: 'Include recurring payments that show on your credit report, such as loans, credit card minimums and child support or alimony. Leave out monthly bills like utilities, groceries and phone plans.'
			}
		],
		sources: [{ title: 'Consumer Financial Protection Bureau', url: 'https://www.consumerfinance.gov' }],
		disclaimer:
			'Estimates only, not a lending decision. Lenders vary in the ratios they accept, so check with your lender for the limits that apply to you.'
	}
});
