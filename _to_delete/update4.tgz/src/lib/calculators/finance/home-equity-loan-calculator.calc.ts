import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct, plural } from '../format';
import meta from './home-equity-loan-calculator.meta';

const isNum = (x: number, lo: number, hi: number) => Number.isFinite(x) && x >= lo && x <= hi;

/** Fixed-rate payment: M = P × r × (1 + r)ⁿ ÷ ((1 + r)ⁿ − 1), with r = 0 → P ÷ n. */
function monthlyPayment(principal: number, annualPct: number, months: number): number {
	const r = annualPct / 1200;
	if (r === 0) return principal / months;
	const f = Math.pow(1 + r, months);
	return (principal * r * f) / (f - 1);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'value', label: 'Home value', type: 'number', default: 400000, min: 1, max: 100_000_000, step: 1000, prefix: '$' },
		{ id: 'balance', label: 'Current mortgage balance', type: 'number', default: 200000, min: 0, max: 100_000_000, step: 1000, prefix: '$' },
		{
			id: 'ltv',
			label: 'Maximum combined loan-to-value',
			type: 'number',
			default: 85,
			min: 1,
			max: 100,
			step: 1,
			suffix: '%',
			help: 'Limit on all loans against the home, as a share of its value'
		},
		{ id: 'amount', label: 'Loan amount wanted', type: 'number', default: 100000, min: 0, max: 100_000_000, step: 1000, prefix: '$' },
		{ id: 'rate', label: 'Interest rate', type: 'number', default: 8, min: 0, max: 30, step: 0.01, suffix: '%', help: 'Annual fixed rate' },
		{ id: 'term', label: 'Loan term', type: 'number', default: 15, min: 1, max: 30, step: 1, suffix: 'years', decimal: false }
	],
	calculate(v): CalculationResult {
		const value = Number(v.value);
		const balance = Number(v.balance);
		const ltv = Number(v.ltv);
		const amount = Number(v.amount);
		const rate = Number(v.rate);
		const years = Number(v.term);

		if (
			!isNum(value, 1, 1e9) ||
			!isNum(balance, 0, 1e9) ||
			!isNum(ltv, 1, 100) ||
			!isNum(amount, 0, 1e9) ||
			!isNum(rate, 0, 30) ||
			!isNum(years, 1, 30) ||
			!Number.isInteger(years)
		) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Monthly payment',
				summary: 'Enter the home value, mortgage balance, loan-to-value limit, loan amount, rate and term.'
			};
		}

		const equity = value - balance;
		const maxCombined = value * (ltv / 100);
		const availableEquity = maxCombined - balance;

		if (availableEquity <= 0) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Monthly payment',
				summary: `Your mortgage balance is at or above ${pct(ltv, 0)} of the home value, so there is no equity to borrow against.`
			};
		}

		const months = years * 12;
		const payment = monthlyPayment(amount, rate, months);
		const totalRepaid = payment * months;
		const totalInterest = totalRepaid - amount;

		const summary =
			amount > availableEquity
				? `Warning: the amount you want is ${money(amount - availableEquity)} above your maximum. Lower it to ${money(availableEquity)} or less.`
				: `You can borrow up to ${money(availableEquity)} within a combined loan-to-value limit of ${pct(ltv, 0)}.`;

		return {
			primaryResult: money(payment),
			primaryLabel: 'Monthly payment',
			summary,
			secondaryMetrics: [
				{ label: 'Home equity', value: money(equity) },
				{ label: `Maximum combined loan (${pct(ltv, 0)} of value)`, value: money(maxCombined) },
				{ label: 'Available equity (maximum loan)', value: money(availableEquity) },
				{ label: 'Loan amount wanted', value: money(amount) },
				{ label: 'Total interest', value: money(totalInterest) },
				{ label: `Total of ${plural(months, 'payment')}`, value: money(totalRepaid) }
			]
		};
	},
	content: {
		intro:
			'Estimate how much you can borrow against your home equity and what the monthly payment would be on a home equity loan. The calculator applies your lender combined loan-to-value limit to your home value.',
		howTo: [
			'Enter the current value of your home and the balance left on your mortgage.',
			'Enter the maximum combined loan-to-value your lender allows, usually around 80% to 85%.',
			'Enter the loan amount you want, plus the interest rate and term.',
			'Read your available equity and monthly payment. A warning appears if the amount is above your limit.'
		],
		formulas: [
			{
				title: 'Available equity',
				expression: 'Available equity = home value × LTV ÷ 100 − mortgage balance',
				variables: [
					{ symbol: 'LTV', meaning: 'maximum combined loan-to-value, such as 85' },
					{ symbol: 'home equity', meaning: 'home value minus the mortgage balance' }
				]
			},
			{
				title: 'Monthly payment',
				expression: 'M = P × r × (1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'P', meaning: 'loan amount you want' },
					{ symbol: 'r', meaning: 'monthly rate: annual rate ÷ 12 ÷ 100' },
					{ symbol: 'n', meaning: 'number of monthly payments: years × 12' }
				]
			}
		],
		example: {
			title: 'A $400,000 home with a $200,000 mortgage, 85% limit, and a $100,000 loan at 8% for 15 years',
			steps: [
				'Maximum combined loan = $400,000 × 0.85 = $340,000',
				'Available equity = $340,000 − $200,000 = $140,000, so the $100,000 request is within the limit',
				'Monthly payment: $100,000 × 0.0066667 × (1.0066667)^180 ÷ ((1.0066667)^180 − 1) ≈ $955.65',
				'Total interest = $955.65 × 180 − $100,000 ≈ $72,017.38'
			],
			result: 'Up to $140,000 available, with a monthly payment of $955.65 on $100,000 and total interest of $72,017.38.'
		},
		faq: [
			{
				q: 'What is combined loan-to-value?',
				a: 'It is the total of your mortgage and any home equity loan, divided by the home value. Lenders set a limit, often 80% to 85%, so the new loan is capped by what is left under that limit.'
			},
			{
				q: 'Is a home equity loan the same as a HELOC?',
				a: 'No. A home equity loan pays out a lump sum and is repaid with fixed payments. A home equity line of credit, or HELOC, lets you draw money as needed and usually has a variable rate.'
			},
			{
				q: 'What happens if I borrow above the maximum?',
				a: 'Most lenders will not approve a loan above the combined limit. The calculator still shows the payment for the amount you entered, but the summary warns you to lower it.'
			},
			{
				q: 'What is not included?',
				a: 'Lender fees, appraisal costs, taxes and insurance are not included. Ask your lender for the full cost before you borrow.'
			}
		],
		sources: [
			{ title: 'Consumer Financial Protection Bureau: owning a home', url: 'https://www.consumerfinance.gov/owning-a-home/' },
			{ title: 'Consumer Financial Protection Bureau', url: 'https://www.consumerfinance.gov/' }
		],
		disclaimer:
			'Estimates only. Your lender sets the loan-to-value limit, rate and fees, and your approval depends on your credit and income.'
	}
});
