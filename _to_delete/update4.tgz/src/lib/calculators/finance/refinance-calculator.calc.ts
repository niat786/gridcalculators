import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct, plural } from '../format';
import meta from './refinance-calculator.meta';

const isNum = (x: number, lo: number, hi: number) => Number.isFinite(x) && x >= lo && x <= hi;

/** Fixed-rate payment: M = P × r × (1 + r)ⁿ ÷ ((1 + r)ⁿ − 1), with r = 0 → P ÷ n. */
function monthlyPayment(principal: number, annualPct: number, months: number): number {
	const r = annualPct / 1200;
	if (r === 0) return principal / months;
	const f = Math.pow(1 + r, months);
	return (principal * r * f) / (f - 1);
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'balance', label: 'Current loan balance', type: 'number', default: 300000, min: 1, max: 100_000_000, step: 1000, prefix: '$' },
		{ id: 'currentRate', label: 'Current interest rate', type: 'number', default: 6.5, min: 0, max: 30, step: 0.01, suffix: '%' },
		{
			id: 'remaining',
			label: 'Years left on current loan',
			type: 'number',
			default: 25,
			min: 1,
			max: 50,
			step: 1,
			suffix: 'years',
			decimal: false
		},
		{ id: 'newRate', label: 'New interest rate', type: 'number', default: 5.5, min: 0, max: 30, step: 0.01, suffix: '%' },
		{
			id: 'newTerm',
			label: 'New loan term',
			type: 'number',
			default: 30,
			min: 1,
			max: 50,
			step: 1,
			suffix: 'years',
			decimal: false
		},
		{
			id: 'closing',
			label: 'Closing costs',
			type: 'number',
			default: 4000,
			min: 0,
			max: 1_000_000,
			step: 100,
			prefix: '$',
			help: 'Fees you pay to refinance. They are not added to the new loan.'
		}
	],
	calculate(v): CalculationResult {
		const balance = Number(v.balance);
		const currentRate = Number(v.currentRate);
		const remaining = Number(v.remaining);
		const newRate = Number(v.newRate);
		const newTerm = Number(v.newTerm);
		const closing = Number(v.closing);

		if (
			!isNum(balance, 1, 1e9) ||
			!isNum(currentRate, 0, 30) ||
			!isNum(remaining, 1, 50) ||
			!isNum(newRate, 0, 30) ||
			!isNum(newTerm, 1, 50) ||
			!isNum(closing, 0, 1e9) ||
			!Number.isInteger(remaining) ||
			!Number.isInteger(newTerm)
		) {
			return {
				primaryResult: DASH,
				primaryLabel: 'New monthly payment',
				summary: 'Enter the loan balance, both rates, both terms in whole years, and the closing costs.'
			};
		}

		const currentMonths = remaining * 12;
		const newMonths = newTerm * 12;
		const currentPayment = monthlyPayment(balance, currentRate, currentMonths);
		const newPayment = monthlyPayment(balance, newRate, newMonths);
		const savings = currentPayment - newPayment;
		const breakEvenMonths = savings > 0 ? Math.ceil(closing / savings) : 0;
		const currentInterest = currentPayment * currentMonths - balance;
		const newInterest = newPayment * newMonths - balance;
		const interestDiff = currentInterest - newInterest;

		let summary: string;
		if (savings > 0) {
			summary = `The new payment is ${money(savings)} lower each month, so the closing costs are recovered in ${plural(breakEvenMonths, 'month')}.`;
		} else if (savings < 0) {
			summary = `The new payment is ${money(-savings)} higher each month, so there is no break-even point.`;
		} else {
			summary = 'The new payment is the same as your current one, so there is no break-even point.';
		}

		return {
			primaryResult: money(newPayment),
			primaryLabel: 'New monthly payment',
			summary,
			secondaryMetrics: [
				{ label: 'Current monthly payment', value: money(currentPayment) },
				{ label: 'Monthly savings', value: money(savings) },
				{
					label: 'Break-even point',
					value: savings > 0 ? plural(breakEvenMonths, 'month') : 'None (no monthly savings)'
				},
				{ label: 'Lifetime interest, current loan', value: money(currentInterest) },
				{ label: 'Lifetime interest, new loan', value: money(newInterest) },
				{
					label: 'Lifetime interest difference',
					value:
						interestDiff > 0
							? `${money(interestDiff)} less`
							: interestDiff < 0
								? `${money(-interestDiff)} more`
								: 'No difference'
				}
			]
		};
	},
	content: {
		intro:
			'Check whether refinancing your mortgage would lower your monthly payment. Compare your current and new payments, then see how long it takes for the monthly savings to cover the closing costs.',
		howTo: [
			'Enter the balance you still owe and the rate on your current loan.',
			'Enter how many years are left on that loan.',
			'Enter the new rate and the term of the refinanced loan, plus the closing costs.',
			'Read the new payment, the monthly savings and the break-even point.'
		],
		formulas: [
			{
				title: 'Monthly payment',
				expression: 'M = P × r × (1 + r)ⁿ ÷ ((1 + r)ⁿ − 1)',
				variables: [
					{ symbol: 'P', meaning: 'loan balance' },
					{ symbol: 'r', meaning: 'monthly rate: annual rate ÷ 12 ÷ 100' },
					{ symbol: 'n', meaning: 'number of monthly payments: years × 12' }
				]
			},
			{
				title: 'Break-even point',
				expression: 'Break-even months = closing costs ÷ monthly savings, rounded up',
				variables: [
					{ symbol: 'monthly savings', meaning: 'current payment minus new payment' }
				]
			},
			{
				title: 'Lifetime interest',
				expression: 'Interest = M × n − P',
				variables: [{ symbol: 'M × n', meaning: 'total of all payments over the loan term' }]
			}
		],
		example: {
			title: 'A $300,000 balance, 6.5% with 25 years left, refinanced at 5.5% for 30 years with $4,000 of costs',
			steps: [
				'Current payment at 6.5% over 300 months ≈ $2,025.62',
				'New payment at 5.5% over 360 months ≈ $1,703.37',
				'Monthly savings = $2,025.62 − $1,703.37 = $322.25',
				'Break-even = $4,000 ÷ $322.25 ≈ 12.4, rounded up to 13 months',
				'Lifetime interest is about $307,686.45 now and $313,212.12 after refinancing, so the longer term costs $5,525.68 more in interest'
			],
			result: 'A new payment of $1,703.37, monthly savings of $322.25, and a break-even point of 13 months.'
		},
		faq: [
			{
				q: 'What is a break-even point?',
				a: 'It is the number of months the monthly savings take to pay back your closing costs. Keep the loan longer than that to come out ahead.'
			},
			{
				q: 'Why can a lower payment still cost more interest?',
				a: 'Stretching the loan to a longer term lowers the payment but adds more monthly payments, so total interest can rise even at a lower rate. Compare the lifetime interest figures before you choose.'
			},
			{
				q: 'Are closing costs paid upfront or added to the loan?',
				a: 'This calculator assumes you pay them upfront and borrow the same balance. If you roll them into the new loan, enter the higher balance instead.'
			}
		],
		sources: [
			{ title: 'Consumer Financial Protection Bureau: explore interest rates', url: 'https://www.consumerfinance.gov/owning-a-home/explore-rates/' },
			{ title: 'Consumer Financial Protection Bureau', url: 'https://www.consumerfinance.gov/' }
		],
		disclaimer:
			'Estimates only. Refinancing fees, rate offers and eligibility depend on your lender and credit, and this does not include taxes or insurance.'
	}
});
