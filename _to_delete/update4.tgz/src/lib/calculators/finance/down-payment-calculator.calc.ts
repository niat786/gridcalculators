import { defineCalculator, type CalculationResult } from '../types';
import { DASH, money, pct, plural, num } from '../format';
import meta from './down-payment-calculator.meta';

const isNum = (x: number, lo: number, hi: number) => Number.isFinite(x) && x >= lo && x <= hi;

/** Whole months and years, e.g. "31 months (2 years 7 months)". */
function describeMonths(months: number): string {
	const years = Math.floor(months / 12);
	const rest = months % 12;
	if (years === 0) return plural(months, 'month');
	const detail = [plural(years, 'year'), rest > 0 ? plural(rest, 'month') : ''].filter(Boolean).join(' ');
	return `${plural(months, 'month')} (${detail})`;
}

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'price', label: 'Home price', type: 'number', default: 400000, min: 1, max: 100_000_000, step: 1000, prefix: '$' },
		{ id: 'down', label: 'Down payment', type: 'number', default: 20, min: 0, max: 100, step: 0.5, suffix: '%', help: 'Share of the home price' },
		{
			id: 'closing',
			label: 'Closing costs',
			type: 'number',
			default: 3,
			min: 0,
			max: 20,
			step: 0.5,
			suffix: '%',
			help: 'Share of the home price, paid at purchase'
		},
		{ id: 'savings', label: 'Savings you have now', type: 'number', default: 30000, min: 0, max: 100_000_000, step: 1000, prefix: '$' },
		{
			id: 'monthly',
			label: 'Savings added each month',
			type: 'number',
			default: 2000,
			min: 0,
			max: 1_000_000,
			step: 100,
			prefix: '$',
			suffix: '/mo'
		}
	],
	calculate(v): CalculationResult {
		const price = Number(v.price);
		const downPct = Number(v.down);
		const closingPct = Number(v.closing);
		const savings = Number(v.savings);
		const monthly = Number(v.monthly);

		if (
			!isNum(price, 1, 1e9) ||
			!isNum(downPct, 0, 100) ||
			!isNum(closingPct, 0, 20) ||
			!isNum(savings, 0, 1e9) ||
			!isNum(monthly, 0, 1e9)
		) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Total cash needed',
				summary: 'Enter a home price, a down payment and closing costs as percentages, and your savings.'
			};
		}

		const downPayment = price * (downPct / 100);
		const closingCosts = price * (closingPct / 100);
		const cashNeeded = downPayment + closingCosts;
		const loan = price - downPayment;
		const gap = Math.max(0, cashNeeded - savings);

		let months: number | null = 0;
		if (gap > 0) months = monthly > 0 ? Math.ceil(gap / monthly) : null;

		let timeText: string;
		let summary: string;
		if (gap === 0) {
			timeText = 'Already saved';
			summary = 'Your savings already cover the down payment and closing costs. Interest on savings is ignored.';
		} else if (months === null) {
			timeText = 'Not reached without monthly savings';
			summary = `You still need ${money(gap)}. Add monthly savings to see a timeline. Interest on savings is ignored.`;
		} else {
			timeText = describeMonths(months);
			summary = `At ${money(monthly)} a month, you reach ${money(cashNeeded)} in ${plural(months, 'month')}. Interest on savings is ignored.`;
		}

		return {
			primaryResult: money(cashNeeded),
			primaryLabel: 'Total cash needed',
			summary,
			secondaryMetrics: [
				{ label: 'Down payment', value: money(downPayment) },
				{ label: `Closing costs (${num(closingPct, 2)}%)`, value: money(closingCosts) },
				{ label: 'Loan amount', value: money(loan) },
				{ label: 'Still to save', value: money(gap) },
				{ label: 'Time to save', value: timeText }
			]
		};
	},
	content: {
		intro:
			'Find out how much cash you need to buy a home. The calculator adds your down payment and closing costs, shows the loan amount, and estimates how long your savings will take to cover the gap.',
		howTo: [
			'Enter the home price and the down payment as a percentage of that price.',
			'Enter closing costs as a percentage. Three percent is a common starting estimate.',
			'Enter the savings you already have and how much you can add each month.',
			'Read the total cash needed and the time to save. Set monthly savings to zero to see the gap alone.'
		],
		formulas: [
			{
				title: 'Cash needed',
				expression: 'Down payment = price × down % ÷ 100        Closing costs = price × closing % ÷ 100',
				variables: [{ symbol: 'Cash needed', meaning: 'down payment plus closing costs' }]
			},
			{
				title: 'Loan amount',
				expression: 'Loan = price − down payment',
				variables: [{ symbol: 'Loan', meaning: 'the amount you will borrow' }]
			},
			{
				title: 'Months to save',
				expression: 'Months = ⌈(cash needed − savings) ÷ monthly savings⌉',
				variables: [
					{ symbol: '⌈ ⌉', meaning: 'round up to the next whole month' },
					{ symbol: 'savings', meaning: 'money you already have set aside' }
				]
			}
		],
		example: {
			title: 'A $400,000 home with 20% down, 3% closing costs, $30,000 saved and $2,000 added each month',
			steps: [
				'Down payment = $400,000 × 20% = $80,000',
				'Closing costs = $400,000 × 3% = $12,000',
				'Cash needed = $80,000 + $12,000 = $92,000, and the loan is $320,000',
				'Still to save = $92,000 − $30,000 = $62,000',
				'Months = $62,000 ÷ $2,000 = 31, which is 2 years and 7 months'
			],
			result: 'Total cash needed of $92,000.00, with 31 months (2 years 7 months) of saving at $2,000 a month.'
		},
		faq: [
			{
				q: 'What are closing costs?',
				a: 'Closing costs are the fees you pay to finish a home purchase, such as lender, legal, title and inspection charges. They are often 2% to 5% of the price, but the amount varies by location and loan.'
			},
			{
				q: 'Is 20% down required?',
				a: 'No. Many loans allow a smaller down payment. A down payment under 20% usually means you must pay for mortgage insurance, which this calculator does not include.'
			},
			{
				q: 'Why does this ignore interest on my savings?',
				a: 'Keeping the timeline simple makes the result easy to check. Savings earning interest would reach your goal a little sooner.'
			}
		],
		sources: [
			{ title: 'Consumer Financial Protection Bureau', url: 'https://www.consumerfinance.gov/' },
			{ title: 'U.S. Department of Housing and Urban Development', url: 'https://www.hud.gov/' }
		],
		disclaimer:
			'Estimates only. Your actual closing costs, down payment rules and mortgage insurance depend on your lender, loan type and location.'
	}
});
