import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, money, num } from '../format';
import meta from './salary-calculator.meta';

/** Pay periods per year for each option. Hourly and daily depend on the working week. */
function periodsPerYear(period: string, hoursWeek: number, daysWeek: number): number {
	switch (period) {
		case 'hourly':
			return hoursWeek * 52;
		case 'daily':
			return daysWeek * 52;
		case 'weekly':
			return 52;
		case 'biweekly':
			return 26;
		case 'semimonthly':
			return 24;
		case 'monthly':
			return 12;
		case 'quarterly':
			return 4;
		default:
			return 1;
	}
}

const ROWS: { label: string; period: string }[] = [
	{ label: 'Hourly', period: 'hourly' },
	{ label: 'Daily', period: 'daily' },
	{ label: 'Weekly', period: 'weekly' },
	{ label: 'Bi-weekly (every 2 weeks)', period: 'biweekly' },
	{ label: 'Semi-monthly (24 a year)', period: 'semimonthly' },
	{ label: 'Monthly', period: 'monthly' },
	{ label: 'Quarterly', period: 'quarterly' },
	{ label: 'Annual', period: 'annual' }
];

export default defineCalculator({
	meta,
	inputs: [
		{ id: 'amount', label: 'Pay amount', type: 'number', default: 25, min: 0, max: 100_000_000, step: 0.5, prefix: '$', decimal: true },
		{
			id: 'period',
			label: 'Pay period',
			type: 'select',
			default: 'hourly',
			options: [
				{ label: 'Hourly', value: 'hourly' },
				{ label: 'Daily', value: 'daily' },
				{ label: 'Weekly', value: 'weekly' },
				{ label: 'Bi-weekly', value: 'biweekly' },
				{ label: 'Semi-monthly', value: 'semimonthly' },
				{ label: 'Monthly', value: 'monthly' },
				{ label: 'Quarterly', value: 'quarterly' },
				{ label: 'Annual', value: 'annual' }
			]
		},
		{ id: 'hours', label: 'Hours per week', type: 'number', default: 40, min: 0.5, max: 168, step: 0.5, suffix: 'hours' },
		{ id: 'days', label: 'Days per week', type: 'number', default: 5, min: 1, max: 7, step: 1, suffix: 'days', decimal: false },
		{
			id: 'off',
			label: 'Holidays and vacation',
			type: 'number',
			default: 0,
			min: 0,
			max: 365,
			step: 1,
			suffix: 'days/yr',
			decimal: false,
			help: 'Paid or unpaid days off per year. The adjusted column treats them as unpaid.'
		}
	],
	calculate(v: InputValues): CalculationResult {
		const amount = Number(v.amount);
		const period = String(v.period);
		const hours = Number(v.hours);
		const days = Number(v.days);
		const off = Number(v.off);
		const invalid = (): CalculationResult => ({
			primaryResult: DASH,
			primaryLabel: 'Annual pay',
			summary: 'Enter a pay amount, 1 to 7 working days, and hours between 0.5 and 168 a week.'
		});

		if (!(amount >= 0) || !(hours > 0 && hours <= 168) || !(days >= 1 && days <= 7) || !(off >= 0)) return invalid();

		const scheduledDays = days * 52;
		const workedDays = scheduledDays - off;
		if (!(workedDays > 0)) {
			return {
				primaryResult: DASH,
				primaryLabel: 'Annual pay',
				summary: 'Days off cannot cover the whole year. Enter fewer holiday and vacation days.'
			};
		}

		const perYear = periodsPerYear(period, hours, days);
		const annual = amount * perYear;
		const adjustedAnnual = annual * (workedDays / scheduledDays);
		const hourly = annual / (hours * 52);

		const table = {
			title: 'Pay for every period',
			columns: [
				{ key: 'period', label: 'Period' },
				{ key: 'unadjusted', label: 'Unadjusted', align: 'end' as const },
				{ key: 'adjusted', label: 'Adjusted for days off', align: 'end' as const }
			],
			rows: ROWS.map((r) => {
				const n = periodsPerYear(r.period, hours, days);
				return {
					period: r.label,
					unadjusted: money(annual / n),
					adjusted: money(adjustedAnnual / n)
				};
			})
		};

		const summary =
			off > 0
				? `Pre-tax. With ${num(off, 0)} days off unpaid, that is about ${money(adjustedAnnual)} a year.`
				: `Pre-tax, for ${num(hours, 1)} hours a week over ${num(days, 0)} days.`;

		return {
			primaryResult: money(annual),
			primaryLabel: 'Annual pay, before tax',
			summary,
			secondaryMetrics: [
				{ label: 'Hourly rate', value: money(hourly) },
				{ label: 'Adjusted annual pay', value: money(adjustedAnnual) },
				{ label: 'Working days a year', value: num(workedDays, 0) },
				{ label: 'Pay lost to days off', value: money(annual - adjustedAnnual) }
			],
			table
		};
	},
	content: {
		intro:
			'Convert a pay rate into every other pay period. Enter your pay and how it is paid, and see the hourly, daily, weekly, monthly and annual equivalents before tax.',
		howTo: [
			'Enter your pay amount and choose how often you are paid.',
			'Enter your usual hours and working days per week.',
			'Add the holidays and vacation days you take each year, if any.',
			'Read the annual pay, then compare the unadjusted and adjusted tables.'
		],
		formulas: [
			{
				title: 'Annual pay',
				expression: 'Annual pay = pay amount × pay periods per year',
				variables: [
					{ symbol: 'pay periods', meaning: 'hours × 52 for hourly, days × 52 for daily, 52 weekly, 26 bi-weekly, 24 semi-monthly, 12 monthly, 4 quarterly, 1 annual' }
				]
			},
			{
				title: 'Adjusted for days off',
				expression: 'Adjusted pay = annual pay × (working days − days off) ÷ working days',
				variables: [
					{ symbol: 'working days', meaning: 'days per week × 52' },
					{ symbol: 'days off', meaning: 'holidays and vacation days per year' }
				]
			},
			{
				title: 'Any period',
				expression: 'Pay per period = annual pay ÷ pay periods per year',
				variables: []
			}
		],
		example: {
			title: '$25 an hour, 40 hours a week, 10 days off a year',
			steps: [
				'Annual pay: $25 × 40 × 52 = $52,000.00',
				'Working days: 5 × 52 = 260 scheduled, minus 10 days off = 250 worked',
				'Adjusted annual pay: $52,000.00 × 250 ÷ 260 = $50,000.00',
				'Monthly, unadjusted: $52,000.00 ÷ 12 = $4,333.33'
			],
			result:
				'Before tax, $25 an hour is $52,000.00 a year. With 10 unpaid days off, it is about $50,000.00 a year.'
		},
		faq: [
			{
				q: 'Is this before or after tax?',
				a: 'Before tax. The results show gross pay only. Income tax, national insurance or payroll tax, pension contributions and other deductions will reduce your take-home pay.'
			},
			{
				q: 'What does adjusted for days off mean?',
				a: 'It shows what you earn across the year when holidays and vacation days are unpaid. Use the unadjusted column if your time off is paid.'
			},
			{
				q: 'How many hours is a standard year?',
				a: 'This calculator uses 52 weeks a year. Many full-time jobs use 40 hours a week, which gives 2,080 hours a year before any time off.'
			}
		],
		sources: [
			{
				title: 'U.S. Bureau of Labor Statistics',
				url: 'https://www.bls.gov/'
			}
		],
		disclaimer:
			'Pre-tax estimates only. Take-home pay depends on tax, benefits, deductions and your employer’s pay rules.'
	}
});
