import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './protein-calculator.meta';

const metric = (v: InputValues) => v.units === 'metric';
const imperial = (v: InputValues) => v.units === 'imperial';

const LB_TO_KG = 0.45359237;
const KG_TO_LB = 2.2046226218;
const KCAL_PER_GRAM_PROTEIN = 4;

/** Grams of protein per kg of body weight for each activity or goal. */
export const GOALS: Record<string, { label: string; low: number; high: number }> = {
	sedentary: { label: 'Sedentary adult: RDA, 0.8 g per kg', low: 0.8, high: 0.8 },
	active: { label: 'Active adult: 1.2 to 1.6 g per kg', low: 1.2, high: 1.6 },
	strength: { label: 'Strength training or building muscle: 1.6 to 2.2 g per kg', low: 1.6, high: 2.2 },
	older: { label: 'Adult 65 or older: 1.0 to 1.2 g per kg', low: 1.0, high: 1.2 }
};

const ok = (n: number) => Number.isFinite(n) && n > 0;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'metric',
			options: [
				{ label: 'Metric (kg)', value: 'metric' },
				{ label: 'Imperial (lb)', value: 'imperial' }
			]
		},
		{ id: 'kg', label: 'Body weight', type: 'number', default: 70, min: 30, max: 300, step: 0.1, suffix: 'kg', visibleWhen: metric },
		{ id: 'lb', label: 'Body weight', type: 'number', default: 154, min: 66, max: 660, step: 0.1, suffix: 'lb', visibleWhen: imperial },
		{
			id: 'goal',
			label: 'Activity or goal',
			type: 'select',
			display: 'menu',
			default: 'active',
			options: Object.entries(GOALS).map(([value, g]) => ({ value, label: g.label }))
		}
	],
	calculate(v): CalculationResult {
		const label = 'Daily protein target';
		const fail = (summary: string): CalculationResult => ({ primaryResult: DASH, primaryLabel: label, summary });

		const isImperial = v.units === 'imperial';
		const kg = isImperial ? Number(v.lb) * LB_TO_KG : Number(v.kg);
		const goal = GOALS[String(v.goal)];
		if (!ok(kg) || !goal) return fail('Enter your body weight and choose an activity or goal.');

		const lo = kg * goal.low;
		const hi = kg * goal.high;
		const fixed = goal.low === goal.high;
		const grams = (a: number, b: number) => (fixed ? `${num(a, 0)}` : `${num(a, 0)}–${num(b, 0)}`);
		const perKg = fixed ? `${num(goal.low, 1, 1)}` : `${num(goal.low, 1, 1)}–${num(goal.high, 1, 1)}`;
		const perMeal = (n: number) => `${grams(lo / n, hi / n)} g`;

		return {
			primaryResult: `${grams(lo, hi)} g/day`,
			primaryLabel: label,
			summary: `${perKg} g of protein for each kg of body weight.`,
			secondaryMetrics: [
				{ label: 'Per kg of body weight', value: `${perKg} g/kg` },
				{ label: 'Calories from protein', value: `${grams(lo * KCAL_PER_GRAM_PROTEIN, hi * KCAL_PER_GRAM_PROTEIN)} kcal` },
				{ label: 'Body weight used', value: `${num(kg, 1, 1)} kg (${num(kg * KG_TO_LB, 1, 1)} lb)` }
			],
			table: {
				title: 'Protein per meal',
				columns: [
					{ key: 'meals', label: 'Meals per day' },
					{ key: 'perMeal', label: 'Protein per meal', align: 'end' }
				],
				rows: [
					{ meals: '3 meals', perMeal: perMeal(3) },
					{ meals: '4 meals', perMeal: perMeal(4) }
				]
			}
		};
	},
	content: {
		intro:
			'Find your daily protein target in grams, based on your body weight and your activity level or goal. The table shows how that total splits across three or four meals.',
		howTo: [
			'Choose metric or imperial units and enter your body weight.',
			'Pick the option that best fits your activity level or goal.',
			'Read your daily grams, then use the table to plan grams per meal.'
		],
		formulas: [
			{
				title: 'Daily protein',
				expression: 'Protein (g) = body weight (kg) × grams per kg',
				variables: [
					{ symbol: 'grams per kg', meaning: '0.8 (sedentary), 1.2 to 1.6 (active), 1.6 to 2.2 (strength), 1.0 to 1.2 (age 65 and over)' }
				]
			},
			{
				title: 'Per meal',
				expression: 'Protein per meal (g) = daily grams ÷ number of meals',
				variables: []
			},
			{
				title: 'Calories from protein',
				expression: 'kcal = grams × 4',
				variables: [{ symbol: '4', meaning: 'kcal per gram of protein' }]
			}
		],
		example: {
			title: 'An active adult, 70 kg',
			steps: [
				'Low end: 70 × 1.2 = 84 g a day',
				'High end: 70 × 1.6 = 112 g a day',
				'Three meals: 84 ÷ 3 = 28 g and 112 ÷ 3 = 37 g per meal',
				'Four meals: 84 ÷ 4 = 21 g and 112 ÷ 4 = 28 g per meal'
			],
			result: 'About 84 to 112 g of protein a day, or 28 to 37 g per meal with three meals.'
		},
		faq: [
			{
				q: 'Where do these numbers come from?',
				a: '0.8 g per kg is the Recommended Dietary Allowance for healthy adults. It is the minimum most people need, not an optimum. The higher ranges for activity, strength training and older adults come from sports nutrition and ageing research.'
			},
			{
				q: 'Is more protein always better?',
				a: 'Not necessarily. Intakes well above these ranges give little extra benefit for most people, and high intakes can be a problem for people with kidney disease. Spreading protein across the day is a practical way to reach your target.'
			},
			{
				q: 'How much protein is in common foods?',
				a: 'As a rough guide, 100 g of cooked chicken breast has about 30 g of protein, a 170 g tub of Greek yogurt has about 15 to 20 g, and two large eggs have about 12 g.'
			},
			{
				q: 'Can I get enough protein from plants?',
				a: 'Yes. Beans, lentils, tofu, soy and other plant foods can meet your target. Some are lower in certain amino acids, so mixing sources across the day helps.'
			}
		],
		sources: [
			{ title: 'National Academies of Sciences, Engineering, and Medicine', url: 'https://www.nationalacademies.org/' },
			{ title: 'National Institutes of Health', url: 'https://www.nih.gov/' }
		],
		disclaimer:
			'These are general targets for healthy adults. If you have kidney disease or another kidney condition, your needs can be different, and a high protein intake may not suit you. Ask a doctor or dietitian before changing your protein intake.'
	}
});
