import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './carbohydrate-calculator.meta';

const metricEstimate = (v: InputValues) => v.mode === 'estimate' && v.units === 'metric';
const imperialEstimate = (v: InputValues) => v.mode === 'estimate' && v.units === 'imperial';
const estimate = (v: InputValues) => v.mode === 'estimate';
const direct = (v: InputValues) => v.mode === 'direct';

const LB_TO_KG = 0.45359237;
const KCAL_PER_GRAM_CARB = 4;

/** Activity factors applied to resting calories (same scale as the calorie calculator). */
export const ACTIVITY: Record<string, { factor: number; label: string }> = {
	sedentary: { factor: 1.2, label: 'Sedentary: little or no exercise' },
	light: { factor: 1.375, label: 'Light: exercise 1–3 days a week' },
	moderate: { factor: 1.55, label: 'Moderate: exercise 3–5 days a week' },
	active: { factor: 1.725, label: 'Active: hard exercise 6–7 days a week' },
	extra: { factor: 1.9, label: 'Very active: physical job or training twice a day' }
};

/** Dietary Guidelines for Americans: carbohydrate supplies 45 to 65 percent of daily calories. */
export const CARB_SHARES = [
	{ key: 'low', label: 'Low', pct: 45 },
	{ key: 'middle', label: 'Middle', pct: 55 },
	{ key: 'high', label: 'High', pct: 65 }
];

const ok = (n: number) => Number.isFinite(n) && n > 0;

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'mode',
			label: 'Calorie target from',
			type: 'select',
			display: 'segmented',
			default: 'estimate',
			options: [
				{ label: 'Estimate', value: 'estimate' },
				{ label: 'Enter calories', value: 'direct' }
			]
		},
		{
			id: 'kcal',
			label: 'Daily calories',
			type: 'number',
			default: 2000,
			min: 800,
			max: 6000,
			step: 1,
			decimal: false,
			suffix: 'kcal/day',
			visibleWhen: direct
		},
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'metric',
			visibleWhen: estimate,
			options: [
				{ label: 'Metric (kg, cm)', value: 'metric' },
				{ label: 'Imperial (lb, ft)', value: 'imperial' }
			]
		},
		{
			id: 'sex',
			label: 'Sex',
			type: 'select',
			display: 'segmented',
			default: 'female',
			visibleWhen: estimate,
			options: [
				{ label: 'Female', value: 'female' },
				{ label: 'Male', value: 'male' }
			]
		},
		{ id: 'age', label: 'Age', type: 'number', default: 30, min: 15, max: 80, step: 1, suffix: 'years', decimal: false, visibleWhen: estimate, help: 'For ages 15 to 80' },
		{ id: 'kg', label: 'Weight', type: 'number', default: 70, min: 30, max: 300, step: 0.1, suffix: 'kg', visibleWhen: metricEstimate },
		{ id: 'cm', label: 'Height', type: 'number', default: 170, min: 120, max: 230, step: 0.1, suffix: 'cm', visibleWhen: metricEstimate },
		{ id: 'lb', label: 'Weight', type: 'number', default: 154, min: 66, max: 660, step: 0.1, suffix: 'lb', visibleWhen: imperialEstimate },
		{ id: 'ft', label: 'Height (feet)', type: 'number', default: 5, min: 4, max: 7, step: 1, suffix: 'ft', decimal: false, width: 'half', visibleWhen: imperialEstimate },
		{ id: 'in', label: 'Height (inches)', type: 'number', default: 7, min: 0, max: 11.9, step: 0.1, suffix: 'in', width: 'half', visibleWhen: imperialEstimate },
		{
			id: 'activity',
			label: 'Activity level',
			type: 'select',
			display: 'menu',
			default: 'light',
			visibleWhen: estimate,
			options: Object.entries(ACTIVITY).map(([value, a]) => ({ value, label: a.label }))
		}
	],
	calculate(v): CalculationResult {
		const label = 'Daily carbohydrate range';
		const fail = (summary: string): CalculationResult => ({ primaryResult: DASH, primaryLabel: label, summary });

		let target: number;
		if (v.mode === 'direct') {
			target = Number(v.kcal);
			if (!ok(target)) return fail('Enter your daily calories.');
		} else {
			const isImperial = v.units === 'imperial';
			const kg = isImperial ? Number(v.lb) * LB_TO_KG : Number(v.kg);
			const cm = isImperial ? (Number(v.ft) * 12 + Number(v.in)) * 2.54 : Number(v.cm);
			const age = Number(v.age);
			const act = ACTIVITY[String(v.activity)];
			if (!ok(kg) || !ok(cm) || !ok(age) || !act) return fail('Fill in every field, or enter your daily calories instead.');
			const bmr = 10 * kg + 6.25 * cm - 5 * age + (v.sex === 'male' ? 5 : -161);
			target = Math.round(bmr * act.factor);
		}

		const levels = CARB_SHARES.map((s) => {
			const kcal = Math.round((target * s.pct) / 100);
			return { ...s, kcal, grams: Math.round(kcal / KCAL_PER_GRAM_CARB) };
		});
		const [low, mid, high] = levels;
		const source = v.mode === 'direct' ? `the ${num(target, 0)} kcal you entered` : `an estimated ${num(target, 0)} kcal a day`;

		return {
			primaryResult: `${num(low.grams, 0)}–${num(high.grams, 0)} g/day`,
			primaryLabel: label,
			summary: `Based on ${source}, with 45 to 65 percent from carbohydrate.`,
			secondaryMetrics: [
				{ label: 'Middle of range (55%)', value: `${num(mid.grams, 0)} g` },
				{ label: 'Calorie target', value: `${num(target, 0)} kcal/day` },
				{ label: 'Calories from carbs (55%)', value: `${num(mid.kcal, 0)} kcal` }
			],
			table: {
				title: 'Carbohydrate levels',
				columns: [
					{ key: 'level', label: 'Level' },
					{ key: 'share', label: 'Share of calories', align: 'end' },
					{ key: 'kcal', label: 'Calories / day', align: 'end' },
					{ key: 'grams', label: 'Grams / day', align: 'end' }
				],
				rows: levels.map((l) => ({
					level: l.label,
					share: `${l.pct}%`,
					kcal: `${num(l.kcal, 0)} kcal`,
					grams: `${num(l.grams, 0)} g`
				}))
			}
		};
	},
	content: {
		intro:
			'Turn your daily calories into grams of carbohydrate. Enter a calorie target you already know, or estimate one from your body and activity, and see the amount at 45%, 55% and 65% of your intake.',
		howTo: [
			'Choose whether to estimate your calories or enter a daily target you already know.',
			'If you estimate, enter your sex, age, weight, height and activity level.',
			'Read your daily carbohydrate range and the grams at each level in the table.'
		],
		formulas: [
			{
				title: 'Calorie target (estimate)',
				expression: 'Men:   BMR = 10W + 6.25H − 5A + 5\nWomen: BMR = 10W + 6.25H − 5A − 161\nTarget = BMR × activity factor (1.2 to 1.9)',
				variables: [
					{ symbol: 'W', meaning: 'weight in kilograms' },
					{ symbol: 'H', meaning: 'height in centimetres' },
					{ symbol: 'A', meaning: 'age in years' }
				]
			},
			{
				title: 'Grams of carbohydrate',
				expression: 'Calories from carbs = target × share (45%, 55% or 65%)\nGrams = calories ÷ 4',
				variables: [{ symbol: '4', meaning: 'kcal per gram of carbohydrate' }]
			}
		],
		example: {
			title: 'A 30-year-old woman, 70 kg, 170 cm, light activity',
			steps: [
				'BMR = 10 × 70 + 6.25 × 170 − 5 × 30 − 161 = 1,451.5 kcal',
				'Target = 1,451.5 × 1.375 = 1,996 kcal a day',
				'Low, 45%: 1,996 × 0.45 = 898 kcal, and 898 ÷ 4 = 225 g',
				'Middle, 55%: 1,996 × 0.55 = 1,098 kcal, and 1,098 ÷ 4 = 275 g',
				'High, 65%: 1,996 × 0.65 = 1,297 kcal, and 1,297 ÷ 4 = 324 g'
			],
			result: 'About 225 to 324 g of carbohydrate a day, with 275 g at the middle of the range.'
		},
		faq: [
			{
				q: 'What do the Dietary Guidelines say about carbohydrate?',
				a: 'The Dietary Guidelines for Americans suggest that 45 to 65 percent of daily calories come from carbohydrate. This is the acceptable range for adults, and it leaves room for different eating patterns.'
			},
			{
				q: 'Do carbs cause weight gain?',
				a: 'Carbohydrate does not cause weight gain on its own. Total calories matter most for body weight, and the carbohydrate share is a way of deciding what those calories are made of.'
			},
			{
				q: 'Are all carbs the same?',
				a: 'No. Whole grains, fruit, vegetables, beans and dairy bring fibre and other nutrients. Many added sugars and refined grains give fewer of these, so the grams are a total to fill with mostly whole-food sources.'
			},
			{
				q: 'Why does the calculator use 4 calories per gram?',
				a: 'Carbohydrate and protein each provide about 4 kilocalories per gram, the standard figure used on food labels. Fat provides 9.'
			}
		],
		sources: [
			{ title: 'Dietary Guidelines for Americans', url: 'https://www.dietaryguidelines.gov/' },
			{ title: 'National Academies of Sciences, Engineering, and Medicine', url: 'https://www.nationalacademies.org/' }
		],
		disclaimer:
			'General estimates for healthy adults, not a diet plan. If you have diabetes or another medical condition, ask a doctor or dietitian about your carbohydrate intake.'
	}
});
