import { defineCalculator, type CalculationResult, type InputValues } from '../types';
import { DASH, num } from '../format';
import meta from './pregnancy-weight-gain-calculator.meta';

const metric = (v: InputValues) => v.units === 'metric';
const imperial = (v: InputValues) => v.units === 'imperial';

const LB_TO_KG = 0.45359237;

type Cat = 'under' | 'normal' | 'over' | 'obese';
const CAT_LABEL: Record<Cat, string> = {
	under: 'Underweight',
	normal: 'Normal weight',
	over: 'Overweight',
	obese: 'Obesity'
};
const CAT_BMI: Record<Cat, string> = {
	under: 'Underweight (below 18.5)',
	normal: 'Normal weight (18.5 to 24.9)',
	over: 'Overweight (25 to 29.9)',
	obese: 'Obesity (30 and over)'
};

/** IOM 2009 total gain for one baby, in lb. */
const SINGLE_TOTAL: Record<Cat, [number, number]> = {
	under: [28, 40],
	normal: [25, 35],
	over: [15, 25],
	obese: [11, 20]
};
/** IOM 2009 total gain for twins, in lb. No range is set for underweight. */
const TWINS_TOTAL: Record<Cat, [number, number] | null> = {
	under: null,
	normal: [37, 54],
	over: [31, 50],
	obese: [25, 42]
};
/** IOM 2009 weekly gain after the first trimester for one baby, in lb per week. */
const SINGLE_RATE: Record<Cat, [number, number]> = {
	under: [1.0, 1.3],
	normal: [0.8, 1.0],
	over: [0.5, 0.7],
	obese: [0.4, 0.6]
};

function category(bmi: number): Cat {
	if (bmi < 18.5) return 'under';
	if (bmi < 25) return 'normal';
	if (bmi < 30) return 'over';
	return 'obese';
}

/** "3.0–5.2 kg (6.7–11.4 lb)", with the user's own unit first. */
function gain(loLb: number, hiLb: number, lbDecimals: number, imp: boolean): string {
	const lb = `${num(loLb, lbDecimals, lbDecimals)}–${num(hiLb, lbDecimals, lbDecimals)} lb`;
	const kg = `${num(loLb * LB_TO_KG, 1, 1)}–${num(hiLb * LB_TO_KG, 1, 1)} kg`;
	return imp ? `${lb} (${kg})` : `${kg} (${lb})`;
}

function pace(lo: number, hi: number, imp: boolean): string {
	return imp
		? `${num(lo, 1, 1)}–${num(hi, 1, 1)} lb a week`
		: `${num(lo * LB_TO_KG, 2, 2)}–${num(hi * LB_TO_KG, 2, 2)} kg a week`;
}

export default defineCalculator({
	meta,
	inputs: [
		{
			id: 'units',
			label: 'Units',
			type: 'select',
			display: 'segmented',
			default: 'metric',
			options: [
				{ label: 'Metric (kg, cm)', value: 'metric' },
				{ label: 'Imperial (lb, ft)', value: 'imperial' }
			]
		},
		{ id: 'kg', label: 'Weight before pregnancy', type: 'number', default: 65, min: 30, max: 300, step: 0.1, suffix: 'kg', visibleWhen: metric },
		{ id: 'cm', label: 'Height', type: 'number', default: 165, min: 120, max: 230, step: 0.1, suffix: 'cm', visibleWhen: metric },
		{ id: 'lb', label: 'Weight before pregnancy', type: 'number', default: 143, min: 66, max: 660, step: 0.1, suffix: 'lb', visibleWhen: imperial },
		{ id: 'ft', label: 'Height (feet)', type: 'number', default: 5, min: 4, max: 7, step: 1, suffix: 'ft', decimal: false, width: 'half', visibleWhen: imperial },
		{ id: 'in', label: 'Height (inches)', type: 'number', default: 5, min: 0, max: 11.9, step: 0.1, suffix: 'in', width: 'half', visibleWhen: imperial },
		{
			id: 'pregnancy',
			label: 'Pregnancy',
			type: 'select',
			display: 'segmented',
			default: 'single',
			options: [
				{ label: 'One baby', value: 'single' },
				{ label: 'Twins', value: 'twins' }
			]
		},
		{
			id: 'week',
			label: 'Current week of pregnancy',
			type: 'number',
			default: 20,
			min: 1,
			max: 42,
			step: 1,
			decimal: false,
			suffix: 'weeks',
			help: 'From 1 to 42'
		}
	],
	calculate(v): CalculationResult {
		const label = 'Recommended gain by week';
		const fail = (summary: string): CalculationResult => ({ primaryResult: DASH, primaryLabel: label, summary });

		const isImperial = v.units === 'imperial';
		const kg = isImperial ? Number(v.lb) * LB_TO_KG : Number(v.kg);
		const cm = isImperial ? (Number(v.ft) * 12 + Number(v.in)) * 2.54 : Number(v.cm);
		const week = Number(v.week);
		const twins = v.pregnancy === 'twins';
		if (!(kg > 0) || !(cm > 0) || !Number.isFinite(kg) || !Number.isFinite(cm)) return fail('Enter your weight and height before pregnancy.');
		if (!Number.isInteger(week) || week < 1 || week > 42) return fail('Enter the current week of pregnancy, from 1 to 42.');

		const bmi = kg / ((cm / 100) ** 2);
		const cat = category(bmi);
		const trimester = week <= 13 ? 'First trimester' : week <= 27 ? 'Second trimester' : 'Third trimester';
		const bmiText = `${num(bmi, 1, 1)} (${CAT_LABEL[cat]})`;
		const totalPair = twins ? TWINS_TOTAL[cat] : SINGLE_TOTAL[cat];
		const totalText = totalPair ? gain(totalPair[0], totalPair[1], 0, isImperial) : 'Not set by the IOM';

		const table = {
			title: 'Total recommended gain (IOM 2009)',
			columns: [
				{ key: 'bmi', label: 'Pre-pregnancy BMI' },
				{ key: 'single', label: 'One baby', align: 'end' as const },
				{ key: 'twins', label: 'Twins', align: 'end' as const }
			],
			rows: (['under', 'normal', 'over', 'obese'] as Cat[]).map((c) => {
				const s = SINGLE_TOTAL[c];
				const t = TWINS_TOTAL[c];
				return {
					bmi: CAT_BMI[c],
					single: gain(s[0], s[1], 0, isImperial),
					twins: t ? gain(t[0], t[1], 0, isImperial) : 'No guideline'
				};
			})
		};

		// Twins get total ranges only. Underweight twins have no range at all.
		if (twins) {
			if (!totalPair) {
				return {
					primaryResult: 'No guideline',
					primaryLabel: 'Total gain for twins',
					summary: 'The IOM did not set a range for underweight people expecting twins. Ask your care team what suits you.',
					secondaryMetrics: [
						{ label: 'Pre-pregnancy BMI', value: bmiText },
						{ label: 'Total gain goal', value: totalText },
						{ label: 'Pace after week 13', value: 'Not set' },
						{ label: 'Trimester', value: trimester }
					],
					table
				};
			}
			return {
				primaryResult: totalText,
				primaryLabel: 'Total gain for twins',
				summary: 'For twins the IOM gives total ranges only. Ask your care team for week-by-week advice.',
				secondaryMetrics: [
					{ label: 'Pre-pregnancy BMI', value: bmiText },
					{ label: 'Total gain goal', value: totalText },
					{ label: 'Pace after week 13', value: 'Ask your care team' },
					{ label: 'Trimester', value: trimester }
				],
				table
			};
		}

		// One baby: first trimester 1.1 to 4.4 lb in total (scaled by week), then the weekly rate.
		const [rLo, rHi] = SINGLE_RATE[cat];
		const after = Math.max(0, week - 13);
		const loLb = week <= 13 ? (1.1 * week) / 13 : 1.1 + rLo * after;
		const hiLb = week <= 13 ? (4.4 * week) / 13 : 4.4 + rHi * after;

		return {
			primaryResult: gain(loLb, hiLb, 1, isImperial),
			primaryLabel: `Recommended gain by week ${week}`,
			summary: `Based on a pre-pregnancy BMI of ${num(bmi, 1, 1)}. These are guides, and your care team can tailor them.`,
			secondaryMetrics: [
				{ label: 'Pre-pregnancy BMI', value: bmiText },
				{ label: 'Total gain goal', value: totalText },
				{ label: 'Pace after week 13', value: pace(rLo, rHi, isImperial) },
				{ label: 'Trimester', value: trimester }
			],
			table
		};
	},
	content: {
		intro:
			'Find out how much weight gain is generally recommended at your current week of pregnancy. It uses your weight before pregnancy and whether you are expecting one baby or twins, based on the 2009 Institute of Medicine guidelines.',
		howTo: [
			'Choose metric or imperial units, then enter your weight and height before pregnancy.',
			'Choose one baby or twins, and enter your current week of pregnancy.',
			'Read the recommended gain for this week, then compare it with the total goal in the table.'
		],
		formulas: [
			{
				title: 'Pre-pregnancy BMI',
				expression: 'BMI = weight in kg ÷ (height in m)²',
				variables: [{ symbol: 'BMI', meaning: 'body mass index before pregnancy, used to choose the category' }]
			},
			{
				title: 'First trimester (up to week 13)',
				expression: 'Gain = 1.1 to 4.4 lb in total by week 13, scaled by week ÷ 13',
				variables: []
			},
			{
				title: 'After week 13, one baby',
				expression:
					'Gain = first trimester total + weekly rate × (week − 13)\nWeekly rates: underweight 1.0–1.3, normal 0.8–1.0, overweight 0.5–0.7, obesity 0.4–0.6 lb a week',
				variables: []
			}
		],
		example: {
			title: 'A woman, 65 kg and 165 cm before pregnancy, at week 20 with one baby',
			steps: [
				'BMI = 65 ÷ 1.65² = 23.9, in the normal weight range',
				'Low end at week 20: 1.1 + 0.8 × (20 − 13) = 6.7 lb',
				'High end at week 20: 4.4 + 1.0 × (20 − 13) = 11.4 lb',
				'In kilograms: 6.7 lb = 3.0 kg and 11.4 lb = 5.2 kg',
				'Total goal for normal weight with one baby: 25 to 35 lb (11.3 to 15.9 kg)'
			],
			result: 'About 3.0 to 5.2 kg (6.7 to 11.4 lb) gained by week 20, on the way to 25 to 35 lb by the end.'
		},
		faq: [
			{
				q: 'Are these numbers targets I need to hit?',
				a: 'No. They are ranges that cover most healthy pregnancies. Weight gain varies a lot, and your care team looks at your growth and wellbeing as a whole rather than at one number.'
			},
			{
				q: 'What if I was already overweight or had obesity before pregnancy?',
				a: 'A higher pre-pregnancy weight comes with a lower recommended gain, to balance the risks for you and your baby. It is not a judgement, and your care team can help you plan.'
			},
			{
				q: 'Why are the totals higher for twins?',
				a: 'Two babies need more energy and more growth of the uterus and placenta, so the total gain is higher. The IOM sets only total ranges for twins, so weekly figures are not shown.'
			},
			{
				q: 'Why is there no range for underweight twins?',
				a: 'The IOM found too little evidence to set a range for this group. Your care team can advise on what is right for you.'
			},
			{
				q: 'What about the first trimester?',
				a: 'Many people gain little in the first 13 weeks, and some lose weight early on because of nausea. The calculator assumes a gain of 1.1 to 4.4 lb by week 13.'
			}
		],
		sources: [
			{ title: 'National Academies of Sciences, Engineering, and Medicine', url: 'https://www.nationalacademies.org/' },
			{ title: 'ACOG — Women’s health and pregnancy', url: 'https://www.acog.org/' }
		],
		disclaimer:
			'Based on the 2009 IOM guidelines for healthy pregnancies. This is not medical advice. Ask your midwife, doctor or care team about your own weight gain.'
	}
});
